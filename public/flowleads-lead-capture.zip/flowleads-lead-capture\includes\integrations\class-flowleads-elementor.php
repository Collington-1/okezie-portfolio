<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Elementor Forms is an Elementor PRO feature (not in free Elementor) —
 * gated on the ELEMENTOR_PRO_VERSION constant, same as the settings page.
 * Elementor tags 'email' and 'tel' field types clearly, but its "Name"
 * field is usually just a plain 'text' field, so unlike WPForms/Gravity
 * Forms this needs one heuristic: the first text field whose id/label
 * mentions "name" (falling back to the first text field at all) is treated
 * as the name — best-effort, not a hard requirement to configure.
 */
class FlowLeads_Elementor_Integration {

	public function __construct() {
		if ( ! defined( 'ELEMENTOR_PRO_VERSION' ) ) {
			return;
		}
		add_action( 'elementor_pro/forms/new_record', array( $this, 'handle_submission' ), 10, 2 );
	}

	public function handle_submission( $record, $handler ) {
		$source = FlowLeads_Settings::get_source( 'elementor' );
		if ( ! $source['enabled'] ) {
			return;
		}

		$fields = $record->get( 'fields' );

		$name          = '';
		$name_fallback = '';
		$phone         = '';
		$email         = '';
		$message       = '';

		foreach ( $fields as $field ) {
			$type  = isset( $field['type'] ) ? $field['type'] : '';
			$value = isset( $field['value'] ) ? trim( (string) $field['value'] ) : '';
			if ( '' === $value ) {
				continue;
			}
			$label = strtolower( ( isset( $field['title'] ) ? $field['title'] : '' ) . ' ' . ( isset( $field['id'] ) ? $field['id'] : '' ) );

			if ( 'email' === $type && '' === $email ) {
				$email = $value;
			} elseif ( 'tel' === $type && '' === $phone ) {
				$phone = $value;
			} elseif ( 'textarea' === $type && '' === $message ) {
				$message = $value;
			} elseif ( in_array( $type, array( 'text' ), true ) ) {
				if ( '' === $name && false !== strpos( $label, 'name' ) ) {
					$name = $value;
				} elseif ( '' === $name_fallback ) {
					$name_fallback = $value;
				}
			}
		}

		if ( '' === $name ) {
			$name = $name_fallback;
		}

		if ( empty( $name ) || ( empty( $phone ) && empty( $email ) ) ) {
			return;
		}

		FlowLeads_API::submit_lead(
			array(
				'name'      => sanitize_text_field( $name ),
				'phone'     => sanitize_text_field( $phone ),
				'email'     => sanitize_email( $email ),
				'message'   => sanitize_textarea_field( $message ),
				'tag'       => $source['tag'],
				'groupName' => $source['group'],
			)
		);
	}
}

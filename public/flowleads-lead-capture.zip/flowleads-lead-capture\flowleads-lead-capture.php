<?php
/**
 * Plugin Name:       FlowLeads Lead Capture
 * Plugin URI:        https://flowleadsapp.netlify.app
 * Description:       Sends new leads — from this plugin's own form, WooCommerce orders, Contact Form 7, WPForms, Gravity Forms, or Elementor Forms — straight into your FlowLeads CRM, tagged and grouped automatically. Requires a free FlowLeads account.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Okezie Collington
 * Author URI:        https://okeziecollington.netlify.app
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       flowleads-lead-capture
 * Domain Path:       /languages
 *
 * This plugin does not store or process payment or personal data beyond what
 * you configure it to forward: name, phone, email, and an optional message
 * from a form submission are sent to your own FlowLeads account (a separate
 * service you must sign up for) over HTTPS, authenticated with an API key
 * you generate in your FlowLeads account and paste into this plugin's
 * settings. No data is sent anywhere unless a source is enabled below and an
 * API key is configured.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'FLOWLEADS_VERSION', '1.0.0' );
define( 'FLOWLEADS_PLUGIN_FILE', __FILE__ );
define( 'FLOWLEADS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'FLOWLEADS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
// Single-vendor connector plugin — same pattern as any WordPress plugin that
// talks to one specific paid SaaS (e.g. Mailchimp for WordPress). Not
// user-configurable; this is where the FlowLeads backend actually lives.
define( 'FLOWLEADS_API_BASE', 'https://flowleads-backend-wogp.onrender.com' );

require_once FLOWLEADS_PLUGIN_DIR . 'includes/class-flowleads-settings.php';
require_once FLOWLEADS_PLUGIN_DIR . 'includes/class-flowleads-api.php';
require_once FLOWLEADS_PLUGIN_DIR . 'includes/class-flowleads-form.php';
require_once FLOWLEADS_PLUGIN_DIR . 'includes/integrations/class-flowleads-woocommerce.php';
require_once FLOWLEADS_PLUGIN_DIR . 'includes/integrations/class-flowleads-cf7.php';
require_once FLOWLEADS_PLUGIN_DIR . 'includes/integrations/class-flowleads-wpforms.php';
require_once FLOWLEADS_PLUGIN_DIR . 'includes/integrations/class-flowleads-gravity-forms.php';
require_once FLOWLEADS_PLUGIN_DIR . 'includes/integrations/class-flowleads-elementor.php';

/**
 * Boots every piece — each integration class checks for its own host plugin
 * internally (e.g. class_exists('WooCommerce')) and no-ops if it's not
 * present, so it's always safe to instantiate all of them.
 */
function flowleads_init() {
	// No load_plugin_textdomain() call needed — WordPress.org auto-loads
	// translations for hosted plugins as of 4.6, and the manual call is now
	// flagged as discouraged.
	new FlowLeads_Settings();
	new FlowLeads_Form();
	new FlowLeads_WooCommerce_Integration();
	new FlowLeads_CF7_Integration();
	new FlowLeads_WPForms_Integration();
	new FlowLeads_Gravity_Forms_Integration();
	new FlowLeads_Elementor_Integration();
}
add_action( 'plugins_loaded', 'flowleads_init' );

/**
 * register_uninstall_hook can't reference instance methods reliably, so
 * cleanup lives in uninstall.php (run once, only when the plugin is deleted
 * from the Plugins screen — never on ordinary deactivate).
 */

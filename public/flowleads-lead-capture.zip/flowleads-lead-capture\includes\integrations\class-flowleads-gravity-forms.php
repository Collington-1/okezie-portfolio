<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Like WPForms, Gravity Forms fields carry a semantic $field->type — no
 * manual mapping needed. get_value_export() is the same API Gravity Forms'
 * own official Feed Add-On Framework uses to flatten a field's value for
 * sending to a third-party service (it handles composite fields, like the
 * "Name" field's separate first/last sub-inputs, correctly on its own).
 */
class FlowLeads_Gravity_Forms_Integration {

	public function __construct() {
		if ( ! class_exists( 'GFForms' ) ) {
			return;
		}
		add_action( 'gform_after_submission', array( $this, 'handle_submission' ), 10, 2 );
	}

	public function handle_submission( $entry, $form ) {
		$source = FlowLeads_Settings::get_source( 'gravity' );
		if ( ! $source['enabled'] ) {
			return;
		}

		$name    = '';
		$phone   = '';
		$email   = '';
		$message = '';

		foreach ( $form['fields'] as $field ) {
			if ( ! method_exists( $field, 'get_value_export' ) ) {
				continue;
			}
			$value = trim( (string) $field->get_value_export( $entry ) );
			if ( '' === $value ) {
				continue;
			}
			if ( 'name' === $field->type && '' === $name ) {
				$name = $value;
			} elseif ( 'email' === $field->type && '' === $email ) {
				$email = $value;
			} elseif ( 'phone' === $field->type && '' === $phone ) {
				$phone = $value;
			} elseif ( 'textarea' === $field->type && '' === $message ) {
				$message = $value;
			}
		}

		if ( empty( $name ) || ( empty( $phone ) && empty( $email ) ) ) {
			return;
		}

		FlowLeads_API::submit_lead(
			array(
				'name'      => sanitize_text_field( $name ),
				'phone'     => sanitize_text_field( $phone ),
				'email'     => sanitize_email( $email ),
				'message'   => sanitize_textarea_field( $message ),
				'tag'       => $source['tag'],
				'groupName' => $source['group'],
			)
		);
	}
}

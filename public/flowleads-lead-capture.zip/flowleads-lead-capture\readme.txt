=== FlowLeads Lead Capture ===
Contributors: flowleads
Tags: leads, crm, whatsapp, contact form, woocommerce
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Send leads from your own form, WooCommerce, Contact Form 7, WPForms, Gravity Forms, or Elementor into your FlowLeads CRM, tagged and grouped.

== Description ==

FlowLeads Lead Capture connects your WordPress site to your [FlowLeads](https://flowleadsapp.netlify.app) account — a WhatsApp + email CRM built for following up on leads without risking your WhatsApp number. This plugin requires a free FlowLeads account and an API key from it (Account → API keys) to do anything.

Once configured, it can send a new contact into FlowLeads whenever:

* Someone submits this plugin's own built-in `[flowleads_form]` shortcode form
* A WooCommerce order is placed
* A Contact Form 7 form is submitted
* A WPForms form is submitted
* A Gravity Forms form is submitted
* An Elementor Pro Forms widget is submitted

Each source can be turned on or off independently, and each has its own FlowLeads group and tag — so, for example, WooCommerce customers can land in a "Customers" group while your ad-landing-page form leads land in "Website Leads," without any manual sorting.

**This plugin only forwards data you explicitly enable it to send.** With no sources enabled and no API key configured, it does nothing. All outbound requests happen server-side (via `wp_remote_post`) — your FlowLeads API key never reaches a visitor's browser, and no data is sent anywhere without your configuration.

= Third-party service =

This plugin sends form/order submission data (name, phone, email, and an optional message) to your FlowLeads account at flowleadsapp.netlify.app over HTTPS, authenticated with your API key. FlowLeads is a separate service you must sign up for; see their [terms](https://flowleadsapp.netlify.app) for how that data is handled once it arrives there.

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/flowleads-lead-capture`, or install it directly through the WordPress Plugins screen.
2. Activate the plugin.
3. Go to **Settings → FlowLeads**.
4. Sign up for a free FlowLeads account, go to Account → API keys, generate a key, and paste it into the plugin settings.
5. Turn on whichever sources apply to your site, set a group/tag for each, and save.
6. If you want the plugin's own form, add `[flowleads_form]` to any page or post.

== Frequently Asked Questions ==

= Do I need a FlowLeads account? =

Yes — this plugin is a connector to your own FlowLeads account. Sign-up is free.

= Does this work without WooCommerce / Contact Form 7 / WPForms / Gravity Forms / Elementor Pro installed? =

Yes. Each integration only activates if its matching plugin is detected as active on your site — the settings page shows which sources are actually available on your install. The plugin's own built-in form works with none of them installed.

= Is Contact Form 7 support automatic? =

Almost — Contact Form 7 doesn't label its fields with a type the way WPForms and Gravity Forms do, so you tell the settings page once, per form, which field name holds the name/phone/email (usually visible in your form's own `[text your-name]`-style tags). WPForms, Gravity Forms, WooCommerce, and Elementor Forms don't need this.

= What happens if the same person submits twice? =

FlowLeads matches by phone number and updates the existing contact instead of creating a duplicate.

== Screenshots ==

1. Settings page — API key and per-source group/tag configuration.
2. The built-in `[flowleads_form]` shortcode form.

== Changelog ==

= 1.0.0 =
* Initial release: built-in form, WooCommerce, Contact Form 7, WPForms, Gravity Forms, Elementor Forms.

== Upgrade Notice ==

= 1.0.0 =
Initial release.

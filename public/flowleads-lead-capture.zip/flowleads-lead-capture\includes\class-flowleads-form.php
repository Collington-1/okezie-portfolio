<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The plugin's own [flowleads_form] shortcode — a self-contained
 * Name/Phone/Email/Message form that submits via AJAX to admin-ajax.php
 * (registered with wp_ajax_nopriv_ since form visitors aren't logged into
 * WordPress), which is what actually calls out to FlowLeads server-side.
 */
class FlowLeads_Form {

	public function __construct() {
		add_shortcode( 'flowleads_form', array( $this, 'render_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_ajax_flowleads_submit_lead', array( $this, 'handle_submit' ) );
		add_action( 'wp_ajax_nopriv_flowleads_submit_lead', array( $this, 'handle_submit' ) );
	}

	public function enqueue_assets() {
		wp_register_style( 'flowleads-form', FLOWLEADS_PLUGIN_URL . 'assets/flowleads-form.css', array(), FLOWLEADS_VERSION );
		wp_register_script( 'flowleads-form', FLOWLEADS_PLUGIN_URL . 'assets/flowleads-form.js', array(), FLOWLEADS_VERSION, true );
	}

	/**
	 * @param array $atts button_text (default "Send"), message_field ("yes"/"no", default "yes").
	 */
	public function render_shortcode( $atts ) {
		wp_enqueue_style( 'flowleads-form' );
		wp_enqueue_script( 'flowleads-form' );
		wp_localize_script(
			'flowleads-form',
			'flowleadsForm',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'flowleads_submit_lead' ),
			)
		);

		$atts = shortcode_atts(
			array(
				'button_text'  => __( 'Send', 'flowleads-lead-capture' ),
				'message_field' => 'yes',
			),
			$atts,
			'flowleads_form'
		);

		ob_start();
		?>
		<form class="flowleads-form" method="post">
			<div class="flowleads-form-field">
				<label for="flowleads-name"><?php esc_html_e( 'Name', 'flowleads-lead-capture' ); ?></label>
				<input type="text" id="flowleads-name" name="name" required />
			</div>
			<div class="flowleads-form-field">
				<label for="flowleads-phone"><?php esc_html_e( 'Phone', 'flowleads-lead-capture' ); ?></label>
				<input type="tel" id="flowleads-phone" name="phone" />
			</div>
			<div class="flowleads-form-field">
				<label for="flowleads-email"><?php esc_html_e( 'Email', 'flowleads-lead-capture' ); ?></label>
				<input type="email" id="flowleads-email" name="email" />
			</div>
			<?php if ( 'no' !== $atts['message_field'] ) : ?>
				<div class="flowleads-form-field">
					<label for="flowleads-message"><?php esc_html_e( 'Message', 'flowleads-lead-capture' ); ?></label>
					<textarea id="flowleads-message" name="message" rows="3"></textarea>
				</div>
			<?php endif; ?>
			<!-- Honeypot: hidden from real visitors via CSS, bots that fill every field trip it. -->
			<div class="flowleads-form-hp" aria-hidden="true">
				<input type="text" name="hp" tabindex="-1" autocomplete="off" />
			</div>
			<p class="flowleads-form-status" role="status"></p>
			<button type="submit"><?php echo esc_html( $atts['button_text'] ); ?></button>
		</form>
		<?php
		return ob_get_clean();
	}

	public function handle_submit() {
		check_ajax_referer( 'flowleads_submit_lead', 'nonce' );

		$source = FlowLeads_Settings::get_source( 'builtin' );
		if ( ! $source['enabled'] ) {
			wp_send_json_error( array( 'message' => __( 'This form is currently disabled.', 'flowleads-lead-capture' ) ) );
		}

		$name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
		$hp      = isset( $_POST['hp'] ) ? sanitize_text_field( wp_unslash( $_POST['hp'] ) ) : '';

		if ( '' !== $hp ) {
			// Bot tripped the honeypot — pretend success, don't tip it off.
			wp_send_json_success( array( 'message' => FlowLeads_Settings::get_success_message() ) );
		}

		if ( empty( $name ) || ( empty( $phone ) && empty( $email ) ) ) {
			wp_send_json_error( array( 'message' => __( 'Please enter your name and at least a phone number or email.', 'flowleads-lead-capture' ) ) );
		}

		$result = FlowLeads_API::submit_lead(
			array(
				'name'      => $name,
				'phone'     => $phone,
				'email'     => $email,
				'message'   => $message,
				'tag'       => $source['tag'],
				'groupName' => $source['group'],
			)
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'message' => FlowLeads_Settings::get_success_message() ) );
	}
}

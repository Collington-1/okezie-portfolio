( function () {
	'use strict';

	document.addEventListener( 'submit', function ( e ) {
		var form = e.target;
		if ( ! form.classList || ! form.classList.contains( 'flowleads-form' ) ) {
			return;
		}
		e.preventDefault();

		var button = form.querySelector( 'button[type="submit"]' );
		var status = form.querySelector( '.flowleads-form-status' );
		var originalText = button.textContent;

		button.disabled = true;
		button.textContent = '…';
		status.textContent = '';
		status.className = 'flowleads-form-status';

		var data = new FormData( form );
		data.append( 'action', 'flowleads_submit_lead' );
		data.append( 'nonce', window.flowleadsForm.nonce );

		fetch( window.flowleadsForm.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: data,
		} )
			.then( function ( res ) {
				return res.json();
			} )
			.then( function ( json ) {
				button.disabled = false;
				button.textContent = originalText;
				if ( json && json.success ) {
					status.textContent = json.data && json.data.message ? json.data.message : 'Thanks!';
					status.className = 'flowleads-form-status flowleads-success';
					form.reset();
				} else {
					status.textContent = json && json.data && json.data.message ? json.data.message : 'Something went wrong — please try again.';
					status.className = 'flowleads-form-status flowleads-error';
				}
			} )
			.catch( function () {
				button.disabled = false;
				button.textContent = originalText;
				status.textContent = 'Something went wrong — please try again.';
				status.className = 'flowleads-form-status flowleads-error';
			} );
	} );
} )();

<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The one place every integration calls out to FlowLeads — always
 * server-side (wp_remote_post), never from the visitor's browser, so the
 * API key never leaves this server and there's no cross-origin/CORS
 * concern on the FlowLeads backend at all.
 */
class FlowLeads_API {

	/**
	 * @param array $lead name, phone, email, message, tag, groupName.
	 * @return true|WP_Error
	 */
	public static function submit_lead( $lead ) {
		$api_key = FlowLeads_Settings::get_api_key();
		if ( empty( $api_key ) ) {
			return new WP_Error( 'flowleads_no_api_key', __( 'FlowLeads API key is not configured.', 'flowleads-lead-capture' ) );
		}
		if ( empty( $lead['name'] ) || ( empty( $lead['phone'] ) && empty( $lead['email'] ) ) ) {
			return new WP_Error( 'flowleads_missing_fields', __( 'A name and at least a phone number or email are required.', 'flowleads-lead-capture' ) );
		}

		$response = wp_remote_post(
			trailingslashit( FLOWLEADS_API_BASE ) . 'public/leads',
			array(
				'timeout' => 20,
				'headers' => array(
					'Content-Type' => 'application/json',
					'X-Api-Key'    => $api_key,
				),
				'body'    => wp_json_encode( $lead ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			$body  = json_decode( wp_remote_retrieve_body( $response ), true );
			$error = isset( $body['error'] ) ? $body['error'] : sprintf(
				/* translators: %d: HTTP status code */
				__( 'FlowLeads returned an unexpected error (status %d).', 'flowleads-lead-capture' ),
				$code
			);
			return new WP_Error( 'flowleads_api_error', $error );
		}

		return true;
	}
}

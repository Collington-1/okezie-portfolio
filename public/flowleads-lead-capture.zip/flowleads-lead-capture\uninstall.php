<?php
// Only WordPress itself loads this file, only when the plugin is deleted
// from the Plugins screen (never on a plain deactivate) — this check is the
// standard guard against anyone hitting the file directly.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'flowleads_settings' );

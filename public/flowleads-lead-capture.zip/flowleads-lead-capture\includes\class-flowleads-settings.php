<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Everything lives in one option (flowleads_settings) — the API key, plus
 * per-source enabled/group/tag config — rather than a row per setting. Every
 * other class reads it through the static getters below instead of calling
 * get_option() directly, so the storage shape only needs to change in one
 * place if it ever does.
 */
class FlowLeads_Settings {

	const OPTION_KEY = 'flowleads_settings';

	/**
	 * Sources a FlowLeads user might not have every plugin for — each entry
	 * here becomes a row on the settings page for its own group name (which
	 * group in FlowLeads new leads get filed into) and tag (added to
	 * contacts.tags on creation). group/tag are per-source so, e.g.,
	 * WooCommerce customers can land in a different group than the ones
	 * this plugin's own ad-landing-page form captures.
	 */
	public static function default_sources() {
		return array(
			'builtin'     => array(
				'label' => __( 'This plugin\'s own form ([flowleads_form])', 'flowleads-lead-capture' ),
				'group' => __( 'Website Leads', 'flowleads-lead-capture' ),
				'tag'   => 'facebook-ad',
			),
			'woocommerce' => array(
				'label' => __( 'WooCommerce orders', 'flowleads-lead-capture' ),
				'group' => __( 'Customers', 'flowleads-lead-capture' ),
				'tag'   => 'woocommerce',
			),
			'cf7'         => array(
				'label' => __( 'Contact Form 7', 'flowleads-lead-capture' ),
				'group' => __( 'Website Leads', 'flowleads-lead-capture' ),
				'tag'   => 'contact-form',
			),
			'wpforms'     => array(
				'label' => __( 'WPForms', 'flowleads-lead-capture' ),
				'group' => __( 'Website Leads', 'flowleads-lead-capture' ),
				'tag'   => 'contact-form',
			),
			'gravity'     => array(
				'label' => __( 'Gravity Forms', 'flowleads-lead-capture' ),
				'group' => __( 'Website Leads', 'flowleads-lead-capture' ),
				'tag'   => 'contact-form',
			),
			'elementor'   => array(
				'label' => __( 'Elementor Forms (requires Elementor Pro)', 'flowleads-lead-capture' ),
				'group' => __( 'Website Leads', 'flowleads-lead-capture' ),
				'tag'   => 'contact-form',
			),
		);
	}

	/** Which PHP class/function/constant proves a given source's host plugin is actually active. */
	public static function source_is_available( $source_key ) {
		switch ( $source_key ) {
			case 'builtin':
				return true;
			case 'woocommerce':
				return class_exists( 'WooCommerce' );
			case 'cf7':
				return defined( 'WPCF7_VERSION' );
			case 'wpforms':
				return class_exists( 'WPForms' );
			case 'gravity':
				return class_exists( 'GFForms' );
			case 'elementor':
				return defined( 'ELEMENTOR_PRO_VERSION' );
			default:
				return false;
		}
	}

	public static function get_all() {
		$defaults = array(
			'api_key'         => '',
			'success_message' => __( 'Thanks! We\'ll be in touch shortly.', 'flowleads-lead-capture' ),
			'sources'         => array(),
			'cf7_field_map'   => array(),
		);
		foreach ( self::default_sources() as $key => $source ) {
			$defaults['sources'][ $key ] = array(
				'enabled' => 'builtin' === $key, // only the built-in form is on by default
				'group'   => $source['group'],
				'tag'     => $source['tag'],
			);
		}
		$stored = get_option( self::OPTION_KEY, array() );
		return wp_parse_args( $stored, $defaults );
	}

	public static function get_api_key() {
		$settings = self::get_all();
		return $settings['api_key'];
	}

	public static function get_success_message() {
		$settings = self::get_all();
		return $settings['success_message'];
	}

	/** Returns array('enabled'=>bool,'group'=>string,'tag'=>string) for one source, e.g. 'woocommerce'. */
	public static function get_source( $source_key ) {
		$settings = self::get_all();
		if ( isset( $settings['sources'][ $source_key ] ) ) {
			return $settings['sources'][ $source_key ];
		}
		return array( 'enabled' => false, 'group' => 'Website Leads', 'tag' => 'contact-form' );
	}

	/** Contact Form 7 has no semantic field types — per-form-id overrides for which field is which. */
	public static function get_cf7_field_map( $form_id ) {
		$settings = self::get_all();
		if ( isset( $settings['cf7_field_map'][ $form_id ] ) ) {
			return $settings['cf7_field_map'][ $form_id ];
		}
		return array( 'name' => '', 'phone' => '', 'email' => '', 'message' => '' );
	}

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		add_action( 'admin_init', array( $this, 'handle_save' ) );
	}

	public function add_settings_page() {
		add_options_page(
			__( 'FlowLeads', 'flowleads-lead-capture' ),
			__( 'FlowLeads', 'flowleads-lead-capture' ),
			'manage_options',
			'flowleads-lead-capture',
			array( $this, 'render_page' )
		);
	}

	public function handle_save() {
		if ( ! isset( $_POST['flowleads_settings_nonce'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['flowleads_settings_nonce'] ) ), 'flowleads_save_settings' ) ) {
			return;
		}

		$current = self::get_all();

		$current['api_key']         = isset( $_POST['flowleads_api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['flowleads_api_key'] ) ) : '';
		$current['success_message'] = isset( $_POST['flowleads_success_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['flowleads_success_message'] ) ) : '';

		foreach ( array_keys( self::default_sources() ) as $key ) {
			$current['sources'][ $key ] = array(
				'enabled' => isset( $_POST[ "flowleads_source_{$key}_enabled" ] ),
				'group'   => isset( $_POST[ "flowleads_source_{$key}_group" ] ) ? sanitize_text_field( wp_unslash( $_POST[ "flowleads_source_{$key}_group" ] ) ) : 'Website Leads',
				'tag'     => isset( $_POST[ "flowleads_source_{$key}_tag" ] ) ? sanitize_text_field( wp_unslash( $_POST[ "flowleads_source_{$key}_tag" ] ) ) : 'contact-form',
			);
		}

		// Contact Form 7 field-name mapping — one row of 3 text inputs per CF7
		// form found on the site. map_deep() + sanitize_text_field applies
		// sanitization to every leaf value in the nested array in one pass,
		// right at the point $_POST is read (rather than in the foreach
		// below), which is what the sanitization sniff expects to see.
		if ( defined( 'WPCF7_VERSION' ) && isset( $_POST['flowleads_cf7_map'] ) && is_array( $_POST['flowleads_cf7_map'] ) ) {
			$posted_map = map_deep( wp_unslash( $_POST['flowleads_cf7_map'] ), 'sanitize_text_field' );
			$map        = array();
			foreach ( $posted_map as $form_id => $fields ) {
				$map[ absint( $form_id ) ] = array(
					'name'    => isset( $fields['name'] ) ? $fields['name'] : '',
					'phone'   => isset( $fields['phone'] ) ? $fields['phone'] : '',
					'email'   => isset( $fields['email'] ) ? $fields['email'] : '',
					'message' => isset( $fields['message'] ) ? $fields['message'] : '',
				);
			}
			$current['cf7_field_map'] = $map;
		}

		update_option( self::OPTION_KEY, $current );
		add_action( 'admin_notices', array( $this, 'saved_notice' ) );
	}

	public function saved_notice() {
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'FlowLeads settings saved.', 'flowleads-lead-capture' ) . '</p></div>';
	}

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$settings = self::get_all();
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'FlowLeads Lead Capture', 'flowleads-lead-capture' ); ?></h1>
			<p>
				<?php
				printf(
					/* translators: %s: link to FlowLeads account API keys page */
					esc_html__( 'Paste the API key from your FlowLeads account (%s → API keys) below, then choose which forms on this site should send leads to FlowLeads.', 'flowleads-lead-capture' ),
					'<a href="https://flowleadsapp.netlify.app/account" target="_blank" rel="noopener noreferrer">flowleadsapp.netlify.app/account</a>'
				);
				?>
			</p>

			<form method="post">
				<?php wp_nonce_field( 'flowleads_save_settings', 'flowleads_settings_nonce' ); ?>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="flowleads_api_key"><?php esc_html_e( 'API key', 'flowleads-lead-capture' ); ?></label></th>
						<td>
							<input type="password" id="flowleads_api_key" name="flowleads_api_key"
								value="<?php echo esc_attr( $settings['api_key'] ); ?>" class="regular-text" autocomplete="off" />
							<p class="description"><?php esc_html_e( 'Required. Nothing below will do anything without this.', 'flowleads-lead-capture' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="flowleads_success_message"><?php esc_html_e( 'Success message', 'flowleads-lead-capture' ); ?></label></th>
						<td>
							<textarea id="flowleads_success_message" name="flowleads_success_message" rows="2" class="large-text"><?php echo esc_textarea( $settings['success_message'] ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Shown after a submission through this plugin\'s own built-in form.', 'flowleads-lead-capture' ); ?></p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Sources', 'flowleads-lead-capture' ); ?></h2>
				<p><?php esc_html_e( 'Each enabled source is tagged and grouped separately — a WooCommerce customer doesn\'t have to land in the same FlowLeads group as an ad-form lead.', 'flowleads-lead-capture' ); ?></p>

				<table class="widefat" style="max-width:900px;margin-top:8px;">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Source', 'flowleads-lead-capture' ); ?></th>
							<th><?php esc_html_e( 'Enabled', 'flowleads-lead-capture' ); ?></th>
							<th><?php esc_html_e( 'FlowLeads group', 'flowleads-lead-capture' ); ?></th>
							<th><?php esc_html_e( 'Tag', 'flowleads-lead-capture' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( self::default_sources() as $key => $source ) : ?>
						<?php $s = $settings['sources'][ $key ]; ?>
						<tr>
							<td>
								<?php echo esc_html( $source['label'] ); ?>
								<?php if ( ! self::source_is_available( $key ) ) : ?>
									<br /><span style="color:#b32d2e;"><?php esc_html_e( 'Not detected on this site', 'flowleads-lead-capture' ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<input type="checkbox" name="flowleads_source_<?php echo esc_attr( $key ); ?>_enabled" value="1"
									<?php checked( $s['enabled'] ); ?> <?php disabled( ! self::source_is_available( $key ) ); ?> />
							</td>
							<td><input type="text" name="flowleads_source_<?php echo esc_attr( $key ); ?>_group" value="<?php echo esc_attr( $s['group'] ); ?>" class="regular-text" /></td>
							<td><input type="text" name="flowleads_source_<?php echo esc_attr( $key ); ?>_tag" value="<?php echo esc_attr( $s['tag'] ); ?>" class="regular-text" /></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<?php if ( defined( 'WPCF7_VERSION' ) ) : ?>
					<h2><?php esc_html_e( 'Contact Form 7 field mapping', 'flowleads-lead-capture' ); ?></h2>
					<p><?php esc_html_e( 'Contact Form 7 doesn\'t label its fields, so tell FlowLeads which field name on each of your forms holds the name/phone/email — usually the field name shown in your form\'s [text your-name] / [tel your-phone] tags.', 'flowleads-lead-capture' ); ?></p>
					<?php
					$cf7_forms = get_posts( array( 'post_type' => 'wpcf7_contact_form', 'numberposts' => -1 ) );
					foreach ( $cf7_forms as $form ) :
						$map = self::get_cf7_field_map( $form->ID );
						?>
						<h4><?php echo esc_html( $form->post_title ); ?></h4>
						<table class="form-table" role="presentation">
							<tr>
								<th><?php esc_html_e( 'Name field', 'flowleads-lead-capture' ); ?></th>
								<td><input type="text" name="flowleads_cf7_map[<?php echo esc_attr( $form->ID ); ?>][name]" value="<?php echo esc_attr( $map['name'] ); ?>" placeholder="your-name" /></td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Phone field', 'flowleads-lead-capture' ); ?></th>
								<td><input type="text" name="flowleads_cf7_map[<?php echo esc_attr( $form->ID ); ?>][phone]" value="<?php echo esc_attr( $map['phone'] ); ?>" placeholder="your-phone" /></td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Email field', 'flowleads-lead-capture' ); ?></th>
								<td><input type="text" name="flowleads_cf7_map[<?php echo esc_attr( $form->ID ); ?>][email]" value="<?php echo esc_attr( $map['email'] ); ?>" placeholder="your-email" /></td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Message field (optional)', 'flowleads-lead-capture' ); ?></th>
								<td><input type="text" name="flowleads_cf7_map[<?php echo esc_attr( $form->ID ); ?>][message]" value="<?php echo esc_attr( $map['message'] ); ?>" placeholder="your-message" /></td>
							</tr>
						</table>
					<?php endforeach; ?>
					<?php if ( empty( $cf7_forms ) ) : ?>
						<p><em><?php esc_html_e( 'No Contact Form 7 forms found yet.', 'flowleads-lead-capture' ); ?></em></p>
					<?php endif; ?>
				<?php endif; ?>

				<?php submit_button( __( 'Save settings', 'flowleads-lead-capture' ) ); ?>
			</form>

			<h2><?php esc_html_e( 'Using the built-in form', 'flowleads-lead-capture' ); ?></h2>
			<p>
				<?php esc_html_e( 'Drop this shortcode onto any page or post:', 'flowleads-lead-capture' ); ?>
				<code>[flowleads_form]</code>
			</p>
		</div>
		<?php
	}
}

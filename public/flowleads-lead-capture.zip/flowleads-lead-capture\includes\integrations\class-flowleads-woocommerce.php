<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Every integration class follows the same shape: hook into the host
 * plugin's own action (only if that plugin is actually active), check this
 * source is enabled in FlowLeads settings, extract name/phone/email, and
 * hand off to FlowLeads_API::submit_lead(). None of these modify what the
 * host plugin does — they only listen.
 */
class FlowLeads_WooCommerce_Integration {

	public function __construct() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'handle_order' ), 10, 3 );
	}

	public function handle_order( $order_id, $posted_data, $order ) {
		$source = FlowLeads_Settings::get_source( 'woocommerce' );
		if ( ! $source['enabled'] ) {
			return;
		}
		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}
		if ( ! $order ) {
			return;
		}

		$name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
		if ( '' === $name ) {
			$name = $order->get_formatted_billing_full_name();
		}

		FlowLeads_API::submit_lead(
			array(
				'name'      => $name,
				'phone'     => $order->get_billing_phone(),
				'email'     => $order->get_billing_email(),
				'message'   => sprintf(
					/* translators: %s: WooCommerce order number */
					__( 'WooCommerce order #%s', 'flowleads-lead-capture' ),
					$order->get_order_number()
				),
				'tag'       => $source['tag'],
				'groupName' => $source['group'],
			)
		);
	}
}

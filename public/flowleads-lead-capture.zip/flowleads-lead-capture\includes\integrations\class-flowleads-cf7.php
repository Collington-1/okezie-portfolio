<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contact Form 7 doesn't tag its fields with a semantic type (a field named
 * "your-name" is just a string the site owner chose) — so unlike WPForms
 * and Gravity Forms below, this needs the per-form field mapping configured
 * on the settings page (FlowLeads_Settings::get_cf7_field_map).
 */
class FlowLeads_CF7_Integration {

	public function __construct() {
		if ( ! defined( 'WPCF7_VERSION' ) ) {
			return;
		}
		add_action( 'wpcf7_mail_sent', array( $this, 'handle_submission' ) );
	}

	public function handle_submission( $contact_form ) {
		$source = FlowLeads_Settings::get_source( 'cf7' );
		if ( ! $source['enabled'] ) {
			return;
		}

		$submission = WPCF7_Submission::get_instance();
		if ( ! $submission ) {
			return;
		}
		$posted = $submission->get_posted_data();
		$map    = FlowLeads_Settings::get_cf7_field_map( $contact_form->id() );

		$get = function ( $field_name ) use ( $posted ) {
			if ( empty( $field_name ) || ! isset( $posted[ $field_name ] ) ) {
				return '';
			}
			$value = $posted[ $field_name ];
			return is_array( $value ) ? implode( ', ', $value ) : (string) $value;
		};

		$name  = $get( $map['name'] );
		$phone = $get( $map['phone'] );
		$email = $get( $map['email'] );

		if ( empty( $name ) || ( empty( $phone ) && empty( $email ) ) ) {
			// Field mapping isn't configured (or is wrong) for this form —
			// nothing sensible to send. Silent no-op, same as any other
			// source that isn't fully set up.
			return;
		}

		FlowLeads_API::submit_lead(
			array(
				'name'      => $name,
				'phone'     => $phone,
				'email'     => $email,
				'message'   => $get( $map['message'] ),
				'tag'       => $source['tag'],
				'groupName' => $source['group'],
			)
		);
	}
}

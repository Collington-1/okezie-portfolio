<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Unlike Contact Form 7, WPForms tags each submitted field with a semantic
 * 'type' (name/email/phone/textarea/...) regardless of what the site owner
 * named it — so this can auto-detect the right fields with zero
 * configuration, instead of needing a mapping screen like CF7 does.
 */
class FlowLeads_WPForms_Integration {

	public function __construct() {
		if ( ! class_exists( 'WPForms' ) ) {
			return;
		}
		add_action( 'wpforms_process_complete', array( $this, 'handle_submission' ), 10, 4 );
	}

	public function handle_submission( $fields, $entry, $form_data, $entry_id ) {
		$source = FlowLeads_Settings::get_source( 'wpforms' );
		if ( ! $source['enabled'] ) {
			return;
		}

		$name = '';
		$phone = '';
		$email = '';
		$message = '';

		foreach ( $fields as $field ) {
			$type  = isset( $field['type'] ) ? $field['type'] : '';
			$value = isset( $field['value'] ) ? $field['value'] : '';
			if ( '' === $value ) {
				continue;
			}
			if ( 'name' === $type && '' === $name ) {
				$name = $value;
			} elseif ( 'email' === $type && '' === $email ) {
				$email = $value;
			} elseif ( 'phone' === $type && '' === $phone ) {
				$phone = $value;
			} elseif ( in_array( $type, array( 'textarea', 'text' ), true ) && '' === $message && 'name' !== $type ) {
				$message = $value; // first free-text field that isn't the name — best-effort "message"
			}
		}

		if ( empty( $name ) || ( empty( $phone ) && empty( $email ) ) ) {
			return;
		}

		FlowLeads_API::submit_lead(
			array(
				'name'      => sanitize_text_field( $name ),
				'phone'     => sanitize_text_field( $phone ),
				'email'     => sanitize_email( $email ),
				'message'   => sanitize_textarea_field( $message ),
				'tag'       => $source['tag'],
				'groupName' => $source['group'],
			)
		);
	}
}

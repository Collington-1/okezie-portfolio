<?php
/**
 * Public manage-booking view (view / cancel / reschedule) — rendered via
 * BookFlow\Frontend\Manage_Booking's `template_include` filter, so it still gets the active
 * theme's get_header()/get_footer() for consistent site chrome, even though no real WP page
 * exists at this URL. Overridable by a theme — see BookFlow\Frontend\Templates::locate().
 *
 * @package BookFlow\Frontend
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BookFlow\Frontend\Manage_Booking;
use BookFlow\Frontend\Templates;
use BookFlow\Frontend\Widget_Config;
use BookFlow\Locations\Location_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;

$bookflow_token       = sanitize_text_field( wp_unslash( (string) get_query_var( 'bookflow_manage', '' ) ) );
$bookflow_appointment = Manage_Booking::find_by_token( $bookflow_token );

get_header();
?>
<div class="bookflow-manage-wrap">
	<?php if ( null === $bookflow_appointment ) : ?>

		<h1><?php esc_html_e( 'Booking not found', 'bookflow-booking-scheduling' ); ?></h1>
		<p><?php esc_html_e( 'This booking link is invalid or has expired.', 'bookflow-booking-scheduling' ); ?></p>

	<?php else : ?>

		<?php
		$bookflow_service  = Service_Repository::find( $bookflow_appointment->service_id );
		$bookflow_staff    = $bookflow_appointment->staff_id ? Staff_Repository::find( $bookflow_appointment->staff_id ) : null;
		$bookflow_location = $bookflow_appointment->location_id ? Location_Repository::find( $bookflow_appointment->location_id ) : null;

		try {
			$bookflow_display_tz = new DateTimeZone( $bookflow_appointment->timezone );
		} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- fall back to site timezone below.
			$bookflow_display_tz = wp_timezone();
		}

		$bookflow_local_start = $bookflow_appointment->start->setTimezone( $bookflow_display_tz );
		?>

		<h1><?php esc_html_e( 'Your Booking', 'bookflow-booking-scheduling' ); ?></h1>

		<table class="bookflow-manage-table">
			<tr>
				<th><?php esc_html_e( 'Reference', 'bookflow-booking-scheduling' ); ?></th>
				<td><?php echo esc_html( $bookflow_appointment->booking_reference ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Service', 'bookflow-booking-scheduling' ); ?></th>
				<td><?php echo esc_html( $bookflow_service ? $bookflow_service->name : '' ); ?></td>
			</tr>
			<?php if ( $bookflow_staff ) : ?>
				<tr>
					<th><?php esc_html_e( 'With', 'bookflow-booking-scheduling' ); ?></th>
					<td><?php echo esc_html( $bookflow_staff->display_name ); ?></td>
				</tr>
			<?php endif; ?>
			<?php if ( $bookflow_location ) : ?>
				<tr>
					<th><?php esc_html_e( 'Location', 'bookflow-booking-scheduling' ); ?></th>
					<td><?php echo esc_html( $bookflow_location->name ); ?></td>
				</tr>
			<?php endif; ?>
			<tr>
				<th><?php esc_html_e( 'Date & time', 'bookflow-booking-scheduling' ); ?></th>
				<td><?php echo esc_html( $bookflow_local_start->format( 'l, F j, Y \a\t g:i A' ) . ' (' . $bookflow_display_tz->getName() . ')' ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></th>
				<td>
					<span class="bookflow-status bookflow-status--<?php echo esc_attr( $bookflow_appointment->status ); ?>">
						<?php echo esc_html( ucfirst( str_replace( '_', '-', $bookflow_appointment->status ) ) ); ?>
					</span>
				</td>
			</tr>
		</table>

		<?php if ( $bookflow_appointment->is_active() ) : ?>

			<?php if ( $bookflow_service ) : ?>
				<h2><?php esc_html_e( 'Need to reschedule?', 'bookflow-booking-scheduling' ); ?></h2>
				<?php
				$bookflow_config = Widget_Config::build(
					array(
						'layout'             => 'classic',
						'locked_service_id'  => $bookflow_service->id,
						'locked_staff_id'    => $bookflow_appointment->staff_id,
						'locked_location_id' => $bookflow_appointment->location_id,
						'reschedule'         => array(
							'token'                => $bookflow_token,
							'appointmentReference' => $bookflow_appointment->booking_reference,
						),
					)
				);

				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Templates::render() output is built entirely from esc_*()-wrapped markup in templates/booking-form.php; nothing here bypasses escaping.
				echo Templates::render( 'booking-form', array( 'layout' => 'classic', 'config' => $bookflow_config ) );
				?>
			<?php endif; ?>

			<h2><?php esc_html_e( 'Cancel this booking', 'bookflow-booking-scheduling' ); ?></h2>
			<form
				method="post"
				action="<?php echo esc_url( Manage_Booking::url( $bookflow_token ) ); ?>"
				onsubmit="return confirm('<?php echo esc_js( __( 'Are you sure you want to cancel this booking?', 'bookflow-booking-scheduling' ) ); ?>');"
			>
				<?php wp_nonce_field( 'bookflow_cancel_booking_' . $bookflow_token ); ?>
				<input type="hidden" name="bookflow_action" value="cancel_booking" />
				<input type="hidden" name="token" value="<?php echo esc_attr( $bookflow_token ); ?>" />
				<button type="submit" class="bookflow-button bookflow-button--danger"><?php esc_html_e( 'Cancel Booking', 'bookflow-booking-scheduling' ); ?></button>
			</form>

		<?php endif; ?>

	<?php endif; ?>
</div>
<?php
get_footer();

<?php
/**
 * Shared event details + registration form block — rendered both by the [bookflow_event]
 * shortcode and templates/event-page.php, via BookFlow\Events\Event_View::render(). Overridable
 * by a theme — see BookFlow\Frontend\Templates::locate().
 *
 * @package BookFlow\Events
 * @var \BookFlow\Events\Event               $event
 * @var \BookFlow\Locations\Location|null     $location
 * @var array<int, \BookFlow\CustomFields\Custom_Field> $fields
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BookFlow\Events\Bootstrap as Events_Bootstrap;
use BookFlow\Events\Event_Attendee_Repository;
use BookFlow\Events\Registration_Handler;

$bookflow_display_tz = wp_timezone();

try {
	$bookflow_display_tz = new DateTimeZone( $event->timezone );
} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- fall back to site timezone above.
	unset( $e );
}

$bookflow_local_start = $event->start->setTimezone( $bookflow_display_tz );
$bookflow_local_end   = $event->end->setTimezone( $bookflow_display_tz );

$bookflow_remaining = null;

if ( null !== $event->capacity ) {
	$bookflow_remaining = max( 0, $event->capacity - Event_Attendee_Repository::confirmed_seat_count( $event->id ) );
}

$bookflow_registered_reference = isset( $_GET['bookflow_registered'] ) ? sanitize_text_field( wp_unslash( $_GET['bookflow_registered'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display flag, not a state change.
$bookflow_error_token           = isset( $_GET['bookflow_reg_error'] ) ? sanitize_text_field( wp_unslash( $_GET['bookflow_reg_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$bookflow_error_message         = '' !== $bookflow_error_token ? Registration_Handler::consume_error( $bookflow_error_token ) : '';

$bookflow_confirmed_attendee = '' !== $bookflow_registered_reference
	? Event_Attendee_Repository::find_by_reference( $bookflow_registered_reference )
	: null;
?>
<div class="bookflow-event-wrap">
	<header class="bookflow-event-header">
		<h2><?php echo esc_html( $event->title ); ?></h2>
		<p class="bookflow-event-meta">
			<?php
			echo esc_html(
				$bookflow_local_start->format( 'l, F j, Y' ) . ' · ' .
				$bookflow_local_start->format( 'g:i A' ) . '–' . $bookflow_local_end->format( 'g:i A' ) .
				' (' . $bookflow_display_tz->getName() . ')'
			);
			?>
		</p>
		<?php if ( $location ) : ?>
			<p class="bookflow-event-meta"><?php echo esc_html( $location->name ); ?></p>
		<?php endif; ?>
		<?php if ( $event->price ) : ?>
			<p class="bookflow-event-meta"><?php echo esc_html( number_format_i18n( $event->price, 2 ) . ( $event->currency ? ' ' . $event->currency : '' ) . ' ' . __( 'per seat', 'bookflow-booking-scheduling' ) ); ?></p>
		<?php endif; ?>
		<?php if ( $event->description ) : ?>
			<div class="bookflow-event-description"><?php echo wp_kses_post( $event->description ); ?></div>
		<?php endif; ?>
	</header>

	<?php if ( $bookflow_confirmed_attendee ) : ?>

		<div class="bookflow-step--success" role="status">
			<h3><?php esc_html_e( "You're registered!", 'bookflow-booking-scheduling' ); ?></h3>
			<p class="bookflow-reference"><?php esc_html_e( 'Registration reference', 'bookflow-booking-scheduling' ); ?>: <strong><?php echo esc_html( $bookflow_confirmed_attendee->booking_reference ); ?></strong></p>
			<?php if ( $bookflow_confirmed_attendee->cancel_token ) : ?>
				<p><a href="<?php echo esc_url( Events_Bootstrap::manage_url( $bookflow_confirmed_attendee->cancel_token ) ); ?>"><?php esc_html_e( 'Manage your registration', 'bookflow-booking-scheduling' ); ?></a></p>
			<?php endif; ?>
		</div>

	<?php elseif ( 'cancelled' === $event->status ) : ?>

		<p class="bookflow-empty"><?php esc_html_e( 'This event has been cancelled.', 'bookflow-booking-scheduling' ); ?></p>

	<?php elseif ( 'completed' === $event->status || $event->start <= new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) ) ) : ?>

		<p class="bookflow-empty"><?php esc_html_e( 'This event has already taken place.', 'bookflow-booking-scheduling' ); ?></p>

	<?php elseif ( ! $event->is_registerable() ) : ?>

		<p class="bookflow-empty"><?php esc_html_e( 'Registration is not currently open for this event.', 'bookflow-booking-scheduling' ); ?></p>

	<?php elseif ( 0 === $bookflow_remaining ) : ?>

		<p class="bookflow-empty"><?php esc_html_e( 'This event is fully booked.', 'bookflow-booking-scheduling' ); ?></p>

	<?php else : ?>

		<?php if ( null !== $bookflow_remaining ) : ?>
			<p class="bookflow-event-seats">
				<?php
				printf(
					/* translators: %d: number of seats remaining. */
					esc_html( _n( '%d seat remaining', '%d seats remaining', $bookflow_remaining, 'bookflow-booking-scheduling' ) ),
					(int) $bookflow_remaining
				);
				?>
			</p>
		<?php endif; ?>

		<?php if ( '' !== $bookflow_error_message ) : ?>
			<p class="bookflow-error-banner" role="alert"><?php echo esc_html( $bookflow_error_message ); ?></p>
		<?php endif; ?>

		<?php // No `action` attribute: an HTML form with none submits to the current URL by
		// default, which is exactly right here — this same block renders both on the
		// dedicated /events/{slug} page and wherever a theme page embeds [bookflow_event],
		// and Registration_Handler::return_url() sends the visitor back to wherever they
		// actually were (wp_get_referer()) regardless of which context this was. ?>
		<form method="post" class="bookflow-form">
			<?php wp_nonce_field( 'bookflow_register_event_' . $event->id ); ?>
			<input type="hidden" name="bookflow_action" value="register_for_event" />
			<input type="hidden" name="event_id" value="<?php echo esc_attr( (string) $event->id ); ?>" />

			<div class="bookflow-field">
				<label for="bf-event-first-name"><?php esc_html_e( 'First name', 'bookflow-booking-scheduling' ); ?></label>
				<input type="text" id="bf-event-first-name" name="first_name" />
			</div>
			<div class="bookflow-field">
				<label for="bf-event-last-name"><?php esc_html_e( 'Last name', 'bookflow-booking-scheduling' ); ?></label>
				<input type="text" id="bf-event-last-name" name="last_name" />
			</div>
			<div class="bookflow-field">
				<label for="bf-event-email"><?php esc_html_e( 'Email', 'bookflow-booking-scheduling' ); ?></label>
				<input type="email" id="bf-event-email" name="email" required />
			</div>
			<div class="bookflow-field">
				<label for="bf-event-phone"><?php esc_html_e( 'Phone (optional)', 'bookflow-booking-scheduling' ); ?></label>
				<input type="tel" id="bf-event-phone" name="phone" />
			</div>

			<?php if ( null === $bookflow_remaining || $bookflow_remaining > 1 ) : ?>
				<div class="bookflow-field">
					<label for="bf-event-quantity"><?php esc_html_e( 'Number of seats', 'bookflow-booking-scheduling' ); ?></label>
					<input type="number" id="bf-event-quantity" name="quantity" min="1" <?php echo null !== $bookflow_remaining ? 'max="' . esc_attr( (string) $bookflow_remaining ) . '"' : ''; ?> value="1" />
				</div>
			<?php endif; ?>

			<?php foreach ( $fields as $bookflow_field ) : ?>
				<div class="bookflow-field">
					<?php
					$bookflow_input_id = 'bf-event-cf-' . esc_attr( $bookflow_field->field_key );
					$bookflow_name     = 'custom_fields[' . esc_attr( $bookflow_field->field_key ) . ']';
					?>
					<label for="<?php echo esc_attr( $bookflow_input_id ); ?>">
						<?php echo esc_html( $bookflow_field->label ); ?>
						<?php if ( ! $bookflow_field->is_required ) : ?>
							<span class="description">(<?php esc_html_e( 'optional', 'bookflow-booking-scheduling' ); ?>)</span>
						<?php endif; ?>
					</label>
					<?php if ( 'textarea' === $bookflow_field->field_type ) : ?>
						<textarea id="<?php echo esc_attr( $bookflow_input_id ); ?>" name="<?php echo esc_attr( $bookflow_name ); ?>" <?php echo $bookflow_field->is_required ? 'required' : ''; ?>></textarea>
					<?php elseif ( 'select' === $bookflow_field->field_type ) : ?>
						<select id="<?php echo esc_attr( $bookflow_input_id ); ?>" name="<?php echo esc_attr( $bookflow_name ); ?>" <?php echo $bookflow_field->is_required ? 'required' : ''; ?>>
							<option value="">—</option>
							<?php foreach ( $bookflow_field->options as $bookflow_option ) : ?>
								<option value="<?php echo esc_attr( $bookflow_option ); ?>"><?php echo esc_html( $bookflow_option ); ?></option>
							<?php endforeach; ?>
						</select>
					<?php elseif ( 'radio' === $bookflow_field->field_type ) : ?>
						<div class="bookflow-radio-group">
							<?php foreach ( $bookflow_field->options as $bookflow_index => $bookflow_option ) : ?>
								<label class="bookflow-radio-option">
									<input type="radio" name="<?php echo esc_attr( $bookflow_name ); ?>" value="<?php echo esc_attr( $bookflow_option ); ?>" <?php echo ( 0 === $bookflow_index && $bookflow_field->is_required ) ? 'required' : ''; ?> />
									<?php echo esc_html( $bookflow_option ); ?>
								</label>
							<?php endforeach; ?>
						</div>
					<?php elseif ( 'checkbox' === $bookflow_field->field_type ) : ?>
						<input type="checkbox" id="<?php echo esc_attr( $bookflow_input_id ); ?>" name="<?php echo esc_attr( $bookflow_name ); ?>" value="1" />
					<?php else : ?>
						<?php
						$bookflow_input_type = in_array( $bookflow_field->field_type, array( 'email', 'number' ), true )
							? $bookflow_field->field_type
							: ( 'phone' === $bookflow_field->field_type ? 'tel' : 'text' );
						?>
						<input type="<?php echo esc_attr( $bookflow_input_type ); ?>" id="<?php echo esc_attr( $bookflow_input_id ); ?>" name="<?php echo esc_attr( $bookflow_name ); ?>" <?php echo $bookflow_field->is_required ? 'required' : ''; ?> />
					<?php endif; ?>
				</div>
			<?php endforeach; ?>

			<button type="submit" class="bookflow-button bookflow-button--primary"><?php esc_html_e( 'Register', 'bookflow-booking-scheduling' ); ?></button>
		</form>

	<?php endif; ?>
</div>

<?php
/**
 * Public scheduling page — rendered via BookFlow\Scheduling\Bootstrap's
 * `template_include` filter at /schedule/{slug} (or whatever bookflow_schedule_url_prefix is
 * set to), still through the active theme's get_header()/get_footer(). Overridable by a theme —
 * see BookFlow\Frontend\Templates::locate().
 *
 * @package BookFlow\Scheduling
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BookFlow\Scheduling\Bootstrap as Scheduling_Bootstrap;
use BookFlow\Scheduling\Scheduling_Page_Repository;
use BookFlow\Scheduling\Scheduling_Page_View;

$bookflow_slug = Scheduling_Bootstrap::requested_slug();
$bookflow_page = '' !== $bookflow_slug ? Scheduling_Page_Repository::find_by_slug( $bookflow_slug ) : null;

if ( null === $bookflow_page || 'active' !== $bookflow_page->status ) {
	status_header( 404 );
	nocache_headers();
}

get_header();

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Scheduling_Page_View::render() output is built entirely from esc_*()-wrapped markup (its own header block plus templates/booking-form.php via Templates::render()).
echo Scheduling_Page_View::render( $bookflow_page );

get_footer();

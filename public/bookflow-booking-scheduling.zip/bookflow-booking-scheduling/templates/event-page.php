<?php
/**
 * Public event page — rendered via BookFlow\Events\Bootstrap's `template_include` filter at
 * /events/{slug} (or whatever bookflow_event_url_prefix is set to), still through the active
 * theme's get_header()/get_footer(). Overridable by a theme — see
 * BookFlow\Frontend\Templates::locate().
 *
 * @package BookFlow\Events
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BookFlow\Events\Bootstrap as Events_Bootstrap;
use BookFlow\Events\Event_Repository;
use BookFlow\Events\Event_View;

$bookflow_slug  = Events_Bootstrap::requested_slug();
$bookflow_event = '' !== $bookflow_slug ? Event_Repository::find_by_slug( $bookflow_slug ) : null;

if ( null === $bookflow_event ) {
	status_header( 404 );
	nocache_headers();

	get_header();
	?>
	<div class="bookflow-event-wrap">
		<h1><?php esc_html_e( 'Event not found', 'bookflow-booking-scheduling' ); ?></h1>
		<p><?php esc_html_e( 'This event does not exist or is no longer available.', 'bookflow-booking-scheduling' ); ?></p>
	</div>
	<?php
	get_footer();
	return;
}

get_header();

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Event_View::render() output is built entirely from esc_*()-wrapped markup in templates/event-registration.php.
echo Event_View::render( $bookflow_event );

get_footer();

<?php
/**
 * Public manage-registration view (view / cancel) for an event registration — rendered via
 * BookFlow\Events\Bootstrap's `template_include` filter, still through the active theme's
 * get_header()/get_footer(). Mirrors templates/manage-booking.php's design for appointments.
 * Overridable by a theme — see BookFlow\Frontend\Templates::locate().
 *
 * @package BookFlow\Events
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use BookFlow\Events\Bootstrap as Events_Bootstrap;
use BookFlow\Events\Event_Attendee_Repository;
use BookFlow\Events\Event_Repository;
use BookFlow\Locations\Location_Repository;

$bookflow_token    = Events_Bootstrap::requested_manage_token();
$bookflow_attendee = '' !== $bookflow_token ? Event_Attendee_Repository::find_by_cancel_token( $bookflow_token ) : null;

get_header();
?>
<div class="bookflow-manage-wrap">
	<?php if ( null === $bookflow_attendee ) : ?>

		<h1><?php esc_html_e( 'Registration not found', 'bookflow-booking-scheduling' ); ?></h1>
		<p><?php esc_html_e( 'This registration link is invalid or has expired.', 'bookflow-booking-scheduling' ); ?></p>

	<?php else : ?>

		<?php
		$bookflow_event    = Event_Repository::find( $bookflow_attendee->event_id );
		$bookflow_location = $bookflow_event && $bookflow_event->location_id ? Location_Repository::find( $bookflow_event->location_id ) : null;

		if ( $bookflow_event ) {
			try {
				$bookflow_display_tz = new DateTimeZone( $bookflow_event->timezone );
			} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- fall back to site timezone below.
				$bookflow_display_tz = wp_timezone();
			}
			$bookflow_local_start = $bookflow_event->start->setTimezone( $bookflow_display_tz );
		}
		?>

		<h1><?php esc_html_e( 'Your Registration', 'bookflow-booking-scheduling' ); ?></h1>

		<table class="bookflow-manage-table">
			<tr>
				<th><?php esc_html_e( 'Reference', 'bookflow-booking-scheduling' ); ?></th>
				<td><?php echo esc_html( $bookflow_attendee->booking_reference ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Event', 'bookflow-booking-scheduling' ); ?></th>
				<td><?php echo esc_html( $bookflow_event ? $bookflow_event->title : '' ); ?></td>
			</tr>
			<?php if ( $bookflow_event ) : ?>
				<tr>
					<th><?php esc_html_e( 'Date & time', 'bookflow-booking-scheduling' ); ?></th>
					<td><?php echo esc_html( $bookflow_local_start->format( 'l, F j, Y \a\t g:i A' ) . ' (' . $bookflow_display_tz->getName() . ')' ); ?></td>
				</tr>
			<?php endif; ?>
			<?php if ( $bookflow_location ) : ?>
				<tr>
					<th><?php esc_html_e( 'Location', 'bookflow-booking-scheduling' ); ?></th>
					<td><?php echo esc_html( $bookflow_location->name ); ?></td>
				</tr>
			<?php endif; ?>
			<tr>
				<th><?php esc_html_e( 'Seats', 'bookflow-booking-scheduling' ); ?></th>
				<td><?php echo esc_html( (string) $bookflow_attendee->quantity ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></th>
				<td>
					<span class="bookflow-status bookflow-status--<?php echo esc_attr( $bookflow_attendee->status ); ?>">
						<?php echo esc_html( ucfirst( $bookflow_attendee->status ) ); ?>
					</span>
				</td>
			</tr>
		</table>

		<?php if ( $bookflow_attendee->is_active() ) : ?>
			<h2><?php esc_html_e( 'Cancel this registration', 'bookflow-booking-scheduling' ); ?></h2>
			<form
				method="post"
				onsubmit="return confirm('<?php echo esc_js( __( 'Are you sure you want to cancel this registration?', 'bookflow-booking-scheduling' ) ); ?>');"
			>
				<?php wp_nonce_field( 'bookflow_cancel_registration_' . $bookflow_token ); ?>
				<input type="hidden" name="bookflow_action" value="cancel_registration" />
				<input type="hidden" name="token" value="<?php echo esc_attr( $bookflow_token ); ?>" />
				<button type="submit" class="bookflow-button bookflow-button--danger"><?php esc_html_e( 'Cancel Registration', 'bookflow-booking-scheduling' ); ?></button>
			</form>
		<?php endif; ?>

	<?php endif; ?>
</div>
<?php
get_footer();

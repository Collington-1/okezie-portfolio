<?php
/**
 * Booking widget container. The actual multi-step UI is rendered client-side by
 * assets/js/booking-form.js from the `data-config` payload — see that file for the state
 * machine. This template's job is just: emit a unique container, the config payload, and a
 * graceful no-JS notice (a booking widget fundamentally needs JS to fetch live availability,
 * same as virtually every scheduling tool; the noscript message says so plainly rather than
 * rendering a broken, non-functional form).
 *
 * Overridable by a theme — see BookFlow\Frontend\Templates::locate().
 *
 * @package BookFlow\Frontend
 * @var string              $layout Layout key: classic | calendar_first | express.
 * @var array<string,mixed> $config Widget configuration payload (see Widget_Config::build()).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bookflow_instance_id = 'bookflow-' . wp_unique_id();
?>
<div
	id="<?php echo esc_attr( $bookflow_instance_id ); ?>"
	class="bookflow-booking bookflow-booking--<?php echo esc_attr( $layout ); ?>"
	data-bookflow-widget="booking"
	data-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>"
>
	<noscript>
		<p class="bookflow-noscript"><?php esc_html_e( 'Please enable JavaScript in your browser to book online.', 'bookflow-booking-scheduling' ); ?></p>
	</noscript>
	<div class="bookflow-loading" aria-live="polite"><?php esc_html_e( 'Loading…', 'bookflow-booking-scheduling' ); ?></div>
</div>

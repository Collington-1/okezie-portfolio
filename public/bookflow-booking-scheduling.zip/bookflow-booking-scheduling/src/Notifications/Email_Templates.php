<?php
/**
 * Builds the subject + HTML body for every Free-scope notification type (Section 17: booking/
 * customer name, staff name, service name, date, time, location, meeting link, cancellation
 * link, reschedule link, booking reference, business information — every one of those tokens is
 * used somewhere below).
 *
 * Free scope is fixed, professional, translatable templates — not an admin-editable template
 * system (Section 3 lists "Advanced email templates" as a Premium feature, implying Free's are
 * not user-editable). The `bookflow_notification_body` filter in Mailer::send() is the
 * documented seam Premium/advanced-templates functionality extends instead — see
 * docs/ARCHITECTURE.md §11.
 *
 * @package BookFlow\Notifications
 */

declare( strict_types = 1 );

namespace BookFlow\Notifications;

use BookFlow\Booking\Appointment;
use BookFlow\Customers\Customer;
use BookFlow\Customers\Customer_Repository;
use BookFlow\Events\Bootstrap as Events_Bootstrap;
use BookFlow\Events\Event;
use BookFlow\Events\Event_Attendee;
use BookFlow\Frontend\Manage_Booking;
use BookFlow\Locations\Location_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Email_Templates
 */
final class Email_Templates {

	/**
	 * Booking confirmation (immediately confirmed) or "received, pending approval" — same
	 * template family, different copy, controlled by whether the appointment's status is
	 * 'pending' at the moment this is built.
	 *
	 * @return array{subject: string, body: string}
	 */
	public static function booking_created( Appointment $appointment ): array {
		$is_pending = 'pending' === $appointment->status;
		$service    = Service_Repository::find( $appointment->service_id );
		$customer   = Customer_Repository::find( $appointment->customer_id );

		$subject = $is_pending
			? sprintf(
				/* translators: %s: service name. */
				__( 'We received your booking request for %s', 'bookflow-booking-scheduling' ),
				$service ? $service->name : ''
			)
			: sprintf(
				/* translators: %s: service name. */
				__( 'Your booking for %s is confirmed', 'bookflow-booking-scheduling' ),
				$service ? $service->name : ''
			);

		$intro = $is_pending
			? __( 'Thanks for your booking request. We’ll confirm it shortly — here are the details:', 'bookflow-booking-scheduling' )
			: __( 'Your booking is confirmed. Here are the details:', 'bookflow-booking-scheduling' );

		$body = self::wrap(
			$subject,
			self::greeting( $customer ) .
			self::paragraph( $intro ) .
			self::details_table( $appointment ) .
			self::manage_links( $appointment )
		);

		return array(
			'subject' => $subject,
			'body'    => $body,
		);
	}

	/**
	 * Booking cancellation.
	 *
	 * @return array{subject: string, body: string}
	 */
	public static function booking_cancellation( Appointment $appointment ): array {
		$service  = Service_Repository::find( $appointment->service_id );
		$customer = Customer_Repository::find( $appointment->customer_id );

		$subject = sprintf(
			/* translators: %s: service name. */
			__( 'Your booking for %s has been cancelled', 'bookflow-booking-scheduling' ),
			$service ? $service->name : ''
		);

		$body = self::wrap(
			$subject,
			self::greeting( $customer ) .
			self::paragraph( __( 'The following booking has been cancelled:', 'bookflow-booking-scheduling' ) ) .
			self::details_table( $appointment )
		);

		return array(
			'subject' => $subject,
			'body'    => $body,
		);
	}

	/**
	 * Booking rescheduled.
	 *
	 * @return array{subject: string, body: string}
	 */
	public static function booking_reschedule( Appointment $appointment, \DateTimeImmutable $old_start, \DateTimeImmutable $old_end ): array {
		$service  = Service_Repository::find( $appointment->service_id );
		$customer = Customer_Repository::find( $appointment->customer_id );

		$subject = sprintf(
			/* translators: %s: service name. */
			__( 'Your booking for %s has been rescheduled', 'bookflow-booking-scheduling' ),
			$service ? $service->name : ''
		);

		try {
			$timezone = new \DateTimeZone( $appointment->timezone );
		} catch ( \Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
			$timezone = wp_timezone();
		}

		$old_when = sprintf(
			'%s – %s',
			self::format_datetime( $old_start, $timezone ),
			$old_end->setTimezone( $timezone )->format( 'g:i A' )
		);

		$body = self::wrap(
			$subject,
			self::greeting( $customer ) .
			self::paragraph( __( 'Your booking has been moved to a new time.', 'bookflow-booking-scheduling' ) ) .
			self::row( __( 'Previous time', 'bookflow-booking-scheduling' ), $old_when . ' (' . $timezone->getName() . ')', true ) .
			self::details_table( $appointment ) .
			self::manage_links( $appointment )
		);

		return array(
			'subject' => $subject,
			'body'    => $body,
		);
	}

	/**
	 * Administrator notification for a new appointment.
	 *
	 * @return array{subject: string, body: string}
	 */
	public static function admin_new_booking( Appointment $appointment ): array {
		$service  = Service_Repository::find( $appointment->service_id );
		$customer = Customer_Repository::find( $appointment->customer_id );

		$subject = sprintf(
			/* translators: 1: service name, 2: customer name. */
			__( 'New booking: %1$s with %2$s', 'bookflow-booking-scheduling' ),
			$service ? $service->name : '',
			$customer ? $customer->display_name() : ''
		);

		$admin_url = admin_url( 'admin.php?page=bookflow-bookings&action=view&id=' . $appointment->id );

		$body = self::wrap(
			$subject,
			self::paragraph( __( 'A new booking was made on your site:', 'bookflow-booking-scheduling' ) ) .
			self::details_table( $appointment ) .
			self::paragraph( self::link( $admin_url, __( 'View in BookFlow', 'bookflow-booking-scheduling' ) ) )
		);

		return array(
			'subject' => $subject,
			'body'    => $body,
		);
	}

	/**
	 * Event registration confirmation.
	 *
	 * @return array{subject: string, body: string}
	 */
	public static function event_registration_confirmation( Event_Attendee $attendee, Event $event ): array {
		$customer = Customer_Repository::find( $attendee->customer_id );

		$subject = sprintf(
			/* translators: %s: event title. */
			__( "You're registered for %s", 'bookflow-booking-scheduling' ),
			$event->title
		);

		$location = $event->location_id ? Location_Repository::find( $event->location_id ) : null;

		try {
			$timezone = new \DateTimeZone( $event->timezone );
		} catch ( \Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
			$timezone = wp_timezone();
		}

		$rows  = self::row( __( 'Event', 'bookflow-booking-scheduling' ), $event->title );
		$rows .= self::row( __( 'When', 'bookflow-booking-scheduling' ), self::format_datetime( $event->start, $timezone ) . ' (' . $timezone->getName() . ')' );

		if ( $location ) {
			$rows .= self::row( __( 'Location', 'bookflow-booking-scheduling' ), $location->name . ( $location->is_online() && $location->meeting_url ? ' — ' . self::link( $location->meeting_url, $location->meeting_url ) : '' ) );
		}

		$rows .= self::row( __( 'Seats', 'bookflow-booking-scheduling' ), (string) $attendee->quantity );
		$rows .= self::row( __( 'Reference', 'bookflow-booking-scheduling' ), $attendee->booking_reference );

		$manage_link = $attendee->cancel_token
			? self::paragraph( self::link( Events_Bootstrap::manage_url( $attendee->cancel_token ), __( 'Manage your registration', 'bookflow-booking-scheduling' ) ) )
			: '';

		$body = self::wrap(
			$subject,
			self::greeting( $customer ) .
			self::paragraph( __( "You're confirmed for the following event:", 'bookflow-booking-scheduling' ) ) .
			'<table role="presentation" style="width:100%;border-collapse:collapse;margin:16px 0;">' . $rows . '</table>' .
			$manage_link
		);

		return array(
			'subject' => $subject,
			'body'    => $body,
		);
	}

	/**
	 * Administrator notification for a new event registration.
	 *
	 * @return array{subject: string, body: string}
	 */
	public static function admin_new_registration( Event_Attendee $attendee, Event $event ): array {
		$customer = Customer_Repository::find( $attendee->customer_id );

		$subject = sprintf(
			/* translators: 1: event title, 2: customer name. */
			__( 'New registration: %1$s — %2$s', 'bookflow-booking-scheduling' ),
			$event->title,
			$customer ? $customer->display_name() : ''
		);

		$admin_url = admin_url( 'admin.php?page=bookflow-events&action=attendees&id=' . $event->id );

		$body = self::wrap(
			$subject,
			self::paragraph(
				sprintf(
					/* translators: 1: customer name, 2: seat count, 3: event title. */
					__( '%1$s registered for %2$d seat(s) at %3$s.', 'bookflow-booking-scheduling' ),
					esc_html( $customer ? $customer->display_name() : '' ),
					$attendee->quantity,
					esc_html( $event->title )
				)
			) .
			self::paragraph( self::link( $admin_url, __( 'View attendees', 'bookflow-booking-scheduling' ) ) )
		);

		return array(
			'subject' => $subject,
			'body'    => $body,
		);
	}

	/**
	 * Common appointment details table shared by the customer-facing templates.
	 */
	private static function details_table( Appointment $appointment ): string {
		$service  = Service_Repository::find( $appointment->service_id );
		$staff    = $appointment->staff_id ? Staff_Repository::find( $appointment->staff_id ) : null;
		$location = $appointment->location_id ? Location_Repository::find( $appointment->location_id ) : null;

		try {
			$timezone = new \DateTimeZone( $appointment->timezone );
		} catch ( \Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
			$timezone = wp_timezone();
		}

		$rows  = self::row( __( 'Service', 'bookflow-booking-scheduling' ), $service ? $service->name : '' );
		$rows .= self::row( __( 'When', 'bookflow-booking-scheduling' ), self::format_datetime( $appointment->start, $timezone ) . ' (' . $timezone->getName() . ')' );

		if ( $staff ) {
			$rows .= self::row( __( 'With', 'bookflow-booking-scheduling' ), $staff->display_name );
		}

		if ( $location ) {
			$meeting = $location->is_online() && $location->meeting_url
				? ' — ' . self::link( $location->meeting_url, __( 'Join online', 'bookflow-booking-scheduling' ) )
				: '';
			$rows   .= self::row( __( 'Location', 'bookflow-booking-scheduling' ), $location->name . $meeting );
		}

		$rows .= self::row( __( 'Reference', 'bookflow-booking-scheduling' ), $appointment->booking_reference );

		return '<table role="presentation" style="width:100%;border-collapse:collapse;margin:16px 0;">' . $rows . '</table>';
	}

	/**
	 * The cancel/reschedule management link, shared by confirmation and reschedule templates.
	 */
	private static function manage_links( Appointment $appointment ): string {
		if ( ! $appointment->cancel_token ) {
			return '';
		}

		return self::paragraph( self::link( Manage_Booking::url( $appointment->cancel_token ), __( 'Manage or cancel your booking', 'bookflow-booking-scheduling' ) ) );
	}

	/**
	 * The business name shown in the email header — from Settings → General if set, else the
	 * site title.
	 */
	private static function business_name(): string {
		$general = get_option( 'bookflow_settings_general', array() );
		$name    = is_array( $general ) ? trim( (string) ( $general['business_name'] ?? '' ) ) : '';

		return '' !== $name ? $name : get_bloginfo( 'name' );
	}

	/**
	 * Format a UTC instant in a given timezone, e.g. "Tuesday, March 10, 2026 at 2:00 PM".
	 */
	private static function format_datetime( \DateTimeImmutable $utc, \DateTimeZone $timezone ): string {
		return $utc->setTimezone( $timezone )->format( 'l, F j, Y \a\t g:i A' );
	}

	/**
	 * A "Hi {name}," greeting line, falling back to a generic greeting if no name is on file.
	 */
	private static function greeting( ?Customer $customer ): string {
		$name = $customer ? trim( (string) $customer->first_name ) : '';

		$text = '' !== $name
			? sprintf( /* translators: %s: customer first name. */ __( 'Hi %s,', 'bookflow-booking-scheduling' ), $name )
			: __( 'Hi there,', 'bookflow-booking-scheduling' );

		return self::paragraph( $text );
	}

	/**
	 * One table row: label cell + value cell. $value_is_struck renders the value with a
	 * strikethrough, used for "previous time" in the reschedule email.
	 */
	private static function row( string $label, string $value, bool $value_is_struck = false ): string {
		$style = $value_is_struck ? 'text-decoration:line-through;color:#6b7280;' : '';

		return sprintf(
			'<tr><td style="padding:6px 12px 6px 0;color:#6b7280;white-space:nowrap;vertical-align:top;">%1$s</td><td style="padding:6px 0;%3$s">%2$s</td></tr>',
			esc_html( $label ),
			wp_kses( $value, array( 'a' => array( 'href' => array() ) ) ),
			esc_attr( $style )
		);
	}

	/**
	 * A paragraph block.
	 */
	private static function paragraph( string $html ): string {
		return '<p style="margin:0 0 16px;line-height:1.5;">' . wp_kses( $html, array( 'a' => array( 'href' => array() ) ) ) . '</p>';
	}

	/**
	 * A styled link.
	 */
	private static function link( string $url, string $label ): string {
		return sprintf( '<a href="%1$s" style="color:#4c6ef5;">%2$s</a>', esc_url( $url ), esc_html( $label ) );
	}

	/**
	 * Wrap a content block in the shared email chrome (business name header, restrained styling
	 * — inline CSS throughout, since email clients don't reliably support external/embedded
	 * stylesheets).
	 */
	private static function wrap( string $title, string $body_html ): string {
		$business = esc_html( self::business_name() );

		return sprintf(
			'<!doctype html><html><body style="margin:0;padding:0;background:#f6f7f7;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#1f2328;">' .
			'<table role="presentation" style="width:100%%;background:#f6f7f7;padding:24px 0;"><tr><td align="center">' .
			'<table role="presentation" style="width:100%%;max-width:520px;background:#ffffff;border-radius:8px;overflow:hidden;">' .
			'<tr><td style="padding:20px 24px;border-bottom:1px solid #edf0f2;"><strong style="font-size:16px;">%1$s</strong></td></tr>' .
			'<tr><td style="padding:24px;">%2$s</td></tr>' .
			'<tr><td style="padding:16px 24px;color:#9aa1a9;font-size:12px;border-top:1px solid #edf0f2;">%1$s</td></tr>' .
			'</table></td></tr></table></body></html>',
			$business,
			$body_html
		);
	}
}

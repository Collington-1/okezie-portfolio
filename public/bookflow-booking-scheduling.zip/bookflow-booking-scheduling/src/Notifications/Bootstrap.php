<?php
/**
 * Notifications module bootstrap: listens on the lifecycle hooks Booking/Events fire
 * (bookflow_appointment_created, _status_changed, _rescheduled, bookflow_event_registration_*)
 * and dispatches the matching email via Email_Templates + Mailer, gated by Settings::is_enabled().
 *
 * Every listener body is wrapped in a catch-all try/catch: do_action() does not itself catch
 * exceptions from hooked callbacks, and Appointment_Repository::create()/Event_Attendee_
 * Repository::register() fire their "created" hook from inside their own try/finally — so an
 * uncaught exception here (a null lookup, a wp_mail()/PHPMailer edge case, anything) would
 * propagate straight through those repositories to whatever called them, making a booking that
 * actually succeeded look like it failed just because the confirmation email hiccupped. A
 * notification failure must always be a soft failure (logged, never able to break the booking
 * flow that triggered it) — see docs/ARCHITECTURE.md §11.
 *
 * @package BookFlow\Notifications
 */

declare( strict_types = 1 );

namespace BookFlow\Notifications;

use BookFlow\Booking\Appointment;
use BookFlow\Customers\Customer_Repository;
use BookFlow\Events\Event;
use BookFlow\Events\Event_Attendee;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Bootstrap
 */
final class Bootstrap {

	/**
	 * Register hooks. Called unconditionally from Plugin::boot_modules() — these listeners need
	 * to fire regardless of admin/frontend/AJAX request context, since a booking can be created
	 * from any of them (frontend widget, admin-ajax.php, or the admin "Add Booking" screen).
	 */
	public static function init(): void {
		add_action( 'bookflow_appointment_created', array( self::class, 'on_appointment_created' ) );
		add_action( 'bookflow_appointment_status_changed', array( self::class, 'on_appointment_status_changed' ), 10, 3 );
		add_action( 'bookflow_appointment_rescheduled', array( self::class, 'on_appointment_rescheduled' ), 10, 3 );
		add_action( 'bookflow_event_registration_created', array( self::class, 'on_event_registration_created' ), 10, 2 );
	}

	/**
	 * A new appointment was created: send the customer's confirmation/received email, and the
	 * administrator notification.
	 */
	public static function on_appointment_created( Appointment $appointment ): void {
		self::guard(
			static function () use ( $appointment ): void {
				$customer = Customer_Repository::find( $appointment->customer_id );

				if ( null !== $customer && Settings::is_enabled( 'booking_confirmation' ) ) {
					$email = Email_Templates::booking_created( $appointment );
					Mailer::send( 'booking_confirmation', $customer->email, $email['subject'], $email['body'], $appointment->id );
				}

				if ( Settings::is_enabled( 'admin_notification' ) ) {
					$email = Email_Templates::admin_new_booking( $appointment );
					Mailer::send( 'admin_notification', Settings::admin_email(), $email['subject'], $email['body'], $appointment->id );
				}
			}
		);
	}

	/**
	 * An appointment's status changed: send the cancellation email on cancellation, or the
	 * confirmation email when a pending booking is approved. Other transitions (completed,
	 * no_show) have no customer-facing email in Free scope.
	 */
	public static function on_appointment_status_changed( Appointment $appointment, string $from, string $to ): void {
		self::guard(
			static function () use ( $appointment, $from, $to ): void {
				$customer = Customer_Repository::find( $appointment->customer_id );

				if ( null === $customer ) {
					return;
				}

				if ( 'cancelled' === $to && Settings::is_enabled( 'booking_cancellation' ) ) {
					$email = Email_Templates::booking_cancellation( $appointment );
					Mailer::send( 'booking_cancellation', $customer->email, $email['subject'], $email['body'], $appointment->id );
					return;
				}

				if ( 'pending' === $from && 'confirmed' === $to && Settings::is_enabled( 'booking_confirmation' ) ) {
					$email = Email_Templates::booking_created( $appointment );
					Mailer::send( 'booking_confirmation', $customer->email, $email['subject'], $email['body'], $appointment->id );
				}
			}
		);
	}

	/**
	 * An appointment was rescheduled: send the reschedule email.
	 */
	public static function on_appointment_rescheduled( Appointment $appointment, \DateTimeImmutable $old_start, \DateTimeImmutable $old_end ): void {
		self::guard(
			static function () use ( $appointment, $old_start, $old_end ): void {
				if ( ! Settings::is_enabled( 'booking_reschedule' ) ) {
					return;
				}

				$customer = Customer_Repository::find( $appointment->customer_id );

				if ( null === $customer ) {
					return;
				}

				$email = Email_Templates::booking_reschedule( $appointment, $old_start, $old_end );
				Mailer::send( 'booking_reschedule', $customer->email, $email['subject'], $email['body'], $appointment->id );
			}
		);
	}

	/**
	 * A new event registration was created: send the attendee's confirmation email, and the
	 * administrator notification.
	 */
	public static function on_event_registration_created( Event_Attendee $attendee, Event $event ): void {
		self::guard(
			static function () use ( $attendee, $event ): void {
				$customer = Customer_Repository::find( $attendee->customer_id );

				if ( null !== $customer && Settings::is_enabled( 'event_registration_confirmation' ) ) {
					$email = Email_Templates::event_registration_confirmation( $attendee, $event );
					Mailer::send( 'event_registration_confirmation', $customer->email, $email['subject'], $email['body'], null, $attendee->id );
				}

				if ( Settings::is_enabled( 'admin_notification' ) ) {
					$email = Email_Templates::admin_new_registration( $attendee, $event );
					Mailer::send( 'admin_notification', Settings::admin_email(), $email['subject'], $email['body'], null, $attendee->id );
				}
			}
		);
	}

	/**
	 * Run a listener body, swallowing (and error_log()-ing) any exception/error it throws — see
	 * class docblock for why this must never propagate back to the repository that fired the
	 * hook.
	 */
	private static function guard( callable $listener ): void {
		try {
			$listener();
		} catch ( \Throwable $e ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- deliberate: a notification failure must be diagnosable without being allowed to break the booking flow that triggered it (see class docblock). No sensitive data (booking details) is included, only the exception's own message/location.
			error_log( sprintf( 'BookFlow: notification listener failed: %s in %s:%d', $e->getMessage(), $e->getFile(), $e->getLine() ) );
		}
	}
}

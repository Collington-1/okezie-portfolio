<?php
/**
 * Shared write/read helper for wp_bookflow_notification_log. Append-only, like
 * Database\Audit_Logger — a sent/failed notification is a historical fact, never edited.
 *
 * @package BookFlow\Notifications
 */

declare( strict_types = 1 );

namespace BookFlow\Notifications;

use BookFlow\Database\Schema;
use BookFlow\Support\Timestamps;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Notification_Log
 */
final class Notification_Log {

	/**
	 * Record a notification attempt.
	 *
	 * @param string   $type               Notification type key (see Settings::types()).
	 * @param string   $recipient          Recipient email address.
	 * @param bool     $sent               Whether wp_mail() reported success.
	 * @param string|null $error           Error detail, if $sent is false.
	 * @param int|null $appointment_id     Related appointment, if any.
	 * @param int|null $event_attendee_id  Related event registration, if any.
	 */
	public static function record(
		string $type,
		string $recipient,
		bool $sent,
		?string $error = null,
		?int $appointment_id = null,
		?int $event_attendee_id = null
	): void {
		global $wpdb;

		$wpdb->insert(
			Schema::table( 'notification_log' ),
			array(
				'appointment_id'    => $appointment_id,
				'event_attendee_id' => $event_attendee_id,
				'type'              => $type,
				'recipient'         => $recipient,
				'status'            => $sent ? 'sent' : 'failed',
				'error'             => $error,
				'sent_at'           => Timestamps::now(),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%s' )
		);
	}

	/**
	 * Notification history for one appointment, most recent first — shown on the admin booking
	 * detail screen so an admin can see what was actually sent.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function for_appointment( int $appointment_id ): array {
		return self::for_object( 'appointment_id', $appointment_id );
	}

	/**
	 * Notification history for one event registration, most recent first.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	public static function for_event_attendee( int $event_attendee_id ): array {
		return self::for_object( 'event_attendee_id', $event_attendee_id );
	}

	/**
	 * @param string $column 'appointment_id' | 'event_attendee_id' — trusted constant, not user input.
	 * @return array<int, array<string, mixed>>
	 */
	private static function for_object( string $column, int $id ): array {
		global $wpdb;

		$table = Schema::table( 'notification_log' );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table/column name are trusted constants, not user input.
		$sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE {$column} = %d ORDER BY sent_at DESC", $id );

		$rows = $wpdb->get_results( $sql, ARRAY_A );

		return $rows ? $rows : array();
	}
}

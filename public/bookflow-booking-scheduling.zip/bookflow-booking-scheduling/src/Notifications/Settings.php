<?php
/**
 * Reads the notifications settings option (Section 17: "Provide administrator controls for
 * enabling/disabling supported notifications"). Stored under 'bookflow_settings_notifications'
 * — a name uninstall.php has cleaned up since Phase 1, in anticipation of this module.
 *
 * @package BookFlow\Notifications
 */

declare( strict_types = 1 );

namespace BookFlow\Notifications;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Settings
 */
final class Settings {

	/**
	 * Option name.
	 *
	 * @var string
	 */
	public const OPTION = 'bookflow_settings_notifications';

	/**
	 * Every notification type Free supports, with its admin-facing label — the single source
	 * of truth for both the Settings screen's toggle list and is_enabled()'s recognised keys.
	 *
	 * @return array<string, string>
	 */
	public static function types(): array {
		return array(
			'booking_confirmation'             => __( 'Booking confirmation (sent to the customer)', 'bookflow-booking-scheduling' ),
			'booking_cancellation'              => __( 'Booking cancellation (sent to the customer)', 'bookflow-booking-scheduling' ),
			'booking_reschedule'                => __( 'Booking rescheduled (sent to the customer)', 'bookflow-booking-scheduling' ),
			'admin_notification'                => __( 'New booking/registration notice (sent to you)', 'bookflow-booking-scheduling' ),
			'event_registration_confirmation'   => __( 'Event registration confirmation (sent to the attendee)', 'bookflow-booking-scheduling' ),
		);
	}

	/**
	 * Whether a given notification type is enabled. Defaults to enabled for any type not yet
	 * present in the stored settings (a fresh install sends notifications immediately, without
	 * requiring the admin to visit Settings first — Section 33's Definition of Done requires
	 * "the customer receives confirmation" to just work out of the box).
	 */
	public static function is_enabled( string $type ): bool {
		$settings = self::all();

		if ( ! array_key_exists( $type, $settings ) ) {
			return true;
		}

		return (bool) $settings[ $type ];
	}

	/**
	 * The address administrator notifications are sent to: the configured override if set and
	 * valid, else the site's own admin_email.
	 */
	public static function admin_email(): string {
		$settings = self::all();
		$override = trim( (string) ( $settings['admin_email'] ?? '' ) );

		if ( '' !== $override && is_email( $override ) ) {
			return $override;
		}

		return (string) get_option( 'admin_email' );
	}

	/**
	 * Raw stored settings.
	 *
	 * @return array<string, mixed>
	 */
	public static function all(): array {
		$settings = get_option( self::OPTION, array() );

		return is_array( $settings ) ? $settings : array();
	}
}

<?php
/**
 * The actual wp_mail() transport, shared by every notification type. Section 17: "Use wp_mail()
 * as the default transport. Do not require a paid email API." No From-address override here —
 * deliberately left to WordPress's own defaults (and whatever `wp_mail_from`/`wp_mail_from_name`
 * filters a host or another plugin already applies), to avoid this plugin fighting SPF/DKIM
 * configuration it has no way to know about. See docs/ARCHITECTURE.md §19.
 *
 * @package BookFlow\Notifications
 */

declare( strict_types = 1 );

namespace BookFlow\Notifications;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Mailer
 */
final class Mailer {

	/**
	 * Send one HTML email and log the outcome.
	 *
	 * @param string   $type               Notification type key (see Settings::types()), for the log.
	 * @param string   $to                 Recipient email address.
	 * @param string   $subject            Subject line (already translated/rendered).
	 * @param string   $html_body          Full HTML body (already rendered — see Email_Templates::wrap()).
	 * @param int|null $appointment_id     Related appointment, for the log.
	 * @param int|null $event_attendee_id  Related event registration, for the log.
	 */
	public static function send(
		string $type,
		string $to,
		string $subject,
		string $html_body,
		?int $appointment_id = null,
		?int $event_attendee_id = null
	): bool {
		if ( ! is_email( $to ) ) {
			Notification_Log::record( $type, $to, false, 'Invalid recipient email address.', $appointment_id, $event_attendee_id );

			return false;
		}

		add_filter( 'wp_mail_content_type', array( self::class, 'html_content_type' ) );

		$error = null;

		$capture_failure = static function ( \WP_Error $wp_error ) use ( &$error ): void {
			$error = $wp_error->get_error_message();
		};

		add_action( 'wp_mail_failed', $capture_failure );

		/**
		 * Filters the email body immediately before sending, for every BookFlow notification
		 * type. Premium/Advanced-email-templates functionality (Section 3) is the intended
		 * consumer — see docs/ARCHITECTURE.md §11.
		 *
		 * @param string $html_body Rendered HTML body.
		 * @param string $type      Notification type key.
		 */
		$html_body = (string) apply_filters( 'bookflow_notification_body', $html_body, $type );

		/**
		 * Filters the extra headers passed to wp_mail() for every BookFlow notification — the
		 * intended way for Premium to Cc/Bcc an additional address (e.g. a staff member's
		 * synced calendar inbox) without needing its own separate mail call. Empty by default;
		 * `wp_mail()` already accepts a plain string or an array of header lines here.
		 *
		 * @param array<int, string>|string $headers Extra headers, empty by default.
		 * @param string                    $type    Notification type key.
		 * @param string                    $to      Primary recipient email address.
		 */
		$headers = apply_filters( 'bookflow_notification_headers', array(), $type, $to );

		$sent = wp_mail( $to, $subject, $html_body, $headers );

		remove_action( 'wp_mail_failed', $capture_failure );
		remove_filter( 'wp_mail_content_type', array( self::class, 'html_content_type' ) );

		Notification_Log::record( $type, $to, $sent, $sent ? null : $error, $appointment_id, $event_attendee_id );

		return $sent;
	}

	/**
	 * `wp_mail_content_type` filter callback — HTML for the duration of one send only (added
	 * and removed around each wp_mail() call, never left globally applied, so this plugin never
	 * silently changes the content type of emails other code sends).
	 */
	public static function html_content_type(): string {
		return 'text/html';
	}
}

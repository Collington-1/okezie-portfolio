<?php
/**
 * Customers domain repository: validation and CRUD for wp_bookflow_customers.
 *
 * @package BookFlow\Customers
 */

declare( strict_types = 1 );

namespace BookFlow\Customers;

use BookFlow\Database\Repository;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Customer_Repository
 */
final class Customer_Repository extends Repository {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'customers';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'wp_user_id' => '%d',
			'first_name' => '%s',
			'last_name'  => '%s',
			'email'      => '%s',
			'phone'      => '%s',
			'timezone'   => '%s',
			'notes'      => '%s',
			'meta'       => '%s',
			'created_at' => '%s',
			'updated_at' => '%s',
		);
	}

	/**
	 * Fetch a customer by ID.
	 */
	public static function find( int $id ): ?Customer {
		$row = parent::find_row( $id );

		return $row ? Customer::from_row( $row ) : null;
	}

	/**
	 * Fetch several customers by ID in one query, keyed by id. See Repository::find_many_rows().
	 *
	 * @param array<int, int> $ids Customer IDs.
	 * @return array<int, Customer>
	 */
	public static function find_many( array $ids ): array {
		return array_map( array( Customer::class, 'from_row' ), parent::find_many_rows( $ids ) );
	}

	/**
	 * Fetch a customer by email address (case-insensitive — emails are normalized to lowercase
	 * on write, see validate()).
	 */
	public static function find_by_email( string $email ): ?Customer {
		$row = self::find_by( 'email', self::normalize_email( $email ), '%s' );

		return $row ? Customer::from_row( $row ) : null;
	}

	/**
	 * Fetch a customer by their linked WordPress user ID.
	 */
	public static function find_by_wp_user_id( int $wp_user_id ): ?Customer {
		$row = self::find_by( 'wp_user_id', $wp_user_id, '%d' );

		return $row ? Customer::from_row( $row ) : null;
	}

	/**
	 * List customers. Paginated server-side — Section 10 explicitly calls out customers,
	 * alongside bookings/events, as needing it (unlike Services/Staff/Locations).
	 *
	 * @param array{search?: string, orderby?: string, order?: string, limit?: int, offset?: int} $args Filter/pagination args.
	 * @return array<int, Customer>
	 */
	public static function all( array $args = array() ): array {
		global $wpdb;

		$table               = static::table();
		[ $where, $params ] = self::build_where( $args );

		$orderby = in_array( $args['orderby'] ?? '', array( 'created_at', 'email', 'last_name' ), true )
			? $args['orderby']
			: 'created_at';
		$order   = 'ASC' === strtoupper( $args['order'] ?? '' ) ? 'ASC' : 'DESC';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $orderby/$order are whitelisted above; $where placeholders are parameterized.
		$sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . " ORDER BY {$orderby} {$order}";

		if ( ! empty( $args['limit'] ) ) {
			$sql     .= ' LIMIT %d OFFSET %d';
			$params[] = (int) $args['limit'];
			$params[] = (int) ( $args['offset'] ?? 0 );
		}

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared whenever placeholders are present.
		$rows     = $wpdb->get_results( $prepared, ARRAY_A );

		return array_map( array( Customer::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Count customers matching the same filters all() accepts (limit/offset/orderby/order are
	 * ignored — this is the total for pagination, not a page count).
	 *
	 * @param array{search?: string} $args Filter args.
	 */
	public static function count( array $args = array() ): int {
		global $wpdb;

		$table               = static::table();
		[ $where, $params ] = self::build_where( $args );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where fragments are hard-coded in build_where(); placeholders are parameterized.
		$sql = "SELECT COUNT(*) FROM {$table} WHERE " . implode( ' AND ', $where );

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared whenever placeholders are present.

		return (int) $wpdb->get_var( $prepared );
	}

	/**
	 * Shared WHERE-clause builder for all() and count(), so the two can never drift out of
	 * sync with each other (the same pattern Appointment_Repository/Event_Repository use).
	 *
	 * @param array<string, mixed> $args Filter args (see all()).
	 * @return array{0: array<int, string>, 1: array<int, mixed>}
	 */
	private static function build_where( array $args ): array {
		global $wpdb;

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
			$where[]  = '(email LIKE %s OR first_name LIKE %s OR last_name LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		return array( $where, $params );
	}

	/**
	 * Create a customer.
	 *
	 * @param array<string, mixed> $input Raw input.
	 *
	 * @throws Validation_Exception When input fails validation.
	 */
	public static function create( array $input ): Customer {
		$data                = self::validate( $input, null );
		$data['created_at']  = Timestamps::now();
		$data['updated_at']  = $data['created_at'];

		$id = parent::insert( $data );

		return self::find( $id );
	}

	/**
	 * Update a customer. Fields absent from $input keep their current value.
	 *
	 * @param int                   $id    Customer ID.
	 * @param array<string, mixed>  $input Raw partial input.
	 *
	 * @throws \InvalidArgumentException When the customer does not exist.
	 * @throws Validation_Exception       When input fails validation.
	 */
	public static function update( int $id, array $input ): Customer {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: customer %d not found.', $id ) );
		}

		$data               = self::validate( $input, $existing );
		$data['updated_at'] = Timestamps::now();

		parent::update_row( $id, $data );

		return self::find( $id );
	}

	/**
	 * Find an existing customer by email, or create one — the shape the booking engine needs
	 * when a visitor books without an existing customer record. Updates first/last name and
	 * phone on an existing match only where the caller supplied a non-empty value, so a repeat
	 * booking with less information never blanks out data already on file.
	 *
	 * @param string                $email Email address (required).
	 * @param array<string, mixed>  $attrs Optional additional attributes (first_name, last_name, phone, timezone).
	 *
	 * @throws Validation_Exception When the email address itself is invalid.
	 */
	public static function find_or_create_by_email( string $email, array $attrs = array() ): Customer {
		$existing = self::find_by_email( $email );

		if ( null === $existing ) {
			return self::create( array_merge( $attrs, array( 'email' => $email ) ) );
		}

		$patch = array();

		foreach ( array( 'first_name', 'last_name', 'phone', 'timezone' ) as $field ) {
			if ( ! empty( $attrs[ $field ] ) ) {
				$patch[ $field ] = $attrs[ $field ];
			}
		}

		if ( empty( $patch ) ) {
			return $existing;
		}

		return self::update( $existing->id, $patch );
	}

	/**
	 * Lowercase + sanitize an email address for consistent lookups/storage.
	 */
	private static function normalize_email( string $email ): string {
		return strtolower( sanitize_email( $email ) );
	}

	/**
	 * Validate and sanitize raw input.
	 *
	 * @param array<string, mixed>      $input    Raw input.
	 * @param array<string, mixed>|null $existing Existing raw row, for partial updates.
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, ?array $existing ): array {
		$get = static function ( string $key, $default ) use ( $input, $existing ) {
			if ( array_key_exists( $key, $input ) ) {
				return $input[ $key ];
			}

			if ( null !== $existing && array_key_exists( $key, $existing ) ) {
				return $existing[ $key ];
			}

			return $default;
		};

		$errors = array();

		$email = self::normalize_email( (string) $get( 'email', '' ) );

		if ( ! is_email( $email ) ) {
			$errors['email'] = __( 'Please enter a valid email address.', 'bookflow-booking-scheduling' );
		}

		if ( ! empty( $errors ) ) {
			throw new Validation_Exception( $errors, __( 'The customer could not be saved.', 'bookflow-booking-scheduling' ) );
		}

		$wp_user_id_raw = $get( 'wp_user_id', null );
		$wp_user_id     = ( null !== $wp_user_id_raw && '' !== $wp_user_id_raw ) ? absint( $wp_user_id_raw ) : null;

		$timezone_raw = $get( 'timezone', null );
		$timezone     = null;

		if ( null !== $timezone_raw && in_array( (string) $timezone_raw, \DateTimeZone::listIdentifiers(), true ) ) {
			$timezone = (string) $timezone_raw;
		}

		$first_name = sanitize_text_field( (string) $get( 'first_name', '' ) );
		$last_name  = sanitize_text_field( (string) $get( 'last_name', '' ) );
		$phone      = sanitize_text_field( (string) $get( 'phone', '' ) );
		$notes      = sanitize_textarea_field( (string) $get( 'notes', '' ) );

		$meta = $get( 'meta', array() );

		if ( ! is_array( $meta ) ) {
			$meta = array();
		}

		return array(
			'wp_user_id' => $wp_user_id,
			'first_name' => '' !== $first_name ? $first_name : null,
			'last_name'  => '' !== $last_name ? $last_name : null,
			'email'      => $email,
			'phone'      => '' !== $phone ? $phone : null,
			'timezone'   => $timezone,
			'notes'      => '' !== $notes ? $notes : null,
			'meta'       => wp_json_encode( $meta ),
		);
	}
}

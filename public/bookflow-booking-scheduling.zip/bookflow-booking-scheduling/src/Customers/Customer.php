<?php
/**
 * Customer entity — one row of wp_bookflow_customers. Treated as personal data; see
 * docs/DATABASE-SCHEMA.md and the Privacy section of docs/ARCHITECTURE.md.
 *
 * @package BookFlow\Customers
 */

declare( strict_types = 1 );

namespace BookFlow\Customers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Customer
 */
final class Customer {

	/**
	 * Constructor.
	 *
	 * @param int         $id         Row ID.
	 * @param int|null    $wp_user_id Linked WordPress user ID, if any.
	 * @param string|null $first_name First name.
	 * @param string|null $last_name  Last name.
	 * @param string      $email      Email address.
	 * @param string|null $phone      Phone number.
	 * @param string|null $timezone   IANA timezone name.
	 * @param string|null $notes      Admin-only internal notes.
	 * @param array<string, mixed> $meta Decoded JSON meta.
	 * @param string      $created_at UTC DATETIME string.
	 * @param string      $updated_at UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public ?int $wp_user_id,
		public ?string $first_name,
		public ?string $last_name,
		public string $email,
		public ?string $phone,
		public ?string $timezone,
		public ?string $notes,
		public array $meta,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		return new self(
			(int) $row['id'],
			isset( $row['wp_user_id'] ) && null !== $row['wp_user_id'] ? (int) $row['wp_user_id'] : null,
			$row['first_name'] ?? null,
			$row['last_name'] ?? null,
			(string) $row['email'],
			$row['phone'] ?? null,
			$row['timezone'] ?? null,
			$row['notes'] ?? null,
			self::decode_meta( $row['meta'] ?? null ),
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}

	/**
	 * Decode the meta JSON column, tolerating null/malformed values.
	 *
	 * @param string|null $json Raw JSON string.
	 * @return array<string, mixed>
	 */
	private static function decode_meta( ?string $json ): array {
		if ( null === $json || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Full display name, falling back to the email address if no name is on file.
	 */
	public function display_name(): string {
		$name = trim( ( $this->first_name ?? '' ) . ' ' . ( $this->last_name ?? '' ) );

		return '' !== $name ? $name : $this->email;
	}
}

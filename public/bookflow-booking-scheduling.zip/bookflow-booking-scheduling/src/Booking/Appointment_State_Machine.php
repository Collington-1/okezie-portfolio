<?php
/**
 * Appointment status state machine (Section 16 of the master spec). Prevents invalid status
 * transitions and records every change to the audit log.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

use BookFlow\Database\Audit_Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Appointment_State_Machine
 */
final class Appointment_State_Machine {

	/**
	 * Allowed transitions, from => [ to, to, ... ]. completed/cancelled/no_show are terminal —
	 * correcting a mistaken status is an explicit admin data edit via the repository, not a
	 * state transition, and is out of this class's scope by design.
	 *
	 * @var array<string, array<int, string>>
	 */
	private const TRANSITIONS = array(
		'pending'   => array( 'confirmed', 'cancelled' ),
		'confirmed' => array( 'completed', 'cancelled', 'no_show' ),
		'completed' => array(),
		'cancelled' => array(),
		'no_show'   => array(),
	);

	/**
	 * Whether a transition from one status to another is allowed.
	 */
	public static function can_transition( string $from, string $to ): bool {
		return in_array( $to, self::TRANSITIONS[ $from ] ?? array(), true );
	}

	/**
	 * Transition an appointment to a new status, recording the change to the audit log.
	 *
	 * @param Appointment $appointment The appointment to transition.
	 * @param string      $to          Target status.
	 * @param int|null    $user_id     Acting user ID, or null for system/customer-initiated actions.
	 * @param string|null $reason      Optional human-readable reason, stored in the audit log only.
	 *
	 * @throws \InvalidArgumentException When the transition is not allowed.
	 */
	public static function transition( Appointment $appointment, string $to, ?int $user_id = null, ?string $reason = null ): Appointment {
		if ( ! self::can_transition( $appointment->status, $to ) ) {
			throw new \InvalidArgumentException(
				sprintf(
					'BookFlow: cannot transition appointment %d from "%s" to "%s".',
					$appointment->id,
					$appointment->status,
					$to
				)
			);
		}

		$from    = $appointment->status;
		$updated = Appointment_Repository::set_status( $appointment->id, $to );

		Audit_Logger::log(
			'appointment',
			$appointment->id,
			'status_changed',
			$user_id,
			array( 'status' => $from ),
			array(
				'status' => $to,
				'reason' => $reason,
			)
		);

		/**
		 * Fires after an appointment's status changes. Notifications hooks here to send the
		 * booking-cancellation email (and the booking-confirmation email for a pending →
		 * confirmed approval) — see docs/ARCHITECTURE.md §11 for why this, not a repository
		 * subclass or a monkey-patch, is the documented extension seam.
		 *
		 * @param Appointment $appointment The appointment at its new status.
		 * @param string      $from        Previous status.
		 * @param string      $to          New status.
		 */
		do_action( 'bookflow_appointment_status_changed', $updated, $from, $to );

		return $updated;
	}
}

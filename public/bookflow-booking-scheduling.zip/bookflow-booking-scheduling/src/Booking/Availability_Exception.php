<?php
/**
 * A one-off deviation from the normal weekly schedule — a holiday closure, staff time off, or
 * extra opened-up availability. One row of wp_bookflow_availability_exceptions.
 *
 * Named to match the database table/domain concept, NOT a PHP \Exception/\Throwable — this is
 * a plain data entity, same shape as Availability_Rule.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Availability_Exception
 */
final class Availability_Exception {

	/**
	 * Constructor.
	 *
	 * @param int         $id           Row ID.
	 * @param string      $entity_type  'business' | 'staff' | 'location'.
	 * @param int|null    $entity_id    Owning entity ID; null when entity_type is 'business'.
	 * @param string      $date         'YYYY-MM-DD', local to the owning entity's timezone.
	 * @param string|null $start_time   'HH:MM:SS', or null for the whole day.
	 * @param string|null $end_time     'HH:MM:SS', or null for the whole day.
	 * @param bool        $is_available False = closed for this date/range; true = additional
	 *                                   open slot beyond the normal weekly schedule.
	 * @param string|null $reason       Optional human-readable reason (e.g. "Public holiday").
	 * @param string      $created_at   UTC DATETIME string.
	 * @param string      $updated_at   UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public string $entity_type,
		public ?int $entity_id,
		public string $date,
		public ?string $start_time,
		public ?string $end_time,
		public bool $is_available,
		public ?string $reason,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		return new self(
			(int) $row['id'],
			(string) $row['entity_type'],
			isset( $row['entity_id'] ) && null !== $row['entity_id'] ? (int) $row['entity_id'] : null,
			(string) $row['date'],
			$row['start_time'] ?? null,
			$row['end_time'] ?? null,
			(bool) ( (int) $row['is_available'] ),
			$row['reason'] ?? null,
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}

	/**
	 * Whether this exception covers the entire day (no start/end time set).
	 */
	public function is_full_day(): bool {
		return null === $this->start_time || null === $this->end_time;
	}
}

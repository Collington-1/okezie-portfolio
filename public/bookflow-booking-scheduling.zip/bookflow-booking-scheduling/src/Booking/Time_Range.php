<?php
/**
 * A UTC start/end instant pair — the one shape used throughout the booking engine for both
 * "open hours" intervals and candidate/existing appointment slots. Deliberately built on
 * DateTimeImmutable rather than formatted strings: see docs/ARCHITECTURE.md §9 — availability
 * math must never compare formatted date strings.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Time_Range
 */
final class Time_Range {

	/**
	 * Constructor. Both instants are expected in UTC; callers are responsible for converting
	 * before constructing one (this class does not re-derive or assume a timezone).
	 *
	 * @param \DateTimeImmutable $start Range start (inclusive).
	 * @param \DateTimeImmutable $end   Range end (exclusive).
	 *
	 * @throws \InvalidArgumentException When $end is not after $start.
	 */
	public function __construct(
		public \DateTimeImmutable $start,
		public \DateTimeImmutable $end
	) {
		if ( $end <= $start ) {
			throw new \InvalidArgumentException( 'BookFlow: Time_Range end must be after start.' );
		}
	}

	/**
	 * Duration in whole minutes.
	 */
	public function duration_minutes(): int {
		return (int) round( ( $this->end->getTimestamp() - $this->start->getTimestamp() ) / 60 );
	}

	/**
	 * A copy of this range padded outward by the given number of minutes on each side —
	 * used to apply buffer-before/buffer-after to an existing appointment before checking it
	 * against a candidate slot.
	 *
	 * @param int $before_minutes Minutes to subtract from the start.
	 * @param int $after_minutes  Minutes to add to the end.
	 */
	public function padded( int $before_minutes, int $after_minutes ): self {
		return new self(
			$this->start->modify( "-{$before_minutes} minutes" ),
			$this->end->modify( "+{$after_minutes} minutes" )
		);
	}

	/**
	 * Whether this range fully contains another (e.g. a candidate slot within an open-hours
	 * interval).
	 */
	public function contains( self $other ): bool {
		return $other->start >= $this->start && $other->end <= $this->end;
	}

	/**
	 * Whether this range overlaps another. Ranges that merely touch at an endpoint (this
	 * range's end equals the other's start, or vice versa) do NOT count as overlapping — a
	 * 9:00–10:00 appointment and a 10:00–11:00 appointment are back-to-back, not conflicting.
	 */
	public function overlaps( self $other ): bool {
		return $this->start < $other->end && $other->start < $this->end;
	}
}

<?php
/**
 * Appointments domain repository: validation, the server-side double-booking guard, and CRUD
 * for wp_bookflow_appointments.
 *
 * Double-booking guard: MySQL has no range-exclusion constraint (unlike PostgreSQL), so a
 * unique index cannot enforce "no two overlapping rows for this staff member" at the schema
 * level. Instead, create()/reschedule() take a MySQL named lock (GET_LOCK()) scoped to the
 * staff member (or service, when no staff is assigned) for the duration of a re-check-then-
 * insert critical section. Named locks are connection-scoped but coordinate correctly across
 * separate PHP-FPM/web requests because they live in MySQL itself, not PHP process memory —
 * unlike a static/in-memory PHP lock, which would not help under a typical multi-worker
 * WordPress deployment. This is a real concurrency guard, not just a best-effort check; see
 * docs/ARCHITECTURE.md §8.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

use BookFlow\Database\Repository;
use BookFlow\Services\Service;
use BookFlow\Services\Service_Repository;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Tokens;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Appointment_Repository
 */
final class Appointment_Repository extends Repository {

	/**
	 * Seconds to wait for the named lock before giving up as a conflict.
	 *
	 * @var int
	 */
	private const LOCK_TIMEOUT_SECONDS = 10;

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'appointments';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'booking_reference'  => '%s',
			'service_id'         => '%d',
			'staff_id'           => '%d',
			'location_id'        => '%d',
			'customer_id'        => '%d',
			'scheduling_page_id' => '%d',
			'start_datetime_utc' => '%s',
			'end_datetime_utc'   => '%s',
			'timezone'           => '%s',
			'status'             => '%s',
			'price'              => '%f',
			'currency'           => '%s',
			'notes'              => '%s',
			'custom_fields'      => '%s',
			'series_id'          => '%d',
			'cancel_token'       => '%s',
			'reschedule_token'   => '%s',
			'source'             => '%s',
			'created_at'         => '%s',
			'updated_at'         => '%s',
		);
	}

	/**
	 * Fetch an appointment by ID.
	 */
	public static function find( int $id ): ?Appointment {
		$row = parent::find_row( $id );

		return $row ? Appointment::from_row( $row ) : null;
	}

	/**
	 * Fetch an appointment by its public booking reference.
	 */
	public static function find_by_reference( string $booking_reference ): ?Appointment {
		$row = self::find_by( 'booking_reference', $booking_reference, '%s' );

		return $row ? Appointment::from_row( $row ) : null;
	}

	/**
	 * Fetch an appointment by its public cancel-link token.
	 */
	public static function find_by_cancel_token( string $token ): ?Appointment {
		$row = self::find_by( 'cancel_token', $token, '%s' );

		return $row ? Appointment::from_row( $row ) : null;
	}

	/**
	 * Fetch an appointment by its public reschedule-link token.
	 */
	public static function find_by_reschedule_token( string $token ): ?Appointment {
		$row = self::find_by( 'reschedule_token', $token, '%s' );

		return $row ? Appointment::from_row( $row ) : null;
	}

	/**
	 * List appointments (the admin bookings list / calendar's data source). Real pagination —
	 * unlike Services/Staff/Locations, appointment volume grows unboundedly (Section 10
	 * explicitly calls out bookings/customers/events as needing pagination).
	 *
	 * @param array{status?: string, staff_id?: int, location_id?: int, service_id?: int, customer_id?: int, date_from?: string, date_to?: string, search?: string, orderby?: string, order?: string, limit?: int, offset?: int} $args Filter/pagination args.
	 * @return array<int, Appointment>
	 */
	public static function all( array $args = array() ): array {
		global $wpdb;

		$table               = static::table();
		[ $where, $params ] = self::build_where( $args );

		$orderby = in_array( $args['orderby'] ?? '', array( 'start_datetime_utc', 'created_at', 'status' ), true )
			? $args['orderby']
			: 'start_datetime_utc';
		$order   = 'DESC' === strtoupper( $args['order'] ?? '' ) ? 'DESC' : 'ASC';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $orderby/$order are whitelisted above; $where placeholders are parameterized.
		$sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . " ORDER BY {$orderby} {$order}";

		if ( ! empty( $args['limit'] ) ) {
			$sql     .= ' LIMIT %d OFFSET %d';
			$params[] = (int) $args['limit'];
			$params[] = (int) ( $args['offset'] ?? 0 );
		}

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared whenever placeholders are present.
		$rows     = $wpdb->get_results( $prepared, ARRAY_A );

		return array_map( array( Appointment::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Count appointments matching the same filters all() accepts (limit/offset/orderby/order
	 * are ignored — this is the total for pagination, not a page count).
	 *
	 * @param array{status?: string, staff_id?: int, location_id?: int, service_id?: int, customer_id?: int, date_from?: string, date_to?: string, search?: string} $args Filter args.
	 */
	public static function count( array $args = array() ): int {
		global $wpdb;

		$table               = static::table();
		[ $where, $params ] = self::build_where( $args );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where fragments are hard-coded in build_where(); placeholders are parameterized.
		$sql = "SELECT COUNT(*) FROM {$table} WHERE " . implode( ' AND ', $where );

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared whenever placeholders are present.

		return (int) $wpdb->get_var( $prepared );
	}

	/**
	 * Appointment counts for a batch of customers in one query, keyed by customer_id — for
	 * screens like Customers_List_Table that show a per-row booking count and would otherwise
	 * run count() once per row (N+1: 20 extra queries per paginated admin screen load). Customer
	 * IDs with zero appointments are simply absent from the result; callers should `?? 0`.
	 *
	 * @param array<int, int> $customer_ids Customer IDs to count for.
	 * @return array<int, int> customer_id => appointment count.
	 */
	public static function counts_by_customer( array $customer_ids ): array {
		global $wpdb;

		$customer_ids = array_values( array_unique( array_map( 'intval', $customer_ids ) ) );

		if ( ! $customer_ids ) {
			return array();
		}

		$table        = static::table();
		$placeholders = implode( ', ', array_fill( 0, count( $customer_ids ), '%d' ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $placeholders is a fixed-count run of %d, not interpolated input; every value is bound below.
		$sql = "SELECT customer_id, COUNT(*) AS total FROM {$table} WHERE customer_id IN ({$placeholders}) GROUP BY customer_id";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $customer_ids ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared above.

		$counts = array();
		foreach ( $rows ? $rows : array() as $row ) {
			$counts[ (int) $row['customer_id'] ] = (int) $row['total'];
		}

		return $counts;
	}

	/**
	 * Shared WHERE-clause builder for all() and count(), so the two can never drift out of
	 * sync with each other.
	 *
	 * @param array<string, mixed> $args Filter args (see all()).
	 * @return array{0: array<int, string>, 1: array<int, mixed>}
	 */
	private static function build_where( array $args ): array {
		global $wpdb;

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = (string) $args['status'];
		}

		if ( ! empty( $args['staff_id'] ) ) {
			$where[]  = 'staff_id = %d';
			$params[] = (int) $args['staff_id'];
		}

		if ( ! empty( $args['location_id'] ) ) {
			$where[]  = 'location_id = %d';
			$params[] = (int) $args['location_id'];
		}

		if ( ! empty( $args['service_id'] ) ) {
			$where[]  = 'service_id = %d';
			$params[] = (int) $args['service_id'];
		}

		if ( ! empty( $args['customer_id'] ) ) {
			$where[]  = 'customer_id = %d';
			$params[] = (int) $args['customer_id'];
		}

		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'start_datetime_utc >= %s';
			$params[] = (string) $args['date_from'];
		}

		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'start_datetime_utc <= %s';
			$params[] = (string) $args['date_to'];
		}

		if ( ! empty( $args['search'] ) ) {
			$where[]  = 'booking_reference LIKE %s';
			$params[] = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
		}

		return array( $where, $params );
	}

	/**
	 * Create an appointment, guarded against double-booking.
	 *
	 * @param array<string, mixed> $input {
	 *     @type int                  $service_id          Required.
	 *     @type int                  $customer_id          Required.
	 *     @type \DateTimeImmutable   $start                Required, UTC.
	 *     @type string               $timezone             Required — the customer's booking timezone, for display.
	 *     @type int|null             $staff_id             Optional.
	 *     @type int|null             $location_id          Optional.
	 *     @type int|null             $scheduling_page_id   Optional.
	 *     @type int|null             $duration_minutes     Optional override of the service's default duration.
	 *     @type string               $status               Optional, default 'pending'.
	 *     @type string|null          $notes                Optional.
	 *     @type array<string,mixed>  $custom_fields         Optional.
	 *     @type string               $source                Optional, default 'frontend'.
	 *     @type array<string,mixed>|null $rule_overrides    Optional. Any of buffer_before_minutes,
	 *                                                         buffer_after_minutes, min_notice_minutes,
	 *                                                         max_advance_days — takes precedence over
	 *                                                         the service's own settings when present.
	 *                                                         Populated by Scheduling_Page::effective_rules_for()
	 *                                                         when booking through a scheduling page
	 *                                                         (Phase 6); omitted entirely for a plain
	 *                                                         service booking, which then uses the
	 *                                                         service's own settings unchanged.
	 * }
	 *
	 * @throws Validation_Exception       When input fails validation.
	 * @throws Booking_Conflict_Exception When the slot is no longer available.
	 */
	public static function create( array $input ): Appointment {
		$service = self::require_service( $input );
		$data    = self::validate( $input, $service, null );
		$rules   = self::effective_rules( $service, is_array( $input['rule_overrides'] ?? null ) ? $input['rule_overrides'] : array() );

		$candidate = new Time_Range(
			new \DateTimeImmutable( $data['start_datetime_utc'], new \DateTimeZone( 'UTC' ) ),
			new \DateTimeImmutable( $data['end_datetime_utc'], new \DateTimeZone( 'UTC' ) )
		);

		self::enforce_booking_window( $candidate, $rules );

		$lock_key = self::lock_key( $data['staff_id'], $data['service_id'] );

		self::acquire_lock( $lock_key );

		try {
			$capacity      = $service->capacity;
			$buffer_before = $rules['buffer_before_minutes'];
			$buffer_after  = $rules['buffer_after_minutes'];
			$window        = $candidate->padded( $buffer_before + 1, $buffer_after + 1 ); // +1 minute of slack around the padded edges.

			$existing = self::active_between( $data['staff_id'], $data['service_id'], $window->start, $window->end );
			$engine   = new Availability_Engine( array(), array(), array(), array(), $existing );

			if ( ! $engine->is_slot_available( $candidate, $data['service_id'], $capacity, $buffer_before, $buffer_after ) ) {
				throw new Booking_Conflict_Exception( __( 'This time is no longer available. Please choose another time.', 'bookflow-booking-scheduling' ) );
			}

			$data['booking_reference'] = self::unique_reference();
			$data['cancel_token']      = Tokens::link();
			$data['reschedule_token']  = Tokens::link();
			$data['created_at']        = Timestamps::now();
			$data['updated_at']        = $data['created_at'];

			$id          = parent::insert( $data );
			$appointment = self::find( $id );
		} finally {
			self::release_lock( $lock_key );
		}

		/**
		 * Fires after a new appointment is successfully created (any status — check
		 * $appointment->status to distinguish 'pending' from an immediately-'confirmed'
		 * booking). This is the extension seam Notifications hooks into to send the booking
		 * confirmation/received and admin-notification emails, and the documented seam
		 * Premium/third-party code should use instead of monkey-patching this repository — see
		 * docs/ARCHITECTURE.md §11. Fired AFTER the named lock is released (not from inside the
		 * try block above): a notification listener may do slow I/O (sending an email), and the
		 * lock must never be held any longer than the actual database critical section, or it
		 * would needlessly block other concurrent booking attempts for this same staff/service.
		 *
		 * @param Appointment $appointment The newly created appointment.
		 */
		do_action( 'bookflow_appointment_created', $appointment );

		return $appointment;
	}

	/**
	 * Move an existing appointment to a new time, re-running the double-booking guard for the
	 * new slot (excluding the appointment's own current row from the conflict check).
	 *
	 * @param int                $id           Appointment ID.
	 * @param \DateTimeImmutable $new_start    New start instant, UTC.
	 * @param string             $new_timezone New display timezone for the customer.
	 *
	 * @throws \InvalidArgumentException  When the appointment does not exist.
	 * @throws Booking_Conflict_Exception When the new slot is not available.
	 */
	public static function reschedule( int $id, \DateTimeImmutable $new_start, string $new_timezone ): Appointment {
		// Normalize to UTC regardless of the timezone $new_start was constructed with — every
		// *_datetime_utc column must hold a true UTC instant, never a caller's local wall clock.
		$new_start = $new_start->setTimezone( new \DateTimeZone( 'UTC' ) );

		$existing_row = parent::find_row( $id );

		if ( null === $existing_row ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: appointment %d not found.', $id ) );
		}

		$appointment = Appointment::from_row( $existing_row );
		$service     = Service_Repository::find( $appointment->service_id );

		if ( null === $service ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: service %d for appointment %d no longer exists.', $appointment->service_id, $id ) );
		}

		$duration_seconds = $appointment->end->getTimestamp() - $appointment->start->getTimestamp();
		$new_end          = $new_start->modify( "+{$duration_seconds} seconds" );
		$candidate        = new Time_Range( $new_start, $new_end );

		// Known Phase 6 scope limitation: rescheduling always uses the SERVICE's own buffer/
		// notice/window rules, even for an appointment originally booked through a scheduling
		// page with its own overrides (Scheduling_Page::effective_rules_for()). Applying the
		// page's rules here too is a reasonable future improvement, not done yet — see
		// docs/ROADMAP.md's Phase 6 notes.
		$rules = self::effective_rules( $service, array() );

		self::enforce_booking_window( $candidate, $rules );

		$lock_key = self::lock_key( $appointment->staff_id, $appointment->service_id );

		self::acquire_lock( $lock_key );

		try {
			$capacity      = $service->capacity;
			$buffer_before = $rules['buffer_before_minutes'];
			$buffer_after  = $rules['buffer_after_minutes'];
			$window        = $candidate->padded( $buffer_before + 1, $buffer_after + 1 ); // +1 minute of slack around the padded edges.

			$existing = self::active_between( $appointment->staff_id, $appointment->service_id, $window->start, $window->end, $id );
			$engine   = new Availability_Engine( array(), array(), array(), array(), $existing );

			if ( ! $engine->is_slot_available( $candidate, $appointment->service_id, $capacity, $buffer_before, $buffer_after ) ) {
				throw new Booking_Conflict_Exception( __( 'This time is no longer available. Please choose another time.', 'bookflow-booking-scheduling' ) );
			}

			parent::update_row(
				$id,
				array(
					'start_datetime_utc' => $new_start->format( 'Y-m-d H:i:s' ),
					'end_datetime_utc'   => $new_end->format( 'Y-m-d H:i:s' ),
					'timezone'           => $new_timezone,
					'updated_at'         => Timestamps::now(),
				)
			);

			$updated = self::find( $id );
		} finally {
			self::release_lock( $lock_key );
		}

		/**
		 * Fires after an appointment is successfully rescheduled. $old_start/$old_end are the
		 * appointment's PREVIOUS time (in UTC) — Notifications uses these to show "moved from
		 * ... to ..." in the reschedule email. Fired AFTER the named lock is released — same
		 * reasoning as create()'s bookflow_appointment_created (see that docblock).
		 *
		 * @param Appointment        $appointment The appointment at its new time.
		 * @param \DateTimeImmutable $old_start   Previous start instant, UTC.
		 * @param \DateTimeImmutable $old_end     Previous end instant, UTC.
		 */
		do_action( 'bookflow_appointment_rescheduled', $updated, $appointment->start, $appointment->end );

		return $updated;
	}

	/**
	 * Update editable fields (notes, custom fields, price/currency). Status is deliberately not
	 * editable here — use Appointment_State_Machine::transition() so status changes are always
	 * validated and audit-logged.
	 *
	 * @param int                   $id    Appointment ID.
	 * @param array<string, mixed>  $input Raw partial input.
	 *
	 * @throws \InvalidArgumentException When the appointment does not exist.
	 */
	public static function update( int $id, array $input ): Appointment {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: appointment %d not found.', $id ) );
		}

		unset( $input['status'] );

		$data = array();

		if ( array_key_exists( 'notes', $input ) ) {
			$data['notes'] = sanitize_textarea_field( (string) $input['notes'] ) ?: null;
		}

		if ( array_key_exists( 'custom_fields', $input ) && is_array( $input['custom_fields'] ) ) {
			$data['custom_fields'] = wp_json_encode( $input['custom_fields'] );
		}

		if ( array_key_exists( 'price', $input ) ) {
			$data['price'] = null !== $input['price'] && '' !== $input['price'] ? (float) $input['price'] : null;
		}

		if ( empty( $data ) ) {
			return Appointment::from_row( $existing );
		}

		$data['updated_at'] = Timestamps::now();

		parent::update_row( $id, $data );

		return self::find( $id );
	}

	/**
	 * Set the status column directly. Only ever called from Appointment_State_Machine, which
	 * owns transition validation and audit logging — never call this directly from admin/REST
	 * code.
	 */
	public static function set_status( int $id, string $status ): Appointment {
		parent::update_row(
			$id,
			array(
				'status'     => $status,
				'updated_at' => Timestamps::now(),
			)
		);

		return self::find( $id );
	}

	/**
	 * Existing active appointments overlapping a UTC window, in the shape Availability_Engine
	 * expects. Scoped to the assigned staff member when one is given, or to "no-staff
	 * appointments of the same service" otherwise (see docs/ARCHITECTURE.md §8). Public: used
	 * both by create()/reschedule()'s conflict guard (a window padded around one candidate
	 * slot) and by Availability_Service's whole-day slot listing (a window spanning a full
	 * calendar day) — one query shape, two callers, so the staff-or-service scoping rule can
	 * never drift between "can I book this" and "what's shown as available".
	 *
	 * @param int|null           $staff_id     Assigned staff, or null.
	 * @param int                $service_id   Service being scheduled.
	 * @param \DateTimeImmutable $from_utc     Window start (inclusive-ish; matches on overlap, see below).
	 * @param \DateTimeImmutable $to_utc       Window end.
	 * @param int|null           $excluding_id Appointment ID to exclude (rescheduling its own row).
	 * @return array<int, array{service_id:int, start:\DateTimeImmutable, end:\DateTimeImmutable}>
	 */
	public static function active_between( ?int $staff_id, int $service_id, \DateTimeImmutable $from_utc, \DateTimeImmutable $to_utc, ?int $excluding_id = null ): array {
		global $wpdb;

		$table = static::table();

		$statuses       = Appointment::active_statuses();
		$placeholders   = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );

		$where  = array( "status IN ({$placeholders})", 'start_datetime_utc < %s', 'end_datetime_utc > %s' );
		$params = array_merge( $statuses, array( $to_utc->format( 'Y-m-d H:i:s' ), $from_utc->format( 'Y-m-d H:i:s' ) ) );

		if ( null !== $staff_id ) {
			$where[]  = 'staff_id = %d';
			$params[] = $staff_id;
		} else {
			$where[]  = 'staff_id IS NULL';
			$where[]  = 'service_id = %d';
			$params[] = $service_id;
		}

		if ( null !== $excluding_id ) {
			$where[]  = 'id != %d';
			$params[] = $excluding_id;
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where fragments/placeholder count are built from trusted constants above.
		$sql = "SELECT service_id, start_datetime_utc, end_datetime_utc FROM {$table} WHERE " . implode( ' AND ', $where );

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared immediately above.

		$utc = new \DateTimeZone( 'UTC' );

		return array_map(
			static function ( array $row ) use ( $utc ): array {
				return array(
					'service_id' => (int) $row['service_id'],
					'start'      => new \DateTimeImmutable( (string) $row['start_datetime_utc'], $utc ),
					'end'        => new \DateTimeImmutable( (string) $row['end_datetime_utc'], $utc ),
				);
			},
			$rows ? $rows : array()
		);
	}

	/**
	 * Merge optional override values over a service's own buffer/notice/advance-window
	 * settings. Shared by create() and reschedule() so "what rules actually apply to this
	 * booking" is computed exactly once per call, the same way, regardless of caller.
	 *
	 * @param Service              $service   The service being booked.
	 * @param array<string, mixed> $overrides Zero or more of buffer_before_minutes,
	 *                                          buffer_after_minutes, min_notice_minutes,
	 *                                          max_advance_days — see create()'s $rule_overrides
	 *                                          docblock. An absent key means "use the service's
	 *                                          own setting", not "force to zero/null".
	 *
	 * @return array{buffer_before_minutes:int, buffer_after_minutes:int, min_notice_minutes:int, max_advance_days:int|null}
	 */
	private static function effective_rules( Service $service, array $overrides ): array {
		return array(
			'buffer_before_minutes' => array_key_exists( 'buffer_before_minutes', $overrides ) ? (int) $overrides['buffer_before_minutes'] : (int) $service->setting( 'buffer_before_minutes', 0 ),
			'buffer_after_minutes'  => array_key_exists( 'buffer_after_minutes', $overrides ) ? (int) $overrides['buffer_after_minutes'] : (int) $service->setting( 'buffer_after_minutes', 0 ),
			'min_notice_minutes'    => array_key_exists( 'min_notice_minutes', $overrides ) ? (int) $overrides['min_notice_minutes'] : (int) $service->setting( 'min_notice_minutes', 0 ),
			'max_advance_days'      => array_key_exists( 'max_advance_days', $overrides ) ? $overrides['max_advance_days'] : $service->setting( 'max_advance_days', null ),
		);
	}

	/**
	 * Server-side enforcement of the effective minimum notice and maximum advance booking
	 * window (service settings, or a scheduling page's overrides — see effective_rules()). The
	 * frontend slot picker already filters these out (Availability_Engine's not_before_utc
	 * parameter), but that alone is client-supplied intent, not a guarantee — Section 14
	 * requires booking restrictions to be enforced server-side, not just hidden from the UI.
	 * Checked outside the GET_LOCK() critical section since it needs no coordination with other
	 * requests.
	 *
	 * @param Time_Range                                                                          $candidate Candidate slot, UTC.
	 * @param array{buffer_before_minutes:int, buffer_after_minutes:int, min_notice_minutes:int, max_advance_days:int|null} $rules Effective rules from effective_rules().
	 *
	 * @throws Validation_Exception When the candidate falls outside the allowed window.
	 */
	private static function enforce_booking_window( Time_Range $candidate, array $rules ): void {
		$min_notice_minutes = $rules['min_notice_minutes'];
		$max_advance_days   = $rules['max_advance_days'];

		$now = new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) );

		if ( $min_notice_minutes > 0 && $candidate->start < $now->modify( "+{$min_notice_minutes} minutes" ) ) {
			throw new Validation_Exception( array( 'start' => __( 'This time no longer meets the minimum booking notice required.', 'bookflow-booking-scheduling' ) ) );
		}

		if ( null !== $max_advance_days && '' !== $max_advance_days && $candidate->start > $now->modify( '+' . ( (int) $max_advance_days ) . ' days' ) ) {
			throw new Validation_Exception( array( 'start' => __( 'This date is beyond the maximum advance booking window.', 'bookflow-booking-scheduling' ) ) );
		}
	}

	/**
	 * MySQL named-lock key for a given staff/service scope.
	 */
	private static function lock_key( ?int $staff_id, int $service_id ): string {
		return null !== $staff_id ? "bookflow_staff_{$staff_id}" : "bookflow_service_{$service_id}";
	}

	/**
	 * Acquire this appointment-scoped named lock (see Repository::acquire_named_lock()), or
	 * throw a conflict exception if it cannot be obtained within the timeout (another request
	 * is already booking this same staff/service).
	 *
	 * @throws Booking_Conflict_Exception When the lock cannot be acquired.
	 */
	private static function acquire_lock( string $key ): void {
		if ( ! self::acquire_named_lock( $key, self::LOCK_TIMEOUT_SECONDS ) ) {
			throw new Booking_Conflict_Exception( __( 'This time slot is currently being booked by someone else. Please try again in a moment.', 'bookflow-booking-scheduling' ) );
		}
	}

	/**
	 * Release a previously acquired named lock.
	 */
	private static function release_lock( string $key ): void {
		self::release_named_lock( $key );
	}

	/**
	 * Generate a booking reference guaranteed unique against existing rows, retrying on the
	 * astronomically unlikely event of a collision.
	 */
	private static function unique_reference(): string {
		for ( $attempt = 0; $attempt < 5; $attempt++ ) {
			$candidate = Tokens::reference();

			if ( ! self::exists_by( 'booking_reference', $candidate, '%s' ) ) {
				return $candidate;
			}
		}

		// Fall through with a longer reference on the vanishingly unlikely chance of repeated
		// collisions — still far more entropy than needed, just no longer "short".
		return Tokens::reference( 16 );
	}

	/**
	 * Resolve and validate the referenced service, common to create().
	 *
	 * @param array<string, mixed> $input Raw input.
	 *
	 * @throws Validation_Exception When service_id is missing or does not reference a real service.
	 */
	private static function require_service( array $input ): Service {
		$service_id = isset( $input['service_id'] ) ? (int) $input['service_id'] : 0;

		if ( $service_id < 1 ) {
			throw new Validation_Exception( array( 'service_id' => __( 'A service is required.', 'bookflow-booking-scheduling' ) ) );
		}

		$service = Service_Repository::find( $service_id );

		if ( null === $service ) {
			throw new Validation_Exception( array( 'service_id' => __( 'The selected service could not be found.', 'bookflow-booking-scheduling' ) ) );
		}

		return $service;
	}

	/**
	 * Validate and sanitize raw input into a column => value map ready for insert().
	 *
	 * @param array<string, mixed>              $input       Raw input.
	 * @param Service         $service     Resolved service (for default duration/price).
	 * @param array<string, mixed>|null          $existing    Existing raw row, for partial updates (unused by create(), reserved for future use).
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, Service $service, ?array $existing ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- $existing reserved for a future direct-field-update validate() path.
		$errors = array();

		$customer_id = isset( $input['customer_id'] ) ? (int) $input['customer_id'] : 0;

		if ( $customer_id < 1 ) {
			$errors['customer_id'] = __( 'A customer is required.', 'bookflow-booking-scheduling' );
		}

		if ( ! isset( $input['start'] ) || ! ( $input['start'] instanceof \DateTimeImmutable ) ) {
			$errors['start'] = __( 'A valid start time is required.', 'bookflow-booking-scheduling' );
		}

		$timezone = (string) ( $input['timezone'] ?? '' );

		if ( '' === $timezone || ! in_array( $timezone, \DateTimeZone::listIdentifiers(), true ) ) {
			$errors['timezone'] = __( 'A valid timezone is required.', 'bookflow-booking-scheduling' );
		}

		$status = (string) ( $input['status'] ?? 'pending' );

		if ( ! in_array( $status, Appointment::statuses(), true ) ) {
			$errors['status'] = __( 'Invalid appointment status.', 'bookflow-booking-scheduling' );
		}

		if ( ! empty( $errors ) ) {
			throw new Validation_Exception( $errors, __( 'The appointment could not be booked.', 'bookflow-booking-scheduling' ) );
		}

		$duration_minutes = isset( $input['duration_minutes'] ) ? (int) $input['duration_minutes'] : $service->duration_minutes;
		$duration_minutes = $duration_minutes > 0 ? $duration_minutes : $service->duration_minutes;

		/** @var \DateTimeImmutable $start */
		$start = $input['start'];
		$end   = $start->setTimezone( new \DateTimeZone( 'UTC' ) )->modify( "+{$duration_minutes} minutes" );

		$staff_id_raw    = $input['staff_id'] ?? null;
		$location_id_raw = $input['location_id'] ?? null;
		$scheduling_raw  = $input['scheduling_page_id'] ?? null;

		$custom_fields = isset( $input['custom_fields'] ) && is_array( $input['custom_fields'] ) ? $input['custom_fields'] : array();

		return array(
			'booking_reference'  => '', // filled in by create() after the conflict check.
			'service_id'         => $service->id,
			'staff_id'           => ( null !== $staff_id_raw && '' !== $staff_id_raw ) ? absint( $staff_id_raw ) : null,
			'location_id'        => ( null !== $location_id_raw && '' !== $location_id_raw ) ? absint( $location_id_raw ) : null,
			'customer_id'        => $customer_id,
			'scheduling_page_id' => ( null !== $scheduling_raw && '' !== $scheduling_raw ) ? absint( $scheduling_raw ) : null,
			'start_datetime_utc' => $start->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ),
			'end_datetime_utc'   => $end->format( 'Y-m-d H:i:s' ),
			'timezone'           => $timezone,
			'status'             => $status,
			'price'              => $service->price,
			'currency'           => $service->currency,
			'notes'              => isset( $input['notes'] ) ? ( sanitize_textarea_field( (string) $input['notes'] ) ?: null ) : null,
			'custom_fields'      => wp_json_encode( $custom_fields ),
			'series_id'          => null,
			'cancel_token'       => '', // filled in by create().
			'reschedule_token'   => '', // filled in by create().
			'source'             => in_array( $input['source'] ?? '', array( 'frontend', 'admin', 'api' ), true ) ? $input['source'] : 'frontend',
		);
	}
}

<?php
/**
 * Orchestration layer between Availability_Engine (pure domain math) and the repositories that
 * hold real data — the "give me bookable slots for this customer" entry point used by the
 * frontend booking flow (Phase 5) and, later, the REST API (Phase 9). Availability_Engine
 * itself deliberately knows nothing about $wpdb/repositories (docs/ARCHITECTURE.md §8); this
 * class is where those two worlds meet.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

use BookFlow\Services\Service;
use BookFlow\Staff\Staff_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Availability_Service
 */
final class Availability_Service {

	/**
	 * Bookable slots for one calendar day AS SEEN BY THE CUSTOMER, in the customer's own
	 * timezone — not the reference timezone the underlying weekly hours are authored in.
	 *
	 * Why this needs more than one Availability_Engine::slots_for_day() call: opening hours are
	 * authored in a reference timezone (the assigned staff member's, or the site's), but the
	 * customer is picking a calendar date in their OWN timezone. If the two timezones differ,
	 * the customer's "Tuesday" can overlap parts of the reference timezone's Monday AND Tuesday
	 * (e.g. a UTC+13 customer's Tuesday morning is still Monday afternoon in a UTC-8 business).
	 * So: compute the customer-local day's UTC boundaries, find every reference-timezone
	 * calendar date that boundary window touches (almost always 1, occasionally 2), run the
	 * engine once per such date, merge, then filter down to only the slots whose start actually
	 * falls inside the customer's requested local day. This is the one correct way to do this
	 * without ever comparing formatted date strings across timezones (docs/ARCHITECTURE.md §9).
	 *
	 * @param Service            $service              The service being booked.
	 * @param int|null           $staff_id             Selected staff member, or null.
	 * @param int|null           $location_id          Selected location, or null.
	 * @param \DateTimeImmutable $customer_day_local   Midnight of the requested date, constructed IN $customer_timezone.
	 * @param \DateTimeZone      $customer_timezone    The customer's own timezone.
	 * @param int|null           $excluding_appointment_id Appointment ID to exclude from the conflict
	 *                                                       check — set when generating slots for
	 *                                                       RESCHEDULING an existing appointment, so
	 *                                                       its own current slot is never reported as
	 *                                                       unavailable due to conflicting with itself.
	 * @param array<string, mixed>|null $rule_overrides     Optional buffer_before_minutes/
	 *                                                        buffer_after_minutes/min_notice_minutes
	 *                                                        overrides, taking precedence over the
	 *                                                        service's own settings — populated by
	 *                                                        Scheduling_Page::effective_rules_for()
	 *                                                        when booking through a scheduling page
	 *                                                        (Phase 6). Mirrors
	 *                                                        Appointment_Repository::create()'s
	 *                                                        $rule_overrides so a scheduling page's
	 *                                                        rules are applied identically to what
	 *                                                        the customer is shown and what actually
	 *                                                        gets booked.
	 * @return array<int, Time_Range> Available slots, in UTC, ordered chronologically.
	 */
	public static function slots_for_customer_day(
		Service $service,
		?int $staff_id,
		?int $location_id,
		\DateTimeImmutable $customer_day_local,
		\DateTimeZone $customer_timezone,
		?int $excluding_appointment_id = null,
		?array $rule_overrides = null
	): array {
		$utc = new \DateTimeZone( 'UTC' );

		$reference_timezone = self::reference_timezone( $staff_id );

		$customer_day_start_utc = $customer_day_local->setTimezone( $utc );
		$customer_day_end_utc   = $customer_day_local->modify( '+1 day' )->setTimezone( $utc );

		// Every reference-timezone calendar date the customer's local day boundary touches —
		// almost always one date, occasionally two near a timezone-offset day boundary.
		$reference_dates = array_unique(
			array(
				$customer_day_start_utc->setTimezone( $reference_timezone )->format( 'Y-m-d' ),
				$customer_day_end_utc->modify( '-1 second' )->setTimezone( $reference_timezone )->format( 'Y-m-d' ),
			)
		);

		[ $business_rules, $staff_rules, $location_rules ] = self::rules( $staff_id, $location_id );

		$overrides = $rule_overrides ?? array();

		$duration_minutes = $service->duration_minutes;
		$step_minutes      = (int) $service->setting( 'slot_step_minutes', $duration_minutes );
		$buffer_before     = array_key_exists( 'buffer_before_minutes', $overrides ) ? (int) $overrides['buffer_before_minutes'] : (int) $service->setting( 'buffer_before_minutes', 0 );
		$buffer_after      = array_key_exists( 'buffer_after_minutes', $overrides ) ? (int) $overrides['buffer_after_minutes'] : (int) $service->setting( 'buffer_after_minutes', 0 );
		$min_notice        = array_key_exists( 'min_notice_minutes', $overrides ) ? (int) $overrides['min_notice_minutes'] : (int) $service->setting( 'min_notice_minutes', 0 );

		$not_before_utc = ( new \DateTimeImmutable( 'now', $utc ) )->modify( "+{$min_notice} minutes" );

		$slots = array();

		foreach ( $reference_dates as $reference_date ) {
			$reference_day_local = new \DateTimeImmutable( $reference_date . ' 00:00:00', $reference_timezone );

			$exceptions = self::exceptions( $staff_id, $location_id, $reference_date );

			// Query a window wide enough to catch appointments that could conflict via buffers
			// spilling across the reference day's boundary, then let the engine's own
			// is_slot_available() do the precise overlap math.
			$window_start = $reference_day_local->modify( '-1 day' )->setTimezone( $utc );
			$window_end   = $reference_day_local->modify( '+2 days' )->setTimezone( $utc );
			$existing     = Appointment_Repository::active_between( $staff_id, $service->id, $window_start, $window_end, $excluding_appointment_id );

			/**
			 * Filters the "existing appointments" list the availability engine treats as
			 * blocking time, before it computes slots — the intended extension point for
			 * calendar-sync integrations (Section 3) to fold in busy time from an external
			 * calendar without the engine itself needing to know external calendars exist. Each
			 * added entry must have the same shape as a real appointment row: `array{service_id:
			 * int, start: DateTimeImmutable, end: DateTimeImmutable}` (both in UTC) — `service_id`
			 * only matters for this service's own capacity/"same session" grouping, so an
			 * external-calendar entry that should block regardless of service can reuse
			 * $service->id. See docs/ARCHITECTURE.md §24.
			 *
			 * @param array<int, array{service_id:int, start:\DateTimeImmutable, end:\DateTimeImmutable}> $existing
			 * @param int|null           $staff_id     Staff member this computation is for, if any.
			 * @param int|null           $location_id  Location this computation is for, if any.
			 * @param \DateTimeImmutable $window_start Window start, UTC.
			 * @param \DateTimeImmutable $window_end   Window end, UTC.
			 */
			$existing = apply_filters( 'bookflow_busy_ranges', $existing, $staff_id, $location_id, $window_start, $window_end );

			$engine = new Availability_Engine( $business_rules, $staff_rules, $location_rules, $exceptions, $existing );

			foreach (
				$engine->slots_for_day(
					$reference_day_local,
					$reference_timezone,
					$duration_minutes,
					$step_minutes,
					$service->capacity,
					$buffer_before,
					$buffer_after,
					$not_before_utc,
					$service->id
				) as $slot
			) {
				if ( $slot->start >= $customer_day_start_utc && $slot->start < $customer_day_end_utc ) {
					$slots[ $slot->start->getTimestamp() ] = $slot;
				}
			}
		}

		ksort( $slots );

		return array_values( $slots );
	}

	/**
	 * The earliest calendar date (in the customer's timezone) that could possibly have any
	 * bookable slot, given the effective minimum notice — used by the frontend to avoid
	 * offering "today" when, say, minimum notice already pushes past midnight.
	 *
	 * @param array<string, mixed>|null $rule_overrides Optional min_notice_minutes override —
	 *                                                    see slots_for_customer_day()'s docblock.
	 */
	public static function earliest_bookable_date( Service $service, \DateTimeZone $customer_timezone, ?array $rule_overrides = null ): \DateTimeImmutable {
		$overrides  = $rule_overrides ?? array();
		$min_notice = array_key_exists( 'min_notice_minutes', $overrides ) ? (int) $overrides['min_notice_minutes'] : (int) $service->setting( 'min_notice_minutes', 0 );
		$now        = new \DateTimeImmutable( 'now', $customer_timezone );

		return $now->modify( "+{$min_notice} minutes" )->setTime( 0, 0 );
	}

	/**
	 * The latest calendar date (in the customer's timezone) the effective maximum advance
	 * booking window allows, or null if unlimited.
	 *
	 * @param array<string, mixed>|null $rule_overrides Optional max_advance_days override — see
	 *                                                    slots_for_customer_day()'s docblock.
	 */
	public static function latest_bookable_date( Service $service, \DateTimeZone $customer_timezone, ?array $rule_overrides = null ): ?\DateTimeImmutable {
		$overrides        = $rule_overrides ?? array();
		$max_advance_days = array_key_exists( 'max_advance_days', $overrides ) ? $overrides['max_advance_days'] : $service->setting( 'max_advance_days', null );

		if ( null === $max_advance_days || '' === $max_advance_days ) {
			return null;
		}

		$now = new \DateTimeImmutable( 'now', $customer_timezone );

		return $now->modify( '+' . ( (int) $max_advance_days ) . ' days' )->setTime( 0, 0 );
	}

	/**
	 * The reference timezone opening hours are authored in for a given staff selection: the
	 * staff member's own timezone if one is selected (falling back to site timezone if that
	 * staff member has none set — see Staff_Member::effective_timezone()), else the site
	 * timezone directly.
	 */
	private static function reference_timezone( ?int $staff_id ): \DateTimeZone {
		if ( null === $staff_id ) {
			return wp_timezone();
		}

		$staff = Staff_Repository::find( $staff_id );

		return $staff ? $staff->effective_timezone() : wp_timezone();
	}

	/**
	 * Business/staff/location rule sets for a given staff/location selection.
	 *
	 * @return array{0: array<int, Availability_Rule>, 1: array<int, Availability_Rule>, 2: array<int, Availability_Rule>}
	 */
	private static function rules( ?int $staff_id, ?int $location_id ): array {
		$business_rules = Availability_Rule_Repository::for_entity( 'business', null );
		$staff_rules    = null !== $staff_id ? Availability_Rule_Repository::for_entity( 'staff', $staff_id ) : array();
		$location_rules = null !== $location_id ? Availability_Rule_Repository::for_entity( 'location', $location_id ) : array();

		return array( $business_rules, $staff_rules, $location_rules );
	}

	/**
	 * Business + staff + location exceptions relevant to one reference-timezone date.
	 *
	 * @return array<int, Availability_Exception>
	 */
	private static function exceptions( ?int $staff_id, ?int $location_id, string $date ): array {
		$exceptions = Availability_Exception_Repository::for_entity_in_range( 'business', null, $date, $date );

		if ( null !== $staff_id ) {
			$exceptions = array_merge( $exceptions, Availability_Exception_Repository::for_entity_in_range( 'staff', $staff_id, $date, $date ) );
		}

		if ( null !== $location_id ) {
			$exceptions = array_merge( $exceptions, Availability_Exception_Repository::for_entity_in_range( 'location', $location_id, $date, $date ) );
		}

		return $exceptions;
	}
}

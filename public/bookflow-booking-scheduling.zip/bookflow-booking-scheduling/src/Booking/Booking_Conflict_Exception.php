<?php
/**
 * Thrown when Appointment_Repository::create() finds the requested slot is no longer available
 * at the moment of insert — either it was never available, or another request booked it in the
 * window between the customer viewing available slots and submitting the booking.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Booking_Conflict_Exception
 */
final class Booking_Conflict_Exception extends \RuntimeException {}

<?php
/**
 * A single weekly recurring open-hours row — one row of wp_bookflow_availability_rules.
 * Scoped by entity_type/entity_id so business hours, staff hours, and location hours share one
 * table; see docs/DATABASE-SCHEMA.md.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Availability_Rule
 */
final class Availability_Rule {

	/**
	 * Constructor.
	 *
	 * @param int      $id          Row ID.
	 * @param string   $entity_type 'business' | 'staff' | 'location'.
	 * @param int|null $entity_id   Owning entity ID; null when entity_type is 'business'.
	 * @param int      $day_of_week 0 (Sunday) through 6 (Saturday).
	 * @param string   $start_time  'HH:MM:SS', local to the owning entity's timezone.
	 * @param string   $end_time    'HH:MM:SS', local to the owning entity's timezone.
	 * @param string   $created_at  UTC DATETIME string.
	 * @param string   $updated_at  UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public string $entity_type,
		public ?int $entity_id,
		public int $day_of_week,
		public string $start_time,
		public string $end_time,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Recognised `entity_type` values.
	 *
	 * @return array<int, string>
	 */
	public static function entity_types(): array {
		return array( 'business', 'staff', 'location' );
	}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		return new self(
			(int) $row['id'],
			(string) $row['entity_type'],
			isset( $row['entity_id'] ) && null !== $row['entity_id'] ? (int) $row['entity_id'] : null,
			(int) $row['day_of_week'],
			(string) $row['start_time'],
			(string) $row['end_time'],
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}
}

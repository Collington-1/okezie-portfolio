<?php
/**
 * The availability/booking domain engine (Section 14 of the master spec). Pure domain logic —
 * no WordPress hooks, no direct database access. Callers (Appointment_Repository, and later the
 * REST/frontend booking flow) fetch the raw rules/exceptions/existing-appointments data and
 * construct one engine instance per computation; see docs/ARCHITECTURE.md §8.
 *
 * v1 simplification, stated plainly rather than silently assumed: all opening-hours wall-clock
 * times (business/staff/location rows) are interpreted against ONE reference timezone per
 * computation — typically the staff member's timezone if one is selected, else the site
 * timezone. True per-row timezone mixing (e.g. a business spanning locations in different
 * timezones, each with its own local hours) is a Premium-era refinement, not a Free-tier
 * requirement.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Availability_Engine
 */
final class Availability_Engine {

	/**
	 * Constructor.
	 *
	 * @param array<int, Availability_Rule>      $business_rules        ALL business rules (any day of week).
	 * @param array<int, Availability_Rule>      $staff_rules           ALL rules for the selected staff member, or [] if none/no staff selected.
	 * @param array<int, Availability_Rule>      $location_rules        ALL rules for the selected location, or [] if none/no location selected.
	 * @param array<int, Availability_Exception> $exceptions            Exceptions relevant to this computation (business + staff + location, already scoped by the caller to the entities actually in play).
	 * @param array<int, array{service_id:int, start:\DateTimeImmutable, end:\DateTimeImmutable}> $existing_appointments Existing active (non-cancelled/no-show) appointments in the relevant scope, in UTC.
	 */
	public function __construct(
		private array $business_rules,
		private array $staff_rules,
		private array $location_rules,
		private array $exceptions,
		private array $existing_appointments
	) {}

	/**
	 * Compute available slots for one calendar date.
	 *
	 * @param \DateTimeImmutable $date_local_midnight    Midnight of the target date, constructed IN $reference_timezone.
	 * @param \DateTimeZone      $reference_timezone      Timezone the weekly/exception wall-clock times are interpreted in.
	 * @param int                $duration_minutes        Slot length.
	 * @param int                $step_minutes             Granularity to step candidate start times by.
	 * @param int                $capacity                 Max concurrent bookings sharing the exact same start time for this service.
	 * @param int                $buffer_before_minutes    Minutes required free immediately before a candidate slot.
	 * @param int                $buffer_after_minutes     Minutes required free immediately after a candidate slot.
	 * @param \DateTimeImmutable $not_before_utc            Earliest bookable instant (already reflects minimum notice), in UTC.
	 * @param int                $service_id                Service being scheduled, for capacity/"same session" grouping.
	 * @return array<int, Time_Range> Available slots, in UTC, ordered chronologically.
	 */
	public function slots_for_day(
		\DateTimeImmutable $date_local_midnight,
		\DateTimeZone $reference_timezone,
		int $duration_minutes,
		int $step_minutes,
		int $capacity,
		int $buffer_before_minutes,
		int $buffer_after_minutes,
		\DateTimeImmutable $not_before_utc,
		int $service_id
	): array {
		$day_of_week = (int) $date_local_midnight->format( 'w' );

		$intervals = $this->resolve_day_intervals( $day_of_week );
		$intervals = $this->apply_exceptions( $intervals, $date_local_midnight->format( 'Y-m-d' ) );

		$step  = max( 1, $step_minutes );
		$slots = array();

		foreach ( $intervals as $interval ) {
			$range  = $this->minute_interval_to_utc_range( $interval[0], $interval[1], $date_local_midnight, $reference_timezone );
			$cursor = $range->start;

			while ( true ) {
				$candidate_end = $cursor->modify( "+{$duration_minutes} minutes" );

				if ( $candidate_end > $range->end ) {
					break;
				}

				$candidate = new Time_Range( $cursor, $candidate_end );

				if (
					$candidate->start >= $not_before_utc
					&& $this->is_slot_available( $candidate, $service_id, $capacity, $buffer_before_minutes, $buffer_after_minutes )
				) {
					// Keyed by timestamp to de-duplicate slots reachable via more than one
					// interval (e.g. an exception-added interval overlapping the normal hours).
					$slots[ $candidate->start->getTimestamp() ] = $candidate;
				}

				$cursor = $cursor->modify( "+{$step} minutes" );
			}
		}

		ksort( $slots );

		return array_values( $slots );
	}

	/**
	 * Whether one specific candidate slot is free, given the existing appointments this engine
	 * was constructed with. Shared by slots_for_day()'s scan and Appointment_Repository::create()'s
	 * final pre-insert guard, so both paths use identical conflict logic.
	 *
	 * @param Time_Range $candidate             Candidate slot, in UTC.
	 * @param int        $service_id             Service being scheduled.
	 * @param int        $capacity               Max concurrent bookings sharing the exact same start.
	 * @param int        $buffer_before_minutes  Minutes required free immediately before.
	 * @param int        $buffer_after_minutes   Minutes required free immediately after.
	 */
	public function is_slot_available( Time_Range $candidate, int $service_id, int $capacity, int $buffer_before_minutes, int $buffer_after_minutes ): bool {
		$padded       = $candidate->padded( $buffer_before_minutes, $buffer_after_minutes );
		$same_session = 0;

		foreach ( $this->existing_appointments as $appointment ) {
			$is_same_session = $appointment['service_id'] === $service_id
				&& $appointment['start']->getTimestamp() === $candidate->start->getTimestamp();

			if ( $is_same_session ) {
				++$same_session;
				continue;
			}

			$existing_range = new Time_Range( $appointment['start'], $appointment['end'] );

			if ( $padded->overlaps( $existing_range ) ) {
				return false;
			}
		}

		return $same_session < $capacity;
	}

	/**
	 * Resolve the base open-hours intervals (business ∩ staff ∩ location, before exceptions)
	 * for one day of week, as minute-of-day pairs [start, end).
	 *
	 * @return array<int, array{0:int, 1:int}>
	 */
	private function resolve_day_intervals( int $day_of_week ): array {
		$intervals = $this->rules_to_minute_intervals( $this->business_rules, $day_of_week );

		if ( ! empty( $this->staff_rules ) ) {
			$intervals = $this->intersect_minute_interval_sets( $intervals, $this->rules_to_minute_intervals( $this->staff_rules, $day_of_week ) );
		}

		if ( ! empty( $this->location_rules ) ) {
			$intervals = $this->intersect_minute_interval_sets( $intervals, $this->rules_to_minute_intervals( $this->location_rules, $day_of_week ) );
		}

		return $intervals;
	}

	/**
	 * Apply exceptions for one date: unavailable exceptions subtract, available exceptions add.
	 *
	 * @param array<int, array{0:int, 1:int}> $intervals Base intervals.
	 * @param string                          $date      'YYYY-MM-DD'.
	 * @return array<int, array{0:int, 1:int}>
	 */
	private function apply_exceptions( array $intervals, string $date ): array {
		$todays = array_values(
			array_filter(
				$this->exceptions,
				static function ( Availability_Exception $exception ) use ( $date ): bool {
					return $exception->date === $date;
				}
			)
		);

		foreach ( $todays as $exception ) {
			if ( $exception->is_available ) {
				continue;
			}

			if ( $exception->is_full_day() ) {
				$intervals = array();
				continue;
			}

			$intervals = $this->subtract_minute_interval(
				$intervals,
				$this->minutes_from_time_string( (string) $exception->start_time ),
				$this->minutes_from_time_string( (string) $exception->end_time )
			);
		}

		foreach ( $todays as $exception ) {
			if ( ! $exception->is_available ) {
				continue;
			}

			if ( $exception->is_full_day() ) {
				$intervals[] = array( 0, 1440 );
				continue;
			}

			$intervals[] = array(
				$this->minutes_from_time_string( (string) $exception->start_time ),
				$this->minutes_from_time_string( (string) $exception->end_time ),
			);
		}

		return $intervals;
	}

	/**
	 * Rule rows for one day of week, as sorted, merged minute-of-day pairs.
	 *
	 * @param array<int, Availability_Rule> $rules Rule set to filter.
	 * @return array<int, array{0:int, 1:int}>
	 */
	private function rules_to_minute_intervals( array $rules, int $day_of_week ): array {
		$intervals = array();

		foreach ( $rules as $rule ) {
			if ( $rule->day_of_week !== $day_of_week ) {
				continue;
			}

			$intervals[] = array(
				$this->minutes_from_time_string( $rule->start_time ),
				$this->minutes_from_time_string( $rule->end_time ),
			);
		}

		return $this->merge_minute_intervals( $intervals );
	}

	/**
	 * Sort and merge overlapping/touching minute intervals, defensively — admin-entered rows
	 * are not guaranteed non-overlapping.
	 *
	 * @param array<int, array{0:int, 1:int}> $intervals Unsorted intervals.
	 * @return array<int, array{0:int, 1:int}>
	 */
	private function merge_minute_intervals( array $intervals ): array {
		if ( empty( $intervals ) ) {
			return array();
		}

		usort(
			$intervals,
			static function ( array $a, array $b ): int {
				return $a[0] <=> $b[0];
			}
		);

		$merged = array( $intervals[0] );

		for ( $i = 1, $count = count( $intervals ); $i < $count; $i++ ) {
			$last = &$merged[ count( $merged ) - 1 ];

			if ( $intervals[ $i ][0] <= $last[1] ) {
				$last[1] = max( $last[1], $intervals[ $i ][1] );
			} else {
				$merged[] = $intervals[ $i ];
			}

			unset( $last );
		}

		return $merged;
	}

	/**
	 * Intersect two sets of minute intervals (e.g. business hours ∩ staff hours).
	 *
	 * @param array<int, array{0:int, 1:int}> $a First set.
	 * @param array<int, array{0:int, 1:int}> $b Second set.
	 * @return array<int, array{0:int, 1:int}>
	 */
	private function intersect_minute_interval_sets( array $a, array $b ): array {
		$result = array();

		foreach ( $a as $interval_a ) {
			foreach ( $b as $interval_b ) {
				$start = max( $interval_a[0], $interval_b[0] );
				$end   = min( $interval_a[1], $interval_b[1] );

				if ( $start < $end ) {
					$result[] = array( $start, $end );
				}
			}
		}

		return $result;
	}

	/**
	 * Subtract one minute range from a set of intervals, splitting as needed.
	 *
	 * @param array<int, array{0:int, 1:int}> $set          Intervals to subtract from.
	 * @param int                             $remove_start Start of the range to remove.
	 * @param int                             $remove_end   End of the range to remove.
	 * @return array<int, array{0:int, 1:int}>
	 */
	private function subtract_minute_interval( array $set, int $remove_start, int $remove_end ): array {
		$result = array();

		foreach ( $set as $interval ) {
			[ $start, $end ] = $interval;

			if ( $remove_end <= $start || $remove_start >= $end ) {
				$result[] = $interval;
				continue;
			}

			if ( $remove_start > $start ) {
				$result[] = array( $start, min( $remove_start, $end ) );
			}

			if ( $remove_end < $end ) {
				$result[] = array( max( $remove_end, $start ), $end );
			}
		}

		return $result;
	}

	/**
	 * Convert an 'HH:MM' or 'HH:MM:SS' string to minutes since midnight.
	 */
	private function minutes_from_time_string( string $time ): int {
		$parts = explode( ':', $time );

		return ( (int) ( $parts[0] ?? 0 ) ) * 60 + (int) ( $parts[1] ?? 0 );
	}

	/**
	 * Convert a minute-of-day interval on a specific date/timezone into a UTC Time_Range.
	 * $end_minute may be 1440 (midnight of the following day), which PHP's setTime() cannot
	 * represent directly — handled by rolling over to the next calendar day at 00:00.
	 */
	private function minute_interval_to_utc_range( int $start_minute, int $end_minute, \DateTimeImmutable $date_local_midnight, \DateTimeZone $reference_timezone ): Time_Range {
		$start_local = $date_local_midnight->setTime( intdiv( $start_minute, 60 ), $start_minute % 60 );

		if ( $end_minute >= 1440 ) {
			$end_local = $date_local_midnight->modify( '+1 day' )->setTime( 0, 0 );
		} else {
			$end_local = $date_local_midnight->setTime( intdiv( $end_minute, 60 ), $end_minute % 60 );
		}

		return new Time_Range(
			$start_local->setTimezone( new \DateTimeZone( 'UTC' ) ),
			$end_local->setTimezone( new \DateTimeZone( 'UTC' ) )
		);
	}
}

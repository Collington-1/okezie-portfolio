<?php
/**
 * Repository for wp_bookflow_availability_rules.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

use BookFlow\Database\Repository;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Availability_Rule_Repository
 */
final class Availability_Rule_Repository extends Repository {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'availability_rules';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'entity_type' => '%s',
			'entity_id'   => '%d',
			'day_of_week' => '%d',
			'start_time'  => '%s',
			'end_time'    => '%s',
			'created_at'  => '%s',
			'updated_at'  => '%s',
		);
	}

	/**
	 * All rules for one entity (every day of week), ordered for display.
	 *
	 * @param string   $entity_type 'business' | 'staff' | 'location'.
	 * @param int|null $entity_id   Entity ID, or null for 'business'.
	 * @return array<int, Availability_Rule>
	 */
	public static function for_entity( string $entity_type, ?int $entity_id ): array {
		global $wpdb;

		$table = static::table();

		if ( null === $entity_id ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
			$sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE entity_type = %s AND entity_id IS NULL ORDER BY day_of_week ASC, start_time ASC", $entity_type );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
			$sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE entity_type = %s AND entity_id = %d ORDER BY day_of_week ASC, start_time ASC", $entity_type, $entity_id );
		}

		$rows = $wpdb->get_results( $sql, ARRAY_A );

		return array_map( array( Availability_Rule::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Replace the full weekly schedule for one entity in a single call — the shape the admin
	 * "set working hours" screen needs (Phase 4): delete every existing row for this entity,
	 * then insert the given set.
	 *
	 * @param string                                                              $entity_type 'business' | 'staff' | 'location'.
	 * @param int|null                                                            $entity_id   Entity ID, or null for 'business'.
	 * @param array<int, array{day_of_week:int, start_time:string, end_time:string}> $rules    New rule set.
	 *
	 * @throws Validation_Exception When a row is malformed.
	 */
	public static function replace_for_entity( string $entity_type, ?int $entity_id, array $rules ): void {
		if ( ! in_array( $entity_type, Availability_Rule::entity_types(), true ) ) {
			throw new Validation_Exception( array( 'entity_type' => __( 'Invalid availability entity type.', 'bookflow-booking-scheduling' ) ) );
		}

		$sanitized = array();

		foreach ( $rules as $rule ) {
			$day = isset( $rule['day_of_week'] ) ? (int) $rule['day_of_week'] : -1;

			if ( $day < 0 || $day > 6 ) {
				throw new Validation_Exception( array( 'day_of_week' => __( 'Day of week must be between 0 and 6.', 'bookflow-booking-scheduling' ) ) );
			}

			$start = self::validate_time( $rule['start_time'] ?? '' );
			$end   = self::validate_time( $rule['end_time'] ?? '' );

			if ( null === $start || null === $end || $end <= $start ) {
				throw new Validation_Exception( array( 'end_time' => __( 'End time must be after start time.', 'bookflow-booking-scheduling' ) ) );
			}

			$sanitized[] = array(
				'entity_type' => $entity_type,
				'entity_id'   => $entity_id,
				'day_of_week' => $day,
				'start_time'  => $start,
				'end_time'    => $end,
			);
		}

		global $wpdb;

		$table = static::table();

		if ( null === $entity_id ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE entity_type = %s AND entity_id IS NULL", $entity_type ) );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE entity_type = %s AND entity_id = %d", $entity_type, $entity_id ) );
		}

		$now = Timestamps::now();

		foreach ( $sanitized as $row ) {
			$row['created_at'] = $now;
			$row['updated_at'] = $now;

			parent::insert( $row );
		}
	}

	/**
	 * Validate an 'HH:MM' or 'HH:MM:SS' time string, returning it normalized to 'HH:MM:SS', or
	 * null if invalid.
	 */
	private static function validate_time( string $time ): ?string {
		if ( ! preg_match( '/^([01]\d|2[0-3]):([0-5]\d)(:([0-5]\d))?$/', $time, $matches ) ) {
			return null;
		}

		$seconds = $matches[4] ?? '00';

		return "{$matches[1]}:{$matches[2]}:{$seconds}";
	}
}

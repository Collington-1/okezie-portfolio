<?php
/**
 * Repository for wp_bookflow_availability_exceptions.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

use BookFlow\Database\Repository;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Availability_Exception_Repository
 */
final class Availability_Exception_Repository extends Repository {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'availability_exceptions';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'entity_type'  => '%s',
			'entity_id'    => '%d',
			'date'         => '%s',
			'start_time'   => '%s',
			'end_time'     => '%s',
			'is_available' => '%d',
			'reason'       => '%s',
			'created_at'   => '%s',
			'updated_at'   => '%s',
		);
	}

	/**
	 * Fetch an exception by ID.
	 */
	public static function find( int $id ): ?Availability_Exception {
		$row = parent::find_row( $id );

		return $row ? Availability_Exception::from_row( $row ) : null;
	}

	/**
	 * All exceptions for one entity within a date range (inclusive), ordered by date.
	 *
	 * @param string   $entity_type 'business' | 'staff' | 'location'.
	 * @param int|null $entity_id   Entity ID, or null for 'business'.
	 * @param string   $from_date   'YYYY-MM-DD'.
	 * @param string   $to_date     'YYYY-MM-DD'.
	 * @return array<int, Availability_Exception>
	 */
	public static function for_entity_in_range( string $entity_type, ?int $entity_id, string $from_date, string $to_date ): array {
		global $wpdb;

		$table = static::table();

		if ( null === $entity_id ) {
			$sql = $wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
				"SELECT * FROM {$table} WHERE entity_type = %s AND entity_id IS NULL AND date BETWEEN %s AND %s ORDER BY date ASC",
				$entity_type,
				$from_date,
				$to_date
			);
		} else {
			$sql = $wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
				"SELECT * FROM {$table} WHERE entity_type = %s AND entity_id = %d AND date BETWEEN %s AND %s ORDER BY date ASC",
				$entity_type,
				$entity_id,
				$from_date,
				$to_date
			);
		}

		$rows = $wpdb->get_results( $sql, ARRAY_A );

		return array_map( array( Availability_Exception::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Create an exception.
	 *
	 * @param array<string, mixed> $input Raw input.
	 *
	 * @throws Validation_Exception When input fails validation.
	 */
	public static function create( array $input ): Availability_Exception {
		$data                = self::validate( $input, null );
		$data['created_at']  = Timestamps::now();
		$data['updated_at']  = $data['created_at'];

		$id = parent::insert( $data );

		return self::find( $id );
	}

	/**
	 * Update an exception. Fields absent from $input keep their current value.
	 *
	 * @param int                   $id    Exception ID.
	 * @param array<string, mixed>  $input Raw partial input.
	 *
	 * @throws \InvalidArgumentException When the exception does not exist.
	 * @throws Validation_Exception       When input fails validation.
	 */
	public static function update( int $id, array $input ): Availability_Exception {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: availability exception %d not found.', $id ) );
		}

		$data               = self::validate( $input, $existing );
		$data['updated_at'] = Timestamps::now();

		parent::update_row( $id, $data );

		return self::find( $id );
	}

	/**
	 * Validate and sanitize raw input.
	 *
	 * @param array<string, mixed>      $input    Raw input.
	 * @param array<string, mixed>|null $existing Existing raw row, for partial updates.
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, ?array $existing ): array {
		$get = static function ( string $key, $default ) use ( $input, $existing ) {
			if ( array_key_exists( $key, $input ) ) {
				return $input[ $key ];
			}

			if ( null !== $existing && array_key_exists( $key, $existing ) ) {
				return $existing[ $key ];
			}

			return $default;
		};

		$errors = array();

		$entity_type = (string) $get( 'entity_type', '' );

		if ( ! in_array( $entity_type, Availability_Rule::entity_types(), true ) ) {
			$errors['entity_type'] = __( 'Invalid availability entity type.', 'bookflow-booking-scheduling' );
		}

		$date = (string) $get( 'date', '' );

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			$errors['date'] = __( 'Please enter a valid date.', 'bookflow-booking-scheduling' );
		}

		$start_time_raw = $get( 'start_time', null );
		$end_time_raw   = $get( 'end_time', null );
		$start_time     = null;
		$end_time       = null;

		if ( ! empty( $start_time_raw ) || ! empty( $end_time_raw ) ) {
			$start_time = self::validate_time( (string) $start_time_raw );
			$end_time   = self::validate_time( (string) $end_time_raw );

			if ( null === $start_time || null === $end_time || $end_time <= $start_time ) {
				$errors['end_time'] = __( 'End time must be after start time.', 'bookflow-booking-scheduling' );
			}
		}

		if ( ! empty( $errors ) ) {
			throw new Validation_Exception( $errors, __( 'The availability exception could not be saved.', 'bookflow-booking-scheduling' ) );
		}

		$entity_id_raw = $get( 'entity_id', null );
		$entity_id     = ( null !== $entity_id_raw && '' !== $entity_id_raw ) ? absint( $entity_id_raw ) : null;

		return array(
			'entity_type'  => $entity_type,
			'entity_id'    => $entity_id,
			'date'         => $date,
			'start_time'   => $start_time,
			'end_time'     => $end_time,
			'is_available' => ! empty( $get( 'is_available', false ) ) ? 1 : 0,
			'reason'       => sanitize_text_field( (string) $get( 'reason', '' ) ) ?: null,
		);
	}

	/**
	 * Validate an 'HH:MM' or 'HH:MM:SS' time string, returning it normalized to 'HH:MM:SS', or
	 * null if invalid.
	 */
	private static function validate_time( string $time ): ?string {
		if ( ! preg_match( '/^([01]\d|2[0-3]):([0-5]\d)(:([0-5]\d))?$/', $time, $matches ) ) {
			return null;
		}

		$seconds = $matches[4] ?? '00';

		return "{$matches[1]}:{$matches[2]}:{$seconds}";
	}
}

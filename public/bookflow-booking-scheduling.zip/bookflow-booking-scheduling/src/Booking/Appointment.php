<?php
/**
 * Appointment entity — one row of wp_bookflow_appointments.
 *
 * @package BookFlow\Booking
 */

declare( strict_types = 1 );

namespace BookFlow\Booking;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Appointment
 */
final class Appointment {

	/**
	 * Constructor.
	 *
	 * @param int                 $id                  Row ID (internal use only — never expose publicly, use $booking_reference).
	 * @param string              $booking_reference   Public-safe random reference.
	 * @param int                 $service_id          Service ID.
	 * @param int|null            $staff_id            Assigned staff ID, if any.
	 * @param int|null            $location_id         Location ID, if any.
	 * @param int                 $customer_id         Customer ID.
	 * @param int|null            $scheduling_page_id  Originating scheduling page, if booked via one.
	 * @param \DateTimeImmutable  $start                Start instant, UTC.
	 * @param \DateTimeImmutable  $end                  End instant, UTC.
	 * @param string              $timezone             Timezone the customer booked in, for display.
	 * @param string              $status               pending | confirmed | completed | cancelled | no_show.
	 * @param float|null          $price                Price snapshot at booking time.
	 * @param string|null         $currency             Currency snapshot at booking time.
	 * @param string|null         $notes                Internal notes.
	 * @param array<string, mixed> $custom_fields        Decoded JSON custom question answers.
	 * @param int|null            $series_id            Reserved for Premium recurring appointments; unused by Free.
	 * @param string|null         $cancel_token         Public cancel-link token.
	 * @param string|null         $reschedule_token     Public reschedule-link token.
	 * @param string              $source               frontend | admin | api.
	 * @param string              $created_at           UTC DATETIME string.
	 * @param string              $updated_at           UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public string $booking_reference,
		public int $service_id,
		public ?int $staff_id,
		public ?int $location_id,
		public int $customer_id,
		public ?int $scheduling_page_id,
		public \DateTimeImmutable $start,
		public \DateTimeImmutable $end,
		public string $timezone,
		public string $status,
		public ?float $price,
		public ?string $currency,
		public ?string $notes,
		public array $custom_fields,
		public ?int $series_id,
		public ?string $cancel_token,
		public ?string $reschedule_token,
		public string $source,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Recognised `status` values, in their normal lifecycle order (see Appointment_State_Machine
	 * for allowed transitions).
	 *
	 * @return array<int, string>
	 */
	public static function statuses(): array {
		return array( 'pending', 'confirmed', 'completed', 'cancelled', 'no_show' );
	}

	/**
	 * Statuses that still hold a slot (count toward capacity/collision checks). Cancelled and
	 * no-show appointments free up their slot.
	 *
	 * @return array<int, string>
	 */
	public static function active_statuses(): array {
		return array( 'pending', 'confirmed', 'completed' );
	}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		$utc = new \DateTimeZone( 'UTC' );

		return new self(
			(int) $row['id'],
			(string) $row['booking_reference'],
			(int) $row['service_id'],
			isset( $row['staff_id'] ) && null !== $row['staff_id'] ? (int) $row['staff_id'] : null,
			isset( $row['location_id'] ) && null !== $row['location_id'] ? (int) $row['location_id'] : null,
			(int) $row['customer_id'],
			isset( $row['scheduling_page_id'] ) && null !== $row['scheduling_page_id'] ? (int) $row['scheduling_page_id'] : null,
			new \DateTimeImmutable( (string) $row['start_datetime_utc'], $utc ),
			new \DateTimeImmutable( (string) $row['end_datetime_utc'], $utc ),
			(string) $row['timezone'],
			(string) $row['status'],
			isset( $row['price'] ) && null !== $row['price'] ? (float) $row['price'] : null,
			$row['currency'] ?? null,
			$row['notes'] ?? null,
			self::decode_custom_fields( $row['custom_fields'] ?? null ),
			isset( $row['series_id'] ) && null !== $row['series_id'] ? (int) $row['series_id'] : null,
			$row['cancel_token'] ?? null,
			$row['reschedule_token'] ?? null,
			(string) $row['source'],
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}

	/**
	 * Decode the custom_fields JSON column, tolerating null/malformed values.
	 *
	 * @param string|null $json Raw JSON string.
	 * @return array<string, mixed>
	 */
	private static function decode_custom_fields( ?string $json ): array {
		if ( null === $json || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Whether this appointment still holds its slot (see active_statuses()).
	 */
	public function is_active(): bool {
		return in_array( $this->status, self::active_statuses(), true );
	}
}

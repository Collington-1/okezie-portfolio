<?php
/**
 * Services domain repository: validation, slug generation, and CRUD for wp_bookflow_services,
 * plus its staff/location pivot associations.
 *
 * @package BookFlow\Services
 */

declare( strict_types = 1 );

namespace BookFlow\Services;

use BookFlow\Database\Pivot_Table;
use BookFlow\Database\Repository;
use BookFlow\Database\Schema;
use BookFlow\Support\Slugs;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Service_Repository
 */
final class Service_Repository extends Repository {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'services';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'category_id'      => '%d',
			'name'              => '%s',
			'slug'              => '%s',
			'description'       => '%s',
			'duration_minutes'  => '%d',
			'price'             => '%f',
			'currency'          => '%s',
			'capacity'          => '%d',
			'color'             => '%s',
			'icon'              => '%s',
			'image_id'          => '%d',
			'status'            => '%s',
			'sort_order'        => '%d',
			'settings'          => '%s',
			'created_at'        => '%s',
			'updated_at'        => '%s',
		);
	}

	/**
	 * Fetch a service by ID.
	 */
	public static function find( int $id ): ?Service {
		$row = parent::find_row( $id );

		return $row ? Service::from_row( $row ) : null;
	}

	/**
	 * Fetch several services by ID in one query, keyed by id. See Repository::find_many_rows().
	 *
	 * @param array<int, int> $ids Service IDs.
	 * @return array<int, Service>
	 */
	public static function find_many( array $ids ): array {
		return array_map( array( Service::class, 'from_row' ), parent::find_many_rows( $ids ) );
	}

	/**
	 * Fetch a service by its unique slug.
	 */
	public static function find_by_slug( string $slug ): ?Service {
		$row = self::find_by( 'slug', $slug, '%s' );

		return $row ? Service::from_row( $row ) : null;
	}

	/**
	 * List services.
	 *
	 * @param array{status?: string, category_id?: int, search?: string, orderby?: string, order?: string, limit?: int, offset?: int} $args Filter/pagination args.
	 * @return array<int, Service>
	 */
	public static function all( array $args = array() ): array {
		global $wpdb;

		$table  = static::table();
		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = (string) $args['status'];
		}

		if ( ! empty( $args['category_id'] ) ) {
			$where[]  = 'category_id = %d';
			$params[] = (int) $args['category_id'];
		}

		if ( ! empty( $args['search'] ) ) {
			$where[]  = 'name LIKE %s';
			$params[] = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
		}

		$orderby = in_array( $args['orderby'] ?? '', array( 'name', 'sort_order', 'created_at' ), true )
			? $args['orderby']
			: 'sort_order';
		$order   = 'DESC' === strtoupper( $args['order'] ?? '' ) ? 'DESC' : 'ASC';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $orderby/$order are whitelisted above, not user input; $where clause placeholders are still parameterized below.
		$sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . " ORDER BY {$orderby} {$order}";

		if ( ! empty( $args['limit'] ) ) {
			$sql     .= ' LIMIT %d OFFSET %d';
			$params[] = (int) $args['limit'];
			$params[] = (int) ( $args['offset'] ?? 0 );
		}

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql built from trusted fragments above; prepared whenever placeholders are present.
		$rows     = $wpdb->get_results( $prepared, ARRAY_A );

		return array_map( array( Service::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Create a new service.
	 *
	 * @param array<string, mixed> $input Raw input (e.g. from an admin form or REST request).
	 *
	 * @throws Validation_Exception When input fails validation.
	 */
	public static function create( array $input ): Service {
		$data                = self::validate( $input, null, null );
		$data['created_at']  = Timestamps::now();
		$data['updated_at']  = $data['created_at'];

		$id = parent::insert( $data );

		return self::find( $id );
	}

	/**
	 * Update an existing service. Fields absent from $input keep their current value.
	 *
	 * @param int                   $id    Service ID.
	 * @param array<string, mixed>  $input Raw partial input.
	 *
	 * @throws \InvalidArgumentException When the service does not exist.
	 * @throws Validation_Exception       When input fails validation.
	 */
	public static function update( int $id, array $input ): Service {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: service %d not found.', $id ) );
		}

		$data               = self::validate( $input, $id, $existing );
		$data['updated_at'] = Timestamps::now();

		parent::update_row( $id, $data );

		return self::find( $id );
	}

	/**
	 * Delete a service and its staff/location associations.
	 */
	public static function delete( int $id ): bool {
		Pivot_Table::delete_all_for( Schema::table( 'staff_services' ), 'service_id', $id );
		Pivot_Table::delete_all_for( Schema::table( 'service_locations' ), 'service_id', $id );

		return parent::delete( $id );
	}

	/**
	 * IDs of staff assigned to a service.
	 *
	 * @return array<int, int>
	 */
	public static function staff_ids( int $service_id ): array {
		return Pivot_Table::left_ids_for( Schema::table( 'staff_services' ), 'staff_id', 'service_id', $service_id );
	}

	/**
	 * Replace the full set of staff assigned to a service.
	 *
	 * @param array<int, int> $staff_ids Staff IDs.
	 */
	public static function set_staff( int $service_id, array $staff_ids ): void {
		Pivot_Table::sync( Schema::table( 'staff_services' ), 'service_id', 'staff_id', $service_id, $staff_ids );
	}

	/**
	 * IDs of locations a service is offered at.
	 *
	 * @return array<int, int>
	 */
	public static function location_ids( int $service_id ): array {
		return Pivot_Table::right_ids_for( Schema::table( 'service_locations' ), 'service_id', 'location_id', $service_id );
	}

	/**
	 * Replace the full set of locations a service is offered at.
	 *
	 * @param array<int, int> $location_ids Location IDs.
	 */
	public static function set_locations( int $service_id, array $location_ids ): void {
		Pivot_Table::sync( Schema::table( 'service_locations' ), 'service_id', 'location_id', $service_id, $location_ids );
	}

	/**
	 * Validate and sanitize raw input into a column => value map ready for insert()/update().
	 *
	 * @param array<string, mixed>      $input        Raw input.
	 * @param int|null                  $excluding_id  Service ID to exclude from the slug
	 *                                                   uniqueness check (update only).
	 * @param array<string, mixed>|null $existing      Existing raw row, used to fill in any
	 *                                                   field absent from $input on update.
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, ?int $excluding_id, ?array $existing ): array {
		$get = static function ( string $key, $default ) use ( $input, $existing ) {
			if ( array_key_exists( $key, $input ) ) {
				return $input[ $key ];
			}

			if ( null !== $existing && array_key_exists( $key, $existing ) ) {
				return $existing[ $key ];
			}

			return $default;
		};

		$errors = array();

		$name = trim( sanitize_text_field( (string) $get( 'name', '' ) ) );

		if ( '' === $name ) {
			$errors['name'] = __( 'Service name is required.', 'bookflow-booking-scheduling' );
		}

		$duration_minutes = (int) $get( 'duration_minutes', 30 );

		if ( $duration_minutes < 1 ) {
			$errors['duration_minutes'] = __( 'Duration must be at least 1 minute.', 'bookflow-booking-scheduling' );
		}

		$capacity = (int) $get( 'capacity', 1 );

		if ( $capacity < 1 ) {
			$errors['capacity'] = __( 'Capacity must be at least 1.', 'bookflow-booking-scheduling' );
		}

		$price_raw = $get( 'price', null );
		$price     = null;

		if ( null !== $price_raw && '' !== $price_raw ) {
			$price = (float) $price_raw;

			if ( $price < 0 ) {
				$errors['price'] = __( 'Price cannot be negative.', 'bookflow-booking-scheduling' );
			}
		}

		$status = (string) $get( 'status', 'active' );

		if ( ! in_array( $status, Service::statuses(), true ) ) {
			$errors['status'] = __( 'Invalid service status.', 'bookflow-booking-scheduling' );
		}

		$color = $get( 'color', null );

		if ( null !== $color && '' !== $color && ! preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $color ) ) {
			$errors['color'] = __( 'Color must be a hex value like #4C6EF5.', 'bookflow-booking-scheduling' );
		}

		$currency = $get( 'currency', null );

		if ( null !== $currency && '' !== $currency && ! preg_match( '/^[A-Z]{3}$/', (string) $currency ) ) {
			$errors['currency'] = __( 'Currency must be a 3-letter ISO 4217 code.', 'bookflow-booking-scheduling' );
		}

		if ( ! empty( $errors ) ) {
			throw new Validation_Exception( $errors, __( 'The service could not be saved.', 'bookflow-booking-scheduling' ) );
		}

		$category_id_raw = $get( 'category_id', null );
		$category_id     = ( null !== $category_id_raw && '' !== $category_id_raw ) ? absint( $category_id_raw ) : null;

		$image_id_raw = $get( 'image_id', null );
		$image_id     = ( null !== $image_id_raw && '' !== $image_id_raw ) ? absint( $image_id_raw ) : null;

		$slug_input = $get( 'slug', '' );
		$slug       = '' !== trim( (string) $slug_input ) ? sanitize_title( (string) $slug_input ) : null;

		if ( null === $slug || '' === $slug ) {
			$slug = Slugs::unique(
				$name,
				static function ( string $candidate ) use ( $excluding_id ): bool {
					return self::exists_by( 'slug', $candidate, '%s', $excluding_id );
				},
				'service'
			);
		} elseif ( self::exists_by( 'slug', $slug, '%s', $excluding_id ) ) {
			$slug = Slugs::unique(
				$slug,
				static function ( string $candidate ) use ( $excluding_id ): bool {
					return self::exists_by( 'slug', $candidate, '%s', $excluding_id );
				},
				'service'
			);
		}

		$settings = $get( 'settings', array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		return array(
			'category_id'      => $category_id,
			'name'              => $name,
			'slug'              => $slug,
			'description'       => wp_kses_post( (string) $get( 'description', '' ) ),
			'duration_minutes'  => $duration_minutes,
			'price'             => $price,
			'currency'          => $currency ? strtoupper( (string) $currency ) : null,
			'capacity'          => $capacity,
			'color'             => $color ? sanitize_hex_color( (string) $color ) : null,
			'icon'              => sanitize_text_field( (string) $get( 'icon', '' ) ) ?: null,
			'image_id'          => $image_id,
			'status'            => $status,
			'sort_order'        => (int) $get( 'sort_order', 0 ),
			'settings'          => wp_json_encode( $settings ),
		);
	}
}

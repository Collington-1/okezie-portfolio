<?php
/**
 * Service entity (value object) — the in-memory representation of one row of
 * wp_bookflow_services. See docs/DATABASE-SCHEMA.md.
 *
 * @package BookFlow\Services
 */

declare( strict_types = 1 );

namespace BookFlow\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Service
 *
 * Plain constructor-promoted properties rather than `readonly` — BookFlow's declared minimum
 * is PHP 8.0, and `readonly` properties require PHP 8.1. See docs/ARCHITECTURE.md §3/§16.
 */
final class Service {

	/**
	 * Constructor.
	 *
	 * @param int         $id               Row ID.
	 * @param int|null    $category_id      Owning category ID, if any.
	 * @param string      $name             Service name.
	 * @param string      $slug             Unique slug.
	 * @param string|null $description      Description (may contain limited HTML).
	 * @param int         $duration_minutes Default duration in minutes.
	 * @param float|null  $price            Price, or null for "no price set".
	 * @param string|null $currency         ISO 4217 currency code, or null to use the site default.
	 * @param int         $capacity         Seats per booking slot (1 = one customer at a time).
	 * @param string|null $color            Hex color for the admin calendar.
	 * @param string|null $icon             Icon identifier.
	 * @param int|null    $image_id         Attachment ID.
	 * @param string      $status           'active' | 'inactive' | 'archived'.
	 * @param int         $sort_order       Manual sort order.
	 * @param array<string, mixed> $settings Decoded JSON settings (buffers, notice window, etc.).
	 * @param string      $created_at       UTC DATETIME string.
	 * @param string      $updated_at       UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public ?int $category_id,
		public string $name,
		public string $slug,
		public ?string $description,
		public int $duration_minutes,
		public ?float $price,
		public ?string $currency,
		public int $capacity,
		public ?string $color,
		public ?string $icon,
		public ?int $image_id,
		public string $status,
		public int $sort_order,
		public array $settings,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Recognised `status` values.
	 *
	 * @return array<int, string>
	 */
	public static function statuses(): array {
		return array( 'active', 'inactive', 'archived' );
	}

	/**
	 * Build a Service from a raw database row (as returned by Database\Repository::find()).
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		return new self(
			(int) $row['id'],
			isset( $row['category_id'] ) && null !== $row['category_id'] ? (int) $row['category_id'] : null,
			(string) $row['name'],
			(string) $row['slug'],
			$row['description'] ?? null,
			(int) $row['duration_minutes'],
			isset( $row['price'] ) && null !== $row['price'] ? (float) $row['price'] : null,
			$row['currency'] ?? null,
			(int) $row['capacity'],
			$row['color'] ?? null,
			$row['icon'] ?? null,
			isset( $row['image_id'] ) && null !== $row['image_id'] ? (int) $row['image_id'] : null,
			(string) $row['status'],
			(int) $row['sort_order'],
			self::decode_settings( $row['settings'] ?? null ),
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}

	/**
	 * Decode the settings JSON column, tolerating null/empty/malformed values by falling back
	 * to an empty settings array rather than throwing — a corrupted settings blob should never
	 * make a service unloadable.
	 *
	 * @param string|null $json Raw JSON string from the database.
	 * @return array<string, mixed>
	 */
	private static function decode_settings( ?string $json ): array {
		if ( null === $json || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * A settings value with a default fallback, e.g. `$service->setting( 'buffer_before_minutes', 0 )`.
	 *
	 * @param string $key     Settings key.
	 * @param mixed  $default Default value if the key is absent.
	 */
	public function setting( string $key, $default = null ) {
		return $this->settings[ $key ] ?? $default;
	}
}

<?php
/**
 * Service category entity — one row of wp_bookflow_service_categories.
 *
 * @package BookFlow\Services
 */

declare( strict_types = 1 );

namespace BookFlow\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Service_Category
 */
final class Service_Category {

	/**
	 * Constructor.
	 *
	 * @param int         $id          Row ID.
	 * @param string      $name        Category name.
	 * @param string      $slug        Unique slug.
	 * @param string|null $description Description.
	 * @param int         $sort_order  Manual sort order.
	 * @param string      $created_at  UTC DATETIME string.
	 * @param string      $updated_at  UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public string $name,
		public string $slug,
		public ?string $description,
		public int $sort_order,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		return new self(
			(int) $row['id'],
			(string) $row['name'],
			(string) $row['slug'],
			$row['description'] ?? null,
			(int) $row['sort_order'],
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}
}

<?php
/**
 * Repository for wp_bookflow_service_categories.
 *
 * @package BookFlow\Services
 */

declare( strict_types = 1 );

namespace BookFlow\Services;

use BookFlow\Database\Repository;
use BookFlow\Database\Schema;
use BookFlow\Support\Slugs;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Service_Category_Repository
 */
final class Service_Category_Repository extends Repository {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'service_categories';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'name'        => '%s',
			'slug'        => '%s',
			'description' => '%s',
			'sort_order'  => '%d',
			'created_at'  => '%s',
			'updated_at'  => '%s',
		);
	}

	/**
	 * Fetch a category by ID.
	 */
	public static function find( int $id ): ?Service_Category {
		$row = parent::find_row( $id );

		return $row ? Service_Category::from_row( $row ) : null;
	}

	/**
	 * List all categories, ordered for display.
	 *
	 * @return array<int, Service_Category>
	 */
	public static function all(): array {
		global $wpdb;

		$table = static::table();
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant, no user input/placeholders involved.
		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY sort_order ASC, name ASC", ARRAY_A );

		return array_map( array( Service_Category::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Create a category.
	 *
	 * @param array<string, mixed> $input Raw input.
	 *
	 * @throws Validation_Exception When input fails validation.
	 */
	public static function create( array $input ): Service_Category {
		$data               = self::validate( $input, null, null );
		$data['created_at'] = Timestamps::now();
		$data['updated_at'] = $data['created_at'];

		$id = parent::insert( $data );

		return self::find( $id );
	}

	/**
	 * Update a category. Fields absent from $input keep their current value.
	 *
	 * @param int                  $id    Category ID.
	 * @param array<string, mixed> $input Raw partial input.
	 *
	 * @throws \InvalidArgumentException When the category does not exist.
	 * @throws Validation_Exception       When input fails validation.
	 */
	public static function update( int $id, array $input ): Service_Category {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: service category %d not found.', $id ) );
		}

		$data               = self::validate( $input, $id, $existing );
		$data['updated_at'] = Timestamps::now();

		parent::update_row( $id, $data );

		return self::find( $id );
	}

	/**
	 * Delete a category. Services in this category are not deleted — they are simply
	 * uncategorised (category_id set to NULL), matching the "category_id BIGINT UNSIGNED NULL"
	 * schema design; a service must never disappear because its category was removed.
	 */
	public static function delete( int $id ): bool {
		global $wpdb;

		$services_table = Schema::table( 'services' );

		$wpdb->update(
			$services_table,
			array( 'category_id' => null ),
			array( 'category_id' => $id ),
			array( '%d' ),
			array( '%d' )
		);

		return parent::delete( $id );
	}

	/**
	 * Validate and sanitize raw input.
	 *
	 * @param array<string, mixed>      $input        Raw input.
	 * @param int|null                  $excluding_id Category ID to exclude from the slug
	 *                                                  uniqueness check (update only).
	 * @param array<string, mixed>|null $existing     Existing raw row, for partial updates.
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, ?int $excluding_id, ?array $existing ): array {
		$get = static function ( string $key, $default ) use ( $input, $existing ) {
			if ( array_key_exists( $key, $input ) ) {
				return $input[ $key ];
			}

			if ( null !== $existing && array_key_exists( $key, $existing ) ) {
				return $existing[ $key ];
			}

			return $default;
		};

		$name = trim( sanitize_text_field( (string) $get( 'name', '' ) ) );

		if ( '' === $name ) {
			throw new Validation_Exception(
				array( 'name' => __( 'Category name is required.', 'bookflow-booking-scheduling' ) ),
				__( 'The category could not be saved.', 'bookflow-booking-scheduling' )
			);
		}

		$slug_input = $get( 'slug', '' );
		$slug       = '' !== trim( (string) $slug_input ) ? sanitize_title( (string) $slug_input ) : null;

		if ( null === $slug || '' === $slug || self::exists_by( 'slug', $slug, '%s', $excluding_id ) ) {
			$slug = Slugs::unique(
				$slug ? $slug : $name,
				static function ( string $candidate ) use ( $excluding_id ): bool {
					return self::exists_by( 'slug', $candidate, '%s', $excluding_id );
				},
				'category'
			);
		}

		return array(
			'name'        => $name,
			'slug'        => $slug,
			'description' => wp_kses_post( (string) $get( 'description', '' ) ),
			'sort_order'  => (int) $get( 'sort_order', 0 ),
		);
	}
}

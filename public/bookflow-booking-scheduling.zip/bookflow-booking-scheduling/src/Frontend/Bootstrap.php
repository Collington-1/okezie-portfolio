<?php
/**
 * Frontend module bootstrap: the shortcode, its AJAX endpoints, the public manage-booking
 * (cancel/reschedule) view, and asset loading.
 *
 * @package BookFlow\Frontend
 */

declare( strict_types = 1 );

namespace BookFlow\Frontend;

use BookFlow\Support\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Bootstrap
 */
final class Bootstrap {

	/**
	 * Register frontend hooks. Called unconditionally from Plugin::boot_modules() — unlike
	 * Admin\Bootstrap, this must NOT be gated behind is_admin(), because admin-ajax.php
	 * requests (where the wp_ajax_* handlers below actually run) report is_admin() === true.
	 */
	public static function init(): void {
		Booking_Shortcode::init();
		Manage_Booking::init();
		Ajax_Handlers::init();

		// Registration lives on 'init', not 'wp_enqueue_scripts', so the handles always exist
		// before ANY other code's own 'wp_enqueue_scripts' callback could run — including a page
		// builder like Elementor, which collects each of its widgets' declared style/script
		// dependencies (Elementor\Booking_Widget::get_style_depends(), etc.) and calls
		// wp_enqueue_style()/wp_enqueue_script() on them from its OWN 'wp_enqueue_scripts' hook.
		// Same-priority callbacks on one action run in the order they were added, which here
		// depends on plugin ACTIVATION order (the `active_plugins` option), not load-order
		// coincidence — a site that activated Elementor before BookFlow would otherwise run
		// Elementor's enqueue-collection before this method ever registered the handles it's
		// trying to enqueue, silently dropping BookFlow's styles/scripts on any page using a
		// BookFlow Elementor widget. Registering on 'init' (which always finishes before
		// 'wp_enqueue_scripts' fires at all) removes the ordering dependency entirely.
		add_action( 'init', array( self::class, 'register_assets' ) );
		add_action( 'wp_enqueue_scripts', array( self::class, 'maybe_enqueue_assets' ) );
	}

	/**
	 * Register (never enqueue) the shared frontend style/script. Cheap, unconditional, and must
	 * run before anything — including a page builder's own dependency collection — might try to
	 * enqueue either handle. See the comment on init() for why this isn't just folded into
	 * maybe_enqueue_assets() below.
	 */
	public static function register_assets(): void {
		wp_register_style( 'bookflow-frontend', BOOKFLOW_PLUGIN_URL . 'assets/css/frontend.css', array(), Constants::VERSION );
		wp_register_script( 'bookflow-booking-form', BOOKFLOW_PLUGIN_URL . 'assets/js/booking-form.js', array(), Constants::VERSION, true );
	}

	/**
	 * Enqueue frontend assets only when a booking component is actually present on the page
	 * (Section 10: "Load frontend assets only when a booking/scheduling component is present").
	 */
	public static function maybe_enqueue_assets(): void {
		if ( ! self::page_needs_assets() ) {
			return;
		}

		wp_enqueue_style( 'bookflow-frontend' );
		wp_enqueue_script( 'bookflow-booking-form' );
	}

	/**
	 * Whether the current request will render a BookFlow frontend component: the shortcode is
	 * present in the queried content, or this is the manage-booking virtual endpoint.
	 */
	private static function page_needs_assets(): bool {
		if ( Manage_Booking::is_manage_booking_request() ) {
			return true;
		}

		if ( ! is_singular() ) {
			return false;
		}

		$post = get_queried_object();

		if ( ! ( $post instanceof \WP_Post ) ) {
			return false;
		}

		// Not has_shortcode() alone: a page built with the Gutenberg block instead of the
		// shortcode has no '[bookflow_booking]' text anywhere in post_content (blocks are
		// stored as an HTML comment, '<!-- wp:bookflow/booking-form ... -->') — confirmed
		// against a real WordPress install that the block rendered its markup fine but the
		// widget was permanently stuck on "Loading…" because this check never found it and the
		// required JS/CSS never got enqueued at all. This bug had been present, unnoticed, since
		// the block shipped in Phase 9 — see docs/ROADMAP.md.
		return has_shortcode( (string) $post->post_content, Booking_Shortcode::TAG )
			|| has_block( 'bookflow/booking-form', $post );
	}
}

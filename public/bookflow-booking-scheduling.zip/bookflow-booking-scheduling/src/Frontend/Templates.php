<?php
/**
 * Tiny template loader: renders a file from templates/ with the given variables in scope,
 * output-buffered. Deliberately minimal — not a templating engine, just avoids repeating the
 * ob_start()/extract()/include/ob_get_clean() boilerplate at every call site. Overridable in
 * principle by a child theme copying templates/ into
 * {theme}/bookflow-booking-scheduling/{name}.php — see locate().
 *
 * @package BookFlow\Frontend
 */

declare( strict_types = 1 );

namespace BookFlow\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Templates
 */
final class Templates {

	/**
	 * Render a template file with $vars extracted into its scope.
	 *
	 * @param string               $name Template name, without .php (e.g. 'booking-form').
	 * @param array<string, mixed> $vars Variables to make available to the template.
	 */
	public static function render( string $name, array $vars = array() ): string {
		$file = self::locate( $name );

		if ( null === $file ) {
			return '';
		}

		ob_start();
		( static function ( string $bookflow_template_file, array $bookflow_template_vars ): void {
			extract( $bookflow_template_vars ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- intentional, isolated template-variable scope; see class docblock.
			include $bookflow_template_file;
		} )( $file, $vars );

		return (string) ob_get_clean();
	}

	/**
	 * Locate a template file: a matching file in the active theme's
	 * /bookflow-booking-scheduling/ directory wins first (override support), falling back to
	 * the plugin's own templates/ directory. Public — also used directly by Manage_Booking's
	 * `template_include` filter, which needs a file path rather than rendered output.
	 */
	public static function locate( string $name ): ?string {
		$relative     = 'bookflow-booking-scheduling/' . $name . '.php';
		$theme_file   = locate_template( $relative );

		if ( '' !== $theme_file ) {
			return $theme_file;
		}

		$plugin_file = BOOKFLOW_PLUGIN_DIR . 'templates/' . $name . '.php';

		return is_readable( $plugin_file ) ? $plugin_file : null;
	}
}

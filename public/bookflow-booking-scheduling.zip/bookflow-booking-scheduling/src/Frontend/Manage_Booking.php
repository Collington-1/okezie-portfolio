<?php
/**
 * The public "manage your booking" view — view details, cancel, or reschedule — reached via a
 * plain query-string link (`?bookflow_manage=<token>`, no rewrite rules/permalink flush needed)
 * rather than requiring the site owner to create a dedicated WordPress page first. Section 17:
 * booking confirmation emails need a working cancellation link and reschedule link the moment
 * BookFlow is activated, not only once an admin has built a page for it.
 *
 * @package BookFlow\Frontend
 */

declare( strict_types = 1 );

namespace BookFlow\Frontend;

use BookFlow\Booking\Appointment;
use BookFlow\Booking\Appointment_Repository;
use BookFlow\Booking\Appointment_State_Machine;
use BookFlow\Support\Rate_Limiter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Manage_Booking
 */
final class Manage_Booking {

	/**
	 * Query var carrying the cancel/reschedule token.
	 *
	 * @var string
	 */
	private const QUERY_VAR = 'bookflow_manage';

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_filter( 'query_vars', array( self::class, 'add_query_var' ) );
		add_filter( 'template_include', array( self::class, 'maybe_render' ) );
		add_action( 'template_redirect', array( self::class, 'maybe_handle_cancel' ) );
	}

	/**
	 * Register the query var so `?bookflow_manage=...` is readable via get_query_var() without
	 * needing a rewrite rule.
	 *
	 * @param array<int, string> $vars Existing public query vars.
	 * @return array<int, string>
	 */
	public static function add_query_var( array $vars ): array {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	/**
	 * Whether the current request is for the manage-booking view.
	 */
	public static function is_manage_booking_request(): bool {
		return '' !== (string) get_query_var( self::QUERY_VAR, '' );
	}

	/**
	 * Swap in our own template (still rendered through the active theme's get_header()/
	 * get_footer(), for consistent site chrome) when the manage-booking query var is present.
	 *
	 * @param string $template Original template path WordPress would have used.
	 */
	public static function maybe_render( string $template ): string {
		if ( ! self::is_manage_booking_request() ) {
			return $template;
		}

		$found = Templates::locate( 'manage-booking' );

		return $found ?? $template;
	}

	/**
	 * Handle the "Cancel this booking" POST before any output is sent, redirecting back to the
	 * same manage-booking URL with a result flag afterward (POST/redirect/GET — reloading the
	 * confirmation page never re-submits the cancellation).
	 */
	public static function maybe_handle_cancel(): void {
		if ( ! self::is_manage_booking_request() ) {
			return;
		}

		if ( ! isset( $_POST['bookflow_action'] ) || 'cancel_booking' !== $_POST['bookflow_action'] ) {
			return;
		}

		// Defense-in-depth alongside the nonce check below: cancelling requires already
		// possessing a valid high-entropy token, so this isn't exploitable the way create/
		// register endpoints are without one — but rate-limiting it too costs nothing and
		// keeps this consistent with every other public state-changing endpoint in the plugin.
		if ( ! Rate_Limiter::allow( 'cancel_booking_' . Rate_Limiter::client_identity(), 8, 300 ) ) {
			wp_die( esc_html__( 'Too many attempts. Please wait a few minutes and try again.', 'bookflow-booking-scheduling' ), 429 );
		}

		$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		$nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';

		// A plain wp_verify_nonce() rather than check_admin_referer(): the latter's failure
		// screen (wp_nonce_ays()) is styled for wp-admin and would look broken on the public
		// site. Token possession is already the real authorization here (see class docblock);
		// the nonce is defense-in-depth against a stray cross-site form post, so failing it
		// silently (just redirect back, nothing cancelled) is the right behavior, not a wp_die().
		if ( ! wp_verify_nonce( $nonce, 'bookflow_cancel_booking_' . $token ) ) {
			wp_safe_redirect( self::url( $token ) );
			exit;
		}

		$appointment = self::find_by_token( $token );

		if ( null !== $appointment && Appointment_State_Machine::can_transition( $appointment->status, 'cancelled' ) ) {
			Appointment_State_Machine::transition( $appointment, 'cancelled', null, __( 'Cancelled by customer.', 'bookflow-booking-scheduling' ) );
		}

		wp_safe_redirect( self::url( $token ) );
		exit;
	}

	/**
	 * The public manage-booking URL for a given cancel or reschedule token (either works — see
	 * find_by_token()).
	 */
	public static function url( string $token ): string {
		return add_query_arg( self::QUERY_VAR, $token, home_url( '/' ) );
	}

	/**
	 * Resolve an appointment from either its cancel_token or reschedule_token — both link types
	 * land on the same unified manage view (see class docblock).
	 */
	public static function find_by_token( string $token ): ?Appointment {
		if ( '' === $token ) {
			return null;
		}

		return Appointment_Repository::find_by_cancel_token( $token ) ?? Appointment_Repository::find_by_reschedule_token( $token );
	}
}

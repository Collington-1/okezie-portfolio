<?php
/**
 * Public AJAX endpoints for the booking widget, via WordPress's classic admin-ajax.php
 * mechanism rather than a REST controller — a deliberate Phase 5 scoping choice (see
 * docs/ARCHITECTURE.md §17): it needs no build step and no new REST-specific security surface,
 * consistent with the rest of the frontend widget being framework-free vanilla JS. Phase 9
 * ("Api\Bootstrap") adds the proper REST API for developer/headless use; these handlers can stay
 * alongside it or be superseded, a decision deferred to that phase.
 *
 * Every handler here is reachable by anyone, logged in or not (`wp_ajax_nopriv_*` +
 * `wp_ajax_*`) — Section 9's "never trust frontend data" applies in full: every value is
 * re-validated server-side regardless of what the client claims, and create/reschedule are
 * rate-limited (Section 9: "Rate-limit or otherwise protect public booking endpoints").
 *
 * @package BookFlow\Frontend
 */

declare( strict_types = 1 );

namespace BookFlow\Frontend;

use BookFlow\Booking\Appointment_Repository;
use BookFlow\Booking\Availability_Service;
use BookFlow\Booking\Booking_Conflict_Exception;
use BookFlow\Booking\Time_Range;
use BookFlow\Customers\Customer;
use BookFlow\Customers\Customer_Repository;
use BookFlow\CustomFields\Custom_Field_Repository;
use BookFlow\Scheduling\Scheduling_Page;
use BookFlow\Scheduling\Scheduling_Page_Repository;
use BookFlow\Services\Service;
use BookFlow\Services\Service_Repository;
use BookFlow\Support\Rate_Limiter;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Ajax_Handlers
 */
final class Ajax_Handlers {

	/**
	 * Register the AJAX actions.
	 */
	public static function init(): void {
		foreach ( array( '', 'nopriv_' ) as $prefix ) {
			add_action( "wp_ajax_{$prefix}bookflow_get_slots", array( self::class, 'get_slots' ) );
			add_action( "wp_ajax_{$prefix}bookflow_create_booking", array( self::class, 'create_booking' ) );
			add_action( "wp_ajax_{$prefix}bookflow_reschedule_booking", array( self::class, 'reschedule_booking' ) );
		}
	}

	/**
	 * `bookflow_get_slots` — available slots for one service/staff/location/date, in the
	 * customer's own timezone. Also used for reschedule mode (an `appointment_token` present
	 * excludes that appointment's own current slot from the conflict check).
	 */
	public static function get_slots(): void {
		check_ajax_referer( 'bookflow_booking', 'nonce' );

		// Read-only, so a lighter/more generous limit than create/reschedule — this fires on
		// every date change during completely normal use of the widget — but still bounded:
		// availability computation runs several real queries per call, and an unauthenticated,
		// unbounded endpoint is a resource-exhaustion vector even without writing any data.
		if ( ! Rate_Limiter::allow( 'get_slots_' . Rate_Limiter::client_identity(), 60, 60 ) ) {
			wp_send_json_error( array( 'message' => __( 'Too many requests. Please slow down and try again.', 'bookflow-booking-scheduling' ) ), 429 );
		}

		$service          = self::require_service();
		$scheduling_page  = self::optional_scheduling_page( $service );
		$rule_overrides   = $scheduling_page ? $scheduling_page->effective_rules_for( $service ) : null;

		$excluding_id = null;
		$staff_id     = null;
		$location_id  = null;

		$token = isset( $_POST['appointment_token'] ) ? sanitize_text_field( wp_unslash( $_POST['appointment_token'] ) ) : '';

		if ( '' !== $token ) {
			$appointment = Manage_Booking::find_by_token( $token );

			if ( null === $appointment || $appointment->service_id !== $service->id ) {
				wp_send_json_error( array( 'message' => __( 'Booking not found.', 'bookflow-booking-scheduling' ) ), 404 );
			}

			$excluding_id = $appointment->id;
			$staff_id     = $appointment->staff_id;
			$location_id  = $appointment->location_id;
		} elseif ( $scheduling_page ) {
			// A scheduling page is inherently tied to one staff member — never client-selectable.
			$staff_id    = $scheduling_page->staff_id;
			$location_id = self::valid_location_id( $service->id );
		} else {
			$staff_id    = self::valid_staff_id( $service->id );
			$location_id = self::valid_location_id( $service->id );
		}

		$customer_timezone = self::customer_timezone();
		$date_str           = self::require_date();

		try {
			$day_local = new \DateTimeImmutable( $date_str . ' 00:00:00', $customer_timezone );
		} catch ( \Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
			wp_send_json_error( array( 'message' => __( 'Invalid date.', 'bookflow-booking-scheduling' ) ), 400 );
			return;
		}

		$slots = Availability_Service::slots_for_customer_day( $service, $staff_id, $location_id, $day_local, $customer_timezone, $excluding_id, $rule_overrides );

		wp_send_json_success(
			array(
				'slots' => array_map(
					static fn( Time_Range $slot ) => array(
						'start' => $slot->start->format( DATE_ATOM ),
						'end'   => $slot->end->format( DATE_ATOM ),
					),
					$slots
				),
			)
		);
	}

	/**
	 * `bookflow_create_booking` — create a new appointment from the widget's final step.
	 */
	public static function create_booking(): void {
		check_ajax_referer( 'bookflow_booking', 'nonce' );

		if ( ! Rate_Limiter::allow( 'create_booking_' . Rate_Limiter::client_identity(), 8, 300 ) ) {
			wp_send_json_error( array( 'message' => __( 'Too many booking attempts. Please wait a few minutes and try again.', 'bookflow-booking-scheduling' ) ), 429 );
		}

		$service         = self::require_service();
		$scheduling_page = self::optional_scheduling_page( $service );
		$rule_overrides  = $scheduling_page ? $scheduling_page->effective_rules_for( $service ) : null;

		if ( $scheduling_page ) {
			$staff_id    = $scheduling_page->staff_id;
			$location_id = self::valid_location_id( $service->id );
		} else {
			$staff_id    = self::valid_staff_id( $service->id );
			$location_id = self::valid_location_id( $service->id );
		}

		$start = self::require_start();
		$timezone_name = self::customer_timezone()->getName();

		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';

		if ( ! is_email( $email ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Please enter a valid email address.', 'bookflow-booking-scheduling' ),
					'errors'  => array( 'email' => __( 'Please enter a valid email address.', 'bookflow-booking-scheduling' ) ),
				),
				422
			);
		}

		[ $custom_field_answers, $custom_field_errors ] = self::collect_custom_field_answers( $service, $scheduling_page );

		if ( ! empty( $custom_field_errors ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Please check your answers.', 'bookflow-booking-scheduling' ),
					'errors'  => $custom_field_errors,
				),
				422
			);
		}

		try {
			$customer = Customer_Repository::find_or_create_by_email(
				$email,
				array(
					'first_name' => isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '',
					'last_name'  => isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '',
					'phone'      => isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '',
				)
			);

			$approval_required = $scheduling_page ? $scheduling_page->approval_required : (bool) $service->setting( 'approval_required', false );
			$status             = $approval_required ? 'pending' : 'confirmed';

			/**
			 * Filters the status a new booking is created with — the intended extension point
			 * for a payment-gate Premium integration (Section 3) to hold a booking as 'pending'
			 * until payment clears, the same way "requires approval" already does, without the
			 * two concepts needing to be conflated in Free's own settings. Must return one of
			 * Appointment::statuses(); an invalid value is rejected by
			 * Appointment_Repository::validate() the same as any other bad input. See
			 * docs/ARCHITECTURE.md §24.
			 *
			 * @param string                $status           'pending' or 'confirmed', per $approval_required above.
			 * @param Service               $service          The service being booked.
			 * @param Customer              $customer         The customer booking it.
			 * @param Scheduling_Page|null  $scheduling_page  The scheduling page this booking came through, if any.
			 */
			$status = (string) apply_filters( 'bookflow_new_appointment_status', $status, $service, $customer, $scheduling_page );

			$appointment = Appointment_Repository::create(
				array(
					'service_id'          => $service->id,
					'staff_id'            => $staff_id,
					'location_id'         => $location_id,
					'customer_id'         => $customer->id,
					'scheduling_page_id'  => $scheduling_page ? $scheduling_page->id : null,
					'start'               => $start,
					'timezone'            => $timezone_name,
					'status'              => $status,
					'notes'               => isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '',
					'custom_fields'       => $custom_field_answers,
					'rule_overrides'      => $rule_overrides,
					'source'              => 'frontend',
				)
			);

			wp_send_json_success(
				array(
					'reference' => $appointment->booking_reference,
					'status'    => $appointment->status,
					'manageUrl' => Manage_Booking::url( (string) $appointment->cancel_token ),
				)
			);
		} catch ( Validation_Exception $e ) {
			wp_send_json_error(
				array(
					'message' => implode( ' ', $e->errors() ),
					'errors'  => $e->errors(),
				),
				422
			);
		} catch ( Booking_Conflict_Exception $e ) {
			wp_send_json_error(
				array(
					'message'  => $e->getMessage(),
					'conflict' => true,
				),
				409
			);
		}
	}

	/**
	 * `bookflow_reschedule_booking` — move an existing appointment (identified by a public
	 * cancel/reschedule token) to a new time, from the manage-booking page's widget.
	 */
	public static function reschedule_booking(): void {
		check_ajax_referer( 'bookflow_booking', 'nonce' );

		if ( ! Rate_Limiter::allow( 'reschedule_' . Rate_Limiter::client_identity(), 8, 300 ) ) {
			wp_send_json_error( array( 'message' => __( 'Too many attempts. Please wait a few minutes and try again.', 'bookflow-booking-scheduling' ) ), 429 );
		}

		$token       = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		$appointment = Manage_Booking::find_by_token( $token );

		if ( null === $appointment ) {
			wp_send_json_error( array( 'message' => __( 'Booking not found.', 'bookflow-booking-scheduling' ) ), 404 );
		}

		if ( ! $appointment->is_active() ) {
			wp_send_json_error( array( 'message' => __( 'This booking can no longer be rescheduled.', 'bookflow-booking-scheduling' ) ), 409 );
		}

		$start         = self::require_start();
		$timezone_name = self::customer_timezone()->getName();

		try {
			$updated = Appointment_Repository::reschedule( $appointment->id, $start, $timezone_name );

			wp_send_json_success(
				array(
					'reference' => $updated->booking_reference,
					'manageUrl' => Manage_Booking::url( $token ),
				)
			);
		} catch ( Booking_Conflict_Exception $e ) {
			wp_send_json_error(
				array(
					'message'  => $e->getMessage(),
					'conflict' => true,
				),
				409
			);
		}
	}

	/**
	 * Resolve and validate the 'service_id' POST field, halting the request with a JSON error
	 * if it does not reference a real, active service.
	 */
	private static function require_service(): Service {
		$service_id = isset( $_POST['service_id'] ) ? absint( $_POST['service_id'] ) : 0;
		$service    = $service_id ? Service_Repository::find( $service_id ) : null;

		if ( null === $service || 'active' !== $service->status ) {
			wp_send_json_error( array( 'message' => __( 'This service is not available.', 'bookflow-booking-scheduling' ) ), 404 );
			exit; // wp_send_json_error() already exits; kept for static analysis clarity.
		}

		return $service;
	}

	/**
	 * Resolve the optional 'scheduling_page_id' POST field. When present, validates the page is
	 * active and that the resolved $service is actually one of the page's offered services —
	 * defensive against a tampered client request pairing an unrelated service with a page.
	 * Returns null (not an error) when no scheduling_page_id was submitted at all — that's the
	 * normal, valid shape for a plain (non-scheduling-page) booking.
	 */
	private static function optional_scheduling_page( Service $service ): ?Scheduling_Page {
		$page_id = isset( $_POST['scheduling_page_id'] ) ? absint( $_POST['scheduling_page_id'] ) : 0;

		if ( ! $page_id ) {
			return null;
		}

		$page = Scheduling_Page_Repository::find( $page_id );

		if ( null === $page || 'active' !== $page->status ) {
			wp_send_json_error( array( 'message' => __( 'This scheduling page is not available.', 'bookflow-booking-scheduling' ) ), 404 );
			exit; // wp_send_json_error() already exits; kept for static analysis clarity.
		}

		if ( ! in_array( $service->id, Scheduling_Page_Repository::service_ids( $page->id ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'This service is not offered on this scheduling page.', 'bookflow-booking-scheduling' ) ), 400 );
			exit;
		}

		return $page;
	}

	/**
	 * Read, validate, and sanitize the 'custom_fields' POST field (a JSON object of
	 * field_key => answer) against the field definitions that actually apply — the SAME
	 * definitions Widget_Config exposed to the client, re-resolved server-side rather than
	 * trusting whatever shape the client submits (Section 9: "never trust frontend data").
	 *
	 * @return array{0: array<string, string>, 1: array<string, string>} [ answers, errors ], both keyed by field_key.
	 */
	private static function collect_custom_field_answers( Service $service, ?Scheduling_Page $scheduling_page ): array {
		$fields = $scheduling_page
			? Custom_Field_Repository::for_context( 'scheduling_page', $scheduling_page->id )
			: Custom_Field_Repository::for_context( 'appointment', $service->id );

		$raw = isset( $_POST['custom_fields'] ) ? json_decode( (string) wp_unslash( $_POST['custom_fields'] ), true ) : array();

		if ( ! is_array( $raw ) ) {
			$raw = array();
		}

		$answers = array();
		$errors  = array();

		foreach ( $fields as $field ) {
			$value = $raw[ $field->field_key ] ?? null;
			$error = $field->validate_answer( $value );

			if ( null !== $error ) {
				$errors[ $field->field_key ] = $error;
				continue;
			}

			if ( null !== $value && '' !== trim( (string) $value ) ) {
				$answers[ $field->field_key ] = $field->sanitize_answer( $value );
			}
		}

		return array( $answers, $errors );
	}

	/**
	 * Resolve the 'staff_id' POST field, ignoring (returning null for) any value that is not
	 * actually assigned to the given service — defensive against a tampered client request
	 * rather than trusting the submitted staff selection at face value.
	 */
	private static function valid_staff_id( int $service_id ): ?int {
		$staff_id = ! empty( $_POST['staff_id'] ) ? absint( $_POST['staff_id'] ) : null;

		if ( null === $staff_id ) {
			return null;
		}

		return in_array( $staff_id, Service_Repository::staff_ids( $service_id ), true ) ? $staff_id : null;
	}

	/**
	 * Resolve the 'location_id' POST field, same defensive validation as valid_staff_id().
	 */
	private static function valid_location_id( int $service_id ): ?int {
		$location_id = ! empty( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : null;

		if ( null === $location_id ) {
			return null;
		}

		return in_array( $location_id, Service_Repository::location_ids( $service_id ), true ) ? $location_id : null;
	}

	/**
	 * Resolve the 'timezone' POST field to a valid DateTimeZone, falling back to the site
	 * timezone for a missing/invalid value rather than erroring the whole request over it.
	 */
	private static function customer_timezone(): \DateTimeZone {
		$name = isset( $_POST['timezone'] ) ? sanitize_text_field( wp_unslash( $_POST['timezone'] ) ) : '';

		if ( '' === $name || ! in_array( $name, \DateTimeZone::listIdentifiers(), true ) ) {
			return wp_timezone();
		}

		return new \DateTimeZone( $name );
	}

	/**
	 * Resolve and validate the 'date' POST field ('YYYY-MM-DD'), halting the request with a
	 * JSON error if missing/malformed.
	 */
	private static function require_date(): string {
		$date = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : '';

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid date.', 'bookflow-booking-scheduling' ) ), 400 );
			exit;
		}

		return $date;
	}

	/**
	 * Resolve and validate the 'start' POST field (an ISO 8601 instant, as returned verbatim by
	 * get_slots()), halting the request with a JSON error if missing/malformed.
	 */
	private static function require_start(): \DateTimeImmutable {
		$raw = isset( $_POST['start'] ) ? sanitize_text_field( wp_unslash( $_POST['start'] ) ) : '';

		try {
			return new \DateTimeImmutable( $raw );
		} catch ( \Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
			wp_send_json_error( array( 'message' => __( 'Invalid time selected.', 'bookflow-booking-scheduling' ) ), 400 );
			exit;
		}
	}
}

<?php
/**
 * Builds the JSON configuration payload the frontend booking widget's JavaScript reads —
 * shared by the [bookflow_booking] shortcode (booking mode) and the public manage-booking page
 * (reschedule mode), so both drive the exact same client-side state machine.
 *
 * @package BookFlow\Frontend
 */

declare( strict_types = 1 );

namespace BookFlow\Frontend;

use BookFlow\CustomFields\Custom_Field_Repository;
use BookFlow\Locations\Location_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Widget_Config
 */
final class Widget_Config {

	/**
	 * Build the config payload.
	 *
	 * @param array{
	 *     layout?: string,
	 *     locked_service_id?: int|null,
	 *     locked_staff_id?: int|null,
	 *     locked_location_id?: int|null,
	 *     allowed_service_ids?: array<int, int>|null,
	 *     scheduling_page_id?: int|null,
	 *     reschedule?: array{token:string, appointment_reference:string}|null
	 * } $options Widget options.
	 * @return array<string, mixed>
	 */
	public static function build( array $options = array() ): array {
		$locked_service_id  = $options['locked_service_id'] ?? null;
		$allowed_service_ids = $options['allowed_service_ids'] ?? null;
		$scheduling_page_id  = $options['scheduling_page_id'] ?? null;

		$services = Service_Repository::all( array( 'status' => 'active' ) );

		if ( null !== $locked_service_id ) {
			$services = array_values( array_filter( $services, static fn( $s ) => $s->id === $locked_service_id ) );
		} elseif ( is_array( $allowed_service_ids ) ) {
			$services = array_values( array_filter( $services, static fn( $s ) => in_array( $s->id, $allowed_service_ids, true ) ) );
		}

		// Scheduling-page mode: one shared set of custom questions for the whole page,
		// regardless of which of the page's services the customer picks. Plain booking mode:
		// each service carries its own questions (global appointment-context fields plus any
		// scoped specifically to that service) — see Custom_Field_Repository::for_context().
		$page_custom_fields = null !== $scheduling_page_id
			? self::custom_fields_payload( Custom_Field_Repository::for_context( 'scheduling_page', $scheduling_page_id ) )
			: null;

		$services_payload = array();

		foreach ( $services as $service ) {
			$services_payload[] = array(
				'id'              => $service->id,
				'name'            => $service->name,
				'description'     => wp_strip_all_tags( (string) $service->description ),
				'durationMinutes' => $service->duration_minutes,
				'price'           => $service->price,
				'currency'        => $service->currency,
				'capacity'        => $service->capacity,
				'staffIds'        => Service_Repository::staff_ids( $service->id ),
				'locationIds'     => Service_Repository::location_ids( $service->id ),
				'customFields'    => null === $page_custom_fields
					? self::custom_fields_payload( Custom_Field_Repository::for_context( 'appointment', $service->id ) )
					: array(),
			);
		}

		$staff_payload = array_map(
			static fn( $s ) => array(
				'id'   => $s->id,
				'name' => $s->display_name,
			),
			Staff_Repository::all( array( 'status' => 'active' ) )
		);

		$locations_payload = array_map(
			static fn( $l ) => array(
				'id'   => $l->id,
				'name' => $l->name,
				'type' => $l->type,
			),
			Location_Repository::all( array( 'status' => 'active' ) )
		);

		return array(
			'ajaxUrl'           => admin_url( 'admin-ajax.php' ),
			'nonce'             => wp_create_nonce( 'bookflow_booking' ),
			'siteTimezone'      => wp_timezone_string(),
			'layout'            => in_array( $options['layout'] ?? 'classic', Booking_Shortcode::LAYOUTS, true ) ? $options['layout'] : 'classic',
			'lockedServiceId'   => $locked_service_id,
			'lockedStaffId'     => $options['locked_staff_id'] ?? null,
			'lockedLocationId'  => $options['locked_location_id'] ?? null,
			'schedulingPageId'  => $scheduling_page_id,
			'customFields'      => $page_custom_fields ?? array(),
			'services'          => $services_payload,
			'staff'             => $staff_payload,
			'locations'         => $locations_payload,
			'reschedule'        => $options['reschedule'] ?? null,
			'i18n'              => self::i18n(),
		);
	}

	/**
	 * Convert Custom_Field entities into the plain-array shape the JS widget reads.
	 *
	 * @param array<int, \BookFlow\CustomFields\Custom_Field> $fields Field definitions.
	 * @return array<int, array<string, mixed>>
	 */
	private static function custom_fields_payload( array $fields ): array {
		return array_map(
			static fn( $field ) => array(
				'key'      => $field->field_key,
				'label'    => $field->label,
				'type'     => $field->field_type,
				'required' => $field->is_required,
				'options'  => $field->options,
			),
			$fields
		);
	}

	/**
	 * Every user-facing string the JavaScript widget needs, translated server-side and handed
	 * over as data — avoids requiring a `wp-i18n` script dependency / build step for a JS file
	 * that is otherwise entirely build-free (Section 12: every user-facing string must be
	 * translatable).
	 *
	 * @return array<string, string>
	 */
	private static function i18n(): array {
		return array(
			'selectService'        => __( 'Select a service', 'bookflow-booking-scheduling' ),
			'next'                 => __( 'Next', 'bookflow-booking-scheduling' ),
			'back'                 => __( 'Back', 'bookflow-booking-scheduling' ),
			'change'               => __( 'Change', 'bookflow-booking-scheduling' ),
			'selectStaff'          => __( 'Select a staff member', 'bookflow-booking-scheduling' ),
			'noPreference'         => __( 'No preference', 'bookflow-booking-scheduling' ),
			'selectLocation'       => __( 'Select a location', 'bookflow-booking-scheduling' ),
			'selectDate'           => __( 'Select a date', 'bookflow-booking-scheduling' ),
			'selectTime'           => __( 'Select a time', 'bookflow-booking-scheduling' ),
			'differentDay'         => __( 'Choose a different day', 'bookflow-booking-scheduling' ),
			'noSlots'              => __( 'No available times on this day. Please try another date.', 'bookflow-booking-scheduling' ),
			'searchingSoonest'     => __( 'Finding the soonest available time…', 'bookflow-booking-scheduling' ),
			'loading'              => __( 'Loading…', 'bookflow-booking-scheduling' ),
			'yourDetails'          => __( 'Your details', 'bookflow-booking-scheduling' ),
			'firstName'            => __( 'First name', 'bookflow-booking-scheduling' ),
			'lastName'             => __( 'Last name', 'bookflow-booking-scheduling' ),
			'email'                => __( 'Email', 'bookflow-booking-scheduling' ),
			'phone'                => __( 'Phone (optional)', 'bookflow-booking-scheduling' ),
			'notes'                => __( 'Notes (optional)', 'bookflow-booking-scheduling' ),
			'optional'             => __( 'optional', 'bookflow-booking-scheduling' ),
			'reviewAndConfirm'     => __( 'Review & confirm', 'bookflow-booking-scheduling' ),
			'confirmBooking'       => __( 'Confirm Booking', 'bookflow-booking-scheduling' ),
			'confirmNewTime'       => __( 'Confirm New Time', 'bookflow-booking-scheduling' ),
			'submitting'           => __( 'Submitting…', 'bookflow-booking-scheduling' ),
			'bookingConfirmedTitle' => __( 'Booking confirmed', 'bookflow-booking-scheduling' ),
			'bookingPendingTitle'  => __( 'Booking received', 'bookflow-booking-scheduling' ),
			'bookingPendingBody'   => __( 'Your booking is pending approval. We will confirm shortly by email.', 'bookflow-booking-scheduling' ),
			'rescheduledTitle'     => __( 'Booking rescheduled', 'bookflow-booking-scheduling' ),
			'reference'            => __( 'Booking reference', 'bookflow-booking-scheduling' ),
			'genericError'         => __( 'Something went wrong. Please try again.', 'bookflow-booking-scheduling' ),
			'requiredField'        => __( 'This field is required.', 'bookflow-booking-scheduling' ),
			'invalidEmail'         => __( 'Please enter a valid email address.', 'bookflow-booking-scheduling' ),
			'today'                => __( 'Today', 'bookflow-booking-scheduling' ),
			'duration'             => __( 'Duration', 'bookflow-booking-scheduling' ),
			'minutes'              => __( 'min', 'bookflow-booking-scheduling' ),
		);
	}
}

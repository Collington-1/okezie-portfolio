<?php
/**
 * The [bookflow_booking] shortcode — Free scope's shortcode fallback for the booking form
 * (Section 18). A Gutenberg block wrapping the same rendering path is Phase 9's job; this class
 * is written so that block can call render() directly rather than duplicating anything.
 *
 * @package BookFlow\Frontend
 */

declare( strict_types = 1 );

namespace BookFlow\Frontend;

use BookFlow\Services\Service_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Booking_Shortcode
 */
final class Booking_Shortcode {

	/**
	 * Shortcode tag.
	 *
	 * @var string
	 */
	public const TAG = 'bookflow_booking';

	/**
	 * Recognised layout values.
	 *
	 * @var array<int, string>
	 */
	public const LAYOUTS = array( 'classic', 'calendar_first', 'express' );

	/**
	 * Register the shortcode.
	 */
	public static function init(): void {
		add_shortcode( self::TAG, array( self::class, 'render' ) );
	}

	/**
	 * Render the shortcode.
	 *
	 * @param array<string, string>|string $atts Shortcode attributes.
	 */
	public static function render( $atts ): string {
		$atts = shortcode_atts(
			array(
				'service'  => '',
				'staff'    => '',
				'location' => '',
				'layout'   => 'classic',
			),
			is_array( $atts ) ? $atts : array(),
			self::TAG
		);

		$layout = in_array( $atts['layout'], self::LAYOUTS, true ) ? $atts['layout'] : 'classic';

		$locked_service_id = self::resolve_service_id( $atts['service'] );

		$config = Widget_Config::build(
			array(
				'layout'             => $layout,
				'locked_service_id'  => $locked_service_id,
				'locked_staff_id'    => $atts['staff'] ? absint( $atts['staff'] ) : null,
				'locked_location_id' => $atts['location'] ? absint( $atts['location'] ) : null,
			)
		);

		return Templates::render(
			'booking-form',
			array(
				'layout' => $layout,
				'config' => $config,
			)
		);
	}

	/**
	 * Resolve a shortcode 'service' attribute (numeric ID or slug) to a service ID.
	 */
	private static function resolve_service_id( string $service_attr ): ?int {
		if ( '' === trim( $service_attr ) ) {
			return null;
		}

		if ( ctype_digit( $service_attr ) ) {
			$service = Service_Repository::find( (int) $service_attr );
			return $service ? $service->id : null;
		}

		$service = Service_Repository::find_by_slug( sanitize_title( $service_attr ) );

		return $service ? $service->id : null;
	}
}

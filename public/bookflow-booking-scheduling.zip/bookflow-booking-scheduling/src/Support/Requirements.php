<?php
/**
 * Defensive runtime environment check, in case a host ignores plugin headers.
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Requirements
 */
final class Requirements {

	/**
	 * Whether the current environment satisfies BookFlow's minimum PHP and WordPress versions.
	 */
	public static function satisfied(): bool {
		return self::php_satisfied() && self::wp_satisfied();
	}

	/**
	 * Whether the running PHP version meets Constants::MIN_PHP.
	 */
	public static function php_satisfied(): bool {
		return version_compare( PHP_VERSION, Constants::MIN_PHP, '>=' );
	}

	/**
	 * Whether the running WordPress version meets Constants::MIN_WP.
	 */
	public static function wp_satisfied(): bool {
		global $wp_version;

		if ( empty( $wp_version ) ) {
			// Unable to determine; fail safe rather than risk a fatal on unsupported cores.
			return false;
		}

		return version_compare( $wp_version, Constants::MIN_WP, '>=' );
	}

	/**
	 * Human-readable, translated but UNESCAPED explanation of why the environment does not
	 * qualify. Callers are responsible for escaping at the point of output (e.g. with
	 * esc_html()) — this deliberately returns raw text rather than pre-escaped text, so it can
	 * also be used in contexts other than HTML (e.g. WP-CLI output) without double-escaping.
	 */
	public static function explanation(): string {
		if ( ! self::php_satisfied() ) {
			return sprintf(
				/* translators: 1: required PHP version, 2: current PHP version. */
				__( 'BookFlow requires PHP %1$s or newer. This site is running PHP %2$s.', 'bookflow-booking-scheduling' ),
				Constants::MIN_PHP,
				PHP_VERSION
			);
		}

		global $wp_version;

		return sprintf(
			/* translators: 1: required WordPress version, 2: current WordPress version. */
			__( 'BookFlow requires WordPress %1$s or newer. This site is running WordPress %2$s.', 'bookflow-booking-scheduling' ),
			Constants::MIN_WP,
			(string) $wp_version
		);
	}
}

<?php
/**
 * Maps BookFlow's meta capability onto a WordPress primitive capability, and grants it on
 * activation. Kept as its own indirection so a site owner (or Premium) can remap who is
 * allowed to manage BookFlow without touching plugin code.
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Capabilities
 */
final class Capabilities {

	/**
	 * Register the capability_type filter so `current_user_can( Constants::CAPABILITY )` maps
	 * to `manage_options` unless a site explicitly changes it.
	 */
	public static function init(): void {
		add_filter( 'map_meta_cap', array( self::class, 'map_meta_cap' ), 10, 4 );
	}

	/**
	 * Map the bookflow meta capability to manage_options by default.
	 *
	 * @param array<int, string> $caps    Primitive capabilities required.
	 * @param string             $cap     Requested capability.
	 * @param int                $user_id User ID.
	 * @param array<int, mixed>  $args    Additional arguments.
	 * @return array<int, string>
	 */
	public static function map_meta_cap( array $caps, string $cap, int $user_id, array $args ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
		if ( Constants::CAPABILITY === $cap ) {
			/**
			 * Filters the primitive capability that BookFlow's manage_bookflow meta capability
			 * maps to. Defaults to `manage_options` (administrators only).
			 *
			 * @param string $mapped_cap Primitive capability.
			 */
			return array( apply_filters( 'bookflow_manage_capability', 'manage_options' ) );
		}

		return $caps;
	}

	/**
	 * Grant the capability to Administrators on activation.
	 */
	public static function grant_defaults(): void {
		$role = get_role( 'administrator' );

		if ( $role instanceof \WP_Role && ! $role->has_cap( Constants::CAPABILITY ) ) {
			$role->add_cap( Constants::CAPABILITY );
		}
	}
}

<?php
/**
 * Collision-safe slug generation, shared by every entity that has a unique `slug` column
 * (services, locations, and — from Phase 6 onward — events and scheduling pages).
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Slugs
 */
final class Slugs {

	/**
	 * Generate a unique slug from a desired string, appending -2, -3, ... until `$exists`
	 * reports no collision.
	 *
	 * @param string   $desired Human-readable source string (usually a name/title).
	 * @param callable $exists  Callable( string $slug ): bool — returns true if the slug is
	 *                          already taken. Callers exclude the entity's own row (on update)
	 *                          from the check.
	 * @param string   $fallback Base slug to use if $desired sanitizes down to an empty string.
	 */
	public static function unique( string $desired, callable $exists, string $fallback = 'item' ): string {
		$base = sanitize_title( $desired );

		if ( '' === $base ) {
			$base = sanitize_title( $fallback );
		}

		if ( '' === $base ) {
			$base = 'item';
		}

		$slug   = $base;
		$suffix = 2;

		while ( $exists( $slug ) ) {
			$slug = $base . '-' . $suffix;
			++$suffix;
		}

		return $slug;
	}
}

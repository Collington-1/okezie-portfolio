<?php
/**
 * Minimal PSR-4-style autoloader for the BookFlow\ namespace.
 *
 * Deliberately not a Composer-generated autoloader: the plugin must run on WordPress.org and on
 * arbitrary hosts without requiring `composer install`, and without shipping a `vendor/`
 * directory. See docs/ARCHITECTURE.md §5.
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Autoloader
 */
final class Autoloader {

	/**
	 * Root PHP namespace mapped by this autoloader.
	 *
	 * @var string
	 */
	private const NAMESPACE_PREFIX = 'BookFlow\\';

	/**
	 * Register the autoloader with the SPL autoload stack.
	 */
	public static function register(): void {
		spl_autoload_register( array( self::class, 'autoload' ) );
	}

	/**
	 * Attempt to load a class file for the given fully-qualified class name.
	 *
	 * @param string $class Fully-qualified class name.
	 */
	private static function autoload( string $class ): void {
		if ( 0 !== strpos( $class, self::NAMESPACE_PREFIX ) ) {
			return;
		}

		$relative = substr( $class, strlen( self::NAMESPACE_PREFIX ) );
		$relative = str_replace( '\\', DIRECTORY_SEPARATOR, $relative );
		$file     = BOOKFLOW_PLUGIN_DIR . 'src' . DIRECTORY_SEPARATOR . $relative . '.php';

		if ( is_readable( $file ) ) {
			require $file;
		}
	}
}

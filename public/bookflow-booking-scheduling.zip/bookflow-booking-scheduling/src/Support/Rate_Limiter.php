<?php
/**
 * A minimal transient-based rate limiter for public, unauthenticated endpoints — Section 9:
 * "Rate-limit or otherwise protect public booking endpoints where appropriate." Deliberately
 * simple (no new table, no external service): good enough to blunt casual abuse/scripted
 * hammering of the booking-creation endpoint on typical shared hosting, not a substitute for a
 * dedicated WAF/bot-mitigation layer for sites under real attack.
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Rate_Limiter
 */
final class Rate_Limiter {

	/**
	 * Whether the given bucket (already includes the acting identity, e.g. IP + action name)
	 * has room for one more attempt within the window, and if so, records this attempt.
	 * Returns false without recording anything if the bucket is already at its limit.
	 *
	 * @param string $bucket_key   Unique key for this rate-limited action + identity.
	 * @param int    $max_attempts Maximum attempts allowed within the window.
	 * @param int    $window_seconds Window length, in seconds.
	 */
	public static function allow( string $bucket_key, int $max_attempts, int $window_seconds ): bool {
		$transient_key = 'bookflow_rl_' . md5( $bucket_key );
		$count         = (int) get_transient( $transient_key );

		if ( $count >= $max_attempts ) {
			return false;
		}

		if ( 0 === $count ) {
			set_transient( $transient_key, 1, $window_seconds );
		} else {
			// Re-set rather than rely on a native increment (transients have no atomic
			// increment) — a lost increment under a race just means the limit is slightly
			// generous under concurrent hits, never a hard failure; acceptable for this
			// endpoint's abuse-mitigation purpose rather than a strict quota.
			set_transient( $transient_key, $count + 1, $window_seconds );
		}

		return true;
	}

	/**
	 * Best-effort identity for the current request, for use as part of a bucket key. Prefers
	 * the client IP as reported by WordPress/the server; falls back to a constant string
	 * (effectively a global limit) if no IP is available, rather than throwing.
	 */
	public static function client_identity(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		return '' !== $ip ? $ip : 'unknown';
	}
}

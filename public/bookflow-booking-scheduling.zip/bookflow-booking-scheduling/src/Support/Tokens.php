<?php
/**
 * Cryptographically random token generation for public-safe identifiers — booking references
 * and cancel/reschedule links. See docs/ARCHITECTURE.md §10: sequential integer IDs are never
 * exposed publicly.
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Tokens
 */
final class Tokens {

	/**
	 * A short, human-readable public booking reference (e.g. "7K4M9PXQ2R") — uppercase
	 * alphanumeric, excluding visually ambiguous characters (0/O, 1/I/L).
	 *
	 * @param int $length Character length.
	 */
	public static function reference( int $length = 10 ): string {
		$alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
		$max      = strlen( $alphabet ) - 1;
		$out      = '';

		for ( $i = 0; $i < $length; $i++ ) {
			$out .= $alphabet[ random_int( 0, $max ) ];
		}

		return $out;
	}

	/**
	 * A long, high-entropy hex token for cancel/reschedule links — not meant to be typed, only
	 * carried in a URL.
	 *
	 * @param int $bytes Number of random bytes (produces $bytes * 2 hex characters).
	 */
	public static function link( int $bytes = 16 ): string {
		return bin2hex( random_bytes( $bytes ) );
	}
}

<?php
/**
 * Deactivation routine. Never deletes data — see docs/ARCHITECTURE.md §6.
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Deactivation
 */
final class Deactivation {

	/**
	 * Run on register_deactivation_hook.
	 */
	public static function run(): void {
		$timestamp = wp_next_scheduled( Constants::CRON_DAILY_MAINTENANCE );

		if ( false !== $timestamp ) {
			wp_unschedule_event( $timestamp, Constants::CRON_DAILY_MAINTENANCE );
		}

		flush_rewrite_rules();
	}
}

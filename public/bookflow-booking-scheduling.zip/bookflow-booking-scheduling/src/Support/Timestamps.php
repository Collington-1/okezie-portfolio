<?php
/**
 * Single source of truth for "now", stored in UTC. See docs/ARCHITECTURE.md §9 — every stored
 * instant is UTC; only display formatting is timezone-aware.
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Timestamps
 */
final class Timestamps {

	/**
	 * Current time formatted for a DATETIME column, in UTC.
	 */
	public static function now(): string {
		// current_time( 'mysql', true ) returns the current time in GMT/UTC, MySQL-formatted —
		// deliberately not gmdate() directly, so this stays consistent with the rest of
		// WordPress core's own "now" (and picks up WordPress's own test-clock handling, if any,
		// rather than reading the system clock a second, independent way).
		return current_time( 'mysql', true );
	}
}

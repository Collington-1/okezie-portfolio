<?php
/**
 * Central, renameable brand/identity constants. See docs/ARCHITECTURE.md §2.
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Constants
 */
final class Constants {

	/**
	 * Plugin slug. Must equal the WordPress.org directory slug and the text domain.
	 *
	 * @var string
	 */
	public const SLUG = 'bookflow-booking-scheduling';

	/**
	 * Translation text domain. Kept identical to SLUG per WordPress.org requirements.
	 *
	 * @var string
	 */
	public const TEXT_DOMAIN = 'bookflow-booking-scheduling';

	/**
	 * Plugin version. Kept in sync with the `Version:` header in bookflow.php.
	 *
	 * @var string
	 */
	public const VERSION = '1.0.0';

	/**
	 * Database schema version. Bump whenever Database\Schema changes, and add a matching
	 * migration if a data transformation (not just a dbDelta re-run) is required.
	 *
	 * @var string
	 */
	public const DB_VERSION = '1.0.0';

	/**
	 * Minimum supported WordPress version (also declared in the plugin header).
	 *
	 * @var string
	 */
	public const MIN_WP = '6.4';

	/**
	 * Minimum supported PHP version (also declared in the plugin header).
	 *
	 * @var string
	 */
	public const MIN_PHP = '8.0';

	/**
	 * Prefix used for options, transients, and hook names.
	 *
	 * @var string
	 */
	public const PREFIX = 'bookflow_';

	/**
	 * Prefix used for custom database table names, appended after $wpdb->prefix.
	 *
	 * @var string
	 */
	public const TABLE_PREFIX = 'bookflow_';

	/**
	 * Capability required to manage BookFlow. Mapped to a WordPress primitive capability by
	 * default in Support\Capabilities, but declared as its own meta capability so hosts/other
	 * plugins can remap it without touching BookFlow code.
	 *
	 * @var string
	 */
	public const CAPABILITY = 'manage_bookflow';

	/**
	 * Name of the recurring maintenance cron event (cleans up expired transients, stale
	 * pending bookings, etc. — registered in a later phase).
	 *
	 * @var string
	 */
	public const CRON_DAILY_MAINTENANCE = 'bookflow_daily_maintenance';

	/**
	 * Option storing the current database schema version.
	 *
	 * @var string
	 */
	public const OPTION_DB_VERSION = 'bookflow_db_version';

	/**
	 * Transient consumed once to trigger the onboarding-wizard redirect after activation.
	 *
	 * @var string
	 */
	public const TRANSIENT_ACTIVATION_REDIRECT = 'bookflow_activation_redirect';

	/**
	 * Option controlling whether uninstall removes all plugin data. Boolean-ish ('1'/'').
	 * Defaults to NOT removing data — see docs/ARCHITECTURE.md §6 and DATABASE-SCHEMA.md.
	 *
	 * @var string
	 */
	public const OPTION_REMOVE_DATA_ON_UNINSTALL = 'bookflow_remove_data_on_uninstall';
}

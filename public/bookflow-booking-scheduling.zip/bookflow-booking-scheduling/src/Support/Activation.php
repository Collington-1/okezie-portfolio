<?php
/**
 * Activation routine.
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

use BookFlow\Database\Migrator;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Activation
 */
final class Activation {

	/**
	 * Run on register_activation_hook. Must stay defensive: activation hooks run before
	 * plugins_loaded, so BookFlow's own translations/other plugins are not guaranteed loaded
	 * yet, and a fatal here breaks the whole Plugins screen for the site owner.
	 */
	public static function run(): void {
		if ( ! Requirements::satisfied() ) {
			// Do not attempt install; deactivate self and surface a notice instead of fataling.
			deactivate_plugins( plugin_basename( BOOKFLOW_PLUGIN_FILE ) );
			set_transient( 'bookflow_activation_blocked', Requirements::explanation(), 60 );
			return;
		}

		Migrator::install();
		Capabilities::grant_defaults();
		self::seed_default_options();

		// Consumed once by Admin\Onboarding to redirect into the setup wizard.
		set_transient( Constants::TRANSIENT_ACTIVATION_REDIRECT, 1, 30 );

		flush_rewrite_rules();
	}

	/**
	 * Seed sensible option defaults on first activation only (never overwrite existing values
	 * on a re-activation/upgrade).
	 */
	private static function seed_default_options(): void {
		add_option( Constants::OPTION_REMOVE_DATA_ON_UNINSTALL, '' );
		add_option( 'bookflow_onboarding_completed', '' );
		add_option( 'bookflow_booking_model', '' ); // 'appointments' | 'events' | 'both'.
		add_option( 'bookflow_business_type', '' );
	}
}

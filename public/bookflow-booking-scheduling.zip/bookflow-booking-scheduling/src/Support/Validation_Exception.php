<?php
/**
 * Domain-level validation failure, carrying field-level error messages rather than a single
 * string, so admin UI (Phase 4) and REST controllers (Phase 9) can attach errors to the
 * specific form field that caused them instead of showing one generic message.
 *
 * @package BookFlow\Support
 */

declare( strict_types = 1 );

namespace BookFlow\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Validation_Exception
 */
final class Validation_Exception extends \RuntimeException {

	/**
	 * Field key => human-readable, already-translated error message.
	 *
	 * @var array<string, string>
	 */
	private array $errors;

	/**
	 * Constructor.
	 *
	 * @param array<string, string> $errors  Field key => error message.
	 * @param string                $message Optional summary message.
	 */
	public function __construct( array $errors, string $message = 'Validation failed.' ) {
		parent::__construct( $message );

		$this->errors = $errors;
	}

	/**
	 * The field-level errors.
	 *
	 * @return array<string, string>
	 */
	public function errors(): array {
		return $this->errors;
	}

	/**
	 * Convert to a WP_Error, for callers (REST controllers, admin-post handlers) that expect
	 * WordPress's own error convention instead of a caught exception.
	 */
	public function to_wp_error(): \WP_Error {
		$wp_error = new \WP_Error();

		foreach ( $this->errors as $field => $message ) {
			$wp_error->add( 'bookflow_invalid_' . $field, $message, array( 'field' => $field ) );
		}

		return $wp_error;
	}
}

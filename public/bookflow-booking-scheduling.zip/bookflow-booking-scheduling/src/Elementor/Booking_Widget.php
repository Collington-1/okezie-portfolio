<?php
/**
 * Elementor widget wrapping Frontend\Booking_Shortcode::render() — the exact same render path
 * the [bookflow_booking] shortcode and the Gutenberg "Booking Form" block already use, so all
 * three ways of placing the booking form on a page share one tested implementation.
 *
 * @package BookFlow\Elementor
 */

declare( strict_types = 1 );

namespace BookFlow\Elementor;

use BookFlow\Frontend\Booking_Shortcode;
use BookFlow\Locations\Location_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Booking_Widget
 */
final class Booking_Widget extends \Elementor\Widget_Base {

	/**
	 * {@inheritDoc}
	 */
	public function get_name() {
		return 'bookflow-booking-form';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_title() {
		return __( 'Booking Form', 'bookflow-booking-scheduling' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_icon() {
		return 'eicon-calendar';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_categories() {
		return array( Bootstrap::CATEGORY );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_keywords() {
		return array( 'booking', 'appointment', 'schedule', 'bookflow' );
	}

	/**
	 * {@inheritDoc}
	 *
	 * Registered on WordPress's 'init' hook by Frontend\Bootstrap::register_assets() regardless
	 * of whether Elementor is even active — see that method's docblock for why registration
	 * (not just enqueueing) has to happen that early for a page builder's own style/script
	 * dependency collection to reliably find these handles already registered.
	 */
	public function get_style_depends() {
		return array( 'bookflow-frontend' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_script_depends() {
		return array( 'bookflow-booking-form' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'bookflow_content',
			array( 'label' => __( 'Booking Form', 'bookflow-booking-scheduling' ) )
		);

		$this->add_control(
			'layout',
			array(
				'label'   => __( 'Layout', 'bookflow-booking-scheduling' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'classic',
				'options' => array(
					'classic'        => __( 'Classic', 'bookflow-booking-scheduling' ),
					'calendar_first' => __( 'Calendar first', 'bookflow-booking-scheduling' ),
					'express'        => __( 'Express (soonest available)', 'bookflow-booking-scheduling' ),
				),
			)
		);

		$this->add_control(
			'service',
			array(
				'label'       => __( 'Service', 'bookflow-booking-scheduling' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'default'     => '',
				'options'     => self::service_options(),
				'description' => __( 'Leave as "Any" to let the visitor choose from every active service.', 'bookflow-booking-scheduling' ),
			)
		);

		$this->add_control(
			'staff',
			array(
				'label'   => __( 'Staff member', 'bookflow-booking-scheduling' ),
				'type'    => \Elementor\Controls_Manager::SELECT2,
				'default' => '',
				'options' => self::staff_options(),
			)
		);

		$this->add_control(
			'location',
			array(
				'label'   => __( 'Location', 'bookflow-booking-scheduling' ),
				'type'    => \Elementor\Controls_Manager::SELECT2,
				'default' => '',
				'options' => self::location_options(),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		echo Booking_Shortcode::render( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Booking_Shortcode::render() returns markup built entirely from esc_*()-wrapped template output; this is the same trusted call already used as the shortcode handler and the Gutenberg block's render_callback.
			array(
				'layout'   => (string) ( $settings['layout'] ?? 'classic' ),
				'service'  => (string) ( $settings['service'] ?? '' ),
				'staff'    => (string) ( $settings['staff'] ?? '' ),
				'location' => (string) ( $settings['location'] ?? '' ),
			)
		);
	}

	/**
	 * @return array<string, string> value => label, keyed for Elementor's SELECT2 control.
	 */
	private static function service_options(): array {
		$options = array( '' => __( '— Any —', 'bookflow-booking-scheduling' ) );

		foreach ( Service_Repository::all( array( 'status' => 'active' ) ) as $service ) {
			$options[ (string) $service->id ] = $service->name;
		}

		return $options;
	}

	/**
	 * @return array<string, string>
	 */
	private static function staff_options(): array {
		$options = array( '' => __( '— Any —', 'bookflow-booking-scheduling' ) );

		foreach ( Staff_Repository::all( array( 'status' => 'active' ) ) as $staff ) {
			$options[ (string) $staff->id ] = $staff->display_name;
		}

		return $options;
	}

	/**
	 * @return array<string, string>
	 */
	private static function location_options(): array {
		$options = array( '' => __( '— Any —', 'bookflow-booking-scheduling' ) );

		foreach ( Location_Repository::all( array( 'status' => 'active' ) ) as $location ) {
			$options[ (string) $location->id ] = $location->name;
		}

		return $options;
	}
}

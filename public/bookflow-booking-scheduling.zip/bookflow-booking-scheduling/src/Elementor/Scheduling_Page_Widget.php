<?php
/**
 * Elementor widget wrapping Scheduling\Bootstrap::render_shortcode() — the exact same render
 * path the [bookflow_schedule] shortcode and the Gutenberg "Scheduling Page" block already use.
 *
 * @package BookFlow\Elementor
 */

declare( strict_types = 1 );

namespace BookFlow\Elementor;

use BookFlow\Scheduling\Bootstrap as Scheduling_Bootstrap;
use BookFlow\Scheduling\Scheduling_Page_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Scheduling_Page_Widget
 */
final class Scheduling_Page_Widget extends \Elementor\Widget_Base {

	/**
	 * {@inheritDoc}
	 */
	public function get_name() {
		return 'bookflow-scheduling-page';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_title() {
		return __( 'Scheduling Page', 'bookflow-booking-scheduling' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_icon() {
		return 'eicon-calendar';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_categories() {
		return array( Bootstrap::CATEGORY );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_keywords() {
		return array( 'booking', 'schedule', 'scheduling page', 'bookflow' );
	}

	/**
	 * {@inheritDoc} See Booking_Widget::get_style_depends() for why registration is guaranteed
	 * to have already happened by the time Elementor collects this.
	 */
	public function get_style_depends() {
		return array( 'bookflow-frontend' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_script_depends() {
		return array( 'bookflow-booking-form' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'bookflow_content',
			array( 'label' => __( 'Scheduling Page', 'bookflow-booking-scheduling' ) )
		);

		$options = self::page_options();

		$this->add_control(
			'page',
			array(
				'label'       => __( 'Scheduling page', 'bookflow-booking-scheduling' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'default'     => '',
				'options'     => $options,
				'description' => empty( $options )
					? __( 'No scheduling pages exist yet — create one under BookFlow → Scheduling first.', 'bookflow-booking-scheduling' )
					: '',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$page_id  = (string) ( $settings['page'] ?? '' );

		if ( '' === $page_id ) {
			echo esc_html__( 'Select a scheduling page in the widget settings.', 'bookflow-booking-scheduling' );
			return;
		}

		echo Scheduling_Bootstrap::render_shortcode( array( 'page' => $page_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- same trusted render path already used as the shortcode handler and the Gutenberg block's render_callback.
	}

	/**
	 * @return array<string, string> value => label.
	 */
	private static function page_options(): array {
		$options = array();

		foreach ( Scheduling_Page_Repository::all( array( 'status' => 'active' ) ) as $page ) {
			$options[ (string) $page->id ] = $page->title;
		}

		return $options;
	}
}

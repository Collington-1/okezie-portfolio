<?php
/**
 * Elementor integration — a dedicated "BookFlow" widget category with one widget per existing
 * shortcode (Booking Form, Scheduling Page, Event Booking), each a thin wrapper around the exact
 * same render method the shortcode/Gutenberg block already use (Frontend\Booking_Shortcode::
 * render(), Scheduling\Bootstrap::render_shortcode(), Events\Bootstrap::render_shortcode()), so
 * all three entry points can never drift out of sync with each other. See docs/ROADMAP.md for
 * why this was added (Elementor is used on a very large share of WordPress sites, and BookFlow's
 * target audience — small businesses booking their own appointments — skews heavily toward
 * exactly the kind of site that uses a page builder rather than hand-editing the block editor).
 *
 * Elementor is an optional third-party plugin, not a BookFlow dependency: every hook here is
 * registered only if Elementor is actually active (`did_action( 'elementor/loaded' )`), and the
 * widget classes themselves (which `extends \Elementor\Widget_Base`, a class that doesn't exist
 * otherwise) are never even autoloaded when it isn't — see Support\Autoloader, which only
 * requires a class file the first time something actually references that class name, so a site
 * without Elementor never parses a line of this module.
 *
 * @package BookFlow\Elementor
 */

declare( strict_types = 1 );

namespace BookFlow\Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Bootstrap
 */
final class Bootstrap {

	/**
	 * Widget category slug shown in Elementor's own widget panel.
	 *
	 * @var string
	 */
	public const CATEGORY = 'bookflow';

	/**
	 * Register Elementor hooks — a complete no-op if Elementor isn't active.
	 */
	public static function init(): void {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		add_action( 'elementor/elements/categories_registered', array( self::class, 'register_category' ) );
		add_action( 'elementor/widgets/register', array( self::class, 'register_widgets' ) );
	}

	/**
	 * Register the "BookFlow" category so all three widgets group together in Elementor's panel
	 * instead of scattering across its generic built-in categories.
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elementor's elements manager.
	 */
	public static function register_category( $elements_manager ): void {
		$elements_manager->add_category(
			self::CATEGORY,
			array(
				'title' => __( 'BookFlow', 'bookflow-booking-scheduling' ),
				'icon'  => 'eicon-calendar',
			)
		);
	}

	/**
	 * Register the three widgets.
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor's widgets manager.
	 */
	public static function register_widgets( $widgets_manager ): void {
		$widgets_manager->register( new Booking_Widget() );
		$widgets_manager->register( new Scheduling_Page_Widget() );
		$widgets_manager->register( new Event_Widget() );
	}
}

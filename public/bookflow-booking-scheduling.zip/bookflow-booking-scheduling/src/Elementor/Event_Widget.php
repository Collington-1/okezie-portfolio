<?php
/**
 * Elementor widget wrapping Events\Bootstrap::render_shortcode() — the exact same render path
 * the [bookflow_event] shortcode and the Gutenberg "Event Booking" block already use.
 *
 * @package BookFlow\Elementor
 */

declare( strict_types = 1 );

namespace BookFlow\Elementor;

use BookFlow\Events\Bootstrap as Events_Bootstrap;
use BookFlow\Events\Event_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Event_Widget
 */
final class Event_Widget extends \Elementor\Widget_Base {

	/**
	 * {@inheritDoc}
	 */
	public function get_name() {
		return 'bookflow-event-booking';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_title() {
		return __( 'Event Booking', 'bookflow-booking-scheduling' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_icon() {
		return 'eicon-calendar';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_categories() {
		return array( Bootstrap::CATEGORY );
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_keywords() {
		return array( 'event', 'registration', 'tickets', 'bookflow' );
	}

	/**
	 * {@inheritDoc}
	 *
	 * The event registration form itself has no interactive JS (Events\Bootstrap's own docblock
	 * explains why — a plain POST form, no AJAX step-through like the booking widget), so unlike
	 * the other two widgets this one only needs the shared stylesheet, not booking-form.js.
	 */
	public function get_style_depends() {
		return array( 'bookflow-frontend' );
	}

	/**
	 * {@inheritDoc}
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'bookflow_content',
			array( 'label' => __( 'Event', 'bookflow-booking-scheduling' ) )
		);

		$options = self::event_options();

		$this->add_control(
			'event',
			array(
				'label'       => __( 'Event', 'bookflow-booking-scheduling' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'default'     => '',
				'options'     => $options,
				'description' => empty( $options )
					? __( 'No upcoming published events yet — create one under BookFlow → Events first.', 'bookflow-booking-scheduling' )
					: '',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * {@inheritDoc}
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$event_id = (string) ( $settings['event'] ?? '' );

		if ( '' === $event_id ) {
			echo esc_html__( 'Select an event in the widget settings.', 'bookflow-booking-scheduling' );
			return;
		}

		echo Events_Bootstrap::render_shortcode( array( 'event' => $event_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- same trusted render path already used as the shortcode handler and the Gutenberg block's render_callback.
	}

	/**
	 * Same "published, upcoming, capped at 100" set the Gutenberg block's editor data uses
	 * (Blocks\Bootstrap::localize_editor_data()) — a widget picking a past or draft event would
	 * be a confusing, useless choice to offer either way.
	 *
	 * @return array<string, string> value => label.
	 */
	private static function event_options(): array {
		$options = array();

		foreach (
			Event_Repository::all(
				array(
					'status'        => 'published',
					'upcoming_only' => true,
					'limit'         => 100,
				)
			) as $event
		) {
			$options[ (string) $event->id ] = $event->title;
		}

		return $options;
	}
}

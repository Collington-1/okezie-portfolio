<?php
/**
 * Location entity — one row of wp_bookflow_locations.
 *
 * @package BookFlow\Locations
 */

declare( strict_types = 1 );

namespace BookFlow\Locations;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Location
 */
final class Location {

	/**
	 * Constructor.
	 *
	 * @param int         $id          Row ID.
	 * @param string      $name        Location name.
	 * @param string      $slug        Unique slug.
	 * @param string      $type        'physical' | 'online'.
	 * @param string|null $address     Postal address (physical locations).
	 * @param string|null $phone       Contact phone.
	 * @param string|null $timezone    IANA timezone name; null falls back to the site timezone.
	 * @param string|null $meeting_url Video meeting URL (online locations).
	 * @param string      $status      'active' | 'inactive'.
	 * @param int         $sort_order  Manual sort order.
	 * @param array<string, mixed> $settings Decoded JSON settings.
	 * @param string      $created_at  UTC DATETIME string.
	 * @param string      $updated_at  UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public string $name,
		public string $slug,
		public string $type,
		public ?string $address,
		public ?string $phone,
		public ?string $timezone,
		public ?string $meeting_url,
		public string $status,
		public int $sort_order,
		public array $settings,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Recognised `type` values.
	 *
	 * @return array<int, string>
	 */
	public static function types(): array {
		return array( 'physical', 'online' );
	}

	/**
	 * Recognised `status` values.
	 *
	 * @return array<int, string>
	 */
	public static function statuses(): array {
		return array( 'active', 'inactive' );
	}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		return new self(
			(int) $row['id'],
			(string) $row['name'],
			(string) $row['slug'],
			(string) $row['type'],
			$row['address'] ?? null,
			$row['phone'] ?? null,
			$row['timezone'] ?? null,
			$row['meeting_url'] ?? null,
			(string) $row['status'],
			(int) $row['sort_order'],
			self::decode_settings( $row['settings'] ?? null ),
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}

	/**
	 * Decode the settings JSON column, tolerating null/malformed values.
	 *
	 * @param string|null $json Raw JSON string.
	 * @return array<string, mixed>
	 */
	private static function decode_settings( ?string $json ): array {
		if ( null === $json || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Whether this is an online (vs. physical) location.
	 */
	public function is_online(): bool {
		return 'online' === $this->type;
	}
}

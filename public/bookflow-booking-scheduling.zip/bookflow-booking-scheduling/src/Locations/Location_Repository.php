<?php
/**
 * Locations domain repository: validation and CRUD for wp_bookflow_locations.
 *
 * @package BookFlow\Locations
 */

declare( strict_types = 1 );

namespace BookFlow\Locations;

use BookFlow\Database\Pivot_Table;
use BookFlow\Database\Repository;
use BookFlow\Database\Schema;
use BookFlow\Support\Slugs;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Location_Repository
 */
final class Location_Repository extends Repository {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'locations';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'name'        => '%s',
			'slug'        => '%s',
			'type'        => '%s',
			'address'     => '%s',
			'phone'       => '%s',
			'timezone'    => '%s',
			'meeting_url' => '%s',
			'status'      => '%s',
			'sort_order'  => '%d',
			'settings'    => '%s',
			'created_at'  => '%s',
			'updated_at'  => '%s',
		);
	}

	/**
	 * Fetch a location by ID.
	 */
	public static function find( int $id ): ?Location {
		$row = parent::find_row( $id );

		return $row ? Location::from_row( $row ) : null;
	}

	/**
	 * Fetch several locations by ID in one query, keyed by id. See Repository::find_many_rows().
	 *
	 * @param array<int, int> $ids Location IDs.
	 * @return array<int, Location>
	 */
	public static function find_many( array $ids ): array {
		return array_map( array( Location::class, 'from_row' ), parent::find_many_rows( $ids ) );
	}

	/**
	 * Fetch a location by its unique slug.
	 */
	public static function find_by_slug( string $slug ): ?Location {
		$row = self::find_by( 'slug', $slug, '%s' );

		return $row ? Location::from_row( $row ) : null;
	}

	/**
	 * List locations.
	 *
	 * @param array{status?: string, type?: string, search?: string} $args Filter args.
	 * @return array<int, Location>
	 */
	public static function all( array $args = array() ): array {
		global $wpdb;

		$table  = static::table();
		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = (string) $args['status'];
		}

		if ( ! empty( $args['type'] ) ) {
			$where[]  = 'type = %s';
			$params[] = (string) $args['type'];
		}

		if ( ! empty( $args['search'] ) ) {
			$where[]  = 'name LIKE %s';
			$params[] = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
		}

		$sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . ' ORDER BY sort_order ASC, name ASC'; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where fragments are hard-coded above; values are parameterized.

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared whenever placeholders are present.
		$rows     = $wpdb->get_results( $prepared, ARRAY_A );

		return array_map( array( Location::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Create a location.
	 *
	 * @param array<string, mixed> $input Raw input.
	 *
	 * @throws Validation_Exception When input fails validation.
	 */
	public static function create( array $input ): Location {
		$data                = self::validate( $input, null, null );
		$data['created_at']  = Timestamps::now();
		$data['updated_at']  = $data['created_at'];

		$id = parent::insert( $data );

		return self::find( $id );
	}

	/**
	 * Update a location. Fields absent from $input keep their current value.
	 *
	 * @param int                   $id    Location ID.
	 * @param array<string, mixed>  $input Raw partial input.
	 *
	 * @throws \InvalidArgumentException When the location does not exist.
	 * @throws Validation_Exception       When input fails validation.
	 */
	public static function update( int $id, array $input ): Location {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: location %d not found.', $id ) );
		}

		$data               = self::validate( $input, $id, $existing );
		$data['updated_at'] = Timestamps::now();

		parent::update_row( $id, $data );

		return self::find( $id );
	}

	/**
	 * Delete a location and its staff/service associations.
	 */
	public static function delete( int $id ): bool {
		Pivot_Table::delete_all_for( Schema::table( 'staff_locations' ), 'location_id', $id );
		Pivot_Table::delete_all_for( Schema::table( 'service_locations' ), 'location_id', $id );

		return parent::delete( $id );
	}

	/**
	 * IDs of staff who work at this location.
	 *
	 * @return array<int, int>
	 */
	public static function staff_ids( int $location_id ): array {
		return Pivot_Table::left_ids_for( Schema::table( 'staff_locations' ), 'staff_id', 'location_id', $location_id );
	}

	/**
	 * IDs of services offered at this location.
	 *
	 * @return array<int, int>
	 */
	public static function service_ids( int $location_id ): array {
		return Pivot_Table::left_ids_for( Schema::table( 'service_locations' ), 'service_id', 'location_id', $location_id );
	}

	/**
	 * Validate and sanitize raw input.
	 *
	 * @param array<string, mixed>      $input        Raw input.
	 * @param int|null                  $excluding_id Location ID to exclude from the slug
	 *                                                  uniqueness check (update only).
	 * @param array<string, mixed>|null $existing     Existing raw row, for partial updates.
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, ?int $excluding_id, ?array $existing ): array {
		$get = static function ( string $key, $default ) use ( $input, $existing ) {
			if ( array_key_exists( $key, $input ) ) {
				return $input[ $key ];
			}

			if ( null !== $existing && array_key_exists( $key, $existing ) ) {
				return $existing[ $key ];
			}

			return $default;
		};

		$errors = array();

		$name = trim( sanitize_text_field( (string) $get( 'name', '' ) ) );

		if ( '' === $name ) {
			$errors['name'] = __( 'Location name is required.', 'bookflow-booking-scheduling' );
		}

		$type = (string) $get( 'type', 'physical' );

		if ( ! in_array( $type, Location::types(), true ) ) {
			$errors['type'] = __( 'Invalid location type.', 'bookflow-booking-scheduling' );
		}

		$status = (string) $get( 'status', 'active' );

		if ( ! in_array( $status, Location::statuses(), true ) ) {
			$errors['status'] = __( 'Invalid location status.', 'bookflow-booking-scheduling' );
		}

		$meeting_url = trim( (string) $get( 'meeting_url', '' ) );

		if ( 'online' === $type && '' !== $meeting_url && false === filter_var( $meeting_url, FILTER_VALIDATE_URL ) ) {
			$errors['meeting_url'] = __( 'Please enter a valid meeting URL.', 'bookflow-booking-scheduling' );
		}

		$timezone_raw = $get( 'timezone', null );
		$timezone     = null;

		if ( null !== $timezone_raw && '' !== trim( (string) $timezone_raw ) ) {
			$timezone = sanitize_text_field( (string) $timezone_raw );

			if ( ! in_array( $timezone, \DateTimeZone::listIdentifiers(), true ) ) {
				$errors['timezone'] = __( 'Please choose a valid timezone.', 'bookflow-booking-scheduling' );
			}
		}

		if ( ! empty( $errors ) ) {
			throw new Validation_Exception( $errors, __( 'The location could not be saved.', 'bookflow-booking-scheduling' ) );
		}

		$slug_input = $get( 'slug', '' );
		$slug       = '' !== trim( (string) $slug_input ) ? sanitize_title( (string) $slug_input ) : null;

		if ( null === $slug || '' === $slug || self::exists_by( 'slug', $slug, '%s', $excluding_id ) ) {
			$slug = Slugs::unique(
				$slug ? $slug : $name,
				static function ( string $candidate ) use ( $excluding_id ): bool {
					return self::exists_by( 'slug', $candidate, '%s', $excluding_id );
				},
				'location'
			);
		}

		$settings = $get( 'settings', array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$phone   = sanitize_text_field( (string) $get( 'phone', '' ) );
		$address = wp_kses_post( (string) $get( 'address', '' ) );

		return array(
			'name'        => $name,
			'slug'        => $slug,
			'type'        => $type,
			'address'     => '' !== $address ? $address : null,
			'phone'       => '' !== $phone ? $phone : null,
			'timezone'    => $timezone,
			'meeting_url' => '' !== $meeting_url ? esc_url_raw( $meeting_url ) : null,
			'status'      => $status,
			'sort_order'  => (int) $get( 'sort_order', 0 ),
			'settings'    => wp_json_encode( $settings ),
		);
	}
}

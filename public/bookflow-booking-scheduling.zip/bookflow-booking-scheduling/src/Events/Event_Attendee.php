<?php
/**
 * Event attendee entity — one row of wp_bookflow_event_attendees (one registration, possibly
 * for more than one seat via $quantity).
 *
 * @package BookFlow\Events
 */

declare( strict_types = 1 );

namespace BookFlow\Events;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Event_Attendee
 */
final class Event_Attendee {

	/**
	 * Constructor.
	 *
	 * @param int                  $id                Row ID (internal use only — never expose publicly, use $booking_reference).
	 * @param int                  $event_id           Event ID.
	 * @param int                  $customer_id        Customer ID.
	 * @param int                  $quantity           Seats registered.
	 * @param string               $status             'confirmed' | 'cancelled' (waitlisted reserved for Premium).
	 * @param array<string, mixed> $custom_fields       Decoded JSON custom question answers.
	 * @param string               $booking_reference   Public-safe random reference.
	 * @param string|null          $cancel_token        Public cancel-link token.
	 * @param string               $created_at          UTC DATETIME string.
	 * @param string               $updated_at          UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public int $event_id,
		public int $customer_id,
		public int $quantity,
		public string $status,
		public array $custom_fields,
		public string $booking_reference,
		public ?string $cancel_token,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Recognised `status` values.
	 *
	 * @return array<int, string>
	 */
	public static function statuses(): array {
		return array( 'confirmed', 'cancelled' );
	}

	/**
	 * Statuses that still hold seats (count toward capacity).
	 *
	 * @return array<int, string>
	 */
	public static function active_statuses(): array {
		return array( 'confirmed' );
	}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		return new self(
			(int) $row['id'],
			(int) $row['event_id'],
			(int) $row['customer_id'],
			(int) $row['quantity'],
			(string) $row['status'],
			self::decode_custom_fields( $row['custom_fields'] ?? null ),
			(string) $row['booking_reference'],
			$row['cancel_token'] ?? null,
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}

	/**
	 * Decode the custom_fields JSON column, tolerating null/malformed values.
	 *
	 * @param string|null $json Raw JSON string.
	 * @return array<string, mixed>
	 */
	private static function decode_custom_fields( ?string $json ): array {
		if ( null === $json || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Whether this registration still holds its seat(s).
	 */
	public function is_active(): bool {
		return in_array( $this->status, self::active_statuses(), true );
	}
}

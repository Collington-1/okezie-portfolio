<?php
/**
 * Shared event registration view — renders event details plus a registration form (or its
 * current state: sold out, past, cancelled, or a just-submitted confirmation/error). Used by
 * both the [bookflow_event] shortcode and the public /events/{slug} page, so the two never
 * drift apart.
 *
 * @package BookFlow\Events
 */

declare( strict_types = 1 );

namespace BookFlow\Events;

use BookFlow\CustomFields\Custom_Field_Repository;
use BookFlow\Frontend\Templates;
use BookFlow\Locations\Location_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Event_View
 */
final class Event_View {

	/**
	 * Render the event details + registration form block.
	 */
	public static function render( Event $event ): string {
		$location = $event->location_id ? Location_Repository::find( $event->location_id ) : null;
		$fields   = Custom_Field_Repository::for_context( 'event', $event->id );

		return Templates::render(
			'event-registration',
			array(
				'event'    => $event,
				'location' => $location,
				'fields'   => $fields,
			)
		);
	}
}

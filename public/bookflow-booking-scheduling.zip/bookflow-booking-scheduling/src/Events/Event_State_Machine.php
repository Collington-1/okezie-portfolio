<?php
/**
 * Event status state machine (Section 16 of the master spec, applied to events the same way
 * Booking\Appointment_State_Machine applies it to appointments). Prevents invalid status
 * transitions and records every change to the audit log.
 *
 * @package BookFlow\Events
 */

declare( strict_types = 1 );

namespace BookFlow\Events;

use BookFlow\Database\Audit_Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Event_State_Machine
 */
final class Event_State_Machine {

	/**
	 * Allowed transitions, from => [ to, to, ... ]. cancelled/completed are terminal.
	 *
	 * @var array<string, array<int, string>>
	 */
	private const TRANSITIONS = array(
		'draft'     => array( 'published', 'cancelled' ),
		'published' => array( 'cancelled', 'completed', 'draft' ),
		'cancelled' => array(),
		'completed' => array(),
	);

	/**
	 * Whether a transition from one status to another is allowed.
	 */
	public static function can_transition( string $from, string $to ): bool {
		return in_array( $to, self::TRANSITIONS[ $from ] ?? array(), true );
	}

	/**
	 * Transition an event to a new status, recording the change to the audit log.
	 *
	 * @param Event       $event   The event to transition.
	 * @param string      $to      Target status.
	 * @param int|null    $user_id Acting user ID, or null for system-initiated actions.
	 * @param string|null $reason  Optional human-readable reason, stored in the audit log only.
	 *
	 * @throws \InvalidArgumentException When the transition is not allowed.
	 */
	public static function transition( Event $event, string $to, ?int $user_id = null, ?string $reason = null ): Event {
		if ( ! self::can_transition( $event->status, $to ) ) {
			throw new \InvalidArgumentException(
				sprintf(
					'BookFlow: cannot transition event %d from "%s" to "%s".',
					$event->id,
					$event->status,
					$to
				)
			);
		}

		$from    = $event->status;
		$updated = Event_Repository::set_status( $event->id, $to );

		Audit_Logger::log(
			'event',
			$event->id,
			'status_changed',
			$user_id,
			array( 'status' => $from ),
			array(
				'status' => $to,
				'reason' => $reason,
			)
		);

		/**
		 * Fires after an event's status changes. Not currently used by Notifications (no
		 * per-event-status customer email is spec'd — attendee-facing emails are triggered by
		 * registration/cancellation instead), but registered for the same documented-extension-
		 * seam reason as every other lifecycle hook in this codebase — see
		 * docs/ARCHITECTURE.md §11.
		 *
		 * @param Event  $event The event at its new status.
		 * @param string $from  Previous status.
		 * @param string $to    New status.
		 */
		do_action( 'bookflow_event_status_changed', $updated, $from, $to );

		return $updated;
	}
}

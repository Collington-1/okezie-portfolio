<?php
/**
 * Events module bootstrap: the [bookflow_event] shortcode, the public /events/{slug} route, and
 * the public manage-registration (cancel) route.
 *
 * Deliberately no AJAX/JS here, unlike the appointment booking widget (Phase 5/6): an event has
 * one fixed date/time — there is no live availability to fetch, so a plain HTML form posting
 * back to itself (POST/redirect/GET) is the simplest robust solution (Section 34), not a scope
 * cut. See Registration_Handler.
 *
 * @package BookFlow\Events
 */

declare( strict_types = 1 );

namespace BookFlow\Events;

use BookFlow\Frontend\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Bootstrap
 */
final class Bootstrap {

	/**
	 * Query var carrying the event slug.
	 *
	 * @var string
	 */
	private const QUERY_VAR = 'bookflow_event';

	/**
	 * Query var carrying a registration's cancel token, for the manage-registration route.
	 *
	 * @var string
	 */
	private const MANAGE_QUERY_VAR = 'bookflow_manage_registration';

	/**
	 * Bump when the rewrite rule pattern changes — see Scheduling\Bootstrap::REWRITE_VERSION
	 * for why this exists (a versioned one-time flush covers sites upgrading from a version
	 * before this route existed; activation-time flush alone only covers fresh installs).
	 *
	 * @var string
	 */
	private const REWRITE_VERSION = '1';

	/**
	 * Option tracking which REWRITE_VERSION has last been flushed for.
	 *
	 * @var string
	 */
	private const OPTION_REWRITE_VERSION = 'bookflow_event_rewrite_version';

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_shortcode( 'bookflow_event', array( self::class, 'render_shortcode' ) );

		add_action( 'init', array( self::class, 'register_rewrite_rules' ) );
		add_action( 'init', array( self::class, 'maybe_flush_rewrite_rules' ), 20 );
		add_filter( 'query_vars', array( self::class, 'add_query_vars' ) );
		add_filter( 'template_include', array( self::class, 'maybe_render' ) );
		add_action( 'template_redirect', array( Registration_Handler::class, 'maybe_handle_registration' ) );
		add_action( 'template_redirect', array( Registration_Handler::class, 'maybe_handle_cancel' ) );

		add_action( 'wp_enqueue_scripts', array( self::class, 'maybe_enqueue_assets' ) );
	}

	/**
	 * Register the /{prefix}/{slug} rewrite rule for public event pages. A single generic
	 * pattern — creating/editing/deleting an event never needs a rewrite flush.
	 */
	public static function register_rewrite_rules(): void {
		$prefix = self::url_prefix();

		add_rewrite_rule(
			'^' . preg_quote( $prefix, '/' ) . '/([^/]+)/?$',
			'index.php?' . self::QUERY_VAR . '=$matches[1]',
			'top'
		);
	}

	/**
	 * The URL path segment events live under (default 'events'). Filterable rather than a
	 * Free-tier settings field — see Scheduling\Bootstrap::url_prefix()'s identical rationale.
	 */
	public static function url_prefix(): string {
		/**
		 * Filters the URL path segment public event pages are published under.
		 *
		 * @param string $prefix Path segment, no leading/trailing slashes. Default 'events'.
		 */
		$prefix = (string) apply_filters( 'bookflow_event_url_prefix', 'events' );

		return trim( $prefix, '/' );
	}

	/**
	 * The public URL for one event — mirrors Scheduling\Bootstrap::public_url()'s identical
	 * rationale (one source of truth instead of every caller concatenating url_prefix()+slug).
	 */
	public static function public_url( Event $event ): string {
		return home_url( '/' . self::url_prefix() . '/' . $event->slug . '/' );
	}

	/**
	 * Flush rewrite rules once per REWRITE_VERSION — see Scheduling\Bootstrap::
	 * maybe_flush_rewrite_rules() for the identical pattern and rationale.
	 */
	public static function maybe_flush_rewrite_rules(): void {
		if ( get_option( self::OPTION_REWRITE_VERSION ) === self::REWRITE_VERSION ) {
			return;
		}

		flush_rewrite_rules();
		update_option( self::OPTION_REWRITE_VERSION, self::REWRITE_VERSION, false );
	}

	/**
	 * Register the query vars so the rewrite rule's target and the manage-registration link are
	 * readable via get_query_var().
	 *
	 * @param array<int, string> $vars Existing public query vars.
	 * @return array<int, string>
	 */
	public static function add_query_vars( array $vars ): array {
		$vars[] = self::QUERY_VAR;
		$vars[] = self::MANAGE_QUERY_VAR;

		return $vars;
	}

	/**
	 * The event slug requested by the current request, or '' if this isn't an event-page request.
	 */
	public static function requested_slug(): string {
		return (string) get_query_var( self::QUERY_VAR, '' );
	}

	/**
	 * The registration cancel token requested by the current request, or '' if this isn't a
	 * manage-registration request.
	 */
	public static function requested_manage_token(): string {
		return (string) get_query_var( self::MANAGE_QUERY_VAR, '' );
	}

	/**
	 * The public manage-registration URL for a given registration's cancel token.
	 */
	public static function manage_url( string $token ): string {
		return add_query_arg( self::MANAGE_QUERY_VAR, $token, home_url( '/' ) );
	}

	/**
	 * Swap in our own templates when an event-page or manage-registration request is detected.
	 *
	 * @param string $template Original template path WordPress would have used.
	 */
	public static function maybe_render( string $template ): string {
		if ( '' !== self::requested_slug() ) {
			return Templates::locate( 'event-page' ) ?? $template;
		}

		if ( '' !== self::requested_manage_token() ) {
			return Templates::locate( 'manage-registration' ) ?? $template;
		}

		return $template;
	}

	/**
	 * Render the [bookflow_event] shortcode.
	 *
	 * @param array<string, string>|string $atts Shortcode attributes ('event' = slug or ID).
	 */
	public static function render_shortcode( $atts ): string {
		$atts = shortcode_atts( array( 'event' => '' ), is_array( $atts ) ? $atts : array(), 'bookflow_event' );

		$event = self::resolve_event( (string) $atts['event'] );

		if ( null === $event ) {
			return '';
		}

		return Event_View::render( $event );
	}

	/**
	 * Resolve a shortcode 'event' attribute (numeric ID or slug) to an Event.
	 */
	private static function resolve_event( string $event_attr ): ?Event {
		if ( '' === trim( $event_attr ) ) {
			return null;
		}

		if ( ctype_digit( $event_attr ) ) {
			return Event_Repository::find( (int) $event_attr );
		}

		return Event_Repository::find_by_slug( sanitize_title( $event_attr ) );
	}

	/**
	 * Enqueue the shared frontend stylesheet when an event page/shortcode/manage-registration
	 * view will actually render (Section 10: load frontend assets only when needed).
	 */
	public static function maybe_enqueue_assets(): void {
		if ( '' !== self::requested_slug() || '' !== self::requested_manage_token() ) {
			wp_enqueue_style( 'bookflow-frontend' );
			return;
		}

		if ( ! is_singular() ) {
			return;
		}

		$post = get_queried_object();

		// Not has_shortcode() alone — see Frontend\Bootstrap::page_needs_assets()'s docblock for
		// the real bug this exact gap caused for the Booking Form block, confirmed against a
		// real WordPress install: the Event Booking block has the identical gap otherwise.
		if (
			$post instanceof \WP_Post
			&& ( has_shortcode( (string) $post->post_content, 'bookflow_event' ) || has_block( 'bookflow/event-booking', $post ) )
		) {
			wp_enqueue_style( 'bookflow-frontend' );
		}
	}
}

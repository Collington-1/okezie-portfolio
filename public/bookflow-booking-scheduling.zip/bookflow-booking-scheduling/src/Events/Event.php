<?php
/**
 * Event entity — one row of wp_bookflow_events.
 *
 * @package BookFlow\Events
 */

declare( strict_types = 1 );

namespace BookFlow\Events;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Event
 */
final class Event {

	/**
	 * Constructor.
	 *
	 * @param int                 $id           Row ID.
	 * @param string              $title        Event title.
	 * @param string              $slug         Unique slug (public URL: /events/{slug}).
	 * @param string|null         $description  Description shown on the public page.
	 * @param \DateTimeImmutable  $start        Start instant, UTC.
	 * @param \DateTimeImmutable  $end          End instant, UTC.
	 * @param string              $timezone     Timezone the event was authored in, for display.
	 * @param int|null            $location_id  Location, if any.
	 * @param int|null            $capacity     Seat limit, or null for unlimited.
	 * @param int|null            $image_id     Attachment ID.
	 * @param string              $status       'draft' | 'published' | 'cancelled' | 'completed'.
	 * @param float|null          $price        Price per seat, or null/0 for free.
	 * @param string|null         $currency     ISO 4217 currency code.
	 * @param array<string, mixed> $settings    Decoded JSON settings.
	 * @param string              $created_at   UTC DATETIME string.
	 * @param string              $updated_at   UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public string $title,
		public string $slug,
		public ?string $description,
		public \DateTimeImmutable $start,
		public \DateTimeImmutable $end,
		public string $timezone,
		public ?int $location_id,
		public ?int $capacity,
		public ?int $image_id,
		public string $status,
		public ?float $price,
		public ?string $currency,
		public array $settings,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Recognised `status` values, in their normal lifecycle order (see Event_State_Machine for
	 * allowed transitions).
	 *
	 * @return array<int, string>
	 */
	public static function statuses(): array {
		return array( 'draft', 'published', 'cancelled', 'completed' );
	}

	/**
	 * Statuses under which the public page accepts new registrations.
	 *
	 * @return array<int, string>
	 */
	public static function registerable_statuses(): array {
		return array( 'published' );
	}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		$utc = new \DateTimeZone( 'UTC' );

		return new self(
			(int) $row['id'],
			(string) $row['title'],
			(string) $row['slug'],
			$row['description'] ?? null,
			new \DateTimeImmutable( (string) $row['start_datetime_utc'], $utc ),
			new \DateTimeImmutable( (string) $row['end_datetime_utc'], $utc ),
			(string) $row['timezone'],
			isset( $row['location_id'] ) && null !== $row['location_id'] ? (int) $row['location_id'] : null,
			isset( $row['capacity'] ) && null !== $row['capacity'] ? (int) $row['capacity'] : null,
			isset( $row['image_id'] ) && null !== $row['image_id'] ? (int) $row['image_id'] : null,
			(string) $row['status'],
			isset( $row['price'] ) && null !== $row['price'] ? (float) $row['price'] : null,
			$row['currency'] ?? null,
			self::decode_settings( $row['settings'] ?? null ),
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}

	/**
	 * Decode the settings JSON column, tolerating null/malformed values.
	 *
	 * @param string|null $json Raw JSON string.
	 * @return array<string, mixed>
	 */
	private static function decode_settings( ?string $json ): array {
		if ( null === $json || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * A settings value with a default fallback.
	 *
	 * @param string $key     Settings key.
	 * @param mixed  $default Default value if the key is absent.
	 */
	public function setting( string $key, $default = null ) {
		return $this->settings[ $key ] ?? $default;
	}

	/**
	 * Whether the event is currently open for registration: published, and its start time has
	 * not yet passed.
	 */
	public function is_registerable(): bool {
		if ( ! in_array( $this->status, self::registerable_statuses(), true ) ) {
			return false;
		}

		return $this->start > new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) );
	}
}

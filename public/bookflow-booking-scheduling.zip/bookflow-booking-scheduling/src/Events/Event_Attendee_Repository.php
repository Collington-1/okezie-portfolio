<?php
/**
 * Event attendee registrations: validation, the server-side overbooking guard, and CRUD for
 * wp_bookflow_event_attendees.
 *
 * Overbooking guard: same reasoning as Appointment_Repository's double-booking guard (see that
 * class's docblock and docs/ARCHITECTURE.md §8) — a MySQL named lock scoped to the event,
 * guarding a re-check-then-insert critical section, via the shared
 * Database\Repository::acquire_named_lock()/release_named_lock() primitives.
 *
 * @package BookFlow\Events
 */

declare( strict_types = 1 );

namespace BookFlow\Events;

use BookFlow\Booking\Booking_Conflict_Exception;
use BookFlow\Database\Repository;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Tokens;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Event_Attendee_Repository
 */
final class Event_Attendee_Repository extends Repository {

	/**
	 * Seconds to wait for the named lock before giving up as a conflict.
	 *
	 * @var int
	 */
	private const LOCK_TIMEOUT_SECONDS = 10;

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'event_attendees';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'event_id'          => '%d',
			'customer_id'       => '%d',
			'quantity'          => '%d',
			'status'            => '%s',
			'custom_fields'     => '%s',
			'booking_reference' => '%s',
			'cancel_token'      => '%s',
			'created_at'        => '%s',
			'updated_at'        => '%s',
		);
	}

	/**
	 * Fetch a registration by ID.
	 */
	public static function find( int $id ): ?Event_Attendee {
		$row = parent::find_row( $id );

		return $row ? Event_Attendee::from_row( $row ) : null;
	}

	/**
	 * Fetch a registration by its public booking reference.
	 */
	public static function find_by_reference( string $booking_reference ): ?Event_Attendee {
		$row = self::find_by( 'booking_reference', $booking_reference, '%s' );

		return $row ? Event_Attendee::from_row( $row ) : null;
	}

	/**
	 * Fetch a registration by its public cancel-link token.
	 */
	public static function find_by_cancel_token( string $token ): ?Event_Attendee {
		$row = self::find_by( 'cancel_token', $token, '%s' );

		return $row ? Event_Attendee::from_row( $row ) : null;
	}

	/**
	 * All active (confirmed) registrations for one event — the admin attendee-management
	 * screen's data source. Not paginated: even a well-attended event's attendee list is a
	 * bounded, moderate-sized dataset in practice, unlike the site-wide bookings/events lists.
	 *
	 * @return array<int, Event_Attendee>
	 */
	public static function for_event( int $event_id ): array {
		global $wpdb;

		$table = static::table();

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
		$sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE event_id = %d ORDER BY created_at ASC", $event_id );

		$rows = $wpdb->get_results( $sql, ARRAY_A );

		return array_map( array( Event_Attendee::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Total seats currently held (active registrations only) for one event.
	 */
	public static function confirmed_seat_count( int $event_id ): int {
		global $wpdb;

		$table = static::table();

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
		$sql = $wpdb->prepare( "SELECT COALESCE(SUM(quantity), 0) FROM {$table} WHERE event_id = %d AND status = 'confirmed'", $event_id );

		return (int) $wpdb->get_var( $sql );
	}

	/**
	 * Register for an event, guarded against overbooking.
	 *
	 * @param array<string, mixed> $input {
	 *     @type int                 $event_id      Required.
	 *     @type int                 $customer_id    Required.
	 *     @type int                 $quantity       Optional, default 1.
	 *     @type array<string,mixed> $custom_fields  Optional.
	 * }
	 *
	 * @throws Validation_Exception       When input fails validation.
	 * @throws Booking_Conflict_Exception When there are not enough seats remaining.
	 */
	public static function register( array $input ): Event_Attendee {
		$event = self::require_event( $input );
		$data  = self::validate( $input, $event );

		$lock_key = 'bookflow_event_' . $event->id;

		if ( ! self::acquire_named_lock( $lock_key, self::LOCK_TIMEOUT_SECONDS ) ) {
			throw new Booking_Conflict_Exception( __( 'This event is currently being booked by someone else. Please try again in a moment.', 'bookflow-booking-scheduling' ) );
		}

		try {
			if ( null !== $event->capacity ) {
				$already = self::confirmed_seat_count( $event->id );

				if ( $already + $data['quantity'] > $event->capacity ) {
					throw new Booking_Conflict_Exception( __( 'Not enough seats remaining for this event.', 'bookflow-booking-scheduling' ) );
				}
			}

			$data['booking_reference'] = self::unique_reference();
			$data['cancel_token']      = Tokens::link();
			$data['created_at']        = Timestamps::now();
			$data['updated_at']        = $data['created_at'];

			$id       = parent::insert( $data );
			$attendee = self::find( $id );
		} finally {
			self::release_named_lock( $lock_key );
		}

		/**
		 * Fires after a new event registration is successfully created. Notifications hooks
		 * here to send the event-registration-confirmation and admin-notification emails — see
		 * docs/ARCHITECTURE.md §11. Fired AFTER the named lock is released — same reasoning as
		 * Appointment_Repository::create()'s bookflow_appointment_created (see that docblock):
		 * a notification listener may do slow I/O, and the lock must never be held any longer
		 * than the actual database critical section.
		 *
		 * @param Event_Attendee $attendee The newly created registration.
		 * @param Event          $event    The event registered for.
		 */
		do_action( 'bookflow_event_registration_created', $attendee, $event );

		return $attendee;
	}

	/**
	 * Cancel a registration, freeing its seats.
	 *
	 * @throws \InvalidArgumentException When the registration does not exist or is already cancelled.
	 */
	public static function cancel( int $id ): Event_Attendee {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: event attendee %d not found.', $id ) );
		}

		if ( 'cancelled' === $existing['status'] ) {
			return Event_Attendee::from_row( $existing );
		}

		parent::update_row(
			$id,
			array(
				'status'     => 'cancelled',
				'updated_at' => Timestamps::now(),
			)
		);

		$updated = self::find( $id );

		/**
		 * Fires after an event registration is cancelled.
		 *
		 * @param Event_Attendee $attendee The now-cancelled registration.
		 */
		do_action( 'bookflow_event_registration_cancelled', $updated );

		return $updated;
	}

	/**
	 * Generate a booking reference guaranteed unique against existing rows.
	 */
	private static function unique_reference(): string {
		for ( $attempt = 0; $attempt < 5; $attempt++ ) {
			$candidate = Tokens::reference();

			if ( ! self::exists_by( 'booking_reference', $candidate, '%s' ) ) {
				return $candidate;
			}
		}

		return Tokens::reference( 16 );
	}

	/**
	 * Resolve and validate the referenced event, common to register().
	 *
	 * @param array<string, mixed> $input Raw input.
	 *
	 * @throws Validation_Exception When event_id is missing, does not reference a real event, or the event is not currently open for registration.
	 */
	private static function require_event( array $input ): Event {
		$event_id = isset( $input['event_id'] ) ? (int) $input['event_id'] : 0;

		if ( $event_id < 1 ) {
			throw new Validation_Exception( array( 'event_id' => __( 'An event is required.', 'bookflow-booking-scheduling' ) ) );
		}

		$event = Event_Repository::find( $event_id );

		if ( null === $event ) {
			throw new Validation_Exception( array( 'event_id' => __( 'The selected event could not be found.', 'bookflow-booking-scheduling' ) ) );
		}

		if ( ! $event->is_registerable() ) {
			throw new Validation_Exception( array( 'event_id' => __( 'This event is no longer open for registration.', 'bookflow-booking-scheduling' ) ) );
		}

		return $event;
	}

	/**
	 * Validate and sanitize raw input into a column => value map ready for insert().
	 *
	 * @param array<string, mixed> $input Raw input.
	 * @param Event                $event Resolved event.
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, Event $event ): array {
		$errors = array();

		$customer_id = isset( $input['customer_id'] ) ? (int) $input['customer_id'] : 0;

		if ( $customer_id < 1 ) {
			$errors['customer_id'] = __( 'A customer is required.', 'bookflow-booking-scheduling' );
		}

		$quantity = isset( $input['quantity'] ) ? (int) $input['quantity'] : 1;

		if ( $quantity < 1 ) {
			$errors['quantity'] = __( 'Quantity must be at least 1.', 'bookflow-booking-scheduling' );
		}

		if ( null !== $event->capacity && $quantity > $event->capacity ) {
			$errors['quantity'] = __( 'That is more seats than this event allows in total.', 'bookflow-booking-scheduling' );
		}

		if ( ! empty( $errors ) ) {
			throw new Validation_Exception( $errors, __( 'The registration could not be completed.', 'bookflow-booking-scheduling' ) );
		}

		$custom_fields = isset( $input['custom_fields'] ) && is_array( $input['custom_fields'] ) ? $input['custom_fields'] : array();

		return array(
			'event_id'      => $event->id,
			'customer_id'   => $customer_id,
			'quantity'      => $quantity,
			'status'        => 'confirmed',
			'custom_fields' => wp_json_encode( $custom_fields ),
		);
	}
}

<?php
/**
 * Events domain repository: validation, slug generation, and CRUD for wp_bookflow_events.
 * Paginated server-side (all()/count()) — unlike Services/Staff/Locations/Scheduling pages,
 * Section 10 explicitly calls out events (alongside bookings/customers) as needing pagination.
 *
 * @package BookFlow\Events
 */

declare( strict_types = 1 );

namespace BookFlow\Events;

use BookFlow\Database\Repository;
use BookFlow\Support\Slugs;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Event_Repository
 */
final class Event_Repository extends Repository {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'events';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'title'              => '%s',
			'slug'               => '%s',
			'description'        => '%s',
			'start_datetime_utc' => '%s',
			'end_datetime_utc'   => '%s',
			'timezone'           => '%s',
			'location_id'        => '%d',
			'capacity'           => '%d',
			'image_id'           => '%d',
			'status'             => '%s',
			'price'              => '%f',
			'currency'           => '%s',
			'settings'           => '%s',
			'created_at'         => '%s',
			'updated_at'         => '%s',
		);
	}

	/**
	 * Fetch an event by ID.
	 */
	public static function find( int $id ): ?Event {
		$row = parent::find_row( $id );

		return $row ? Event::from_row( $row ) : null;
	}

	/**
	 * Fetch an event by its unique slug — the public /events/{slug} route's lookup.
	 */
	public static function find_by_slug( string $slug ): ?Event {
		$row = self::find_by( 'slug', $slug, '%s' );

		return $row ? Event::from_row( $row ) : null;
	}

	/**
	 * List events.
	 *
	 * @param array{status?: string, location_id?: int, search?: string, upcoming_only?: bool, orderby?: string, order?: string, limit?: int, offset?: int} $args Filter/pagination args.
	 * @return array<int, Event>
	 */
	public static function all( array $args = array() ): array {
		global $wpdb;

		$table               = static::table();
		[ $where, $params ] = self::build_where( $args );

		$orderby = in_array( $args['orderby'] ?? '', array( 'start_datetime_utc', 'created_at', 'title' ), true )
			? $args['orderby']
			: 'start_datetime_utc';
		$order   = 'DESC' === strtoupper( $args['order'] ?? '' ) ? 'DESC' : 'ASC';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $orderby/$order are whitelisted above; $where placeholders are parameterized.
		$sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . " ORDER BY {$orderby} {$order}";

		if ( ! empty( $args['limit'] ) ) {
			$sql     .= ' LIMIT %d OFFSET %d';
			$params[] = (int) $args['limit'];
			$params[] = (int) ( $args['offset'] ?? 0 );
		}

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared whenever placeholders are present.
		$rows     = $wpdb->get_results( $prepared, ARRAY_A );

		return array_map( array( Event::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Count events matching the same filters all() accepts (limit/offset/orderby/order are
	 * ignored — this is the total for pagination, not a page count).
	 *
	 * @param array{status?: string, location_id?: int, search?: string, upcoming_only?: bool} $args Filter args.
	 */
	public static function count( array $args = array() ): int {
		global $wpdb;

		$table               = static::table();
		[ $where, $params ] = self::build_where( $args );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where fragments are hard-coded in build_where(); placeholders are parameterized.
		$sql = "SELECT COUNT(*) FROM {$table} WHERE " . implode( ' AND ', $where );

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared whenever placeholders are present.

		return (int) $wpdb->get_var( $prepared );
	}

	/**
	 * Shared WHERE-clause builder for all() and count().
	 *
	 * @param array<string, mixed> $args Filter args (see all()).
	 * @return array{0: array<int, string>, 1: array<int, mixed>}
	 */
	private static function build_where( array $args ): array {
		global $wpdb;

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = (string) $args['status'];
		}

		if ( ! empty( $args['location_id'] ) ) {
			$where[]  = 'location_id = %d';
			$params[] = (int) $args['location_id'];
		}

		if ( ! empty( $args['upcoming_only'] ) ) {
			$where[]  = 'start_datetime_utc >= %s';
			$params[] = ( new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) ) )->format( 'Y-m-d H:i:s' );
		}

		if ( ! empty( $args['search'] ) ) {
			$where[]  = 'title LIKE %s';
			$params[] = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
		}

		return array( $where, $params );
	}

	/**
	 * Create an event.
	 *
	 * @param array<string, mixed> $input Raw input.
	 *
	 * @throws Validation_Exception When input fails validation.
	 */
	public static function create( array $input ): Event {
		$data                = self::validate( $input, null, null );
		$data['created_at']  = Timestamps::now();
		$data['updated_at']  = $data['created_at'];

		$id = parent::insert( $data );

		return self::find( $id );
	}

	/**
	 * Update an event. Fields absent from $input keep their current value.
	 *
	 * @param int                   $id    Event ID.
	 * @param array<string, mixed>  $input Raw partial input.
	 *
	 * @throws \InvalidArgumentException When the event does not exist.
	 * @throws Validation_Exception       When input fails validation.
	 */
	public static function update( int $id, array $input ): Event {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: event %d not found.', $id ) );
		}

		$data               = self::validate( $input, $id, $existing );
		$data['updated_at'] = Timestamps::now();

		parent::update_row( $id, $data );

		return self::find( $id );
	}

	/**
	 * Resolve a start/end instant for validate(): the explicitly provided DateTimeImmutable if
	 * given, else the existing row's stored UTC DATETIME string parsed back into one, else null
	 * (create() with nothing provided — validate() turns that into a required-field error).
	 *
	 * @param mixed       $provided     $input['start'] or $input['end'], if present.
	 * @param string|null $existing_utc The existing row's start_datetime_utc/end_datetime_utc column, if present.
	 */
	private static function resolve_datetime( $provided, ?string $existing_utc ): ?\DateTimeImmutable {
		if ( $provided instanceof \DateTimeImmutable ) {
			return $provided;
		}

		if ( null !== $existing_utc && '' !== $existing_utc ) {
			return new \DateTimeImmutable( $existing_utc, new \DateTimeZone( 'UTC' ) );
		}

		return null;
	}

	/**
	 * Set the status column directly. Only ever called from Event_State_Machine, which owns
	 * transition validation and audit logging.
	 *
	 * Deliberately NOT routed through update()/validate(): that pipeline expects a full set of
	 * fields including 'start'/'end' as DateTimeImmutable objects, reconstructed from the
	 * existing row when absent from $input — but the raw row stores those as
	 * 'start_datetime_utc'/'end_datetime_utc' STRING columns, a key-name mismatch that would
	 * make a status-only update wrongly fail validation with "a valid start time is required".
	 * Appointment_Repository::set_status() exists for the identical reason — see that method.
	 */
	public static function set_status( int $id, string $status ): Event {
		parent::update_row(
			$id,
			array(
				'status'     => $status,
				'updated_at' => Timestamps::now(),
			)
		);

		return self::find( $id );
	}

	/**
	 * Validate and sanitize raw input.
	 *
	 * @param array<string, mixed>      $input        Raw input.
	 * @param int|null                  $excluding_id Event ID to exclude from the slug uniqueness check (update only).
	 * @param array<string, mixed>|null $existing     Existing raw row, for partial updates.
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, ?int $excluding_id, ?array $existing ): array {
		$get = static function ( string $key, $default ) use ( $input, $existing ) {
			if ( array_key_exists( $key, $input ) ) {
				return $input[ $key ];
			}

			if ( null !== $existing && array_key_exists( $key, $existing ) ) {
				return $existing[ $key ];
			}

			return $default;
		};

		$errors = array();

		$title = trim( sanitize_text_field( (string) $get( 'title', '' ) ) );

		if ( '' === $title ) {
			$errors['title'] = __( 'Title is required.', 'bookflow-booking-scheduling' );
		}

		$status = (string) $get( 'status', 'draft' );

		if ( ! in_array( $status, Event::statuses(), true ) ) {
			$errors['status'] = __( 'Invalid event status.', 'bookflow-booking-scheduling' );
		}

		$timezone = (string) $get( 'timezone', '' );

		// Not `in_array( $timezone, DateTimeZone::listIdentifiers(), true )`: that only accepts
		// named IANA identifiers ('UTC', 'Africa/Lagos', ...), but Events_Page passes
		// wp_timezone()->getName() here, which returns a raw UTC-offset string like '+00:00' —
		// not a listIdentifiers() entry — for any site configured with a numeric UTC offset
		// instead of a named timezone under Settings → General (the default for a fresh
		// install, confirmed against a real WordPress site: every event creation failed with
		// this exact "invalid timezone" error until this was fixed). Constructing a real
		// DateTimeZone accepts both forms and is the same thing PHP itself will do with this
		// value later, so it's the correct validity check either way.
		try {
			new \DateTimeZone( $timezone );
		} catch ( \Exception $e ) {
			$errors['timezone'] = __( 'A valid timezone is required.', 'bookflow-booking-scheduling' );
		}

		// $get()'s generic array_key_exists() fallback can't resolve these on a partial update:
		// the raw row stores them as 'start_datetime_utc'/'end_datetime_utc' STRING columns, a
		// different key name than the 'start'/'end' DateTimeImmutable objects create() is called
		// with — so they need their own explicit "provided, or reconstructed from the existing
		// row, or null on create()" resolution instead of going through $get().
		$start = self::resolve_datetime( $input['start'] ?? null, $existing['start_datetime_utc'] ?? null );
		$end   = self::resolve_datetime( $input['end'] ?? null, $existing['end_datetime_utc'] ?? null );

		if ( ! ( $start instanceof \DateTimeImmutable ) ) {
			$errors['start'] = __( 'A valid start date and time is required.', 'bookflow-booking-scheduling' );
		}

		if ( ! ( $end instanceof \DateTimeImmutable ) ) {
			$errors['end'] = __( 'A valid end date and time is required.', 'bookflow-booking-scheduling' );
		} elseif ( $start instanceof \DateTimeImmutable && $end <= $start ) {
			$errors['end'] = __( 'End time must be after start time.', 'bookflow-booking-scheduling' );
		}

		$capacity_raw = $get( 'capacity', null );

		if ( null !== $capacity_raw && '' !== $capacity_raw && (int) $capacity_raw < 1 ) {
			$errors['capacity'] = __( 'Capacity must be at least 1, or left blank for unlimited.', 'bookflow-booking-scheduling' );
		}

		if ( ! empty( $errors ) ) {
			throw new Validation_Exception( $errors, __( 'The event could not be saved.', 'bookflow-booking-scheduling' ) );
		}

		$slug_input = $get( 'slug', '' );
		$slug       = '' !== trim( (string) $slug_input ) ? sanitize_title( (string) $slug_input ) : null;

		if ( null === $slug || '' === $slug || self::exists_by( 'slug', $slug, '%s', $excluding_id ) ) {
			$slug = Slugs::unique(
				$slug ? $slug : $title,
				static function ( string $candidate ) use ( $excluding_id ): bool {
					return self::exists_by( 'slug', $candidate, '%s', $excluding_id );
				},
				'event'
			);
		}

		$location_id_raw = $get( 'location_id', null );
		$location_id     = ( null !== $location_id_raw && '' !== $location_id_raw ) ? absint( $location_id_raw ) : null;

		$capacity = ( null !== $capacity_raw && '' !== $capacity_raw ) ? absint( $capacity_raw ) : null;

		$image_id_raw = $get( 'image_id', null );
		$image_id     = ( null !== $image_id_raw && '' !== $image_id_raw ) ? absint( $image_id_raw ) : null;

		$price_raw = $get( 'price', null );
		$price     = ( null !== $price_raw && '' !== $price_raw ) ? max( 0.0, (float) $price_raw ) : null;

		$currency = $get( 'currency', null );

		$settings = $get( 'settings', array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$utc = new \DateTimeZone( 'UTC' );

		return array(
			'title'              => $title,
			'slug'               => $slug,
			'description'        => wp_kses_post( (string) $get( 'description', '' ) ),
			'start_datetime_utc' => $start->setTimezone( $utc )->format( 'Y-m-d H:i:s' ),
			'end_datetime_utc'   => $end->setTimezone( $utc )->format( 'Y-m-d H:i:s' ),
			'timezone'           => $timezone,
			'location_id'        => $location_id,
			'capacity'           => $capacity,
			'image_id'           => $image_id,
			'status'             => $status,
			'price'              => $price,
			'currency'           => $currency ? strtoupper( (string) $currency ) : null,
			'settings'           => wp_json_encode( $settings ),
		);
	}
}

<?php
/**
 * Handles the event registration form's POST (submitted from either the [bookflow_event]
 * shortcode, wherever it's embedded, or the dedicated /events/{slug} page) and the
 * manage-registration page's cancel POST — both plain HTML forms, no AJAX/JS (see
 * Bootstrap's docblock for why).
 *
 * Both run on `template_redirect` (before any output), following the same POST/redirect/GET
 * pattern used throughout the plugin's public forms (Frontend\Manage_Booking's cancel handler
 * is the closest precedent) — a reload never resubmits, and each no-ops immediately unless the
 * current request actually matches its own action.
 *
 * @package BookFlow\Events
 */

declare( strict_types = 1 );

namespace BookFlow\Events;

use BookFlow\Booking\Booking_Conflict_Exception;
use BookFlow\CustomFields\Custom_Field_Repository;
use BookFlow\Customers\Customer_Repository;
use BookFlow\Support\Rate_Limiter;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Registration_Handler
 */
final class Registration_Handler {

	/**
	 * Transient key prefix for one-time error messages carried across the redirect (arbitrary
	 * length text can't safely live in the redirect URL's query string the way the success
	 * reference can).
	 *
	 * @var string
	 */
	private const ERROR_TRANSIENT_PREFIX = 'bookflow_event_reg_error_';

	/**
	 * Handle the registration form submission.
	 */
	public static function maybe_handle_registration(): void {
		if ( ! isset( $_POST['bookflow_action'] ) || 'register_for_event' !== $_POST['bookflow_action'] ) {
			return;
		}

		$event_id = isset( $_POST['event_id'] ) ? absint( $_POST['event_id'] ) : 0;
		$nonce    = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'bookflow_register_event_' . $event_id ) ) {
			self::redirect_with_error( __( 'Your session expired. Please try again.', 'bookflow-booking-scheduling' ) );
		}

		if ( ! Rate_Limiter::allow( 'event_register_' . Rate_Limiter::client_identity(), 8, 300 ) ) {
			self::redirect_with_error( __( 'Too many attempts. Please wait a few minutes and try again.', 'bookflow-booking-scheduling' ) );
		}

		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';

		if ( ! is_email( $email ) ) {
			self::redirect_with_error( __( 'Please enter a valid email address.', 'bookflow-booking-scheduling' ) );
		}

		$fields = Custom_Field_Repository::for_context( 'event', $event_id );
		[ $answers, $field_errors ] = self::collect_custom_field_answers( $fields );

		if ( ! empty( $field_errors ) ) {
			self::redirect_with_error( implode( ' ', $field_errors ) );
		}

		try {
			$customer = Customer_Repository::find_or_create_by_email(
				$email,
				array(
					'first_name' => isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '',
					'last_name'  => isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '',
					'phone'      => isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '',
				)
			);

			$attendee = Event_Attendee_Repository::register(
				array(
					'event_id'      => $event_id,
					'customer_id'   => $customer->id,
					'quantity'      => isset( $_POST['quantity'] ) ? max( 1, (int) $_POST['quantity'] ) : 1,
					'custom_fields' => $answers,
				)
			);

			wp_safe_redirect( add_query_arg( 'bookflow_registered', $attendee->booking_reference, self::return_url() ) );
			exit;
		} catch ( Validation_Exception $e ) {
			self::redirect_with_error( implode( ' ', $e->errors() ) );
		} catch ( Booking_Conflict_Exception $e ) {
			self::redirect_with_error( $e->getMessage() );
		}
	}

	/**
	 * Handle the manage-registration page's "Cancel my registration" POST.
	 */
	public static function maybe_handle_cancel(): void {
		if ( ! isset( $_POST['bookflow_action'] ) || 'cancel_registration' !== $_POST['bookflow_action'] ) {
			return;
		}

		// Defense-in-depth alongside the nonce check below — see
		// Frontend\Manage_Booking::maybe_handle_cancel()'s identical rationale.
		if ( ! Rate_Limiter::allow( 'cancel_registration_' . Rate_Limiter::client_identity(), 8, 300 ) ) {
			wp_die( esc_html__( 'Too many attempts. Please wait a few minutes and try again.', 'bookflow-booking-scheduling' ), 429 );
		}

		$token = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		$nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';

		// A plain wp_verify_nonce() rather than check_admin_referer() — see
		// Frontend\Manage_Booking::maybe_handle_cancel() for the identical rationale: the
		// latter's failure screen is styled for wp-admin. Token possession is the real
		// authorization here; the nonce is defense-in-depth, so failing it silently (redirect
		// back, nothing cancelled) is correct, not a wp_die().
		if ( ! wp_verify_nonce( $nonce, 'bookflow_cancel_registration_' . $token ) ) {
			wp_safe_redirect( Bootstrap::manage_url( $token ) );
			exit;
		}

		$attendee = '' !== $token ? Event_Attendee_Repository::find_by_cancel_token( $token ) : null;

		if ( null !== $attendee && $attendee->is_active() ) {
			Event_Attendee_Repository::cancel( $attendee->id );
		}

		wp_safe_redirect( Bootstrap::manage_url( $token ) );
		exit;
	}

	/**
	 * Queue a one-time error message and redirect back to the page the form was submitted from.
	 */
	private static function redirect_with_error( string $message ): void {
		$token = wp_generate_password( 12, false );

		set_transient( self::ERROR_TRANSIENT_PREFIX . $token, $message, 60 );

		wp_safe_redirect( add_query_arg( 'bookflow_reg_error', $token, self::return_url() ) );
		exit;
	}

	/**
	 * Read and consume (delete) a one-time error message by its token, for the template to
	 * display. Returns '' if the token is missing/expired/already consumed.
	 */
	public static function consume_error( string $token ): string {
		if ( '' === $token ) {
			return '';
		}

		$key     = self::ERROR_TRANSIENT_PREFIX . $token;
		$message = get_transient( $key );

		delete_transient( $key );

		return is_string( $message ) ? $message : '';
	}

	/**
	 * Where to send the visitor back to after processing — the page the form was actually
	 * submitted from (works whether that's the dedicated /events/{slug} page or an arbitrary
	 * page embedding the [bookflow_event] shortcode), falling back to the site home if the
	 * referer is unavailable (e.g. stripped by the browser/a privacy extension).
	 *
	 * Not `wp_get_referer()` alone: this form has no `action` attribute (submits to its own
	 * current URL — see templates/event-registration.php), so on every real submission the
	 * `_wp_http_referer` hidden field's value is IDENTICAL to the request's own URI.
	 * `wp_get_referer()` treats a referer equal to the current request URI as suspicious and
	 * deliberately returns false in that case — a false positive for this form's own design,
	 * confirmed against a real WordPress install: every registration silently redirected to the
	 * site homepage instead of back to the event page, losing the success message entirely (the
	 * registration itself still succeeded — only the confirmation display was lost). Reading the
	 * submitted field directly (validated via wp_validate_redirect(), the same safety check
	 * wp_safe_redirect() itself applies) uses the value for exactly what it's for without
	 * tripping that guard, while still falling back to wp_get_referer()/home_url() if it's ever
	 * genuinely absent.
	 */
	private static function return_url(): string {
		if ( isset( $_REQUEST['_wp_http_referer'] ) ) {
			$submitted = wp_validate_redirect( wp_unslash( $_REQUEST['_wp_http_referer'] ), '' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- not a state change on its own; the actual state-changing action this accompanies is nonce-checked before this ever runs.

			if ( $submitted ) {
				return $submitted;
			}
		}

		$referer = wp_get_referer();

		return $referer ? $referer : home_url( '/' );
	}

	/**
	 * Read, validate, and sanitize the 'custom_fields' POST field (field_key => raw string,
	 * submitted as individual form fields named custom_fields[key] — not JSON, since this is a
	 * plain HTML form, not an AJAX request) against the given field definitions.
	 *
	 * @param array<int, \BookFlow\CustomFields\Custom_Field> $fields Field definitions.
	 * @return array{0: array<string, string>, 1: array<string, string>} [ answers, errors ].
	 */
	private static function collect_custom_field_answers( array $fields ): array {
		$raw = isset( $_POST['custom_fields'] ) && is_array( $_POST['custom_fields'] ) ? wp_unslash( $_POST['custom_fields'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce already verified by the caller before this is reached.

		$answers = array();
		$errors  = array();

		foreach ( $fields as $field ) {
			$value = $raw[ $field->field_key ] ?? null;
			$error = $field->validate_answer( $value );

			if ( null !== $error ) {
				$errors[ $field->field_key ] = $error;
				continue;
			}

			if ( null !== $value && '' !== trim( (string) $value ) ) {
				$answers[ $field->field_key ] = $field->sanitize_answer( $value );
			}
		}

		return array( $answers, $errors );
	}
}

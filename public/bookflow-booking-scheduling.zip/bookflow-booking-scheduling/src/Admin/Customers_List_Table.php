<?php
/**
 * Customers list table — paginated server-side (Section 10 explicitly calls out customers,
 * alongside bookings/events, as needing it — unlike Services/Staff/Locations/Scheduling pages).
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Booking\Appointment_Repository;
use BookFlow\Customers\Customer;
use BookFlow\Customers\Customer_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Class Customers_List_Table
 */
final class Customers_List_Table extends \WP_List_Table {

	/**
	 * Rows per page.
	 *
	 * @var int
	 */
	private const PER_PAGE = 20;

	/**
	 * Booking counts for the customers on the current page, keyed by customer_id — batch-fetched
	 * once in prepare_items() via Appointment_Repository::counts_by_customer() instead of
	 * running a separate COUNT query per row in column_default() (N+1).
	 *
	 * @var array<int, int>
	 */
	private array $booking_counts = array();

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'customer',
				'plural'   => 'customers',
				'ajax'     => false,
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'name'     => __( 'Name', 'bookflow-booking-scheduling' ),
			'email'    => __( 'Email', 'bookflow-booking-scheduling' ),
			'phone'    => __( 'Phone', 'bookflow-booking-scheduling' ),
			'bookings' => __( 'Bookings', 'bookflow-booking-scheduling' ),
			'joined'   => __( 'Joined', 'bookflow-booking-scheduling' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'name'   => array( 'last_name', false ),
			'email'  => array( 'email', false ),
			'joined' => array( 'created_at', false ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function prepare_items(): void {
		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns() );

		$args = array();

		if ( ! empty( $_GET['s'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filtering.
			$args['search'] = sanitize_text_field( wp_unslash( $_GET['s'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		$current_page   = $this->get_pagenum();
		$args['limit']  = self::PER_PAGE;
		$args['offset'] = ( $current_page - 1 ) * self::PER_PAGE;
		$args['orderby'] = isset( $_GET['orderby'] ) ? sanitize_key( $_GET['orderby'] ) : 'created_at'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$args['order']   = isset( $_GET['order'] ) ? sanitize_key( $_GET['order'] ) : 'desc'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$total       = Customer_Repository::count( $args );
		$this->items = Customer_Repository::all( $args );

		$this->booking_counts = Appointment_Repository::counts_by_customer(
			array_map(
				static function ( Customer $customer ): int {
					return $customer->id;
				},
				$this->items
			)
		);

		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => self::PER_PAGE,
				'total_pages' => (int) ceil( $total / self::PER_PAGE ),
			)
		);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Customer $item Row data.
	 */
	public function column_name( $item ): string {
		$edit_url   = add_query_arg( array( 'page' => 'bookflow-customers', 'action' => 'edit', 'id' => $item->id ), admin_url( 'admin.php' ) );
		$delete_url = wp_nonce_url( add_query_arg( array( 'page' => 'bookflow-customers', 'bookflow_action' => 'delete', 'id' => $item->id ), admin_url( 'admin.php' ) ), 'bookflow_delete_customer_' . $item->id );

		$actions = array(
			'edit'   => sprintf( '<a href="%s">%s</a>', esc_url( $edit_url ), esc_html__( 'Edit', 'bookflow-booking-scheduling' ) ),
			'delete' => sprintf(
				'<a href="%s" onclick="return confirm(%s);">%s</a>',
				esc_url( $delete_url ),
				esc_attr( wp_json_encode( __( 'Delete this customer? Their bookings will remain but will no longer show a linked customer record. This cannot be undone.', 'bookflow-booking-scheduling' ) ) ),
				esc_html__( 'Delete', 'bookflow-booking-scheduling' )
			),
		);

		return sprintf( '<strong><a href="%s">%s</a></strong>%s', esc_url( $edit_url ), esc_html( $item->display_name() ), $this->row_actions( $actions ) );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Customer $item        Row data.
	 * @param string   $column_name Column key.
	 */
	public function column_default( $item, $column_name ): string {
		switch ( $column_name ) {
			case 'email':
				return esc_html( $item->email );

			case 'phone':
				return $item->phone ? esc_html( $item->phone ) : '&#8212;';

			case 'bookings':
				return esc_html( (string) ( $this->booking_counts[ $item->id ] ?? 0 ) );

			case 'joined':
				// Not mysql2date(): it formats the stored string as-is with no UTC-to-site-
				// timezone conversion, and created_at is stored in UTC like every other
				// datetime column in this plugin (docs/ARCHITECTURE.md §9) — a real
				// DateTimeImmutable conversion costs nothing extra and stays consistent with
				// how every booking time elsewhere is displayed.
				$joined = new \DateTimeImmutable( $item->created_at, new \DateTimeZone( 'UTC' ) );
				return esc_html( $joined->setTimezone( wp_timezone() )->format( get_option( 'date_format' ) ) );

			default:
				return '';
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public function no_items(): void {
		esc_html_e( 'No customers yet.', 'bookflow-booking-scheduling' );
	}
}

<?php
/**
 * Services admin screen: list, add, edit, delete.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Locations\Location_Repository;
use BookFlow\Services\Service;
use BookFlow\Services\Service_Category_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Services_Page
 */
final class Services_Page {

	/**
	 * Validation errors from the most recent failed save attempt in THIS request, if any —
	 * consumed by render() to redisplay the form with inline errors instead of redirecting.
	 *
	 * @var Validation_Exception|null
	 */
	private static ?Validation_Exception $error = null;

	/**
	 * Raw $_POST from the most recent failed save attempt in THIS request, for re-populating
	 * the form.
	 *
	 * @var array<string, mixed>
	 */
	private static array $submitted = array();

	/**
	 * Process add/edit/delete submissions. Hooked to admin_init so a successful save can
	 * redirect before any HTML is sent.
	 */
	public static function handle_request(): void {
		if ( ! self::is_current_screen() ) {
			return;
		}

		if ( isset( $_GET['bookflow_action'], $_GET['id'] ) && 'delete' === $_GET['bookflow_action'] ) {
			self::handle_delete( absint( $_GET['id'] ) );
			return;
		}

		if ( isset( $_POST['bookflow_action'] ) && 'save' === $_POST['bookflow_action'] ) {
			self::handle_save();
		}
	}

	/**
	 * Render the screen: list, add form, or edit form, based on ?action=.
	 */
	public static function render(): void {
		$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : 'list'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.

		if ( 'add' === $action || 'edit' === $action || null !== self::$error ) {
			self::render_form( $action );
			return;
		}

		self::render_list();
	}

	/**
	 * Whether the current admin request targets this screen.
	 */
	private static function is_current_screen(): bool {
		return isset( $_GET['page'] ) && 'bookflow-services' === $_GET['page']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- routing check only.
	}

	/**
	 * Handle a delete link click.
	 */
	private static function handle_delete( int $id ): void {
		Form_Guard::verify( 'bookflow_delete_service_' . $id );

		Service_Repository::delete( $id );

		Notices::add( __( 'Service deleted.', 'bookflow-booking-scheduling' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-services' ) );
		exit;
	}

	/**
	 * Handle the add/edit form submission.
	 */
	private static function handle_save(): void {
		Form_Guard::verify( 'bookflow_save_service' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

		$category_id = self::resolve_category(
			isset( $_POST['category_id'] ) ? sanitize_text_field( wp_unslash( $_POST['category_id'] ) ) : '',
			isset( $_POST['new_category_name'] ) ? sanitize_text_field( wp_unslash( $_POST['new_category_name'] ) ) : ''
		);

		$input = array(
			'name'             => isset( $_POST['name'] ) ? wp_unslash( $_POST['name'] ) : '',
			'category_id'      => $category_id,
			'description'      => isset( $_POST['description'] ) ? wp_unslash( $_POST['description'] ) : '',
			'duration_minutes' => isset( $_POST['duration_minutes'] ) ? (int) $_POST['duration_minutes'] : 30,
			'price'            => isset( $_POST['price'] ) && '' !== $_POST['price'] ? (float) $_POST['price'] : null,
			'currency'         => isset( $_POST['currency'] ) ? strtoupper( wp_unslash( $_POST['currency'] ) ) : '',
			'capacity'         => isset( $_POST['capacity'] ) ? (int) $_POST['capacity'] : 1,
			'color'            => isset( $_POST['color'] ) ? wp_unslash( $_POST['color'] ) : '',
			'status'           => isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : 'active',
			'sort_order'       => isset( $_POST['sort_order'] ) ? (int) $_POST['sort_order'] : 0,
			'settings'         => array(
				'buffer_before_minutes' => isset( $_POST['buffer_before_minutes'] ) ? max( 0, (int) $_POST['buffer_before_minutes'] ) : 0,
				'buffer_after_minutes'  => isset( $_POST['buffer_after_minutes'] ) ? max( 0, (int) $_POST['buffer_after_minutes'] ) : 0,
				'min_notice_minutes'    => isset( $_POST['min_notice_minutes'] ) ? max( 0, (int) $_POST['min_notice_minutes'] ) : 0,
				'max_advance_days'      => isset( $_POST['max_advance_days'] ) && '' !== $_POST['max_advance_days'] ? max( 0, (int) $_POST['max_advance_days'] ) : null,
				'approval_required'     => ! empty( $_POST['approval_required'] ),
			),
		);

		$staff_ids     = array_map( 'absint', (array) ( $_POST['staff_ids'] ?? array() ) );
		$location_ids  = array_map( 'absint', (array) ( $_POST['location_ids'] ?? array() ) );

		try {
			$service = $id > 0 ? Service_Repository::update( $id, $input ) : Service_Repository::create( $input );

			Service_Repository::set_staff( $service->id, $staff_ids );
			Service_Repository::set_locations( $service->id, $location_ids );

			Notices::add( $id > 0 ? __( 'Service updated.', 'bookflow-booking-scheduling' ) : __( 'Service created.', 'bookflow-booking-scheduling' ) );
			wp_safe_redirect( admin_url( 'admin.php?page=bookflow-services' ) );
			exit;
		} catch ( Validation_Exception $e ) {
			self::$error     = $e;
			self::$submitted = wp_unslash( $_POST );
		}
	}

	/**
	 * Find an existing category by ID, or create one from a typed name — supports the form's
	 * "or create a new category" text field without a separate category management screen.
	 *
	 * @param string $category_id_field Selected existing category ID (as string, '' = none).
	 * @param string $new_category_name New category name, if the admin typed one.
	 */
	private static function resolve_category( string $category_id_field, string $new_category_name ): ?int {
		if ( '' !== trim( $new_category_name ) ) {
			$category = Service_Category_Repository::create( array( 'name' => $new_category_name ) );
			return $category->id;
		}

		return '' !== $category_id_field ? absint( $category_id_field ) : null;
	}

	/**
	 * Render the list screen.
	 */
	private static function render_list(): void {
		$table = new Services_List_Table();
		$table->prepare_items();

		$add_url = admin_url( 'admin.php?page=bookflow-services&action=add' );
		?>
		<div class="wrap bookflow-wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Services', 'bookflow-booking-scheduling' ); ?></h1>
			<a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action"><?php esc_html_e( 'Add Service', 'bookflow-booking-scheduling' ); ?></a>
			<hr class="wp-header-end" />
			<form method="get">
				<input type="hidden" name="page" value="bookflow-services" />
				<?php $table->search_box( __( 'Search services', 'bookflow-booking-scheduling' ), 'bookflow-service' ); ?>
				<?php $table->display(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the add/edit form.
	 */
	private static function render_form( string $action ): void {
		$service = null;

		if ( 'edit' === $action && empty( self::$submitted ) ) {
			$id      = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.
			$service = Service_Repository::find( $id );

			if ( null === $service ) {
				wp_die( esc_html__( 'Service not found.', 'bookflow-booking-scheduling' ) );
			}
		}

		$values = self::form_values( $service );

		$categories     = Service_Category_Repository::all();
		$staff_members   = Staff_Repository::all( array( 'status' => 'active' ) );
		$locations       = Location_Repository::all( array( 'status' => 'active' ) );
		$assigned_staff  = $service ? Service_Repository::staff_ids( $service->id ) : array();
		$assigned_locs   = $service ? Service_Repository::location_ids( $service->id ) : array();

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php echo $service ? esc_html__( 'Edit Service', 'bookflow-booking-scheduling' ) : esc_html__( 'Add Service', 'bookflow-booking-scheduling' ); ?></h1>

			<?php if ( self::$error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( implode( ' ', self::$error->errors() ) ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-services' ) ); ?>" class="bookflow-form">
				<?php wp_nonce_field( 'bookflow_save_service' ); ?>
				<input type="hidden" name="bookflow_action" value="save" />
				<input type="hidden" name="id" value="<?php echo esc_attr( (string) ( $service ? $service->id : 0 ) ); ?>" />

				<table class="form-table" role="presentation">
					<tr>
						<th><label for="bf-name"><?php esc_html_e( 'Name', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-name" name="name" class="regular-text" required value="<?php echo esc_attr( $values['name'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-category"><?php esc_html_e( 'Category', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-category" name="category_id">
								<option value=""><?php esc_html_e( '— None —', 'bookflow-booking-scheduling' ); ?></option>
								<?php foreach ( $categories as $category ) : ?>
									<option value="<?php echo esc_attr( (string) $category->id ); ?>" <?php selected( (string) $values['category_id'], (string) $category->id ); ?>><?php echo esc_html( $category->name ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description">
								<label for="bf-new-category"><?php esc_html_e( 'Or create a new category:', 'bookflow-booking-scheduling' ); ?></label>
								<input type="text" id="bf-new-category" name="new_category_name" class="regular-text" />
							</p>
						</td>
					</tr>
					<tr>
						<th><label for="bf-description"><?php esc_html_e( 'Description', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><textarea id="bf-description" name="description" rows="4" class="large-text"><?php echo esc_textarea( $values['description'] ); ?></textarea></td>
					</tr>
					<tr>
						<th><label for="bf-duration"><?php esc_html_e( 'Duration (minutes)', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="number" min="1" id="bf-duration" name="duration_minutes" value="<?php echo esc_attr( (string) $values['duration_minutes'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-price"><?php esc_html_e( 'Price', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<input type="number" min="0" step="0.01" id="bf-price" name="price" value="<?php echo esc_attr( (string) $values['price'] ); ?>" style="width:120px" />
							<input type="text" name="currency" maxlength="3" placeholder="USD" value="<?php echo esc_attr( $values['currency'] ); ?>" style="width:70px;text-transform:uppercase" />
						</td>
					</tr>
					<tr>
						<th><label for="bf-capacity"><?php esc_html_e( 'Capacity', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="number" min="1" id="bf-capacity" name="capacity" value="<?php echo esc_attr( (string) $values['capacity'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-color"><?php esc_html_e( 'Calendar color', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="color" id="bf-color" name="color" value="<?php echo esc_attr( $values['color'] ?: '#4C6EF5' ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-status"><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-status" name="status">
								<?php foreach ( Service::statuses() as $status ) : ?>
									<option value="<?php echo esc_attr( $status ); ?>" <?php selected( $values['status'], $status ); ?>><?php echo esc_html( ucfirst( $status ) ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Scheduling rules', 'bookflow-booking-scheduling' ); ?></th>
						<td>
							<p>
								<label><?php esc_html_e( 'Buffer before (minutes)', 'bookflow-booking-scheduling' ); ?>
									<input type="number" min="0" name="buffer_before_minutes" value="<?php echo esc_attr( (string) $values['buffer_before_minutes'] ); ?>" style="width:80px" /></label>
								&nbsp;
								<label><?php esc_html_e( 'Buffer after (minutes)', 'bookflow-booking-scheduling' ); ?>
									<input type="number" min="0" name="buffer_after_minutes" value="<?php echo esc_attr( (string) $values['buffer_after_minutes'] ); ?>" style="width:80px" /></label>
							</p>
							<p>
								<label><?php esc_html_e( 'Minimum notice (minutes)', 'bookflow-booking-scheduling' ); ?>
									<input type="number" min="0" name="min_notice_minutes" value="<?php echo esc_attr( (string) $values['min_notice_minutes'] ); ?>" style="width:80px" /></label>
								&nbsp;
								<label><?php esc_html_e( 'Maximum advance (days)', 'bookflow-booking-scheduling' ); ?>
									<input type="number" min="0" name="max_advance_days" value="<?php echo esc_attr( (string) $values['max_advance_days'] ); ?>" style="width:80px" /></label>
							</p>
							<p>
								<label><input type="checkbox" name="approval_required" value="1" <?php checked( $values['approval_required'] ); ?> /> <?php esc_html_e( 'Require approval before confirming a booking', 'bookflow-booking-scheduling' ); ?></label>
							</p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Staff', 'bookflow-booking-scheduling' ); ?></th>
						<td>
							<?php if ( empty( $staff_members ) ) : ?>
								<p class="description"><?php esc_html_e( 'No staff members yet.', 'bookflow-booking-scheduling' ); ?></p>
							<?php endif; ?>
							<?php foreach ( $staff_members as $staff ) : ?>
								<label style="display:block"><input type="checkbox" name="staff_ids[]" value="<?php echo esc_attr( (string) $staff->id ); ?>" <?php checked( in_array( $staff->id, $assigned_staff, true ) ); ?> /> <?php echo esc_html( $staff->display_name ); ?></label>
							<?php endforeach; ?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Locations', 'bookflow-booking-scheduling' ); ?></th>
						<td>
							<?php if ( empty( $locations ) ) : ?>
								<p class="description"><?php esc_html_e( 'No locations yet.', 'bookflow-booking-scheduling' ); ?></p>
							<?php endif; ?>
							<?php foreach ( $locations as $location ) : ?>
								<label style="display:block"><input type="checkbox" name="location_ids[]" value="<?php echo esc_attr( (string) $location->id ); ?>" <?php checked( in_array( $location->id, $assigned_locs, true ) ); ?> /> <?php echo esc_html( $location->name ); ?></label>
							<?php endforeach; ?>
						</td>
					</tr>
				</table>

				<?php submit_button( $service ? __( 'Update Service', 'bookflow-booking-scheduling' ) : __( 'Create Service', 'bookflow-booking-scheduling' ) ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-services' ) ); ?>" class="button-link" style="margin-left:8px"><?php esc_html_e( 'Cancel', 'bookflow-booking-scheduling' ); ?></a>
			</form>
		</div>
		<?php
	}

	/**
	 * Resolve display values for the form: from a resubmitted (invalid) POST, an existing
	 * service being edited, or defaults for a new one.
	 *
	 * @return array<string, mixed>
	 */
	private static function form_values( ?Service $service ): array {
		if ( ! empty( self::$submitted ) ) {
			$post     = self::$submitted;
			$settings = array();

			return array(
				'name'                   => $post['name'] ?? '',
				'category_id'            => $post['category_id'] ?? '',
				'description'            => $post['description'] ?? '',
				'duration_minutes'       => (int) ( $post['duration_minutes'] ?? 30 ),
				'price'                  => $post['price'] ?? '',
				'currency'               => $post['currency'] ?? '',
				'capacity'               => (int) ( $post['capacity'] ?? 1 ),
				'color'                  => $post['color'] ?? '',
				'status'                 => $post['status'] ?? 'active',
				'buffer_before_minutes'  => (int) ( $post['buffer_before_minutes'] ?? 0 ),
				'buffer_after_minutes'   => (int) ( $post['buffer_after_minutes'] ?? 0 ),
				'min_notice_minutes'     => (int) ( $post['min_notice_minutes'] ?? 0 ),
				'max_advance_days'       => $post['max_advance_days'] ?? '',
				'approval_required'      => ! empty( $post['approval_required'] ),
			);
		}

		if ( $service ) {
			return array(
				'name'                  => $service->name,
				'category_id'           => (string) $service->category_id,
				'description'           => (string) $service->description,
				'duration_minutes'      => $service->duration_minutes,
				'price'                 => $service->price,
				'currency'              => (string) $service->currency,
				'capacity'              => $service->capacity,
				'color'                 => (string) $service->color,
				'status'                => $service->status,
				'buffer_before_minutes' => (int) $service->setting( 'buffer_before_minutes', 0 ),
				'buffer_after_minutes'  => (int) $service->setting( 'buffer_after_minutes', 0 ),
				'min_notice_minutes'    => (int) $service->setting( 'min_notice_minutes', 0 ),
				'max_advance_days'      => $service->setting( 'max_advance_days', '' ),
				'approval_required'     => (bool) $service->setting( 'approval_required', false ),
			);
		}

		return array(
			'name'                  => '',
			'category_id'           => '',
			'description'           => '',
			'duration_minutes'      => 30,
			'price'                 => '',
			'currency'              => '',
			'capacity'              => 1,
			'color'                 => '',
			'status'                => 'active',
			'buffer_before_minutes' => 0,
			'buffer_after_minutes'  => 0,
			'min_notice_minutes'    => 0,
			'max_advance_days'      => '',
			'approval_required'     => false,
		);
	}
}

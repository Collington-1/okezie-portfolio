<?php
/**
 * Services list table. Services are reference data, not high-volume transactional records, so
 * (per Section 10) this deliberately does not paginate server-side — unlike Bookings_List_Table.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Services\Service;
use BookFlow\Services\Service_Category_Repository;
use BookFlow\Services\Service_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Class Services_List_Table
 */
final class Services_List_Table extends \WP_List_Table {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'service',
				'plural'   => 'services',
				'ajax'     => false,
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'name'     => __( 'Name', 'bookflow-booking-scheduling' ),
			'category' => __( 'Category', 'bookflow-booking-scheduling' ),
			'duration' => __( 'Duration', 'bookflow-booking-scheduling' ),
			'price'    => __( 'Price', 'bookflow-booking-scheduling' ),
			'capacity' => __( 'Capacity', 'bookflow-booking-scheduling' ),
			'status'   => __( 'Status', 'bookflow-booking-scheduling' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'name' => array( 'name', false ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function prepare_items(): void {
		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns() );

		// Defaults to alphabetical: there is no reorder UI yet (Phase 4 scope), so sort_order is
		// always 0 for every service and would otherwise leave rows in arbitrary DB order.
		$args = array(
			'orderby' => in_array( $_GET['orderby'] ?? '', array( 'name', 'sort_order', 'created_at' ), true ) ? $_GET['orderby'] : 'name', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filtering, no state change.
			'order'   => $_GET['order'] ?? 'asc', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		);

		if ( ! empty( $_GET['s'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['search'] = sanitize_text_field( wp_unslash( $_GET['s'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( ! empty( $_GET['status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['status'] = sanitize_key( $_GET['status'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		$this->items = Service_Repository::all( $args );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Service $item Row data.
	 */
	public function column_name( $item ): string {
		$edit_url   = add_query_arg( array( 'page' => 'bookflow-services', 'action' => 'edit', 'id' => $item->id ), admin_url( 'admin.php' ) );
		$delete_url = wp_nonce_url( add_query_arg( array( 'page' => 'bookflow-services', 'bookflow_action' => 'delete', 'id' => $item->id ), admin_url( 'admin.php' ) ), 'bookflow_delete_service_' . $item->id );

		$actions = array(
			'edit'   => sprintf( '<a href="%s">%s</a>', esc_url( $edit_url ), esc_html__( 'Edit', 'bookflow-booking-scheduling' ) ),
			'delete' => sprintf(
				'<a href="%s" onclick="return confirm(%s);">%s</a>',
				esc_url( $delete_url ),
				esc_attr( wp_json_encode( __( 'Delete this service? This cannot be undone.', 'bookflow-booking-scheduling' ) ) ),
				esc_html__( 'Delete', 'bookflow-booking-scheduling' )
			),
		);

		return sprintf( '<strong><a href="%s">%s</a></strong>%s', esc_url( $edit_url ), esc_html( $item->name ), $this->row_actions( $actions ) );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Service $item      Row data.
	 * @param string  $column_name Column key.
	 */
	public function column_default( $item, $column_name ): string {
		switch ( $column_name ) {
			case 'category':
				if ( ! $item->category_id ) {
					return '&#8212;';
				}
				$category = Service_Category_Repository::find( $item->category_id );
				return $category ? esc_html( $category->name ) : '&#8212;';

			case 'duration':
				/* translators: %d: duration in minutes. */
				return esc_html( sprintf( _n( '%d minute', '%d minutes', $item->duration_minutes, 'bookflow-booking-scheduling' ), $item->duration_minutes ) );

			case 'price':
				return null === $item->price ? '&#8212;' : esc_html( number_format_i18n( $item->price, 2 ) . ( $item->currency ? ' ' . $item->currency : '' ) );

			case 'capacity':
				return esc_html( (string) $item->capacity );

			case 'status':
				return sprintf( '<span class="bookflow-status bookflow-status--%1$s">%2$s</span>', esc_attr( $item->status ), esc_html( ucfirst( $item->status ) ) );

			default:
				return '';
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public function no_items(): void {
		esc_html_e( 'No services yet. Add your first service to get started.', 'bookflow-booking-scheduling' );
	}
}

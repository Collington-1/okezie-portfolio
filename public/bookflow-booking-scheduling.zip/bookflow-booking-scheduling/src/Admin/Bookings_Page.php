<?php
/**
 * Bookings admin screen: filtered/paginated list, single booking detail (notes, reschedule,
 * status), and manual "Add booking" — the only way to create an appointment before the
 * frontend booking flow (Phase 5) exists.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Booking\Appointment;
use BookFlow\Booking\Appointment_Repository;
use BookFlow\Booking\Appointment_State_Machine;
use BookFlow\Booking\Booking_Conflict_Exception;
use BookFlow\CustomFields\Custom_Field_Repository;
use BookFlow\Customers\Customer_Repository;
use BookFlow\Locations\Location_Repository;
use BookFlow\Notifications\Notification_Log;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Bookings_Page
 */
final class Bookings_Page {

	/**
	 * @var Validation_Exception|null
	 */
	private static ?Validation_Exception $error = null;

	/**
	 * @var array<string, mixed>
	 */
	private static array $submitted = array();

	/**
	 * Process transitions, notes/reschedule edits, and manual booking creation.
	 */
	public static function handle_request(): void {
		if ( ! self::is_current_screen() ) {
			return;
		}

		if ( isset( $_GET['bookflow_action'], $_GET['id'], $_GET['to'] ) && 'transition' === $_GET['bookflow_action'] ) {
			self::handle_transition( absint( $_GET['id'] ), sanitize_key( $_GET['to'] ) );
			return;
		}

		if ( ! isset( $_POST['bookflow_action'] ) ) {
			self::handle_bulk_action();
			return;
		}

		switch ( $_POST['bookflow_action'] ) {
			case 'add_booking':
				self::handle_add_booking();
				break;
			case 'save_notes':
				self::handle_save_notes();
				break;
			case 'reschedule':
				self::handle_reschedule();
				break;
		}
	}

	/**
	 * Render the screen.
	 */
	public static function render(): void {
		$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : 'list'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'add' === $action ) {
			self::render_add_form();
			return;
		}

		if ( 'view' === $action ) {
			self::render_detail();
			return;
		}

		self::render_list();
	}

	/**
	 * Whether the current admin request targets this screen.
	 */
	private static function is_current_screen(): bool {
		return isset( $_GET['page'] ) && 'bookflow-bookings' === $_GET['page']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Handle a single-row status transition link.
	 */
	private static function handle_transition( int $id, string $to ): void {
		Form_Guard::verify( 'bookflow_transition_booking_' . $id );

		$appointment = Appointment_Repository::find( $id );

		if ( null === $appointment ) {
			wp_die( esc_html__( 'Booking not found.', 'bookflow-booking-scheduling' ) );
		}

		try {
			Appointment_State_Machine::transition( $appointment, $to, get_current_user_id() );
			Notices::add( __( 'Booking status updated.', 'bookflow-booking-scheduling' ) );
		} catch ( \InvalidArgumentException $e ) {
			Notices::add( __( 'That status change is not allowed.', 'bookflow-booking-scheduling' ), 'error' );
		}

		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=bookflow-bookings' ) );
		exit;
	}

	/**
	 * Handle the list screen's bulk action dropdown (mark confirmed / cancel selected rows).
	 */
	private static function handle_bulk_action(): void {
		$action = self::current_bulk_action();

		if ( null === $action || empty( $_POST['booking_ids'] ) || ! is_array( $_POST['booking_ids'] ) ) {
			return;
		}

		Form_Guard::verify( 'bulk-bookings' );

		$to      = 'confirm' === $action ? 'confirmed' : 'cancelled';
		$ids     = array_map( 'absint', $_POST['booking_ids'] );
		$updated = 0;

		foreach ( $ids as $id ) {
			$appointment = Appointment_Repository::find( $id );

			if ( null === $appointment || ! Appointment_State_Machine::can_transition( $appointment->status, $to ) ) {
				continue;
			}

			Appointment_State_Machine::transition( $appointment, $to, get_current_user_id(), __( 'Bulk action', 'bookflow-booking-scheduling' ) );
			++$updated;
		}

		/* translators: %d: number of bookings updated. */
		Notices::add( sprintf( _n( '%d booking updated.', '%d bookings updated.', $updated, 'bookflow-booking-scheduling' ), $updated ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-bookings' ) );
		exit;
	}

	/**
	 * WP_List_Table renders both a top and bottom bulk-action dropdown ('action' and 'action2');
	 * only one is meaningfully selected. Returns the recognised action, or null if neither
	 * dropdown has a real selection.
	 */
	private static function current_bulk_action(): ?string {
		foreach ( array( 'action', 'action2' ) as $field ) {
			$value = isset( $_POST[ $field ] ) ? sanitize_key( $_POST[ $field ] ) : '-1';

			if ( in_array( $value, array( 'confirm', 'cancel' ), true ) ) {
				return $value;
			}
		}

		return null;
	}

	/**
	 * Handle the "Add booking" form.
	 */
	private static function handle_add_booking(): void {
		Form_Guard::verify( 'bookflow_add_booking' );

		self::$submitted = wp_unslash( $_POST );

		$email = isset( $_POST['customer_email'] ) ? sanitize_email( wp_unslash( $_POST['customer_email'] ) ) : '';

		if ( ! is_email( $email ) ) {
			self::$error = new Validation_Exception( array( 'customer_email' => __( 'A valid customer email is required.', 'bookflow-booking-scheduling' ) ) );
			return;
		}

		$date = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : '';
		$time = isset( $_POST['time'] ) ? sanitize_text_field( wp_unslash( $_POST['time'] ) ) : '';
		$site_timezone = wp_timezone();
		$start = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i', "{$date} {$time}", $site_timezone );

		if ( false === $start ) {
			self::$error = new Validation_Exception( array( 'date' => __( 'Please enter a valid date and time.', 'bookflow-booking-scheduling' ) ) );
			return;
		}

		try {
			$customer = Customer_Repository::find_or_create_by_email(
				$email,
				array(
					'first_name' => isset( $_POST['customer_first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['customer_first_name'] ) ) : '',
					'last_name'  => isset( $_POST['customer_last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['customer_last_name'] ) ) : '',
					'phone'      => isset( $_POST['customer_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['customer_phone'] ) ) : '',
				)
			);

			$appointment = Appointment_Repository::create(
				array(
					'service_id'  => isset( $_POST['service_id'] ) ? absint( $_POST['service_id'] ) : 0,
					'staff_id'    => ! empty( $_POST['staff_id'] ) ? absint( $_POST['staff_id'] ) : null,
					'location_id' => ! empty( $_POST['location_id'] ) ? absint( $_POST['location_id'] ) : null,
					'customer_id' => $customer->id,
					'start'       => $start,
					'timezone'    => $site_timezone->getName(),
					'status'      => in_array( $_POST['status'] ?? '', array( 'pending', 'confirmed' ), true ) ? $_POST['status'] : 'confirmed',
					'notes'       => isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '',
					'source'      => 'admin',
				)
			);

			Notices::add(
				sprintf(
					/* translators: %s: booking reference. */
					__( 'Booking %s created.', 'bookflow-booking-scheduling' ),
					$appointment->booking_reference
				)
			);
			wp_safe_redirect( admin_url( 'admin.php?page=bookflow-bookings' ) );
			exit;
		} catch ( Validation_Exception $e ) {
			self::$error = $e;
		} catch ( Booking_Conflict_Exception $e ) {
			self::$error = new Validation_Exception( array( 'start' => $e->getMessage() ) );
		}
	}

	/**
	 * Handle the detail screen's notes edit form.
	 */
	private static function handle_save_notes(): void {
		Form_Guard::verify( 'bookflow_booking_notes' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

		Appointment_Repository::update(
			$id,
			array( 'notes' => isset( $_POST['notes'] ) ? wp_unslash( $_POST['notes'] ) : '' )
		);

		Notices::add( __( 'Notes saved.', 'bookflow-booking-scheduling' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-bookings&action=view&id=' . $id ) );
		exit;
	}

	/**
	 * Handle the detail screen's reschedule form.
	 */
	private static function handle_reschedule(): void {
		Form_Guard::verify( 'bookflow_booking_reschedule' );

		$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$date = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : '';
		$time = isset( $_POST['time'] ) ? sanitize_text_field( wp_unslash( $_POST['time'] ) ) : '';

		$site_timezone = wp_timezone();
		$new_start     = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i', "{$date} {$time}", $site_timezone );

		if ( false === $new_start ) {
			Notices::add( __( 'Please enter a valid date and time.', 'bookflow-booking-scheduling' ), 'error' );
			wp_safe_redirect( admin_url( 'admin.php?page=bookflow-bookings&action=view&id=' . $id ) );
			exit;
		}

		try {
			Appointment_Repository::reschedule( $id, $new_start, $site_timezone->getName() );
			Notices::add( __( 'Booking rescheduled.', 'bookflow-booking-scheduling' ) );
		} catch ( Booking_Conflict_Exception $e ) {
			Notices::add( $e->getMessage(), 'error' );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-bookings&action=view&id=' . $id ) );
		exit;
	}

	/**
	 * Render the list screen.
	 */
	private static function render_list(): void {
		$table = new Bookings_List_Table();
		$table->prepare_items();

		$add_url = admin_url( 'admin.php?page=bookflow-bookings&action=add' );
		?>
		<div class="wrap bookflow-wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Bookings', 'bookflow-booking-scheduling' ); ?></h1>
			<a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action"><?php esc_html_e( 'Add Booking', 'bookflow-booking-scheduling' ); ?></a>
			<hr class="wp-header-end" />
			<?php $table->views(); ?>
			<form method="post">
				<input type="hidden" name="page" value="bookflow-bookings" />
				<?php $table->search_box( __( 'Search bookings', 'bookflow-booking-scheduling' ), 'bookflow-booking' ); ?>
				<?php $table->display(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the manual "Add booking" form.
	 */
	private static function render_add_form(): void {
		$values = array_merge(
			array(
				'service_id'         => '',
				'staff_id'           => '',
				'location_id'        => '',
				'customer_email'     => '',
				'customer_first_name' => '',
				'customer_last_name'  => '',
				'customer_phone'      => '',
				'date'               => '',
				'time'               => '',
				'status'             => 'confirmed',
				'notes'              => '',
			),
			self::$submitted
		);

		$services  = Service_Repository::all( array( 'status' => 'active' ) );
		$staff     = Staff_Repository::all( array( 'status' => 'active' ) );
		$locations = Location_Repository::all( array( 'status' => 'active' ) );

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php esc_html_e( 'Add Booking', 'bookflow-booking-scheduling' ); ?></h1>

			<?php if ( self::$error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( implode( ' ', self::$error->errors() ) ); ?></p></div>
			<?php endif; ?>

			<p class="description"><?php esc_html_e( 'Times are entered in your site’s timezone. BookFlow checks availability the same way the (upcoming) public booking page will.', 'bookflow-booking-scheduling' ); ?></p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-bookings' ) ); ?>" class="bookflow-form">
				<?php wp_nonce_field( 'bookflow_add_booking' ); ?>
				<input type="hidden" name="bookflow_action" value="add_booking" />

				<table class="form-table" role="presentation">
					<tr>
						<th><label for="bf-service"><?php esc_html_e( 'Service', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-service" name="service_id" required>
								<option value=""><?php esc_html_e( '— Select —', 'bookflow-booking-scheduling' ); ?></option>
								<?php foreach ( $services as $service ) : ?>
									<option value="<?php echo esc_attr( (string) $service->id ); ?>" <?php selected( (string) $values['service_id'], (string) $service->id ); ?>><?php echo esc_html( $service->name ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="bf-staff"><?php esc_html_e( 'Staff', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-staff" name="staff_id">
								<option value=""><?php esc_html_e( '— Any / none —', 'bookflow-booking-scheduling' ); ?></option>
								<?php foreach ( $staff as $member ) : ?>
									<option value="<?php echo esc_attr( (string) $member->id ); ?>" <?php selected( (string) $values['staff_id'], (string) $member->id ); ?>><?php echo esc_html( $member->display_name ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="bf-location"><?php esc_html_e( 'Location', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-location" name="location_id">
								<option value=""><?php esc_html_e( '— None —', 'bookflow-booking-scheduling' ); ?></option>
								<?php foreach ( $locations as $location ) : ?>
									<option value="<?php echo esc_attr( (string) $location->id ); ?>" <?php selected( (string) $values['location_id'], (string) $location->id ); ?>><?php echo esc_html( $location->name ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="bf-date"><?php esc_html_e( 'Date & time', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<input type="date" id="bf-date" name="date" required value="<?php echo esc_attr( $values['date'] ); ?>" />
							<input type="time" name="time" required value="<?php echo esc_attr( $values['time'] ); ?>" />
						</td>
					</tr>
					<tr>
						<th><label for="bf-customer-email"><?php esc_html_e( 'Customer email', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="email" id="bf-customer-email" name="customer_email" class="regular-text" required value="<?php echo esc_attr( $values['customer_email'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-customer-first"><?php esc_html_e( 'Customer name', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<input type="text" id="bf-customer-first" name="customer_first_name" placeholder="<?php esc_attr_e( 'First name', 'bookflow-booking-scheduling' ); ?>" value="<?php echo esc_attr( $values['customer_first_name'] ); ?>" />
							<input type="text" name="customer_last_name" placeholder="<?php esc_attr_e( 'Last name', 'bookflow-booking-scheduling' ); ?>" value="<?php echo esc_attr( $values['customer_last_name'] ); ?>" />
						</td>
					</tr>
					<tr>
						<th><label for="bf-customer-phone"><?php esc_html_e( 'Customer phone', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-customer-phone" name="customer_phone" class="regular-text" value="<?php echo esc_attr( $values['customer_phone'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-status"><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-status" name="status">
								<option value="confirmed" <?php selected( $values['status'], 'confirmed' ); ?>><?php esc_html_e( 'Confirmed', 'bookflow-booking-scheduling' ); ?></option>
								<option value="pending" <?php selected( $values['status'], 'pending' ); ?>><?php esc_html_e( 'Pending', 'bookflow-booking-scheduling' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="bf-notes"><?php esc_html_e( 'Notes', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><textarea id="bf-notes" name="notes" rows="3" class="large-text"><?php echo esc_textarea( $values['notes'] ); ?></textarea></td>
					</tr>
				</table>

				<?php submit_button( __( 'Create Booking', 'bookflow-booking-scheduling' ) ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-bookings' ) ); ?>" class="button-link" style="margin-left:8px"><?php esc_html_e( 'Cancel', 'bookflow-booking-scheduling' ); ?></a>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the single booking detail screen.
	 */
	private static function render_detail(): void {
		$id          = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$appointment = Appointment_Repository::find( $id );

		if ( null === $appointment ) {
			wp_die( esc_html__( 'Booking not found.', 'bookflow-booking-scheduling' ) );
		}

		$customer = Customer_Repository::find( $appointment->customer_id );
		$service  = Service_Repository::find( $appointment->service_id );
		$staff    = $appointment->staff_id ? Staff_Repository::find( $appointment->staff_id ) : null;
		$location = $appointment->location_id ? Location_Repository::find( $appointment->location_id ) : null;

		$site_timezone  = wp_timezone();
		$local_start    = $appointment->start->setTimezone( $site_timezone );

		?>
		<div class="wrap bookflow-wrap">
			<h1>
				<?php
				printf(
					/* translators: %s: booking reference. */
					esc_html__( 'Booking %s', 'bookflow-booking-scheduling' ),
					esc_html( $appointment->booking_reference )
				);
				?>
			</h1>

			<p>
				<span class="bookflow-status bookflow-status--<?php echo esc_attr( $appointment->status ); ?>"><?php echo esc_html( ucfirst( str_replace( '_', '-', $appointment->status ) ) ); ?></span>
				<?php foreach ( Appointment::statuses() as $to ) :
					if ( ! Appointment_State_Machine::can_transition( $appointment->status, $to ) ) {
						continue;
					}
					$url = wp_nonce_url( add_query_arg( array( 'page' => 'bookflow-bookings', 'bookflow_action' => 'transition', 'id' => $appointment->id, 'to' => $to ), admin_url( 'admin.php' ) ), 'bookflow_transition_booking_' . $appointment->id );
					?>
					<a href="<?php echo esc_url( $url ); ?>" class="button"><?php echo esc_html( ucfirst( str_replace( '_', ' ', $to ) ) ); ?></a>
				<?php endforeach; ?>
			</p>

			<table class="form-table" role="presentation">
				<tr><th><?php esc_html_e( 'Customer', 'bookflow-booking-scheduling' ); ?></th><td><?php echo $customer ? esc_html( $customer->display_name() . ' <' . $customer->email . '>' ) : '&#8212;'; ?></td></tr>
				<tr><th><?php esc_html_e( 'Service', 'bookflow-booking-scheduling' ); ?></th><td><?php echo $service ? esc_html( $service->name ) : '&#8212;'; ?></td></tr>
				<tr><th><?php esc_html_e( 'Staff', 'bookflow-booking-scheduling' ); ?></th><td><?php echo $staff ? esc_html( $staff->display_name ) : '&#8212;'; ?></td></tr>
				<tr><th><?php esc_html_e( 'Location', 'bookflow-booking-scheduling' ); ?></th><td><?php echo $location ? esc_html( $location->name ) : '&#8212;'; ?></td></tr>
				<tr><th><?php esc_html_e( 'Date & time (site timezone)', 'bookflow-booking-scheduling' ); ?></th><td><?php echo esc_html( $local_start->format( 'Y-m-d H:i' ) . ' – ' . $appointment->end->setTimezone( $site_timezone )->format( 'H:i' ) ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Booked in customer’s timezone', 'bookflow-booking-scheduling' ); ?></th><td><?php echo esc_html( $appointment->timezone ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Source', 'bookflow-booking-scheduling' ); ?></th><td><?php echo esc_html( ucfirst( $appointment->source ) ); ?></td></tr>
			</table>

			<?php self::render_custom_field_answers( $appointment ); ?>

			<h2><?php esc_html_e( 'Notes', 'bookflow-booking-scheduling' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-bookings' ) ); ?>">
				<?php wp_nonce_field( 'bookflow_booking_notes' ); ?>
				<input type="hidden" name="bookflow_action" value="save_notes" />
				<input type="hidden" name="id" value="<?php echo esc_attr( (string) $appointment->id ); ?>" />
				<textarea name="notes" rows="4" class="large-text"><?php echo esc_textarea( (string) $appointment->notes ); ?></textarea>
				<?php submit_button( __( 'Save Notes', 'bookflow-booking-scheduling' ), 'secondary' ); ?>
			</form>

			<h2><?php esc_html_e( 'Reschedule', 'bookflow-booking-scheduling' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-bookings' ) ); ?>">
				<?php wp_nonce_field( 'bookflow_booking_reschedule' ); ?>
				<input type="hidden" name="bookflow_action" value="reschedule" />
				<input type="hidden" name="id" value="<?php echo esc_attr( (string) $appointment->id ); ?>" />
				<input type="date" name="date" required value="<?php echo esc_attr( $local_start->format( 'Y-m-d' ) ); ?>" />
				<input type="time" name="time" required value="<?php echo esc_attr( $local_start->format( 'H:i' ) ); ?>" />
				<?php submit_button( __( 'Reschedule', 'bookflow-booking-scheduling' ), 'secondary' ); ?>
			</form>

			<?php self::render_notification_history( $appointment->id ); ?>

			<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-bookings' ) ); ?>">&larr; <?php esc_html_e( 'Back to bookings', 'bookflow-booking-scheduling' ); ?></a></p>
		</div>
		<?php
	}

	/**
	 * The customer's answers to any custom booking questions — collected since Phase 6/7 but,
	 * until this review pass, never actually shown anywhere for an admin to read (Section 34:
	 * "do not claim a feature is complete unless it is actually implemented"; collecting an
	 * answer nobody can ever see is not a complete feature). Resolves field_key => label from
	 * whichever set of question definitions this booking would have used at booking time — the
	 * scheduling page's own questions if booked through one, else the service's — falling back
	 * to the raw key if a definition was since edited or deleted.
	 */
	private static function render_custom_field_answers( Appointment $appointment ): void {
		if ( empty( $appointment->custom_fields ) ) {
			return;
		}

		$fields = $appointment->scheduling_page_id
			? Custom_Field_Repository::for_context( 'scheduling_page', $appointment->scheduling_page_id )
			: Custom_Field_Repository::for_context( 'appointment', $appointment->service_id );

		$labels = array();
		foreach ( $fields as $field ) {
			$labels[ $field->field_key ] = $field->label;
		}

		?>
		<h2><?php esc_html_e( 'Additional details', 'bookflow-booking-scheduling' ); ?></h2>
		<table class="form-table" role="presentation">
			<?php foreach ( $appointment->custom_fields as $key => $answer ) : ?>
				<tr>
					<th><?php echo esc_html( $labels[ $key ] ?? $key ); ?></th>
					<td><?php echo esc_html( is_scalar( $answer ) ? (string) $answer : wp_json_encode( $answer ) ); ?></td>
				</tr>
			<?php endforeach; ?>
		</table>
		<?php
	}

	/**
	 * A small "what did we actually send" list — Notification_Log is append-only, so this is
	 * purely informational, with no actions of its own.
	 */
	private static function render_notification_history( int $appointment_id ): void {
		$entries = Notification_Log::for_appointment( $appointment_id );

		if ( empty( $entries ) ) {
			return;
		}

		?>
		<h2><?php esc_html_e( 'Notifications sent', 'bookflow-booking-scheduling' ); ?></h2>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'When', 'bookflow-booking-scheduling' ); ?></th>
					<th><?php esc_html_e( 'Type', 'bookflow-booking-scheduling' ); ?></th>
					<th><?php esc_html_e( 'Recipient', 'bookflow-booking-scheduling' ); ?></th>
					<th><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $entries as $entry ) : ?>
					<tr>
						<td><?php echo esc_html( $entry['sent_at'] ); ?></td>
						<td><?php echo esc_html( ucwords( str_replace( '_', ' ', $entry['type'] ) ) ); ?></td>
						<td><?php echo esc_html( $entry['recipient'] ); ?></td>
						<td><span class="bookflow-status bookflow-status--<?php echo esc_attr( 'sent' === $entry['status'] ? 'confirmed' : 'cancelled' ); ?>"><?php echo esc_html( ucfirst( $entry['status'] ) ); ?></span></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}
}

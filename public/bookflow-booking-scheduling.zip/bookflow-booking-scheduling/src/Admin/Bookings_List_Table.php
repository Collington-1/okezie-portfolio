<?php
/**
 * Bookings list table — the only list table in Phase 4 with real server-side pagination, since
 * appointment volume grows unboundedly (Section 10).
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Booking\Appointment;
use BookFlow\Booking\Appointment_Repository;
use BookFlow\Booking\Appointment_State_Machine;
use BookFlow\Customers\Customer_Repository;
use BookFlow\Locations\Location_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Class Bookings_List_Table
 */
final class Bookings_List_Table extends \WP_List_Table {

	/**
	 * Rows per page.
	 *
	 * @var int
	 */
	private const PER_PAGE = 20;

	/**
	 * Batch-fetched lookups for the current page's rows, keyed by id — populated in
	 * prepare_items() to avoid N+1 queries.
	 *
	 * @var array<int, \BookFlow\Customers\Customer>
	 */
	private array $customers = array();

	/**
	 * @var array<int, \BookFlow\Services\Service>
	 */
	private array $services = array();

	/**
	 * @var array<int, \BookFlow\Staff\Staff_Member>
	 */
	private array $staff = array();

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'booking',
				'plural'   => 'bookings',
				'ajax'     => false,
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'cb'       => '<input type="checkbox" />',
			'reference' => __( 'Reference', 'bookflow-booking-scheduling' ),
			'customer'  => __( 'Customer', 'bookflow-booking-scheduling' ),
			'service'   => __( 'Service', 'bookflow-booking-scheduling' ),
			'staff'     => __( 'Staff', 'bookflow-booking-scheduling' ),
			'when'      => __( 'Date & Time', 'bookflow-booking-scheduling' ),
			'status'    => __( 'Status', 'bookflow-booking-scheduling' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'when' => array( 'start_datetime_utc', true ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_bulk_actions(): array {
		return array(
			'confirm' => __( 'Mark as confirmed', 'bookflow-booking-scheduling' ),
			'cancel'  => __( 'Cancel', 'bookflow-booking-scheduling' ),
		);
	}

	/**
	 * Status filter tabs with counts, shown above the table.
	 *
	 * @return array<string, string>
	 */
	protected function get_views(): array {
		$current = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter state.
		$base    = admin_url( 'admin.php?page=bookflow-bookings' );

		$views = array(
			'' => sprintf(
				'<a href="%s" class="%s">%s <span class="count">(%d)</span></a>',
				esc_url( $base ),
				'' === $current ? 'current' : '',
				esc_html__( 'All', 'bookflow-booking-scheduling' ),
				Appointment_Repository::count()
			),
		);

		foreach ( Appointment::statuses() as $status ) {
			$views[ $status ] = sprintf(
				'<a href="%s" class="%s">%s <span class="count">(%d)</span></a>',
				esc_url( add_query_arg( 'status', $status, $base ) ),
				$current === $status ? 'current' : '',
				esc_html( ucfirst( str_replace( '_', '-', $status ) ) ),
				Appointment_Repository::count( array( 'status' => $status ) )
			);
		}

		return $views;
	}

	/**
	 * {@inheritDoc}
	 */
	public function prepare_items(): void {
		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns() );

		$args = self::filters_from_request();

		$current_page      = $this->get_pagenum();
		$args['limit']      = self::PER_PAGE;
		$args['offset']     = ( $current_page - 1 ) * self::PER_PAGE;
		$args['orderby']    = 'start_datetime_utc';
		$args['order']      = isset( $_GET['order'] ) && 'asc' === strtolower( (string) $_GET['order'] ) ? 'asc' : 'desc'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$total = Appointment_Repository::count( $args );
		$items = Appointment_Repository::all( $args );

		$this->items = $items;

		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => self::PER_PAGE,
				'total_pages' => (int) ceil( $total / self::PER_PAGE ),
			)
		);

		$this->preload_lookups( $items );
	}

	/**
	 * Filter args shared by prepare_items() (for the page of rows) and get_views() (for the
	 * status-tab counts) — read from the request once, in one place.
	 *
	 * @return array<string, mixed>
	 */
	public static function filters_from_request(): array {
		$args = array();

		if ( ! empty( $_GET['status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['status'] = sanitize_key( $_GET['status'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( ! empty( $_GET['staff_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['staff_id'] = absint( $_GET['staff_id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( ! empty( $_GET['location_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['location_id'] = absint( $_GET['location_id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( ! empty( $_GET['service_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['service_id'] = absint( $_GET['service_id'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		// Populated by Calendar_Page's day links; expected as 'Y-m-d H:i:s' UTC strings.
		if ( ! empty( $_GET['date_from'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['date_from'] = sanitize_text_field( wp_unslash( $_GET['date_from'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( ! empty( $_GET['date_to'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['date_to'] = sanitize_text_field( wp_unslash( $_GET['date_to'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( ! empty( $_GET['s'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['search'] = sanitize_text_field( wp_unslash( $_GET['s'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		return $args;
	}

	/**
	 * Batch-fetch customers/services/staff for the current page's rows in three queries total,
	 * instead of one query per row per lookup (Section 10: avoid N+1 queries).
	 *
	 * @param array<int, Appointment> $items Current page's appointments.
	 */
	private function preload_lookups( array $items ): void {
		$customer_ids = array_map( static fn( Appointment $a ) => $a->customer_id, $items );
		$service_ids  = array_map( static fn( Appointment $a ) => $a->service_id, $items );
		$staff_ids    = array_filter( array_map( static fn( Appointment $a ) => $a->staff_id, $items ) );

		$this->customers = Customer_Repository::find_many( $customer_ids );
		$this->services   = Service_Repository::find_many( $service_ids );
		$this->staff       = Staff_Repository::find_many( $staff_ids );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Appointment $item Row data.
	 */
	public function column_cb( $item ): string {
		return sprintf( '<input type="checkbox" name="booking_ids[]" value="%d" />', $item->id );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Appointment $item Row data.
	 */
	public function column_reference( $item ): string {
		$view_url = add_query_arg( array( 'page' => 'bookflow-bookings', 'action' => 'view', 'id' => $item->id ), admin_url( 'admin.php' ) );

		$actions = array(
			'view' => sprintf( '<a href="%s">%s</a>', esc_url( $view_url ), esc_html__( 'View', 'bookflow-booking-scheduling' ) ),
		);

		foreach ( self::available_transitions( $item->status ) as $to => $label ) {
			$action_url = wp_nonce_url(
				add_query_arg( array( 'page' => 'bookflow-bookings', 'bookflow_action' => 'transition', 'id' => $item->id, 'to' => $to ), admin_url( 'admin.php' ) ),
				'bookflow_transition_booking_' . $item->id
			);
			$actions[ $to ] = sprintf( '<a href="%s">%s</a>', esc_url( $action_url ), esc_html( $label ) );
		}

		return sprintf( '<strong><a href="%s">%s</a></strong>%s', esc_url( $view_url ), esc_html( $item->booking_reference ), $this->row_actions( $actions ) );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Appointment $item        Row data.
	 * @param string      $column_name Column key.
	 */
	public function column_default( $item, $column_name ): string {
		switch ( $column_name ) {
			case 'customer':
				$customer = $this->customers[ $item->customer_id ] ?? null;
				return $customer ? esc_html( $customer->display_name() ) : '&#8212;';

			case 'service':
				$service = $this->services[ $item->service_id ] ?? null;
				return $service ? esc_html( $service->name ) : '&#8212;';

			case 'staff':
				if ( ! $item->staff_id ) {
					return '&#8212;';
				}
				$staff = $this->staff[ $item->staff_id ] ?? null;
				return $staff ? esc_html( $staff->display_name ) : '&#8212;';

			case 'when':
				return esc_html( $item->start->format( 'Y-m-d H:i' ) . ' UTC' );

			case 'status':
				return sprintf( '<span class="bookflow-status bookflow-status--%1$s">%2$s</span>', esc_attr( $item->status ), esc_html( ucfirst( str_replace( '_', '-', $item->status ) ) ) );

			default:
				return '';
		}
	}

	/**
	 * Human-readable labels for each status this appointment can transition to right now.
	 *
	 * @return array<string, string>
	 */
	private static function available_transitions( string $from ): array {
		$labels = array(
			'confirmed' => __( 'Confirm', 'bookflow-booking-scheduling' ),
			'completed' => __( 'Mark completed', 'bookflow-booking-scheduling' ),
			'cancelled' => __( 'Cancel', 'bookflow-booking-scheduling' ),
			'no_show'   => __( 'Mark no-show', 'bookflow-booking-scheduling' ),
		);

		$available = array();

		foreach ( $labels as $to => $label ) {
			if ( Appointment_State_Machine::can_transition( $from, $to ) ) {
				$available[ $to ] = $label;
			}
		}

		return $available;
	}

	/**
	 * {@inheritDoc}
	 */
	public function no_items(): void {
		esc_html_e( 'No bookings match these filters.', 'bookflow-booking-scheduling' );
	}
}

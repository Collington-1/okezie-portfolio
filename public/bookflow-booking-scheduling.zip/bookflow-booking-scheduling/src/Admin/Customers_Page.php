<?php
/**
 * Customers admin screen: list, add, edit, delete, and a customer's booking history. Existed as
 * a data model since Phase 2 (Customer_Repository) with zero admin UI ever built for it — found
 * during the Phase 13 review despite Section 5 explicitly listing "Customers" in the primary
 * navigation and Section 20 explicitly requiring customer search/filter. Fixed here rather than
 * left for a later phase, the same way Phase 8/10/11 fixed gaps found while working nearby.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Booking\Appointment_Repository;
use BookFlow\Customers\Customer;
use BookFlow\Customers\Customer_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Customers_Page
 */
final class Customers_Page {

	/**
	 * @var Validation_Exception|null
	 */
	private static ?Validation_Exception $error = null;

	/**
	 * @var array<string, mixed>
	 */
	private static array $submitted = array();

	/**
	 * Process add/edit/delete submissions.
	 */
	public static function handle_request(): void {
		if ( ! self::is_current_screen() ) {
			return;
		}

		if ( isset( $_GET['bookflow_action'], $_GET['id'] ) && 'delete' === $_GET['bookflow_action'] ) {
			self::handle_delete( absint( $_GET['id'] ) );
			return;
		}

		if ( isset( $_POST['bookflow_action'] ) && 'save' === $_POST['bookflow_action'] ) {
			self::handle_save();
		}
	}

	/**
	 * Render the screen.
	 */
	public static function render(): void {
		$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : 'list'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'add' === $action || 'edit' === $action || null !== self::$error ) {
			self::render_form( $action );
			return;
		}

		self::render_list();
	}

	/**
	 * Whether the current admin request targets this screen.
	 */
	private static function is_current_screen(): bool {
		return isset( $_GET['page'] ) && 'bookflow-customers' === $_GET['page']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Handle a delete link click. Does not touch any appointment rows referencing this customer
	 * — they remain, simply with no linked customer record afterward (every admin view already
	 * handles a missing customer gracefully, showing "—" rather than erroring).
	 */
	private static function handle_delete( int $id ): void {
		Form_Guard::verify( 'bookflow_delete_customer_' . $id );

		Customer_Repository::delete( $id );

		Notices::add( __( 'Customer deleted.', 'bookflow-booking-scheduling' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-customers' ) );
		exit;
	}

	/**
	 * Handle the add/edit form submission.
	 */
	private static function handle_save(): void {
		Form_Guard::verify( 'bookflow_save_customer' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

		$input = array(
			'first_name' => isset( $_POST['first_name'] ) ? wp_unslash( $_POST['first_name'] ) : '',
			'last_name'  => isset( $_POST['last_name'] ) ? wp_unslash( $_POST['last_name'] ) : '',
			'email'      => isset( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '',
			'phone'      => isset( $_POST['phone'] ) ? wp_unslash( $_POST['phone'] ) : '',
			'notes'      => isset( $_POST['notes'] ) ? wp_unslash( $_POST['notes'] ) : '',
		);

		try {
			$id > 0 ? Customer_Repository::update( $id, $input ) : Customer_Repository::create( $input );

			Notices::add( $id > 0 ? __( 'Customer updated.', 'bookflow-booking-scheduling' ) : __( 'Customer created.', 'bookflow-booking-scheduling' ) );
			wp_safe_redirect( admin_url( 'admin.php?page=bookflow-customers' ) );
			exit;
		} catch ( Validation_Exception $e ) {
			self::$error     = $e;
			self::$submitted = wp_unslash( $_POST );
		}
	}

	/**
	 * Render the list screen.
	 */
	private static function render_list(): void {
		$table = new Customers_List_Table();
		$table->prepare_items();

		$add_url = admin_url( 'admin.php?page=bookflow-customers&action=add' );
		?>
		<div class="wrap bookflow-wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Customers', 'bookflow-booking-scheduling' ); ?></h1>
			<a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action"><?php esc_html_e( 'Add Customer', 'bookflow-booking-scheduling' ); ?></a>
			<hr class="wp-header-end" />
			<form method="get">
				<input type="hidden" name="page" value="bookflow-customers" />
				<?php $table->search_box( __( 'Search customers', 'bookflow-booking-scheduling' ), 'bookflow-customer' ); ?>
				<?php $table->display(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the add/edit form.
	 */
	private static function render_form( string $action ): void {
		$customer = null;

		if ( 'edit' === $action && empty( self::$submitted ) ) {
			$id       = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$customer = Customer_Repository::find( $id );

			if ( null === $customer ) {
				wp_die( esc_html__( 'Customer not found.', 'bookflow-booking-scheduling' ) );
			}
		}

		$values = self::form_values( $customer );

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php echo $customer ? esc_html__( 'Edit Customer', 'bookflow-booking-scheduling' ) : esc_html__( 'Add Customer', 'bookflow-booking-scheduling' ); ?></h1>

			<?php if ( self::$error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( implode( ' ', self::$error->errors() ) ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-customers' ) ); ?>" class="bookflow-form">
				<?php wp_nonce_field( 'bookflow_save_customer' ); ?>
				<input type="hidden" name="bookflow_action" value="save" />
				<input type="hidden" name="id" value="<?php echo esc_attr( (string) ( $customer ? $customer->id : 0 ) ); ?>" />

				<table class="form-table" role="presentation">
					<tr>
						<th><label for="bf-first-name"><?php esc_html_e( 'First name', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-first-name" name="first_name" class="regular-text" value="<?php echo esc_attr( $values['first_name'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-last-name"><?php esc_html_e( 'Last name', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-last-name" name="last_name" class="regular-text" value="<?php echo esc_attr( $values['last_name'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-email"><?php esc_html_e( 'Email', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="email" id="bf-email" name="email" class="regular-text" required value="<?php echo esc_attr( $values['email'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-phone"><?php esc_html_e( 'Phone', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-phone" name="phone" class="regular-text" value="<?php echo esc_attr( $values['phone'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-notes"><?php esc_html_e( 'Notes', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><textarea id="bf-notes" name="notes" rows="4" class="large-text"><?php echo esc_textarea( $values['notes'] ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Internal notes — never shown to the customer.', 'bookflow-booking-scheduling' ); ?></p></td>
					</tr>
				</table>

				<?php submit_button( $customer ? __( 'Update Customer', 'bookflow-booking-scheduling' ) : __( 'Create Customer', 'bookflow-booking-scheduling' ) ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-customers' ) ); ?>" class="button-link" style="margin-left:8px"><?php esc_html_e( 'Cancel', 'bookflow-booking-scheduling' ); ?></a>
			</form>

			<?php if ( $customer ) : ?>
				<?php self::render_booking_history( $customer ); ?>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * A customer's booking history — read-only, links out to each booking's own detail screen
	 * for anything actionable (status changes, notes, reschedule).
	 */
	private static function render_booking_history( Customer $customer ): void {
		$appointments = Appointment_Repository::all(
			array(
				'customer_id' => $customer->id,
				'orderby'     => 'start_datetime_utc',
				'order'       => 'desc',
				'limit'       => 50,
			)
		);

		?>
		<h2><?php esc_html_e( 'Booking history', 'bookflow-booking-scheduling' ); ?></h2>
		<?php if ( empty( $appointments ) ) : ?>
			<p><?php esc_html_e( 'No bookings yet.', 'bookflow-booking-scheduling' ); ?></p>
		<?php else : ?>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Reference', 'bookflow-booking-scheduling' ); ?></th>
						<th><?php esc_html_e( 'Service', 'bookflow-booking-scheduling' ); ?></th>
						<th><?php esc_html_e( 'Date', 'bookflow-booking-scheduling' ); ?></th>
						<th><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $appointments as $appointment ) : ?>
						<?php $service = Service_Repository::find( $appointment->service_id ); ?>
						<tr>
							<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-bookings&action=view&id=' . $appointment->id ) ); ?>"><?php echo esc_html( $appointment->booking_reference ); ?></a></td>
							<td><?php echo esc_html( $service ? $service->name : '' ); ?></td>
							<td><?php echo esc_html( $appointment->start->setTimezone( wp_timezone() )->format( 'Y-m-d H:i' ) ); ?></td>
							<td><span class="bookflow-status bookflow-status--<?php echo esc_attr( $appointment->status ); ?>"><?php echo esc_html( ucfirst( str_replace( '_', '-', $appointment->status ) ) ); ?></span></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}

	/**
	 * Resolve display values for the form.
	 *
	 * @return array<string, mixed>
	 */
	private static function form_values( ?Customer $customer ): array {
		if ( ! empty( self::$submitted ) ) {
			$post = self::$submitted;

			return array(
				'first_name' => $post['first_name'] ?? '',
				'last_name'  => $post['last_name'] ?? '',
				'email'      => $post['email'] ?? '',
				'phone'      => $post['phone'] ?? '',
				'notes'      => $post['notes'] ?? '',
			);
		}

		if ( $customer ) {
			return array(
				'first_name' => (string) $customer->first_name,
				'last_name'  => (string) $customer->last_name,
				'email'      => $customer->email,
				'phone'      => (string) $customer->phone,
				'notes'      => (string) $customer->notes,
			);
		}

		return array(
			'first_name' => '',
			'last_name'  => '',
			'email'      => '',
			'phone'      => '',
			'notes'      => '',
		);
	}
}

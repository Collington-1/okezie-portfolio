<?php
/**
 * Staff list table. Not paginated server-side — see Services_List_Table's docblock for why.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Staff\Staff_Member;
use BookFlow\Staff\Staff_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Class Staff_List_Table
 */
final class Staff_List_Table extends \WP_List_Table {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'staff_member',
				'plural'   => 'staff_members',
				'ajax'     => false,
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'name'     => __( 'Name', 'bookflow-booking-scheduling' ),
			'email'    => __( 'Email', 'bookflow-booking-scheduling' ),
			'services' => __( 'Services', 'bookflow-booking-scheduling' ),
			'timezone' => __( 'Timezone', 'bookflow-booking-scheduling' ),
			'status'   => __( 'Status', 'bookflow-booking-scheduling' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'name' => array( 'display_name', false ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function prepare_items(): void {
		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns() );

		$args = array();

		if ( ! empty( $_GET['s'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filtering.
			$args['search'] = sanitize_text_field( wp_unslash( $_GET['s'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( ! empty( $_GET['status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['status'] = sanitize_key( $_GET['status'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		$this->items = Staff_Repository::all( $args );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Staff_Member $item Row data.
	 */
	public function column_name( $item ): string {
		$edit_url   = add_query_arg( array( 'page' => 'bookflow-staff', 'action' => 'edit', 'id' => $item->id ), admin_url( 'admin.php' ) );
		$delete_url = wp_nonce_url( add_query_arg( array( 'page' => 'bookflow-staff', 'bookflow_action' => 'delete', 'id' => $item->id ), admin_url( 'admin.php' ) ), 'bookflow_delete_staff_' . $item->id );

		$actions = array(
			'edit'   => sprintf( '<a href="%s">%s</a>', esc_url( $edit_url ), esc_html__( 'Edit', 'bookflow-booking-scheduling' ) ),
			'delete' => sprintf(
				'<a href="%s" onclick="return confirm(%s);">%s</a>',
				esc_url( $delete_url ),
				esc_attr( wp_json_encode( __( 'Delete this staff member? This cannot be undone.', 'bookflow-booking-scheduling' ) ) ),
				esc_html__( 'Delete', 'bookflow-booking-scheduling' )
			),
		);

		return sprintf( '<strong><a href="%s">%s</a></strong>%s', esc_url( $edit_url ), esc_html( $item->display_name ), $this->row_actions( $actions ) );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Staff_Member $item        Row data.
	 * @param string       $column_name Column key.
	 */
	public function column_default( $item, $column_name ): string {
		switch ( $column_name ) {
			case 'email':
				return $item->email ? esc_html( $item->email ) : '&#8212;';

			case 'services':
				return esc_html( (string) count( Staff_Repository::service_ids( $item->id ) ) );

			case 'timezone':
				return esc_html( $item->timezone ?: __( 'Site default', 'bookflow-booking-scheduling' ) );

			case 'status':
				return sprintf( '<span class="bookflow-status bookflow-status--%1$s">%2$s</span>', esc_attr( $item->status ), esc_html( ucfirst( $item->status ) ) );

			default:
				return '';
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public function no_items(): void {
		esc_html_e( 'No staff members yet. Add your first team member to get started.', 'bookflow-booking-scheduling' );
	}
}

<?php
/**
 * Guided first-run setup wizard (Section 4). Not in the visible admin menu — reached only via
 * the one-time activation redirect (maybe_redirect_after_activation(), consuming the transient
 * Support\Activation::run() has set since Phase 1) or a "Resume setup" link on Overview while
 * incomplete. Every step persists immediately through the same repositories the regular admin
 * screens use (Service_Repository::create(), etc.) — nothing here is wizard-only data, so
 * abandoning the wizard partway never loses work, and everything created remains fully editable
 * from its normal screen afterward (Section 4: "all values must remain editable later").
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Events\Bootstrap as Events_Bootstrap;
use BookFlow\Events\Event_Repository;
use BookFlow\Locations\Location_Repository;
use BookFlow\Scheduling\Bootstrap as Scheduling_Bootstrap;
use BookFlow\Scheduling\Scheduling_Page_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;
use BookFlow\Support\Constants;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Onboarding_Page
 */
final class Onboarding_Page {

	/**
	 * Step order. Business-type/model-dependent steps are skipped at navigation time (see
	 * is_applicable()), never removed from this list — the list itself stays a stable, complete
	 * description of the whole wizard.
	 *
	 * @var array<int, string>
	 */
	private const STEPS = array( 'welcome', 'model', 'business_type', 'service', 'hours', 'staff', 'location', 'event', 'finish' );

	/**
	 * Option storing IDs created so far, so later steps can reference earlier ones (e.g.
	 * assigning the service created in the 'service' step to the staff member created in the
	 * 'staff' step) without re-querying or holding wizard state in a session.
	 *
	 * @var string
	 */
	private const OPTION_PROGRESS = 'bookflow_onboarding_progress';

	/**
	 * @var Validation_Exception|null
	 */
	private static ?Validation_Exception $error = null;

	/**
	 * @var array<string, mixed>
	 */
	private static array $submitted = array();

	/**
	 * Redirect a freshly-activated admin into the wizard, once. Hooked to admin_init.
	 */
	public static function maybe_redirect_after_activation(): void {
		if ( ! current_user_can( Constants::CAPABILITY ) ) {
			return;
		}

		// A bulk activation (Plugins screen, multiple plugins checked at once) never redirects
		// anywhere — WordPress core itself suppresses activation redirects in that case, and
		// every other well-behaved plugin's setup wizard follows the same convention.
		if ( isset( $_GET['activate-multi'] ) ) {
			return;
		}

		if ( ! get_transient( Constants::TRANSIENT_ACTIVATION_REDIRECT ) ) {
			return;
		}

		delete_transient( Constants::TRANSIENT_ACTIVATION_REDIRECT );

		if ( '1' === get_option( 'bookflow_onboarding_completed' ) ) {
			return;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-onboarding' ) );
		exit;
	}

	/**
	 * Process step submissions.
	 */
	public static function handle_request(): void {
		if ( ! self::is_current_screen() ) {
			return;
		}

		if ( isset( $_GET['bookflow_action'] ) && 'skip_all' === $_GET['bookflow_action'] ) {
			// Form_Guard::verify() works for a GET request too — check_admin_referer() reads
			// from $_REQUEST, which includes the query string wp_nonce_url() appended to
			// skip_all_link()'s href. This is a real state change (marks onboarding complete),
			// so it needs the same capability+nonce guard as every POST handler in this class,
			// not just a plain action-name check.
			Form_Guard::verify( 'bookflow_onboarding_skip_all' );
			self::finish_wizard();
			return;
		}

		if ( ! isset( $_POST['bookflow_action'] ) || 'save_step' !== $_POST['bookflow_action'] ) {
			return;
		}

		Form_Guard::verify( 'bookflow_onboarding_step' );

		$step = isset( $_POST['step'] ) ? sanitize_key( $_POST['step'] ) : 'welcome';

		try {
			switch ( $step ) {
				case 'model':
					self::save_model();
					break;
				case 'business_type':
					self::save_business_type();
					break;
				case 'service':
					self::save_service();
					break;
				case 'hours':
					self::save_hours();
					break;
				case 'staff':
					self::save_staff();
					break;
				case 'location':
					self::save_location();
					break;
				case 'event':
					self::save_event();
					break;
			}
		} catch ( Validation_Exception $e ) {
			self::$error     = $e;
			self::$submitted = wp_unslash( $_POST );
			return;
		}

		self::redirect_to_step( self::next_step( $step ) );
	}

	/**
	 * Render the current step.
	 */
	public static function render(): void {
		$step = isset( $_GET['step'] ) ? sanitize_key( $_GET['step'] ) : 'welcome'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing.

		if ( ! in_array( $step, self::STEPS, true ) ) {
			$step = 'welcome';
		}

		echo '<div class="wrap bookflow-onboarding">';
		self::render_progress( $step );

		switch ( $step ) {
			case 'welcome':
				self::render_welcome();
				break;
			case 'model':
				self::render_model();
				break;
			case 'business_type':
				self::render_business_type();
				break;
			case 'service':
				self::render_service();
				break;
			case 'hours':
				self::render_hours();
				break;
			case 'staff':
				self::render_staff();
				break;
			case 'location':
				self::render_location();
				break;
			case 'event':
				self::render_event();
				break;
			case 'finish':
				self::render_finish();
				break;
		}

		echo '</div>';
	}

	/* ---------------------------------------------------------------------
	 * Step navigation
	 * ------------------------------------------------------------------- */

	/**
	 * Whether the current admin request targets this screen.
	 */
	private static function is_current_screen(): bool {
		return isset( $_GET['page'] ) && 'bookflow-onboarding' === $_GET['page']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * The next step to show after $current, skipping any step that doesn't apply to the chosen
	 * booking model.
	 */
	private static function next_step( string $current ): string {
		$model = (string) get_option( 'bookflow_booking_model', '' );
		$index = array_search( $current, self::STEPS, true );

		if ( false === $index ) {
			return 'finish';
		}

		for ( $i = $index + 1; $i < count( self::STEPS ); $i++ ) {
			if ( self::is_applicable( self::STEPS[ $i ], $model ) ) {
				return self::STEPS[ $i ];
			}
		}

		return 'finish';
	}

	/**
	 * Whether a step applies given the chosen booking model. An unset model ('' — the visitor
	 * hasn't reached the 'model' step's own answer yet, or skipped it) shows every step, the
	 * safest fallback (never hides something that might matter).
	 */
	private static function is_applicable( string $step, string $model ): bool {
		if ( in_array( $step, array( 'service', 'hours', 'staff' ), true ) && 'events' === $model ) {
			return false;
		}

		if ( 'event' === $step && 'appointments' === $model ) {
			return false;
		}

		return true;
	}

	/**
	 * Redirect to a given step (GET, so the browser's back/forward/reload behave normally
	 * between steps — this is a wizard, not a single form).
	 */
	private static function redirect_to_step( string $step ): void {
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-onboarding&step=' . $step ) );
		exit;
	}

	/**
	 * Skip the entire remaining wizard: mark it complete and go straight to Overview.
	 */
	private static function finish_wizard(): void {
		update_option( 'bookflow_onboarding_completed', '1' );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow' ) );
		exit;
	}

	/* ---------------------------------------------------------------------
	 * Progress (created-so-far IDs)
	 * ------------------------------------------------------------------- */

	/**
	 * @return array{service_id?: int, staff_id?: int, location_id?: int}
	 */
	private static function progress(): array {
		$progress = get_option( self::OPTION_PROGRESS, array() );

		return is_array( $progress ) ? $progress : array();
	}

	private static function remember( string $key, int $id ): void {
		$progress         = self::progress();
		$progress[ $key ] = $id;
		update_option( self::OPTION_PROGRESS, $progress, false );
	}

	/* ---------------------------------------------------------------------
	 * Step handlers (POST)
	 * ------------------------------------------------------------------- */

	private static function save_model(): void {
		$model = isset( $_POST['booking_model'] ) ? sanitize_key( $_POST['booking_model'] ) : 'appointments';

		if ( ! in_array( $model, array( 'appointments', 'events', 'both' ), true ) ) {
			$model = 'appointments';
		}

		update_option( 'bookflow_booking_model', $model );
	}

	/**
	 * Recognised business-type presets (Section 4).
	 *
	 * @return array<int, string>
	 */
	public static function business_types(): array {
		return array( 'salon', 'consultant', 'clinic', 'coach', 'agency', 'tutor', 'trainer', 'other' );
	}

	private static function save_business_type(): void {
		$type = isset( $_POST['business_type'] ) ? sanitize_key( $_POST['business_type'] ) : 'other';

		if ( ! in_array( $type, self::business_types(), true ) ) {
			$type = 'other';
		}

		update_option( 'bookflow_business_type', $type );
	}

	/**
	 * @throws Validation_Exception
	 */
	private static function save_service(): void {
		$name = isset( $_POST['name'] ) ? trim( (string) wp_unslash( $_POST['name'] ) ) : '';

		if ( '' === $name ) {
			return; // Left blank — treat as "skip this step" rather than forcing an error.
		}

		$service = Service_Repository::create(
			array(
				'name'             => $name,
				'duration_minutes' => isset( $_POST['duration_minutes'] ) ? (int) $_POST['duration_minutes'] : 30,
				'price'            => isset( $_POST['price'] ) && '' !== $_POST['price'] ? (float) $_POST['price'] : null,
				'capacity'         => 1,
				'status'           => 'active',
			)
		);

		self::remember( 'service_id', $service->id );
	}

	/**
	 * @throws Validation_Exception
	 */
	private static function save_hours(): void {
		Weekly_Hours_Field::save_from_request( 'business', null );
	}

	/**
	 * @throws Validation_Exception
	 */
	private static function save_staff(): void {
		$name = isset( $_POST['display_name'] ) ? trim( (string) wp_unslash( $_POST['display_name'] ) ) : '';

		if ( '' === $name ) {
			return;
		}

		$staff = Staff_Repository::create(
			array(
				'display_name' => $name,
				'email'        => isset( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '',
				'status'       => 'active',
			)
		);

		self::remember( 'staff_id', $staff->id );

		$progress = self::progress();

		if ( isset( $progress['service_id'] ) ) {
			Staff_Repository::set_services( $staff->id, array( (int) $progress['service_id'] ) );
			Service_Repository::set_staff( (int) $progress['service_id'], array( $staff->id ) );
		}
	}

	/**
	 * @throws Validation_Exception
	 */
	private static function save_location(): void {
		$name = isset( $_POST['name'] ) ? trim( (string) wp_unslash( $_POST['name'] ) ) : '';

		if ( '' === $name ) {
			return;
		}

		$location = Location_Repository::create(
			array(
				'name'   => $name,
				'type'   => isset( $_POST['type'] ) ? sanitize_key( $_POST['type'] ) : 'physical',
				'status' => 'active',
			)
		);

		self::remember( 'location_id', $location->id );

		$progress = self::progress();

		if ( isset( $progress['service_id'] ) ) {
			Service_Repository::set_locations( (int) $progress['service_id'], array( $location->id ) );
		}

		if ( isset( $progress['staff_id'] ) ) {
			Staff_Repository::set_locations( (int) $progress['staff_id'], array( $location->id ) );
		}
	}

	/**
	 * @throws Validation_Exception
	 */
	private static function save_event(): void {
		$title = isset( $_POST['title'] ) ? trim( (string) wp_unslash( $_POST['title'] ) ) : '';

		if ( '' === $title ) {
			return;
		}

		$site_timezone = wp_timezone();
		$date          = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : '';
		$time          = isset( $_POST['time'] ) ? sanitize_text_field( wp_unslash( $_POST['time'] ) ) : '';
		$start         = ( '' !== $date && '' !== $time )
			? \DateTimeImmutable::createFromFormat( 'Y-m-d H:i', "{$date} {$time}", $site_timezone )
			: false;

		if ( false === $start ) {
			$start = ( new \DateTimeImmutable( 'next monday 10:00', $site_timezone ) );
		}

		$progress = self::progress();

		$event = Event_Repository::create(
			array(
				'title'       => $title,
				'start'       => $start,
				'end'         => $start->modify( '+1 hour' ),
				'timezone'    => $site_timezone->getName(),
				'location_id' => $progress['location_id'] ?? null,
				'capacity'    => isset( $_POST['capacity'] ) && '' !== $_POST['capacity'] ? (int) $_POST['capacity'] : null,
				'status'      => 'published',
			)
		);

		self::remember( 'event_id', $event->id );
	}

	/* ---------------------------------------------------------------------
	 * Rendering
	 * ------------------------------------------------------------------- */

	/**
	 * A compact step indicator.
	 */
	private static function render_progress( string $current ): void {
		$model     = (string) get_option( 'bookflow_booking_model', '' );
		$labels    = array(
			'welcome'       => __( 'Welcome', 'bookflow-booking-scheduling' ),
			'model'         => __( 'Booking type', 'bookflow-booking-scheduling' ),
			'business_type' => __( 'Business', 'bookflow-booking-scheduling' ),
			'service'       => __( 'Service', 'bookflow-booking-scheduling' ),
			'hours'         => __( 'Hours', 'bookflow-booking-scheduling' ),
			'staff'         => __( 'Staff', 'bookflow-booking-scheduling' ),
			'location'      => __( 'Location', 'bookflow-booking-scheduling' ),
			'event'         => __( 'Event', 'bookflow-booking-scheduling' ),
			'finish'        => __( 'Done', 'bookflow-booking-scheduling' ),
		);

		echo '<ol class="bookflow-onboarding-steps">';
		foreach ( self::STEPS as $step ) {
			if ( ! self::is_applicable( $step, $model ) ) {
				continue;
			}
			$class = $step === $current ? ' class="is-current"' : '';
			printf( '<li%s>%s</li>', $class, esc_html( $labels[ $step ] ?? $step ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $class is a hard-coded constant string, not user input.
		}
		echo '</ol>';
	}

	/**
	 * A "skip this step" link to the next applicable step.
	 */
	private static function skip_link( string $current ): void {
		$url = admin_url( 'admin.php?page=bookflow-onboarding&step=' . self::next_step( $current ) );
		printf( '<a href="%s" class="bookflow-onboarding-skip">%s</a>', esc_url( $url ), esc_html__( 'Skip this step', 'bookflow-booking-scheduling' ) );
	}

	/**
	 * The persistent "exit the wizard entirely" link, shown on every step.
	 */
	private static function skip_all_link(): void {
		$url = wp_nonce_url( admin_url( 'admin.php?page=bookflow-onboarding&bookflow_action=skip_all' ), 'bookflow_onboarding_skip_all' );
		printf( '<a href="%s" class="bookflow-onboarding-skip-all">%s</a>', esc_url( $url ), esc_html__( 'Skip setup', 'bookflow-booking-scheduling' ) );
	}

	private static function render_error(): void {
		if ( self::$error ) {
			printf( '<div class="notice notice-error"><p>%s</p></div>', esc_html( implode( ' ', self::$error->errors() ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- esc_html() is applied above; printf's own %s does no escaping itself.
		}
	}

	private static function form_open( string $step ): void {
		printf(
			'<form method="post" action="%s" class="bookflow-onboarding-form">',
			esc_url( admin_url( 'admin.php?page=bookflow-onboarding' ) )
		);
		wp_nonce_field( 'bookflow_onboarding_step' );
		echo '<input type="hidden" name="bookflow_action" value="save_step" />';
		printf( '<input type="hidden" name="step" value="%s" />', esc_attr( $step ) );
	}

	private static function render_welcome(): void {
		?>
		<div class="bookflow-onboarding-card">
			<h1><?php esc_html_e( 'Welcome to BookFlow', 'bookflow-booking-scheduling' ); ?></h1>
			<p class="bookflow-onboarding-intro"><?php esc_html_e( 'BookFlow turns your WordPress site into your own booking and scheduling workspace — appointments, events, and shareable scheduling pages — without a subscription to another SaaS tool. This quick setup takes about five minutes and gets you a working booking page. You can change everything afterward.', 'bookflow-booking-scheduling' ); ?></p>
			<p>
				<a class="bookflow-button bookflow-button--primary" href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-onboarding&step=model' ) ); ?>"><?php esc_html_e( 'Get Started', 'bookflow-booking-scheduling' ); ?></a>
				<?php self::skip_all_link(); ?>
			</p>
		</div>
		<?php
	}

	private static function render_model(): void {
		$current = (string) get_option( 'bookflow_booking_model', 'appointments' );
		?>
		<div class="bookflow-onboarding-card">
			<h2><?php esc_html_e( 'What will you use BookFlow for?', 'bookflow-booking-scheduling' ); ?></h2>
			<?php self::render_error(); ?>
			<?php self::form_open( 'model' ); ?>
			<div class="bookflow-onboarding-choices">
				<?php
				$options = array(
					'appointments' => __( 'Appointments — one-on-one or per-service bookings', 'bookflow-booking-scheduling' ),
					'events'       => __( 'Events — one-time events with seats', 'bookflow-booking-scheduling' ),
					'both'         => __( 'Both', 'bookflow-booking-scheduling' ),
				);
				foreach ( $options as $value => $label ) :
					?>
					<label class="bookflow-onboarding-choice">
						<input type="radio" name="booking_model" value="<?php echo esc_attr( $value ); ?>" <?php checked( $current, $value ); ?> />
						<?php echo esc_html( $label ); ?>
					</label>
					<?php
				endforeach;
				?>
			</div>
			<p><button type="submit" class="bookflow-button bookflow-button--primary"><?php esc_html_e( 'Continue', 'bookflow-booking-scheduling' ); ?></button> <?php self::skip_all_link(); ?></p>
			</form>
		</div>
		<?php
	}

	private static function render_business_type(): void {
		$current = (string) get_option( 'bookflow_business_type', '' );
		$labels  = array(
			'salon'      => __( 'Salon', 'bookflow-booking-scheduling' ),
			'consultant' => __( 'Consultant', 'bookflow-booking-scheduling' ),
			'clinic'     => __( 'Clinic', 'bookflow-booking-scheduling' ),
			'coach'      => __( 'Coach', 'bookflow-booking-scheduling' ),
			'agency'     => __( 'Agency', 'bookflow-booking-scheduling' ),
			'tutor'      => __( 'Tutor', 'bookflow-booking-scheduling' ),
			'trainer'    => __( 'Trainer', 'bookflow-booking-scheduling' ),
			'other'      => __( 'Other', 'bookflow-booking-scheduling' ),
		);
		?>
		<div class="bookflow-onboarding-card">
			<h2><?php esc_html_e( 'What kind of business is this?', 'bookflow-booking-scheduling' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Just for tailoring suggestions later — nothing here is locked in.', 'bookflow-booking-scheduling' ); ?></p>
			<?php self::render_error(); ?>
			<?php self::form_open( 'business_type' ); ?>
			<div class="bookflow-onboarding-choices bookflow-onboarding-choices--grid">
				<?php foreach ( self::business_types() as $type ) : ?>
					<label class="bookflow-onboarding-choice">
						<input type="radio" name="business_type" value="<?php echo esc_attr( $type ); ?>" <?php checked( $current, $type ); ?> />
						<?php echo esc_html( $labels[ $type ] ?? ucfirst( $type ) ); ?>
					</label>
				<?php endforeach; ?>
			</div>
			<p><button type="submit" class="bookflow-button bookflow-button--primary"><?php esc_html_e( 'Continue', 'bookflow-booking-scheduling' ); ?></button> <?php self::skip_link( 'business_type' ); ?> <?php self::skip_all_link(); ?></p>
			</form>
		</div>
		<?php
	}

	private static function render_service(): void {
		$values = self::$submitted;
		?>
		<div class="bookflow-onboarding-card">
			<h2><?php esc_html_e( 'Create your first service', 'bookflow-booking-scheduling' ); ?></h2>
			<?php self::render_error(); ?>
			<?php self::form_open( 'service' ); ?>
			<p>
				<label for="bf-ob-service-name"><?php esc_html_e( 'Service name', 'bookflow-booking-scheduling' ); ?></label><br />
				<input type="text" id="bf-ob-service-name" name="name" class="regular-text" value="<?php echo esc_attr( (string) ( $values['name'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'e.g. Consultation', 'bookflow-booking-scheduling' ); ?>" />
			</p>
			<p>
				<label for="bf-ob-duration"><?php esc_html_e( 'Duration (minutes)', 'bookflow-booking-scheduling' ); ?></label><br />
				<input type="number" min="1" id="bf-ob-duration" name="duration_minutes" value="<?php echo esc_attr( (string) ( $values['duration_minutes'] ?? 30 ) ); ?>" style="width:100px" />
			</p>
			<p>
				<label for="bf-ob-price"><?php esc_html_e( 'Price (optional)', 'bookflow-booking-scheduling' ); ?></label><br />
				<input type="number" min="0" step="0.01" id="bf-ob-price" name="price" value="<?php echo esc_attr( (string) ( $values['price'] ?? '' ) ); ?>" style="width:120px" />
			</p>
			<p><button type="submit" class="bookflow-button bookflow-button--primary"><?php esc_html_e( 'Continue', 'bookflow-booking-scheduling' ); ?></button> <?php self::skip_link( 'service' ); ?> <?php self::skip_all_link(); ?></p>
			</form>
		</div>
		<?php
	}

	private static function render_hours(): void {
		?>
		<div class="bookflow-onboarding-card">
			<h2><?php esc_html_e( 'Set your business hours', 'bookflow-booking-scheduling' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Used whenever a staff member or location doesn’t have its own schedule. You can fine-tune this anytime in Settings.', 'bookflow-booking-scheduling' ); ?></p>
			<?php self::render_error(); ?>
			<?php self::form_open( 'hours' ); ?>
			<?php Weekly_Hours_Field::render( 'business', null ); ?>
			<p><button type="submit" class="bookflow-button bookflow-button--primary"><?php esc_html_e( 'Continue', 'bookflow-booking-scheduling' ); ?></button> <?php self::skip_link( 'hours' ); ?> <?php self::skip_all_link(); ?></p>
			</form>
		</div>
		<?php
	}

	private static function render_staff(): void {
		$values = self::$submitted;
		?>
		<div class="bookflow-onboarding-card">
			<h2><?php esc_html_e( 'Add your first staff member', 'bookflow-booking-scheduling' ); ?></h2>
			<p class="description"><?php esc_html_e( 'This can be you.', 'bookflow-booking-scheduling' ); ?></p>
			<?php self::render_error(); ?>
			<?php self::form_open( 'staff' ); ?>
			<p>
				<label for="bf-ob-staff-name"><?php esc_html_e( 'Name', 'bookflow-booking-scheduling' ); ?></label><br />
				<input type="text" id="bf-ob-staff-name" name="display_name" class="regular-text" value="<?php echo esc_attr( (string) ( $values['display_name'] ?? '' ) ); ?>" />
			</p>
			<p>
				<label for="bf-ob-staff-email"><?php esc_html_e( 'Email (optional)', 'bookflow-booking-scheduling' ); ?></label><br />
				<input type="email" id="bf-ob-staff-email" name="email" class="regular-text" value="<?php echo esc_attr( (string) ( $values['email'] ?? '' ) ); ?>" />
			</p>
			<p><button type="submit" class="bookflow-button bookflow-button--primary"><?php esc_html_e( 'Continue', 'bookflow-booking-scheduling' ); ?></button> <?php self::skip_link( 'staff' ); ?> <?php self::skip_all_link(); ?></p>
			</form>
		</div>
		<?php
	}

	private static function render_location(): void {
		$values = self::$submitted;
		?>
		<div class="bookflow-onboarding-card">
			<h2><?php esc_html_e( 'Add a location', 'bookflow-booking-scheduling' ); ?></h2>
			<?php self::render_error(); ?>
			<?php self::form_open( 'location' ); ?>
			<p>
				<label for="bf-ob-location-name"><?php esc_html_e( 'Location name', 'bookflow-booking-scheduling' ); ?></label><br />
				<input type="text" id="bf-ob-location-name" name="name" class="regular-text" value="<?php echo esc_attr( (string) ( $values['name'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'e.g. Main Office, or Online', 'bookflow-booking-scheduling' ); ?>" />
			</p>
			<p>
				<label><input type="radio" name="type" value="physical" <?php checked( (string) ( $values['type'] ?? 'physical' ), 'physical' ); ?> /> <?php esc_html_e( 'Physical', 'bookflow-booking-scheduling' ); ?></label>
				&nbsp;
				<label><input type="radio" name="type" value="online" <?php checked( (string) ( $values['type'] ?? '' ), 'online' ); ?> /> <?php esc_html_e( 'Online', 'bookflow-booking-scheduling' ); ?></label>
			</p>
			<p><button type="submit" class="bookflow-button bookflow-button--primary"><?php esc_html_e( 'Continue', 'bookflow-booking-scheduling' ); ?></button> <?php self::skip_link( 'location' ); ?> <?php self::skip_all_link(); ?></p>
			</form>
		</div>
		<?php
	}

	private static function render_event(): void {
		$values = self::$submitted;
		$default_date = ( new \DateTimeImmutable( 'next monday', wp_timezone() ) )->format( 'Y-m-d' );
		?>
		<div class="bookflow-onboarding-card">
			<h2><?php esc_html_e( 'Create your first event', 'bookflow-booking-scheduling' ); ?></h2>
			<?php self::render_error(); ?>
			<?php self::form_open( 'event' ); ?>
			<p>
				<label for="bf-ob-event-title"><?php esc_html_e( 'Event title', 'bookflow-booking-scheduling' ); ?></label><br />
				<input type="text" id="bf-ob-event-title" name="title" class="regular-text" value="<?php echo esc_attr( (string) ( $values['title'] ?? '' ) ); ?>" />
			</p>
			<p>
				<label for="bf-ob-event-date"><?php esc_html_e( 'Date & time', 'bookflow-booking-scheduling' ); ?></label><br />
				<input type="date" id="bf-ob-event-date" name="date" value="<?php echo esc_attr( (string) ( $values['date'] ?? $default_date ) ); ?>" />
				<input type="time" name="time" value="<?php echo esc_attr( (string) ( $values['time'] ?? '10:00' ) ); ?>" />
			</p>
			<p>
				<label for="bf-ob-event-capacity"><?php esc_html_e( 'Capacity (optional)', 'bookflow-booking-scheduling' ); ?></label><br />
				<input type="number" min="1" id="bf-ob-event-capacity" name="capacity" value="<?php echo esc_attr( (string) ( $values['capacity'] ?? '' ) ); ?>" style="width:100px" />
			</p>
			<p><button type="submit" class="bookflow-button bookflow-button--primary"><?php esc_html_e( 'Continue', 'bookflow-booking-scheduling' ); ?></button> <?php self::skip_link( 'event' ); ?> <?php self::skip_all_link(); ?></p>
			</form>
		</div>
		<?php
	}

	private static function render_finish(): void {
		$progress   = self::progress();
		$test_url   = null;
		$test_label = '';

		// Generate the initial scheduling page (Section 4: "Generate the initial booking page
		// automatically") only once, the first time this screen is reached with a service+staff
		// on hand — re-visiting Finish (e.g. via back button) must not create duplicates.
		if ( isset( $progress['service_id'], $progress['staff_id'] ) && empty( $progress['scheduling_page_id'] ) ) {
			$staff = Staff_Repository::find( (int) $progress['staff_id'] );

			$page = Scheduling_Page_Repository::create(
				array(
					'staff_id' => (int) $progress['staff_id'],
					'title'    => $staff ? sprintf( /* translators: %s: staff display name. */ __( 'Book with %s', 'bookflow-booking-scheduling' ), $staff->display_name ) : __( 'Book an appointment', 'bookflow-booking-scheduling' ),
					'layout'   => 'classic',
					'status'   => 'active',
				)
			);

			Scheduling_Page_Repository::set_services( $page->id, array( (int) $progress['service_id'] ) );
			self::remember( 'scheduling_page_id', $page->id );
			$progress = self::progress();
		}

		if ( ! empty( $progress['scheduling_page_id'] ) ) {
			$page = Scheduling_Page_Repository::find( (int) $progress['scheduling_page_id'] );
			if ( $page ) {
				$test_url   = Scheduling_Bootstrap::public_url( $page );
				$test_label = __( 'View your scheduling page', 'bookflow-booking-scheduling' );
			}
		} elseif ( ! empty( $progress['event_id'] ) ) {
			// No scheduling page exists for an events-only business (the 'service'/'staff'
			// steps that would feed one are skipped for that model) — link to the created
			// event's own public page instead, so "test/view booking" always has something to
			// point at regardless of which booking model was chosen (Section 4).
			$event = Event_Repository::find( (int) $progress['event_id'] );
			if ( $event ) {
				$test_url   = Events_Bootstrap::public_url( $event );
				$test_label = __( 'View your event page', 'bookflow-booking-scheduling' );
			}
		}

		update_option( 'bookflow_onboarding_completed', '1' );

		?>
		<div class="bookflow-onboarding-card">
			<h1><?php esc_html_e( "You're all set!", 'bookflow-booking-scheduling' ); ?></h1>
			<p class="bookflow-onboarding-intro"><?php esc_html_e( 'BookFlow is ready. Here’s what you can do next:', 'bookflow-booking-scheduling' ); ?></p>

			<?php if ( $test_url ) : ?>
				<p><a class="bookflow-button bookflow-button--primary" href="<?php echo esc_url( $test_url ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $test_label ); ?> ↗</a></p>
			<?php endif; ?>

			<ul class="bookflow-onboarding-next">
				<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-services' ) ); ?>"><?php esc_html_e( 'Review your services', 'bookflow-booking-scheduling' ); ?></a></li>
				<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-staff' ) ); ?>"><?php esc_html_e( 'Review your staff', 'bookflow-booking-scheduling' ); ?></a></li>
				<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-settings' ) ); ?>"><?php esc_html_e( 'Configure notifications', 'bookflow-booking-scheduling' ); ?></a></li>
			</ul>

			<p><a class="bookflow-button" href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow' ) ); ?>"><?php esc_html_e( 'Go to Dashboard', 'bookflow-booking-scheduling' ); ?></a></p>
		</div>
		<?php
	}
}

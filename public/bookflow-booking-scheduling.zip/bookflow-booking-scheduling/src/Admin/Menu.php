<?php
/**
 * Admin menu registration.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Support\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Menu
 */
final class Menu {

	/**
	 * Top-level menu slug. Also the Overview submenu's slug (see register() for why).
	 *
	 * @var string
	 */
	public const SLUG = 'bookflow';

	/**
	 * Hook suffixes returned by add_menu_page()/add_submenu_page(), used by Bootstrap to load
	 * admin assets only on BookFlow's own screens (Section 10).
	 *
	 * @var array<int, string>
	 */
	private static array $hooks = array();

	/**
	 * Register the admin menu.
	 */
	public static function register(): void {
		$cap = Constants::CAPABILITY;

		self::$hooks[] = add_menu_page(
			__( 'BookFlow', 'bookflow-booking-scheduling' ),
			__( 'BookFlow', 'bookflow-booking-scheduling' ),
			$cap,
			self::SLUG,
			array( Overview_Page::class, 'render' ),
			'dashicons-calendar-alt',
			26
		);

		// Re-declaring a submenu with the SAME slug as the top-level page is the standard way
		// to give the auto-created first submenu item its own label ("Overview" instead of a
		// second "BookFlow").
		self::$hooks[] = add_submenu_page( self::SLUG, __( 'Overview', 'bookflow-booking-scheduling' ), __( 'Overview', 'bookflow-booking-scheduling' ), $cap, self::SLUG, array( Overview_Page::class, 'render' ) );
		self::$hooks[] = add_submenu_page( self::SLUG, __( 'Calendar', 'bookflow-booking-scheduling' ), __( 'Calendar', 'bookflow-booking-scheduling' ), $cap, 'bookflow-calendar', array( Calendar_Page::class, 'render' ) );
		self::$hooks[] = add_submenu_page( self::SLUG, __( 'Bookings', 'bookflow-booking-scheduling' ), __( 'Bookings', 'bookflow-booking-scheduling' ), $cap, 'bookflow-bookings', array( Bookings_Page::class, 'render' ) );
		self::$hooks[] = add_submenu_page( self::SLUG, __( 'Services', 'bookflow-booking-scheduling' ), __( 'Services', 'bookflow-booking-scheduling' ), $cap, 'bookflow-services', array( Services_Page::class, 'render' ) );
		self::$hooks[] = add_submenu_page( self::SLUG, __( 'Scheduling', 'bookflow-booking-scheduling' ), __( 'Scheduling', 'bookflow-booking-scheduling' ), $cap, 'bookflow-scheduling', array( Scheduling_Pages_Page::class, 'render' ) );
		self::$hooks[] = add_submenu_page( self::SLUG, __( 'Events', 'bookflow-booking-scheduling' ), __( 'Events', 'bookflow-booking-scheduling' ), $cap, 'bookflow-events', array( Events_Page::class, 'render' ) );
		self::$hooks[] = add_submenu_page( self::SLUG, __( 'Customers', 'bookflow-booking-scheduling' ), __( 'Customers', 'bookflow-booking-scheduling' ), $cap, 'bookflow-customers', array( Customers_Page::class, 'render' ) );
		self::$hooks[] = add_submenu_page( self::SLUG, __( 'Staff', 'bookflow-booking-scheduling' ), __( 'Staff', 'bookflow-booking-scheduling' ), $cap, 'bookflow-staff', array( Staff_Page::class, 'render' ) );
		self::$hooks[] = add_submenu_page( self::SLUG, __( 'Locations', 'bookflow-booking-scheduling' ), __( 'Locations', 'bookflow-booking-scheduling' ), $cap, 'bookflow-locations', array( Locations_Page::class, 'render' ) );
		self::$hooks[] = add_submenu_page( self::SLUG, __( 'Settings', 'bookflow-booking-scheduling' ), __( 'Settings', 'bookflow-booking-scheduling' ), $cap, 'bookflow-settings', array( Settings_Page::class, 'render' ) );

		// A null parent registers the page (so admin.php?page=bookflow-onboarding works and
		// capability is still enforced) without adding a visible menu item — the wizard is only
		// ever reached via the one-time activation redirect or a "Resume setup" link, never
		// browsed to directly from the nav (the standard pattern for setup-wizard screens).
		$onboarding_hook = add_submenu_page( null, __( 'Setup', 'bookflow-booking-scheduling' ), __( 'Setup', 'bookflow-booking-scheduling' ), $cap, 'bookflow-onboarding', array( Onboarding_Page::class, 'render' ) );
		self::$hooks[]   = $onboarding_hook;

		// A null-parent add_submenu_page() registers the page under $submenu[''] internally,
		// which get_admin_page_parent() then resolves back to '' — get_admin_page_title() reads
		// that as "no parent" and only ever searches TOP-LEVEL menu entries for a title match,
		// which a submenu-registered slug can never satisfy. Left alone, $title stays null and
		// wp-admin/admin-header.php's `strip_tags( $title )` throws a PHP deprecation notice on
		// every load of this screen (confirmed against a real WordPress install — see
		// docs/ROADMAP.md's local-WP-testing notes). load-{hook} fires before admin-header.php
		// runs, and get_admin_page_title()'s first line short-circuits on a non-empty $title, so
		// setting it here fixes both the deprecation notice and the otherwise-blank browser tab
		// title in one place.
		if ( $onboarding_hook ) {
			add_action(
				"load-{$onboarding_hook}",
				static function (): void {
					$GLOBALS['title'] = __( 'Setup', 'bookflow-booking-scheduling' );
				}
			);
		}
	}

	/**
	 * Hook suffixes for every registered BookFlow admin screen.
	 *
	 * @return array<int, string>
	 */
	public static function hooks(): array {
		return array_filter( self::$hooks );
	}
}

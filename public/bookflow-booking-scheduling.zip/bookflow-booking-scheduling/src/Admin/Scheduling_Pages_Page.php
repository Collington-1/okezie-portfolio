<?php
/**
 * Scheduling pages admin screen: list, add, edit, delete.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Scheduling\Bootstrap as Scheduling_Bootstrap;
use BookFlow\Scheduling\Scheduling_Page;
use BookFlow\Scheduling\Scheduling_Page_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Scheduling_Pages_Page
 */
final class Scheduling_Pages_Page {

	/**
	 * @var Validation_Exception|null
	 */
	private static ?Validation_Exception $error = null;

	/**
	 * @var array<string, mixed>
	 */
	private static array $submitted = array();

	/**
	 * Process add/edit/delete submissions.
	 */
	public static function handle_request(): void {
		if ( ! self::is_current_screen() ) {
			return;
		}

		if ( isset( $_GET['bookflow_action'], $_GET['id'] ) && 'delete' === $_GET['bookflow_action'] ) {
			self::handle_delete( absint( $_GET['id'] ) );
			return;
		}

		if ( isset( $_POST['bookflow_action'] ) && 'save' === $_POST['bookflow_action'] ) {
			self::handle_save();
		}
	}

	/**
	 * Render the screen.
	 */
	public static function render(): void {
		$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : 'list'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'add' === $action || 'edit' === $action || null !== self::$error ) {
			self::render_form( $action );
			return;
		}

		self::render_list();
	}

	/**
	 * Whether the current admin request targets this screen.
	 */
	private static function is_current_screen(): bool {
		return isset( $_GET['page'] ) && 'bookflow-scheduling' === $_GET['page']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Handle a delete link click.
	 */
	private static function handle_delete( int $id ): void {
		Form_Guard::verify( 'bookflow_delete_scheduling_page_' . $id );

		Scheduling_Page_Repository::delete( $id );

		Notices::add( __( 'Scheduling page deleted.', 'bookflow-booking-scheduling' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-scheduling' ) );
		exit;
	}

	/**
	 * Handle the add/edit form submission.
	 */
	private static function handle_save(): void {
		Form_Guard::verify( 'bookflow_save_scheduling_page' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

		$input = array(
			'title'                 => isset( $_POST['title'] ) ? wp_unslash( $_POST['title'] ) : '',
			'staff_id'              => isset( $_POST['staff_id'] ) ? absint( $_POST['staff_id'] ) : null,
			'description'           => isset( $_POST['description'] ) ? wp_unslash( $_POST['description'] ) : '',
			'layout'                => isset( $_POST['layout'] ) ? sanitize_key( $_POST['layout'] ) : 'classic',
			'buffer_before_minutes' => isset( $_POST['buffer_before_minutes'] ) ? (int) $_POST['buffer_before_minutes'] : 0,
			'buffer_after_minutes'  => isset( $_POST['buffer_after_minutes'] ) ? (int) $_POST['buffer_after_minutes'] : 0,
			'min_notice_minutes'    => isset( $_POST['min_notice_minutes'] ) ? (int) $_POST['min_notice_minutes'] : 0,
			'max_advance_days'      => isset( $_POST['max_advance_days'] ) && '' !== $_POST['max_advance_days'] ? (int) $_POST['max_advance_days'] : null,
			'approval_required'     => ! empty( $_POST['approval_required'] ),
			'status'                => isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : 'active',
		);

		$service_ids = array_map( 'absint', (array) ( $_POST['service_ids'] ?? array() ) );

		try {
			$page = $id > 0 ? Scheduling_Page_Repository::update( $id, $input ) : Scheduling_Page_Repository::create( $input );

			Scheduling_Page_Repository::set_services( $page->id, $service_ids );

			Notices::add( $id > 0 ? __( 'Scheduling page updated.', 'bookflow-booking-scheduling' ) : __( 'Scheduling page created.', 'bookflow-booking-scheduling' ) );
			wp_safe_redirect( admin_url( 'admin.php?page=bookflow-scheduling' ) );
			exit;
		} catch ( Validation_Exception $e ) {
			self::$error     = $e;
			self::$submitted = wp_unslash( $_POST );
		}
	}

	/**
	 * Render the list screen.
	 */
	private static function render_list(): void {
		$table = new Scheduling_Pages_List_Table();
		$table->prepare_items();

		$add_url = admin_url( 'admin.php?page=bookflow-scheduling&action=add' );
		?>
		<div class="wrap bookflow-wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Scheduling Pages', 'bookflow-booking-scheduling' ); ?></h1>
			<a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action"><?php esc_html_e( 'Add Scheduling Page', 'bookflow-booking-scheduling' ); ?></a>
			<hr class="wp-header-end" />
			<form method="get">
				<input type="hidden" name="page" value="bookflow-scheduling" />
				<?php $table->search_box( __( 'Search scheduling pages', 'bookflow-booking-scheduling' ), 'bookflow-scheduling-page' ); ?>
				<?php $table->display(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the add/edit form.
	 */
	private static function render_form( string $action ): void {
		$page = null;

		if ( 'edit' === $action && empty( self::$submitted ) ) {
			$id   = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$page = Scheduling_Page_Repository::find( $id );

			if ( null === $page ) {
				wp_die( esc_html__( 'Scheduling page not found.', 'bookflow-booking-scheduling' ) );
			}
		}

		$values           = self::form_values( $page );
		$staff_members    = Staff_Repository::all( array( 'status' => 'active' ) );
		$services         = Service_Repository::all( array( 'status' => 'active' ) );
		$assigned_services = $page ? Scheduling_Page_Repository::service_ids( $page->id ) : array();

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php echo $page ? esc_html__( 'Edit Scheduling Page', 'bookflow-booking-scheduling' ) : esc_html__( 'Add Scheduling Page', 'bookflow-booking-scheduling' ); ?></h1>

			<?php if ( $page ) : ?>
				<p class="description">
					<?php esc_html_e( 'Public URL:', 'bookflow-booking-scheduling' ); ?>
					<code><?php echo esc_html( Scheduling_Bootstrap::public_url( $page ) ); ?></code>
				</p>
			<?php endif; ?>

			<?php if ( self::$error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( implode( ' ', self::$error->errors() ) ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-scheduling' ) ); ?>" class="bookflow-form">
				<?php wp_nonce_field( 'bookflow_save_scheduling_page' ); ?>
				<input type="hidden" name="bookflow_action" value="save" />
				<input type="hidden" name="id" value="<?php echo esc_attr( (string) ( $page ? $page->id : 0 ) ); ?>" />

				<table class="form-table" role="presentation">
					<tr>
						<th><label for="bf-title"><?php esc_html_e( 'Title', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-title" name="title" class="regular-text" required value="<?php echo esc_attr( $values['title'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-staff"><?php esc_html_e( 'Owner (staff member)', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-staff" name="staff_id">
								<option value=""><?php esc_html_e( '— None —', 'bookflow-booking-scheduling' ); ?></option>
								<?php foreach ( $staff_members as $staff ) : ?>
									<option value="<?php echo esc_attr( (string) $staff->id ); ?>" <?php selected( (string) $values['staff_id'], (string) $staff->id ); ?>><?php echo esc_html( $staff->display_name ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'A scheduling page belongs to one staff member — their working hours and timezone govern its availability.', 'bookflow-booking-scheduling' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="bf-description"><?php esc_html_e( 'Description', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><textarea id="bf-description" name="description" rows="3" class="large-text"><?php echo esc_textarea( $values['description'] ); ?></textarea></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Services offered', 'bookflow-booking-scheduling' ); ?></th>
						<td>
							<?php if ( empty( $services ) ) : ?>
								<p class="description"><?php esc_html_e( 'No services yet.', 'bookflow-booking-scheduling' ); ?></p>
							<?php endif; ?>
							<?php foreach ( $services as $service ) : ?>
								<label style="display:block"><input type="checkbox" name="service_ids[]" value="<?php echo esc_attr( (string) $service->id ); ?>" <?php checked( in_array( $service->id, $assigned_services, true ) ); ?> /> <?php echo esc_html( $service->name ); ?> <span class="description">(<?php echo esc_html( (string) $service->duration_minutes ); ?> <?php esc_html_e( 'min', 'bookflow-booking-scheduling' ); ?>)</span></label>
							<?php endforeach; ?>
						</td>
					</tr>
					<tr>
						<th><label for="bf-layout"><?php esc_html_e( 'Layout', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-layout" name="layout">
								<option value="classic" <?php selected( $values['layout'], 'classic' ); ?>><?php esc_html_e( 'Classic', 'bookflow-booking-scheduling' ); ?></option>
								<option value="calendar_first" <?php selected( $values['layout'], 'calendar_first' ); ?>><?php esc_html_e( 'Calendar-first', 'bookflow-booking-scheduling' ); ?></option>
								<option value="express" <?php selected( $values['layout'], 'express' ); ?>><?php esc_html_e( 'Express', 'bookflow-booking-scheduling' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Booking rules', 'bookflow-booking-scheduling' ); ?></th>
						<td>
							<p class="description"><?php esc_html_e( 'These override the selected service’s own settings for bookings made through this page.', 'bookflow-booking-scheduling' ); ?></p>
							<p>
								<label><?php esc_html_e( 'Buffer before (minutes)', 'bookflow-booking-scheduling' ); ?>
									<input type="number" min="0" name="buffer_before_minutes" value="<?php echo esc_attr( (string) $values['buffer_before_minutes'] ); ?>" style="width:80px" /></label>
								&nbsp;
								<label><?php esc_html_e( 'Buffer after (minutes)', 'bookflow-booking-scheduling' ); ?>
									<input type="number" min="0" name="buffer_after_minutes" value="<?php echo esc_attr( (string) $values['buffer_after_minutes'] ); ?>" style="width:80px" /></label>
							</p>
							<p>
								<label><?php esc_html_e( 'Minimum notice (minutes)', 'bookflow-booking-scheduling' ); ?>
									<input type="number" min="0" name="min_notice_minutes" value="<?php echo esc_attr( (string) $values['min_notice_minutes'] ); ?>" style="width:80px" /></label>
								&nbsp;
								<label><?php esc_html_e( 'Maximum advance (days, blank = use service’s own)', 'bookflow-booking-scheduling' ); ?>
									<input type="number" min="0" name="max_advance_days" value="<?php echo esc_attr( (string) $values['max_advance_days'] ); ?>" style="width:80px" /></label>
							</p>
							<p>
								<label><input type="checkbox" name="approval_required" value="1" <?php checked( $values['approval_required'] ); ?> /> <?php esc_html_e( 'Require approval before confirming a booking made through this page', 'bookflow-booking-scheduling' ); ?></label>
							</p>
						</td>
					</tr>
					<tr>
						<th><label for="bf-status"><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-status" name="status">
								<?php foreach ( Scheduling_Page::statuses() as $status ) : ?>
									<option value="<?php echo esc_attr( $status ); ?>" <?php selected( $values['status'], $status ); ?>><?php echo esc_html( ucfirst( $status ) ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				</table>

				<?php submit_button( $page ? __( 'Update Scheduling Page', 'bookflow-booking-scheduling' ) : __( 'Create Scheduling Page', 'bookflow-booking-scheduling' ) ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-scheduling' ) ); ?>" class="button-link" style="margin-left:8px"><?php esc_html_e( 'Cancel', 'bookflow-booking-scheduling' ); ?></a>
			</form>
		</div>
		<?php
	}

	/**
	 * Resolve display values for the form.
	 *
	 * @return array<string, mixed>
	 */
	private static function form_values( ?Scheduling_Page $page ): array {
		if ( ! empty( self::$submitted ) ) {
			$post = self::$submitted;

			return array(
				'title'                 => $post['title'] ?? '',
				'staff_id'              => $post['staff_id'] ?? '',
				'description'           => $post['description'] ?? '',
				'layout'                => $post['layout'] ?? 'classic',
				'buffer_before_minutes' => (int) ( $post['buffer_before_minutes'] ?? 0 ),
				'buffer_after_minutes'  => (int) ( $post['buffer_after_minutes'] ?? 0 ),
				'min_notice_minutes'    => (int) ( $post['min_notice_minutes'] ?? 0 ),
				'max_advance_days'      => $post['max_advance_days'] ?? '',
				'approval_required'     => ! empty( $post['approval_required'] ),
				'status'                => $post['status'] ?? 'active',
			);
		}

		if ( $page ) {
			return array(
				'title'                 => $page->title,
				'staff_id'              => (string) $page->staff_id,
				'description'           => (string) $page->description,
				'layout'                => $page->layout,
				'buffer_before_minutes' => $page->buffer_before_minutes,
				'buffer_after_minutes'  => $page->buffer_after_minutes,
				'min_notice_minutes'    => $page->min_notice_minutes,
				'max_advance_days'      => $page->max_advance_days ?? '',
				'approval_required'     => $page->approval_required,
				'status'                => $page->status,
			);
		}

		return array(
			'title'                 => '',
			'staff_id'              => '',
			'description'           => '',
			'layout'                => 'classic',
			'buffer_before_minutes' => 0,
			'buffer_after_minutes'  => 0,
			'min_notice_minutes'    => 0,
			'max_advance_days'      => '',
			'approval_required'     => false,
			'status'                => 'active',
		);
	}
}

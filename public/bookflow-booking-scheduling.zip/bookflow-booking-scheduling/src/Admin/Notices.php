<?php
/**
 * Flash admin notices that survive a post-redirect-get cycle, keyed per-user via a short-lived
 * transient so one admin's "Service updated" notice never leaks into another admin's session.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Notices
 */
final class Notices {

	/**
	 * Transient key prefix.
	 *
	 * @var string
	 */
	private const TRANSIENT_PREFIX = 'bookflow_admin_notice_';

	/**
	 * Register the render hook.
	 */
	public static function init(): void {
		add_action( 'admin_notices', array( self::class, 'render' ) );
	}

	/**
	 * Queue a notice to render on the next admin page load for the current user.
	 *
	 * @param string $message Notice text (escaped at render time — pass plain text here).
	 * @param string $type    'success' | 'error' | 'warning' | 'info'.
	 */
	public static function add( string $message, string $type = 'success' ): void {
		set_transient(
			self::TRANSIENT_PREFIX . get_current_user_id(),
			array(
				'message' => $message,
				'type'    => $type,
			),
			30
		);
	}

	/**
	 * Render (and consume) the current user's queued notice, if any.
	 */
	public static function render(): void {
		$key    = self::TRANSIENT_PREFIX . get_current_user_id();
		$notice = get_transient( $key );

		if ( ! is_array( $notice ) || empty( $notice['message'] ) ) {
			return;
		}

		delete_transient( $key );

		$type = in_array( $notice['type'] ?? '', array( 'success', 'error', 'warning', 'info' ), true ) ? $notice['type'] : 'info';

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $type ),
			esc_html( $notice['message'] )
		);
	}
}

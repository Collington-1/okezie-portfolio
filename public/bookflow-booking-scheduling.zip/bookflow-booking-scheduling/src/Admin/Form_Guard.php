<?php
/**
 * One shared place enforcing "every state-changing admin action gets a capability check AND a
 * nonce check" (Section 9), rather than trusting each screen to remember both consistently.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Support\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Form_Guard
 */
final class Form_Guard {

	/**
	 * Verify the current user may manage BookFlow and that the request carries a valid nonce
	 * for the given action. Halts the request (wp_die) on failure — callers never need to
	 * handle a false/void "did it pass" return value incorrectly.
	 *
	 * @param string $nonce_action Nonce action name, matching the form's wp_nonce_field().
	 */
	public static function verify( string $nonce_action ): void {
		if ( ! current_user_can( Constants::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'bookflow-booking-scheduling' ), 403 );
		}

		check_admin_referer( $nonce_action );
	}
}

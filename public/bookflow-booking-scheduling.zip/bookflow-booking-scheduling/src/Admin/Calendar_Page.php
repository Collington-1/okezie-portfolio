<?php
/**
 * Admin calendar — a server-rendered month grid. Deliberately not a JS drag-and-drop calendar:
 * that needs a JS build pipeline this environment cannot currently verify (see
 * docs/ROADMAP.md "Environment notes"), and a plain server-rendered grid is a complete, real,
 * testable "Admin calendar" feature in its own right (Section 2's Free-scope requirement),
 * not a placeholder. A richer JS calendar is a reasonable future enhancement, not a Phase 4
 * requirement.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Booking\Appointment;
use BookFlow\Booking\Appointment_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Calendar_Page
 */
final class Calendar_Page {

	/**
	 * Render the screen.
	 */
	public static function render(): void {
		$site_timezone = wp_timezone();
		$today         = new \DateTimeImmutable( 'now', $site_timezone );

		$year  = isset( $_GET['bf_year'] ) ? max( 1970, (int) $_GET['bf_year'] ) : (int) $today->format( 'Y' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only navigation.
		$month = isset( $_GET['bf_month'] ) ? min( 12, max( 1, (int) $_GET['bf_month'] ) ) : (int) $today->format( 'n' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$first_of_month = new \DateTimeImmutable( sprintf( '%04d-%02d-01 00:00:00', $year, $month ), $site_timezone );
		$grid_start     = $first_of_month->modify( '-' . ( (int) $first_of_month->format( 'w' ) ) . ' days' );
		$grid_end       = $grid_start->modify( '+42 days' ); // 6 full weeks, always covers the month.

		$appointments_by_day = self::appointments_by_local_day( $grid_start, $grid_end, $site_timezone );

		$prev = $first_of_month->modify( '-1 month' );
		$next = $first_of_month->modify( '+1 month' );

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php esc_html_e( 'Calendar', 'bookflow-booking-scheduling' ); ?></h1>

			<p class="bookflow-calendar-nav">
				<a class="button" href="<?php echo esc_url( add_query_arg( array( 'bf_year' => $prev->format( 'Y' ), 'bf_month' => $prev->format( 'n' ) ), admin_url( 'admin.php?page=bookflow-calendar' ) ) ); ?>">&larr; <?php esc_html_e( 'Previous', 'bookflow-booking-scheduling' ); ?></a>
				<strong style="margin:0 12px"><?php echo esc_html( $first_of_month->format( 'F Y' ) ); ?></strong>
				<a class="button" href="<?php echo esc_url( add_query_arg( array( 'bf_year' => $next->format( 'Y' ), 'bf_month' => $next->format( 'n' ) ), admin_url( 'admin.php?page=bookflow-calendar' ) ) ); ?>"><?php esc_html_e( 'Next', 'bookflow-booking-scheduling' ); ?> &rarr;</a>
			</p>

			<table class="bookflow-calendar">
				<thead>
					<tr>
						<?php foreach ( self::weekday_labels() as $label ) : ?>
							<th><?php echo esc_html( $label ); ?></th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php
					$cursor = $grid_start;
					for ( $week = 0; $week < 6; $week++ ) :
						?>
						<tr>
							<?php
							for ( $day = 0; $day < 7; $day++ ) :
								$key             = $cursor->format( 'Y-m-d' );
								$in_month        = (int) $cursor->format( 'n' ) === $month;
								$is_today        = $key === $today->format( 'Y-m-d' );
								$day_appointments = $appointments_by_day[ $key ] ?? array();

								// Convert this LOCAL calendar day's 00:00:00–23:59:59 boundaries to UTC before
								// linking — Appointment_Repository filters compare against UTC-stored columns,
								// so passing the raw local date string here would shift results by the site's
								// UTC offset on any non-UTC site.
								$day_start_utc = $cursor->setTimezone( new \DateTimeZone( 'UTC' ) );
								$day_end_utc   = $cursor->modify( '+1 day' )->modify( '-1 second' )->setTimezone( new \DateTimeZone( 'UTC' ) );
								$day_url       = admin_url( 'admin.php?page=bookflow-bookings&date_from=' . rawurlencode( $day_start_utc->format( 'Y-m-d H:i:s' ) ) . '&date_to=' . rawurlencode( $day_end_utc->format( 'Y-m-d H:i:s' ) ) );
								?>
								<td class="bookflow-calendar__day<?php echo $in_month ? '' : ' bookflow-calendar__day--muted'; ?><?php echo $is_today ? ' bookflow-calendar__day--today' : ''; ?>">
									<a href="<?php echo esc_url( $day_url ); ?>" class="bookflow-calendar__date"><?php echo esc_html( $cursor->format( 'j' ) ); ?></a>
									<?php foreach ( array_slice( $day_appointments, 0, 3 ) as $appointment ) : ?>
										<div class="bookflow-calendar__event bookflow-status--<?php echo esc_attr( $appointment->status ); ?>">
											<?php echo esc_html( $appointment->start->setTimezone( $site_timezone )->format( 'H:i' ) ); ?>
										</div>
									<?php endforeach; ?>
									<?php if ( count( $day_appointments ) > 3 ) : ?>
										<div class="bookflow-calendar__more">
											<?php
											printf(
												/* translators: %d: number of additional bookings that day. */
												esc_html__( '+%d more', 'bookflow-booking-scheduling' ),
												count( $day_appointments ) - 3
											);
											?>
										</div>
									<?php endif; ?>
								</td>
								<?php
								$cursor = $cursor->modify( '+1 day' );
							endfor;
							?>
						</tr>
					<?php endfor; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Weekday header labels, Sunday first, respecting the site's date_format/locale week start
	 * is out of scope for this v1 grid (always Sunday-first) — see docs/ROADMAP.md Phase 4 notes.
	 *
	 * @return array<int, string>
	 */
	private static function weekday_labels(): array {
		return array(
			__( 'Sun', 'bookflow-booking-scheduling' ),
			__( 'Mon', 'bookflow-booking-scheduling' ),
			__( 'Tue', 'bookflow-booking-scheduling' ),
			__( 'Wed', 'bookflow-booking-scheduling' ),
			__( 'Thu', 'bookflow-booking-scheduling' ),
			__( 'Fri', 'bookflow-booking-scheduling' ),
			__( 'Sat', 'bookflow-booking-scheduling' ),
		);
	}

	/**
	 * Fetch active appointments in the grid's date range and group them by local calendar date.
	 *
	 * @return array<string, array<int, Appointment>> Keyed by 'Y-m-d' (site timezone).
	 */
	private static function appointments_by_local_day( \DateTimeImmutable $grid_start, \DateTimeImmutable $grid_end, \DateTimeZone $site_timezone ): array {
		$utc_start = $grid_start->setTimezone( new \DateTimeZone( 'UTC' ) );
		$utc_end   = $grid_end->setTimezone( new \DateTimeZone( 'UTC' ) );

		$appointments = Appointment_Repository::all(
			array(
				'date_from' => $utc_start->format( 'Y-m-d H:i:s' ),
				'date_to'   => $utc_end->format( 'Y-m-d H:i:s' ),
				'orderby'   => 'start_datetime_utc',
				'order'     => 'asc',
				'limit'     => 1000,
			)
		);

		$by_day = array();

		foreach ( $appointments as $appointment ) {
			if ( ! $appointment->is_active() ) {
				continue;
			}

			$key             = $appointment->start->setTimezone( $site_timezone )->format( 'Y-m-d' );
			$by_day[ $key ][] = $appointment;
		}

		return $by_day;
	}
}

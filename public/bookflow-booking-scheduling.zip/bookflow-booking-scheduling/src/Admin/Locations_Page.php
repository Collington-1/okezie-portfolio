<?php
/**
 * Locations admin screen: list, add, edit, delete.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Locations\Location;
use BookFlow\Locations\Location_Repository;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Locations_Page
 */
final class Locations_Page {

	/**
	 * @var Validation_Exception|null
	 */
	private static ?Validation_Exception $error = null;

	/**
	 * @var array<string, mixed>
	 */
	private static array $submitted = array();

	/**
	 * Process add/edit/delete submissions.
	 */
	public static function handle_request(): void {
		if ( ! self::is_current_screen() ) {
			return;
		}

		if ( isset( $_GET['bookflow_action'], $_GET['id'] ) && 'delete' === $_GET['bookflow_action'] ) {
			self::handle_delete( absint( $_GET['id'] ) );
			return;
		}

		if ( isset( $_POST['bookflow_action'] ) && 'save' === $_POST['bookflow_action'] ) {
			self::handle_save();
		}
	}

	/**
	 * Render the screen.
	 */
	public static function render(): void {
		$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : 'list'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'add' === $action || 'edit' === $action || null !== self::$error ) {
			self::render_form( $action );
			return;
		}

		self::render_list();
	}

	/**
	 * Whether the current admin request targets this screen.
	 */
	private static function is_current_screen(): bool {
		return isset( $_GET['page'] ) && 'bookflow-locations' === $_GET['page']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Handle a delete link click.
	 */
	private static function handle_delete( int $id ): void {
		Form_Guard::verify( 'bookflow_delete_location_' . $id );

		Location_Repository::delete( $id );

		Notices::add( __( 'Location deleted.', 'bookflow-booking-scheduling' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-locations' ) );
		exit;
	}

	/**
	 * Handle the add/edit form submission.
	 */
	private static function handle_save(): void {
		Form_Guard::verify( 'bookflow_save_location' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

		$input = array(
			'name'        => isset( $_POST['name'] ) ? wp_unslash( $_POST['name'] ) : '',
			'type'        => isset( $_POST['type'] ) ? sanitize_key( $_POST['type'] ) : 'physical',
			'address'     => isset( $_POST['address'] ) ? wp_unslash( $_POST['address'] ) : '',
			'phone'       => isset( $_POST['phone'] ) ? wp_unslash( $_POST['phone'] ) : '',
			'timezone'    => isset( $_POST['timezone'] ) ? wp_unslash( $_POST['timezone'] ) : '',
			'meeting_url' => isset( $_POST['meeting_url'] ) ? wp_unslash( $_POST['meeting_url'] ) : '',
			'status'      => isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : 'active',
		);

		try {
			$location = $id > 0 ? Location_Repository::update( $id, $input ) : Location_Repository::create( $input );

			Weekly_Hours_Field::save_from_request( 'location', $location->id );

			Notices::add( $id > 0 ? __( 'Location updated.', 'bookflow-booking-scheduling' ) : __( 'Location created.', 'bookflow-booking-scheduling' ) );
			wp_safe_redirect( admin_url( 'admin.php?page=bookflow-locations' ) );
			exit;
		} catch ( Validation_Exception $e ) {
			self::$error     = $e;
			self::$submitted = wp_unslash( $_POST );
		}
	}

	/**
	 * Render the list screen.
	 */
	private static function render_list(): void {
		$table = new Locations_List_Table();
		$table->prepare_items();

		$add_url = admin_url( 'admin.php?page=bookflow-locations&action=add' );
		?>
		<div class="wrap bookflow-wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Locations', 'bookflow-booking-scheduling' ); ?></h1>
			<a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action"><?php esc_html_e( 'Add Location', 'bookflow-booking-scheduling' ); ?></a>
			<hr class="wp-header-end" />
			<form method="get">
				<input type="hidden" name="page" value="bookflow-locations" />
				<?php $table->search_box( __( 'Search locations', 'bookflow-booking-scheduling' ), 'bookflow-location' ); ?>
				<?php $table->display(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the add/edit form.
	 */
	private static function render_form( string $action ): void {
		$location = null;

		if ( 'edit' === $action && empty( self::$submitted ) ) {
			$id       = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$location = Location_Repository::find( $id );

			if ( null === $location ) {
				wp_die( esc_html__( 'Location not found.', 'bookflow-booking-scheduling' ) );
			}
		}

		$values = self::form_values( $location );

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php echo $location ? esc_html__( 'Edit Location', 'bookflow-booking-scheduling' ) : esc_html__( 'Add Location', 'bookflow-booking-scheduling' ); ?></h1>

			<?php if ( self::$error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( implode( ' ', self::$error->errors() ) ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-locations' ) ); ?>" class="bookflow-form">
				<?php wp_nonce_field( 'bookflow_save_location' ); ?>
				<input type="hidden" name="bookflow_action" value="save" />
				<input type="hidden" name="id" value="<?php echo esc_attr( (string) ( $location ? $location->id : 0 ) ); ?>" />

				<table class="form-table" role="presentation">
					<tr>
						<th><label for="bf-name"><?php esc_html_e( 'Name', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-name" name="name" class="regular-text" required value="<?php echo esc_attr( $values['name'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-type"><?php esc_html_e( 'Type', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-type" name="type">
								<?php foreach ( Location::types() as $type ) : ?>
									<option value="<?php echo esc_attr( $type ); ?>" <?php selected( $values['type'], $type ); ?>><?php echo esc_html( ucfirst( $type ) ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="bf-address"><?php esc_html_e( 'Address', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><textarea id="bf-address" name="address" rows="3" class="large-text"><?php echo esc_textarea( $values['address'] ); ?></textarea></td>
					</tr>
					<tr>
						<th><label for="bf-phone"><?php esc_html_e( 'Phone', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-phone" name="phone" class="regular-text" value="<?php echo esc_attr( $values['phone'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-meeting-url"><?php esc_html_e( 'Meeting URL (online locations)', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="url" id="bf-meeting-url" name="meeting_url" class="regular-text" value="<?php echo esc_attr( $values['meeting_url'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-timezone"><?php esc_html_e( 'Timezone', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-timezone" name="timezone">
								<option value=""><?php esc_html_e( '— Use site default —', 'bookflow-booking-scheduling' ); ?></option>
								<?php foreach ( \DateTimeZone::listIdentifiers() as $tz ) : ?>
									<option value="<?php echo esc_attr( $tz ); ?>" <?php selected( $values['timezone'], $tz ); ?>><?php echo esc_html( $tz ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="bf-status"><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-status" name="status">
								<?php foreach ( Location::statuses() as $status ) : ?>
									<option value="<?php echo esc_attr( $status ); ?>" <?php selected( $values['status'], $status ); ?>><?php echo esc_html( ucfirst( $status ) ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Hours', 'bookflow-booking-scheduling' ); ?></th>
						<td>
							<?php Weekly_Hours_Field::render( 'location', $location ? $location->id : null ); ?>
							<p class="description"><?php esc_html_e( 'Leave unchecked days closed. Leave every day unchecked to follow business hours with no location-specific restriction.', 'bookflow-booking-scheduling' ); ?></p>
						</td>
					</tr>
				</table>

				<?php submit_button( $location ? __( 'Update Location', 'bookflow-booking-scheduling' ) : __( 'Create Location', 'bookflow-booking-scheduling' ) ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-locations' ) ); ?>" class="button-link" style="margin-left:8px"><?php esc_html_e( 'Cancel', 'bookflow-booking-scheduling' ); ?></a>
			</form>
		</div>
		<?php
	}

	/**
	 * Resolve display values for the form.
	 *
	 * @return array<string, mixed>
	 */
	private static function form_values( ?Location $location ): array {
		if ( ! empty( self::$submitted ) ) {
			$post = self::$submitted;

			return array(
				'name'        => $post['name'] ?? '',
				'type'        => $post['type'] ?? 'physical',
				'address'     => $post['address'] ?? '',
				'phone'       => $post['phone'] ?? '',
				'meeting_url' => $post['meeting_url'] ?? '',
				'timezone'    => $post['timezone'] ?? '',
				'status'      => $post['status'] ?? 'active',
			);
		}

		if ( $location ) {
			return array(
				'name'        => $location->name,
				'type'        => $location->type,
				'address'     => (string) $location->address,
				'phone'       => (string) $location->phone,
				'meeting_url' => (string) $location->meeting_url,
				'timezone'    => (string) $location->timezone,
				'status'      => $location->status,
			);
		}

		return array(
			'name'        => '',
			'type'        => 'physical',
			'address'     => '',
			'phone'       => '',
			'meeting_url' => '',
			'timezone'    => '',
			'status'      => 'active',
		);
	}
}

<?php
/**
 * Admin module bootstrap.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Support\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Bootstrap
 */
final class Bootstrap {

	/**
	 * Register admin hooks. Only ever called when is_admin() — see Plugin::boot_modules().
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( Menu::class, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'maybe_enqueue_assets' ) );

		Notices::init();
		Privacy::init();

		// Form processing runs on admin_init so a successful save can redirect (PRG pattern)
		// before any HTML has been sent. Each handle_request() no-ops immediately unless the
		// current request is actually for that screen.
		add_action( 'admin_init', array( Services_Page::class, 'handle_request' ) );
		add_action( 'admin_init', array( Staff_Page::class, 'handle_request' ) );
		add_action( 'admin_init', array( Locations_Page::class, 'handle_request' ) );
		add_action( 'admin_init', array( Bookings_Page::class, 'handle_request' ) );
		add_action( 'admin_init', array( Scheduling_Pages_Page::class, 'handle_request' ) );
		add_action( 'admin_init', array( Events_Page::class, 'handle_request' ) );
		add_action( 'admin_init', array( Customers_Page::class, 'handle_request' ) );
		add_action( 'admin_init', array( Settings_Page::class, 'handle_request' ) );
		add_action( 'admin_init', array( Onboarding_Page::class, 'handle_request' ) );

		// Consumes the one-time activation transient Support\Activation::run() sets, sending a
		// freshly-activated admin into the setup wizard.
		add_action( 'admin_init', array( Onboarding_Page::class, 'maybe_redirect_after_activation' ) );
	}

	/**
	 * Enqueue admin CSS only on BookFlow's own screens (Section 10: "Load admin assets only on
	 * plugin admin screens").
	 *
	 * @param string $hook Current admin page hook suffix.
	 */
	public static function maybe_enqueue_assets( string $hook ): void {
		if ( ! in_array( $hook, Menu::hooks(), true ) ) {
			return;
		}

		wp_enqueue_style( 'bookflow-admin', BOOKFLOW_PLUGIN_URL . 'assets/css/admin.css', array(), Constants::VERSION );
	}
}

<?php
/**
 * Events admin screen: list, add, edit, delete, attendee management.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\CustomFields\Custom_Field_Repository;
use BookFlow\Customers\Customer_Repository;
use BookFlow\Events\Event;
use BookFlow\Events\Event_Attendee_Repository;
use BookFlow\Events\Event_Repository;
use BookFlow\Events\Event_State_Machine;
use BookFlow\Locations\Location_Repository;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Events_Page
 */
final class Events_Page {

	/**
	 * @var Validation_Exception|null
	 */
	private static ?Validation_Exception $error = null;

	/**
	 * @var array<string, mixed>
	 */
	private static array $submitted = array();

	/**
	 * Process add/edit/delete submissions and attendee actions.
	 */
	public static function handle_request(): void {
		if ( ! self::is_current_screen() ) {
			return;
		}

		if ( isset( $_GET['bookflow_action'], $_GET['id'] ) && 'delete' === $_GET['bookflow_action'] ) {
			self::handle_delete( absint( $_GET['id'] ) );
			return;
		}

		if ( isset( $_GET['bookflow_action'], $_GET['id'], $_GET['to'] ) && 'transition' === $_GET['bookflow_action'] ) {
			self::handle_transition( absint( $_GET['id'] ), sanitize_key( $_GET['to'] ) );
			return;
		}

		if ( isset( $_GET['bookflow_action'], $_GET['attendee_id'] ) && 'cancel_attendee' === $_GET['bookflow_action'] ) {
			self::handle_cancel_attendee( absint( $_GET['attendee_id'] ), absint( $_GET['id'] ?? 0 ) );
			return;
		}

		if ( isset( $_POST['bookflow_action'] ) && 'save' === $_POST['bookflow_action'] ) {
			self::handle_save();
		}
	}

	/**
	 * Render the screen.
	 */
	public static function render(): void {
		$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : 'list'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'attendees' === $action ) {
			self::render_attendees();
			return;
		}

		if ( 'add' === $action || 'edit' === $action || null !== self::$error ) {
			self::render_form( $action );
			return;
		}

		self::render_list();
	}

	/**
	 * Whether the current admin request targets this screen.
	 */
	private static function is_current_screen(): bool {
		return isset( $_GET['page'] ) && 'bookflow-events' === $_GET['page']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Handle a delete link click.
	 */
	private static function handle_delete( int $id ): void {
		Form_Guard::verify( 'bookflow_delete_event_' . $id );

		Event_Repository::delete( $id );

		Notices::add( __( 'Event deleted.', 'bookflow-booking-scheduling' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-events' ) );
		exit;
	}

	/**
	 * Handle a status transition link.
	 */
	private static function handle_transition( int $id, string $to ): void {
		Form_Guard::verify( 'bookflow_transition_event_' . $id );

		$event = Event_Repository::find( $id );

		if ( null === $event ) {
			wp_die( esc_html__( 'Event not found.', 'bookflow-booking-scheduling' ) );
		}

		try {
			Event_State_Machine::transition( $event, $to, get_current_user_id() );
			Notices::add( __( 'Event status updated.', 'bookflow-booking-scheduling' ) );
		} catch ( \InvalidArgumentException $e ) {
			Notices::add( __( 'That status change is not allowed.', 'bookflow-booking-scheduling' ), 'error' );
		}

		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=bookflow-events' ) );
		exit;
	}

	/**
	 * Handle an attendee cancellation from the attendees view.
	 */
	private static function handle_cancel_attendee( int $attendee_id, int $event_id ): void {
		Form_Guard::verify( 'bookflow_cancel_attendee_' . $attendee_id );

		Event_Attendee_Repository::cancel( $attendee_id );

		Notices::add( __( 'Registration cancelled.', 'bookflow-booking-scheduling' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-events&action=attendees&id=' . $event_id ) );
		exit;
	}

	/**
	 * Handle the add/edit form submission.
	 */
	private static function handle_save(): void {
		Form_Guard::verify( 'bookflow_save_event' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

		$site_timezone = wp_timezone();
		$start         = self::parse_datetime( $_POST['start_date'] ?? '', $_POST['start_time'] ?? '', $site_timezone );
		$end           = self::parse_datetime( $_POST['end_date'] ?? '', $_POST['end_time'] ?? '', $site_timezone );

		$input = array(
			'title'       => isset( $_POST['title'] ) ? wp_unslash( $_POST['title'] ) : '',
			'description' => isset( $_POST['description'] ) ? wp_unslash( $_POST['description'] ) : '',
			'start'       => $start,
			'end'         => $end,
			'timezone'    => $site_timezone->getName(),
			'location_id' => isset( $_POST['location_id'] ) && '' !== $_POST['location_id'] ? absint( $_POST['location_id'] ) : null,
			'capacity'    => isset( $_POST['capacity'] ) && '' !== $_POST['capacity'] ? (int) $_POST['capacity'] : null,
			'price'       => isset( $_POST['price'] ) && '' !== $_POST['price'] ? (float) $_POST['price'] : null,
			'currency'    => isset( $_POST['currency'] ) ? wp_unslash( $_POST['currency'] ) : '',
			'status'      => isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : 'draft',
		);

		try {
			$event = $id > 0 ? Event_Repository::update( $id, $input ) : Event_Repository::create( $input );

			Notices::add( $id > 0 ? __( 'Event updated.', 'bookflow-booking-scheduling' ) : __( 'Event created.', 'bookflow-booking-scheduling' ) );
			wp_safe_redirect( admin_url( 'admin.php?page=bookflow-events' ) );
			exit;
		} catch ( Validation_Exception $e ) {
			self::$error     = $e;
			self::$submitted = wp_unslash( $_POST );
		}
	}

	/**
	 * Parse a date + time form field pair into a DateTimeImmutable in the given timezone, or
	 * null if either part is missing/malformed (validate() then reports the field as required).
	 */
	private static function parse_datetime( $date, $time, \DateTimeZone $timezone ): ?\DateTimeImmutable {
		$date = sanitize_text_field( wp_unslash( (string) $date ) );
		$time = sanitize_text_field( wp_unslash( (string) $time ) );

		if ( '' === $date || '' === $time ) {
			return null;
		}

		$result = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i', "{$date} {$time}", $timezone );

		return false !== $result ? $result : null;
	}

	/**
	 * Render the list screen.
	 */
	private static function render_list(): void {
		$table = new Events_List_Table();
		$table->prepare_items();

		$add_url = admin_url( 'admin.php?page=bookflow-events&action=add' );
		?>
		<div class="wrap bookflow-wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Events', 'bookflow-booking-scheduling' ); ?></h1>
			<a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action"><?php esc_html_e( 'Add Event', 'bookflow-booking-scheduling' ); ?></a>
			<hr class="wp-header-end" />
			<?php $table->views(); ?>
			<form method="get">
				<input type="hidden" name="page" value="bookflow-events" />
				<?php $table->search_box( __( 'Search events', 'bookflow-booking-scheduling' ), 'bookflow-event' ); ?>
				<?php $table->display(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the add/edit form.
	 */
	private static function render_form( string $action ): void {
		$event = null;

		if ( 'edit' === $action && empty( self::$submitted ) ) {
			$id    = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$event = Event_Repository::find( $id );

			if ( null === $event ) {
				wp_die( esc_html__( 'Event not found.', 'bookflow-booking-scheduling' ) );
			}
		}

		$values    = self::form_values( $event );
		$locations = Location_Repository::all( array( 'status' => 'active' ) );

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php echo $event ? esc_html__( 'Edit Event', 'bookflow-booking-scheduling' ) : esc_html__( 'Add Event', 'bookflow-booking-scheduling' ); ?></h1>

			<?php if ( self::$error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( implode( ' ', self::$error->errors() ) ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-events' ) ); ?>" class="bookflow-form">
				<?php wp_nonce_field( 'bookflow_save_event' ); ?>
				<input type="hidden" name="bookflow_action" value="save" />
				<input type="hidden" name="id" value="<?php echo esc_attr( (string) ( $event ? $event->id : 0 ) ); ?>" />

				<table class="form-table" role="presentation">
					<tr>
						<th><label for="bf-title"><?php esc_html_e( 'Title', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-title" name="title" class="regular-text" required value="<?php echo esc_attr( $values['title'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-description"><?php esc_html_e( 'Description', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><textarea id="bf-description" name="description" rows="4" class="large-text"><?php echo esc_textarea( $values['description'] ); ?></textarea></td>
					</tr>
					<tr>
						<th><label for="bf-start"><?php esc_html_e( 'Starts (site timezone)', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<input type="date" id="bf-start" name="start_date" required value="<?php echo esc_attr( $values['start_date'] ); ?>" />
							<input type="time" name="start_time" required value="<?php echo esc_attr( $values['start_time'] ); ?>" />
						</td>
					</tr>
					<tr>
						<th><label for="bf-end"><?php esc_html_e( 'Ends (site timezone)', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<input type="date" id="bf-end" name="end_date" required value="<?php echo esc_attr( $values['end_date'] ); ?>" />
							<input type="time" name="end_time" required value="<?php echo esc_attr( $values['end_time'] ); ?>" />
						</td>
					</tr>
					<tr>
						<th><label for="bf-location"><?php esc_html_e( 'Location', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-location" name="location_id">
								<option value=""><?php esc_html_e( '— None —', 'bookflow-booking-scheduling' ); ?></option>
								<?php foreach ( $locations as $location ) : ?>
									<option value="<?php echo esc_attr( (string) $location->id ); ?>" <?php selected( (string) $values['location_id'], (string) $location->id ); ?>><?php echo esc_html( $location->name ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="bf-capacity"><?php esc_html_e( 'Capacity (blank = unlimited)', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="number" min="1" id="bf-capacity" name="capacity" value="<?php echo esc_attr( (string) $values['capacity'] ); ?>" style="width:100px" /></td>
					</tr>
					<tr>
						<th><label for="bf-price"><?php esc_html_e( 'Price per seat (blank = free)', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<input type="number" min="0" step="0.01" id="bf-price" name="price" value="<?php echo esc_attr( (string) $values['price'] ); ?>" style="width:120px" />
							<input type="text" name="currency" maxlength="3" placeholder="USD" value="<?php echo esc_attr( $values['currency'] ); ?>" style="width:70px;text-transform:uppercase" />
						</td>
					</tr>
					<tr>
						<th><label for="bf-status"><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-status" name="status">
								<?php foreach ( Event::statuses() as $status ) : ?>
									<option value="<?php echo esc_attr( $status ); ?>" <?php selected( $values['status'], $status ); ?>><?php echo esc_html( ucfirst( $status ) ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Only "Published" events accept registrations and appear on their public page.', 'bookflow-booking-scheduling' ); ?></p>
						</td>
					</tr>
				</table>

				<?php submit_button( $event ? __( 'Update Event', 'bookflow-booking-scheduling' ) : __( 'Create Event', 'bookflow-booking-scheduling' ) ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-events' ) ); ?>" class="button-link" style="margin-left:8px"><?php esc_html_e( 'Cancel', 'bookflow-booking-scheduling' ); ?></a>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the attendees view for one event.
	 */
	private static function render_attendees(): void {
		$id    = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$event = Event_Repository::find( $id );

		if ( null === $event ) {
			wp_die( esc_html__( 'Event not found.', 'bookflow-booking-scheduling' ) );
		}

		$attendees = Event_Attendee_Repository::for_event( $id );

		// Resolved once for the whole list, not per row — field_key => label, so each
		// attendee's raw custom_fields JSON (keyed by field_key) can show human-readable
		// question labels instead of internal keys.
		$field_labels = array();
		foreach ( Custom_Field_Repository::for_context( 'event', $id ) as $field ) {
			$field_labels[ $field->field_key ] = $field->label;
		}

		// Batch-fetched once for the whole (unpaginated) attendee list rather than once per row
		// — an event with a large attendee list would otherwise run one Customer_Repository::find()
		// query per row (Section 10: "Avoid N+1 database queries", also the exact bug just fixed
		// on the Customers admin screen — see docs/ROADMAP.md Phase 13 notes).
		$customers = Customer_Repository::find_many(
			array_map(
				static function ( $attendee ) {
					return $attendee->customer_id;
				},
				$attendees
			)
		);

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php printf( /* translators: %s: event title. */ esc_html__( 'Attendees — %s', 'bookflow-booking-scheduling' ), esc_html( $event->title ) ); ?></h1>

			<?php if ( empty( $attendees ) ) : ?>
				<p><?php esc_html_e( 'No one has registered yet.', 'bookflow-booking-scheduling' ); ?></p>
			<?php else : ?>
				<table class="widefat striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Reference', 'bookflow-booking-scheduling' ); ?></th>
							<th><?php esc_html_e( 'Customer', 'bookflow-booking-scheduling' ); ?></th>
							<th><?php esc_html_e( 'Seats', 'bookflow-booking-scheduling' ); ?></th>
							<th><?php esc_html_e( 'Details', 'bookflow-booking-scheduling' ); ?></th>
							<th><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $attendees as $attendee ) : ?>
							<?php $customer = $customers[ $attendee->customer_id ] ?? null; ?>
							<tr>
								<td><?php echo esc_html( $attendee->booking_reference ); ?></td>
								<td><?php echo esc_html( $customer ? $customer->display_name() . ' <' . $customer->email . '>' : '' ); ?></td>
								<td><?php echo esc_html( (string) $attendee->quantity ); ?></td>
								<td>
									<?php foreach ( $attendee->custom_fields as $field_key => $answer ) : ?>
										<div><strong><?php echo esc_html( $field_labels[ $field_key ] ?? $field_key ); ?>:</strong> <?php echo esc_html( is_scalar( $answer ) ? (string) $answer : wp_json_encode( $answer ) ); ?></div>
									<?php endforeach; ?>
								</td>
								<td><span class="bookflow-status bookflow-status--<?php echo esc_attr( $attendee->status ); ?>"><?php echo esc_html( ucfirst( $attendee->status ) ); ?></span></td>
								<td>
									<?php if ( $attendee->is_active() ) : ?>
										<?php $cancel_url = wp_nonce_url( admin_url( 'admin.php?page=bookflow-events&action=attendees&id=' . $id . '&bookflow_action=cancel_attendee&attendee_id=' . $attendee->id ), 'bookflow_cancel_attendee_' . $attendee->id ); ?>
										<a href="<?php echo esc_url( $cancel_url ); ?>" onclick="return confirm(<?php echo esc_attr( wp_json_encode( __( 'Cancel this registration?', 'bookflow-booking-scheduling' ) ) ); ?>);"><?php esc_html_e( 'Cancel', 'bookflow-booking-scheduling' ); ?></a>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<p style="margin-top:16px"><a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-events' ) ); ?>">&larr; <?php esc_html_e( 'Back to events', 'bookflow-booking-scheduling' ); ?></a></p>
		</div>
		<?php
	}

	/**
	 * Resolve display values for the form.
	 *
	 * @return array<string, mixed>
	 */
	private static function form_values( ?Event $event ): array {
		if ( ! empty( self::$submitted ) ) {
			$post = self::$submitted;

			return array(
				'title'       => $post['title'] ?? '',
				'description' => $post['description'] ?? '',
				'start_date'  => $post['start_date'] ?? '',
				'start_time'  => $post['start_time'] ?? '',
				'end_date'    => $post['end_date'] ?? '',
				'end_time'    => $post['end_time'] ?? '',
				'location_id' => $post['location_id'] ?? '',
				'capacity'    => $post['capacity'] ?? '',
				'price'       => $post['price'] ?? '',
				'currency'    => $post['currency'] ?? '',
				'status'      => $post['status'] ?? 'draft',
			);
		}

		if ( $event ) {
			$site_timezone = wp_timezone();
			$local_start   = $event->start->setTimezone( $site_timezone );
			$local_end     = $event->end->setTimezone( $site_timezone );

			return array(
				'title'       => $event->title,
				'description' => (string) $event->description,
				'start_date'  => $local_start->format( 'Y-m-d' ),
				'start_time'  => $local_start->format( 'H:i' ),
				'end_date'    => $local_end->format( 'Y-m-d' ),
				'end_time'    => $local_end->format( 'H:i' ),
				'location_id' => (string) $event->location_id,
				'capacity'    => $event->capacity ?? '',
				'price'       => $event->price ?? '',
				'currency'    => (string) $event->currency,
				'status'      => $event->status,
			);
		}

		return array(
			'title'       => '',
			'description' => '',
			'start_date'  => '',
			'start_time'  => '',
			'end_date'    => '',
			'end_time'    => '',
			'location_id' => '',
			'capacity'    => '',
			'price'       => '',
			'currency'    => '',
			'status'      => 'draft',
		);
	}
}

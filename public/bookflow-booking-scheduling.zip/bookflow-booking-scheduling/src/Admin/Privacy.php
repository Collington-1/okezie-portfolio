<?php
/**
 * Suggested privacy policy content — WordPress.org's plugin guidelines recommend (though don't
 * strictly require) that any plugin collecting personal data register this, so site owners get
 * accurate starting text under Settings → Privacy → "Policy Guide" instead of having to write it
 * from scratch. See docs/ROADMAP.md's Phase 14 notes for why this was added.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Privacy
 */
final class Privacy {

	/**
	 * Register the content-suggestion hook.
	 */
	public static function init(): void {
		// admin_init, not plugins_loaded — this is the hook WordPress core's own privacy-tools
		// documentation calls out, and wp_add_privacy_policy_content() only exists once wp-admin
		// has loaded (guarded below too, since admin-ajax.php requests also fire admin_init).
		add_action( 'admin_init', array( self::class, 'add_content' ) );
	}

	/**
	 * Register BookFlow's suggested policy text.
	 */
	public static function add_content(): void {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content = '<p class="privacy-policy-tutorial">' .
			esc_html__( 'The suggested text below is a starting point. Edit it to accurately describe how your business actually uses BookFlow — for example, whether you follow up with customers by phone as well as email.', 'bookflow-booking-scheduling' ) .
			'</p>' .
			'<p>' . esc_html__( 'When someone books an appointment, registers for an event, or submits a scheduling page request, we collect the information they provide — typically their name, email address, and phone number, plus answers to any custom questions we ask as part of booking (for example, special requests or the reason for a visit). We use this information only to manage the booking: to confirm it, to contact them about it, and to provide the service or event they booked.', 'bookflow-booking-scheduling' ) . '</p>' .
			'<p>' . esc_html__( 'This information is stored in our WordPress database. We do not send it to any third-party service as part of this booking system\'s core functionality.', 'bookflow-booking-scheduling' ) . '</p>' .
			'<p>' . esc_html__( 'We keep booking and customer records for as long as needed to provide our services, unless a shorter retention period is required or requested. If someone wants their booking information removed, contact us using the details on this site.', 'bookflow-booking-scheduling' ) . '</p>';

		wp_add_privacy_policy_content(
			__( 'BookFlow – Booking & Scheduling', 'bookflow-booking-scheduling' ),
			wp_kses_post( $content )
		);
	}
}

<?php
/**
 * Staff admin screen: list, add, edit, delete.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Locations\Location_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Member;
use BookFlow\Staff\Staff_Repository;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Staff_Page
 */
final class Staff_Page {

	/**
	 * @var Validation_Exception|null
	 */
	private static ?Validation_Exception $error = null;

	/**
	 * @var array<string, mixed>
	 */
	private static array $submitted = array();

	/**
	 * Process add/edit/delete submissions.
	 */
	public static function handle_request(): void {
		if ( ! self::is_current_screen() ) {
			return;
		}

		if ( isset( $_GET['bookflow_action'], $_GET['id'] ) && 'delete' === $_GET['bookflow_action'] ) {
			self::handle_delete( absint( $_GET['id'] ) );
			return;
		}

		if ( isset( $_POST['bookflow_action'] ) && 'save' === $_POST['bookflow_action'] ) {
			self::handle_save();
		}
	}

	/**
	 * Render the screen.
	 */
	public static function render(): void {
		$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : 'list'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'add' === $action || 'edit' === $action || null !== self::$error ) {
			self::render_form( $action );
			return;
		}

		self::render_list();
	}

	/**
	 * Whether the current admin request targets this screen.
	 */
	private static function is_current_screen(): bool {
		return isset( $_GET['page'] ) && 'bookflow-staff' === $_GET['page']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Handle a delete link click.
	 */
	private static function handle_delete( int $id ): void {
		Form_Guard::verify( 'bookflow_delete_staff_' . $id );

		Staff_Repository::delete( $id );

		Notices::add( __( 'Staff member deleted.', 'bookflow-booking-scheduling' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-staff' ) );
		exit;
	}

	/**
	 * Handle the add/edit form submission.
	 */
	private static function handle_save(): void {
		Form_Guard::verify( 'bookflow_save_staff' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

		$input = array(
			'display_name' => isset( $_POST['display_name'] ) ? wp_unslash( $_POST['display_name'] ) : '',
			'email'        => isset( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '',
			'phone'        => isset( $_POST['phone'] ) ? wp_unslash( $_POST['phone'] ) : '',
			'timezone'     => isset( $_POST['timezone'] ) ? wp_unslash( $_POST['timezone'] ) : '',
			'color'        => isset( $_POST['color'] ) ? wp_unslash( $_POST['color'] ) : '',
			'status'       => isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : 'active',
		);

		$service_ids  = array_map( 'absint', (array) ( $_POST['service_ids'] ?? array() ) );
		$location_ids = array_map( 'absint', (array) ( $_POST['location_ids'] ?? array() ) );

		try {
			$staff = $id > 0 ? Staff_Repository::update( $id, $input ) : Staff_Repository::create( $input );

			Staff_Repository::set_services( $staff->id, $service_ids );
			Staff_Repository::set_locations( $staff->id, $location_ids );
			Weekly_Hours_Field::save_from_request( 'staff', $staff->id );

			Notices::add( $id > 0 ? __( 'Staff member updated.', 'bookflow-booking-scheduling' ) : __( 'Staff member created.', 'bookflow-booking-scheduling' ) );
			wp_safe_redirect( admin_url( 'admin.php?page=bookflow-staff' ) );
			exit;
		} catch ( Validation_Exception $e ) {
			self::$error     = $e;
			self::$submitted = wp_unslash( $_POST );
		}
	}

	/**
	 * Render the list screen.
	 */
	private static function render_list(): void {
		$table = new Staff_List_Table();
		$table->prepare_items();

		$add_url = admin_url( 'admin.php?page=bookflow-staff&action=add' );
		?>
		<div class="wrap bookflow-wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Staff', 'bookflow-booking-scheduling' ); ?></h1>
			<a href="<?php echo esc_url( $add_url ); ?>" class="page-title-action"><?php esc_html_e( 'Add Staff', 'bookflow-booking-scheduling' ); ?></a>
			<hr class="wp-header-end" />
			<form method="get">
				<input type="hidden" name="page" value="bookflow-staff" />
				<?php $table->search_box( __( 'Search staff', 'bookflow-booking-scheduling' ), 'bookflow-staff' ); ?>
				<?php $table->display(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render the add/edit form.
	 */
	private static function render_form( string $action ): void {
		$staff = null;

		if ( 'edit' === $action && empty( self::$submitted ) ) {
			$id    = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$staff = Staff_Repository::find( $id );

			if ( null === $staff ) {
				wp_die( esc_html__( 'Staff member not found.', 'bookflow-booking-scheduling' ) );
			}
		}

		$values = self::form_values( $staff );

		$services          = Service_Repository::all( array( 'status' => 'active' ) );
		$locations         = Location_Repository::all( array( 'status' => 'active' ) );
		$assigned_services = $staff ? Staff_Repository::service_ids( $staff->id ) : array();
		$assigned_locs     = $staff ? Staff_Repository::location_ids( $staff->id ) : array();

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php echo $staff ? esc_html__( 'Edit Staff Member', 'bookflow-booking-scheduling' ) : esc_html__( 'Add Staff Member', 'bookflow-booking-scheduling' ); ?></h1>

			<?php if ( self::$error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( implode( ' ', self::$error->errors() ) ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-staff' ) ); ?>" class="bookflow-form">
				<?php wp_nonce_field( 'bookflow_save_staff' ); ?>
				<input type="hidden" name="bookflow_action" value="save" />
				<input type="hidden" name="id" value="<?php echo esc_attr( (string) ( $staff ? $staff->id : 0 ) ); ?>" />

				<table class="form-table" role="presentation">
					<tr>
						<th><label for="bf-name"><?php esc_html_e( 'Name', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-name" name="display_name" class="regular-text" required value="<?php echo esc_attr( $values['display_name'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-email"><?php esc_html_e( 'Email', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="email" id="bf-email" name="email" class="regular-text" value="<?php echo esc_attr( $values['email'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-phone"><?php esc_html_e( 'Phone', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="text" id="bf-phone" name="phone" class="regular-text" value="<?php echo esc_attr( $values['phone'] ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-timezone"><?php esc_html_e( 'Timezone', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-timezone" name="timezone">
								<option value=""><?php esc_html_e( '— Use site default —', 'bookflow-booking-scheduling' ); ?></option>
								<?php foreach ( \DateTimeZone::listIdentifiers() as $tz ) : ?>
									<option value="<?php echo esc_attr( $tz ); ?>" <?php selected( $values['timezone'], $tz ); ?>><?php echo esc_html( $tz ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="bf-color"><?php esc_html_e( 'Calendar color', 'bookflow-booking-scheduling' ); ?></label></th>
						<td><input type="color" id="bf-color" name="color" value="<?php echo esc_attr( $values['color'] ?: '#4C6EF5' ); ?>" /></td>
					</tr>
					<tr>
						<th><label for="bf-status"><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></label></th>
						<td>
							<select id="bf-status" name="status">
								<?php foreach ( Staff_Member::statuses() as $status ) : ?>
									<option value="<?php echo esc_attr( $status ); ?>" <?php selected( $values['status'], $status ); ?>><?php echo esc_html( ucfirst( $status ) ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Working hours', 'bookflow-booking-scheduling' ); ?></th>
						<td>
							<?php Weekly_Hours_Field::render( 'staff', $staff ? $staff->id : null ); ?>
							<p class="description"><?php esc_html_e( 'Leave a day unchecked if this staff member does not work that day. Hours are in this staff member’s timezone above (or the site timezone if none is set).', 'bookflow-booking-scheduling' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Services', 'bookflow-booking-scheduling' ); ?></th>
						<td>
							<?php if ( empty( $services ) ) : ?>
								<p class="description"><?php esc_html_e( 'No services yet.', 'bookflow-booking-scheduling' ); ?></p>
							<?php endif; ?>
							<?php foreach ( $services as $service ) : ?>
								<label style="display:block"><input type="checkbox" name="service_ids[]" value="<?php echo esc_attr( (string) $service->id ); ?>" <?php checked( in_array( $service->id, $assigned_services, true ) ); ?> /> <?php echo esc_html( $service->name ); ?></label>
							<?php endforeach; ?>
						</td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Locations', 'bookflow-booking-scheduling' ); ?></th>
						<td>
							<?php if ( empty( $locations ) ) : ?>
								<p class="description"><?php esc_html_e( 'No locations yet.', 'bookflow-booking-scheduling' ); ?></p>
							<?php endif; ?>
							<?php foreach ( $locations as $location ) : ?>
								<label style="display:block"><input type="checkbox" name="location_ids[]" value="<?php echo esc_attr( (string) $location->id ); ?>" <?php checked( in_array( $location->id, $assigned_locs, true ) ); ?> /> <?php echo esc_html( $location->name ); ?></label>
							<?php endforeach; ?>
						</td>
					</tr>
				</table>

				<?php submit_button( $staff ? __( 'Update Staff Member', 'bookflow-booking-scheduling' ) : __( 'Create Staff Member', 'bookflow-booking-scheduling' ) ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-staff' ) ); ?>" class="button-link" style="margin-left:8px"><?php esc_html_e( 'Cancel', 'bookflow-booking-scheduling' ); ?></a>
			</form>
		</div>
		<?php
	}

	/**
	 * Resolve display values for the form.
	 *
	 * @return array<string, mixed>
	 */
	private static function form_values( ?Staff_Member $staff ): array {
		if ( ! empty( self::$submitted ) ) {
			$post = self::$submitted;

			return array(
				'display_name' => $post['display_name'] ?? '',
				'email'        => $post['email'] ?? '',
				'phone'        => $post['phone'] ?? '',
				'timezone'     => $post['timezone'] ?? '',
				'color'        => $post['color'] ?? '',
				'status'       => $post['status'] ?? 'active',
			);
		}

		if ( $staff ) {
			return array(
				'display_name' => $staff->display_name,
				'email'        => (string) $staff->email,
				'phone'        => (string) $staff->phone,
				'timezone'     => (string) $staff->timezone,
				'color'        => (string) $staff->color,
				'status'       => $staff->status,
			);
		}

		return array(
			'display_name' => '',
			'email'        => '',
			'phone'        => '',
			'timezone'     => '',
			'color'        => '',
			'status'       => 'active',
		);
	}
}

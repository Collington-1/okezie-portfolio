<?php
/**
 * Shared weekly working-hours editor, embedded in the Staff form, the Locations form, and the
 * business-wide hours section of Settings — the only UI path (Phase 4) for populating
 * bookflow_availability_rules, which the Phase 3 booking engine depends on.
 *
 * UI scope note: one start/end range per day. The underlying data model
 * (Availability_Rule_Repository) already supports multiple rows per day (split shifts), but a
 * dynamic add/remove-row JS interface for that is deferred — see docs/ROADMAP.md Phase 4 notes.
 * A day with existing split-shift rules (e.g. set via a future UI or REST) is shown using only
 * its first row here; saving the form will collapse it back to a single range.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Booking\Availability_Rule_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Weekly_Hours_Field
 */
final class Weekly_Hours_Field {

	/**
	 * Day labels, index-aligned with the day_of_week column (0 = Sunday).
	 *
	 * @return array<int, string>
	 */
	private static function day_labels(): array {
		return array(
			0 => __( 'Sunday', 'bookflow-booking-scheduling' ),
			1 => __( 'Monday', 'bookflow-booking-scheduling' ),
			2 => __( 'Tuesday', 'bookflow-booking-scheduling' ),
			3 => __( 'Wednesday', 'bookflow-booking-scheduling' ),
			4 => __( 'Thursday', 'bookflow-booking-scheduling' ),
			5 => __( 'Friday', 'bookflow-booking-scheduling' ),
			6 => __( 'Saturday', 'bookflow-booking-scheduling' ),
		);
	}

	/**
	 * Render the editor. Field names are namespaced under $field_prefix so more than one of
	 * these can appear on the same form if ever needed (not currently the case).
	 *
	 * @param string   $entity_type  'business' | 'staff' | 'location'.
	 * @param int|null $entity_id    Entity ID, or null for 'business'.
	 * @param string   $field_prefix POST field name prefix, e.g. 'hours'.
	 */
	public static function render( string $entity_type, ?int $entity_id, string $field_prefix = 'hours' ): void {
		$existing = Availability_Rule_Repository::for_entity( $entity_type, $entity_id );

		// Keep only the first rule per day for this single-range-per-day editor.
		$by_day = array();

		foreach ( $existing as $rule ) {
			if ( ! isset( $by_day[ $rule->day_of_week ] ) ) {
				$by_day[ $rule->day_of_week ] = $rule;
			}
		}

		?>
		<table class="bookflow-hours-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Day', 'bookflow-booking-scheduling' ); ?></th>
					<th><?php esc_html_e( 'Open', 'bookflow-booking-scheduling' ); ?></th>
					<th><?php esc_html_e( 'Start', 'bookflow-booking-scheduling' ); ?></th>
					<th><?php esc_html_e( 'End', 'bookflow-booking-scheduling' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( self::day_labels() as $day => $label ) : ?>
				<?php
				$rule   = $by_day[ $day ] ?? null;
				$open   = null !== $rule;
				$start  = $rule ? substr( $rule->start_time, 0, 5 ) : '09:00';
				$end    = $rule ? substr( $rule->end_time, 0, 5 ) : '17:00';
				?>
				<tr>
					<td><?php echo esc_html( $label ); ?></td>
					<td><input type="checkbox" name="<?php echo esc_attr( $field_prefix ); ?>[<?php echo esc_attr( (string) $day ); ?>][open]" value="1" <?php checked( $open ); ?> /></td>
					<td><input type="time" name="<?php echo esc_attr( $field_prefix ); ?>[<?php echo esc_attr( (string) $day ); ?>][start]" value="<?php echo esc_attr( $start ); ?>" /></td>
					<td><input type="time" name="<?php echo esc_attr( $field_prefix ); ?>[<?php echo esc_attr( (string) $day ); ?>][end]" value="<?php echo esc_attr( $end ); ?>" /></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Read submitted values from $_POST[$field_prefix] and persist them, replacing the entity's
	 * entire weekly schedule.
	 *
	 * @param string   $entity_type  'business' | 'staff' | 'location'.
	 * @param int|null $entity_id    Entity ID, or null for 'business'.
	 * @param string   $field_prefix POST field name prefix, matching render()'s.
	 */
	public static function save_from_request( string $entity_type, ?int $entity_id, string $field_prefix = 'hours' ): void {
		$raw = isset( $_POST[ $field_prefix ] ) && is_array( $_POST[ $field_prefix ] ) ? wp_unslash( $_POST[ $field_prefix ] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- caller verifies the form nonce before calling this.

		$rules = array();

		foreach ( $raw as $day => $entry ) {
			if ( empty( $entry['open'] ) ) {
				continue;
			}

			$day = (int) $day;

			if ( $day < 0 || $day > 6 ) {
				continue;
			}

			$rules[] = array(
				'day_of_week' => $day,
				'start_time'  => sanitize_text_field( $entry['start'] ?? '09:00' ),
				'end_time'    => sanitize_text_field( $entry['end'] ?? '17:00' ),
			);
		}

		Availability_Rule_Repository::replace_for_entity( $entity_type, $entity_id, $rules );
	}
}

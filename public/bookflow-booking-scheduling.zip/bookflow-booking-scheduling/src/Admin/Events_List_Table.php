<?php
/**
 * Events list table — paginated server-side (Section 10 explicitly calls out events, alongside
 * bookings/customers, as needing it — unlike Services/Staff/Locations/Scheduling pages).
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Events\Event;
use BookFlow\Events\Event_Attendee_Repository;
use BookFlow\Events\Event_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Class Events_List_Table
 */
final class Events_List_Table extends \WP_List_Table {

	/**
	 * Rows per page.
	 *
	 * @var int
	 */
	private const PER_PAGE = 20;

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'event',
				'plural'   => 'events',
				'ajax'     => false,
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'title'    => __( 'Title', 'bookflow-booking-scheduling' ),
			'when'     => __( 'Date & Time', 'bookflow-booking-scheduling' ),
			'capacity' => __( 'Seats', 'bookflow-booking-scheduling' ),
			'status'   => __( 'Status', 'bookflow-booking-scheduling' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_sortable_columns(): array {
		return array(
			'when' => array( 'start_datetime_utc', false ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function get_views(): array {
		$current = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter state.
		$base    = admin_url( 'admin.php?page=bookflow-events' );

		$views = array(
			'' => sprintf(
				'<a href="%s" class="%s">%s <span class="count">(%d)</span></a>',
				esc_url( $base ),
				'' === $current ? 'current' : '',
				esc_html__( 'All', 'bookflow-booking-scheduling' ),
				Event_Repository::count()
			),
		);

		foreach ( Event::statuses() as $status ) {
			$views[ $status ] = sprintf(
				'<a href="%s" class="%s">%s <span class="count">(%d)</span></a>',
				esc_url( add_query_arg( 'status', $status, $base ) ),
				$current === $status ? 'current' : '',
				esc_html( ucfirst( $status ) ),
				Event_Repository::count( array( 'status' => $status ) )
			);
		}

		return $views;
	}

	/**
	 * {@inheritDoc}
	 */
	public function prepare_items(): void {
		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns() );

		$args = array();

		if ( ! empty( $_GET['status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filtering.
			$args['status'] = sanitize_key( $_GET['status'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( ! empty( $_GET['s'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['search'] = sanitize_text_field( wp_unslash( $_GET['s'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		$current_page   = $this->get_pagenum();
		$args['limit']  = self::PER_PAGE;
		$args['offset'] = ( $current_page - 1 ) * self::PER_PAGE;
		$args['orderby'] = 'start_datetime_utc';
		$args['order']   = isset( $_GET['order'] ) && 'desc' === strtolower( (string) $_GET['order'] ) ? 'desc' : 'asc'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$total = Event_Repository::count( $args );
		$this->items = Event_Repository::all( $args );

		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => self::PER_PAGE,
				'total_pages' => (int) ceil( $total / self::PER_PAGE ),
			)
		);
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Event $item Row data.
	 */
	public function column_title( $item ): string {
		$edit_url        = add_query_arg( array( 'page' => 'bookflow-events', 'action' => 'edit', 'id' => $item->id ), admin_url( 'admin.php' ) );
		$attendees_url   = add_query_arg( array( 'page' => 'bookflow-events', 'action' => 'attendees', 'id' => $item->id ), admin_url( 'admin.php' ) );
		$delete_url      = wp_nonce_url( add_query_arg( array( 'page' => 'bookflow-events', 'bookflow_action' => 'delete', 'id' => $item->id ), admin_url( 'admin.php' ) ), 'bookflow_delete_event_' . $item->id );

		$actions = array(
			'edit'      => sprintf( '<a href="%s">%s</a>', esc_url( $edit_url ), esc_html__( 'Edit', 'bookflow-booking-scheduling' ) ),
			'attendees' => sprintf( '<a href="%s">%s</a>', esc_url( $attendees_url ), esc_html__( 'Attendees', 'bookflow-booking-scheduling' ) ),
			'delete'    => sprintf(
				'<a href="%s" onclick="return confirm(%s);">%s</a>',
				esc_url( $delete_url ),
				esc_attr( wp_json_encode( __( 'Delete this event? Registrations will also be removed. This cannot be undone.', 'bookflow-booking-scheduling' ) ) ),
				esc_html__( 'Delete', 'bookflow-booking-scheduling' )
			),
		);

		return sprintf( '<strong><a href="%s">%s</a></strong>%s', esc_url( $edit_url ), esc_html( $item->title ), $this->row_actions( $actions ) );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Event  $item        Row data.
	 * @param string $column_name Column key.
	 */
	public function column_default( $item, $column_name ): string {
		switch ( $column_name ) {
			case 'when':
				return esc_html( $item->start->setTimezone( wp_timezone() )->format( 'Y-m-d H:i' ) );

			case 'capacity':
				if ( null === $item->capacity ) {
					return esc_html__( 'Unlimited', 'bookflow-booking-scheduling' );
				}
				$taken = Event_Attendee_Repository::confirmed_seat_count( $item->id );
				return esc_html( sprintf( '%d / %d', $taken, $item->capacity ) );

			case 'status':
				return sprintf( '<span class="bookflow-status bookflow-status--%1$s">%2$s</span>', esc_attr( $item->status ), esc_html( ucfirst( $item->status ) ) );

			default:
				return '';
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public function no_items(): void {
		esc_html_e( 'No events yet. Create one to start taking registrations.', 'bookflow-booking-scheduling' );
	}
}

<?php
/**
 * Settings screen. Grows incrementally alongside the phases that actually implement each
 * feature — see docs/ROADMAP.md. Phase 4 added General/Business hours/Privacy; Phase 6 adds a
 * "Custom Fields" tab (Section 2's "basic custom booking fields"), kept here rather than as its
 * own top-level menu item since it's a small, secondary configuration surface, not something an
 * admin visits often (Section 23: "Do not expose dozens of settings unnecessarily").
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\CustomFields\Custom_Field;
use BookFlow\CustomFields\Custom_Field_Repository;
use BookFlow\Notifications\Settings as Notification_Settings;
use BookFlow\Scheduling\Scheduling_Page_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Support\Constants;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Settings_Page
 */
final class Settings_Page {

	/**
	 * Option storing general settings.
	 *
	 * @var string
	 */
	private const OPTION_GENERAL = 'bookflow_settings_general';

	/**
	 * @var Validation_Exception|null
	 */
	private static ?Validation_Exception $error = null;

	/**
	 * @var array<string, mixed>
	 */
	private static array $submitted = array();

	/**
	 * Process the settings form.
	 */
	public static function handle_request(): void {
		if ( ! self::is_current_screen() ) {
			return;
		}

		if ( isset( $_GET['bookflow_action'], $_GET['id'] ) && 'delete_custom_field' === $_GET['bookflow_action'] ) {
			self::handle_delete_custom_field( absint( $_GET['id'] ) );
			return;
		}

		if ( ! isset( $_POST['bookflow_action'] ) ) {
			return;
		}

		switch ( $_POST['bookflow_action'] ) {
			case 'save_settings':
				self::handle_save_settings();
				break;
			case 'save_custom_field':
				self::handle_save_custom_field();
				break;
			case 'save_notifications':
				self::handle_save_notifications();
				break;
		}
	}

	/**
	 * Handle the Notifications tab's form.
	 */
	private static function handle_save_notifications(): void {
		Form_Guard::verify( 'bookflow_save_notifications' );

		$settings = array();

		foreach ( array_keys( Notification_Settings::types() ) as $type ) {
			$settings[ $type ] = ! empty( $_POST['notify'][ $type ] );
		}

		$admin_email = isset( $_POST['admin_email'] ) ? sanitize_email( wp_unslash( $_POST['admin_email'] ) ) : '';
		$settings['admin_email'] = ( '' !== $admin_email && is_email( $admin_email ) ) ? $admin_email : '';

		update_option( Notification_Settings::OPTION, $settings );

		Notices::add( __( 'Notification settings saved.', 'bookflow-booking-scheduling' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-settings&tab=notifications' ) );
		exit;
	}

	/**
	 * Handle the General/Business hours/Privacy tab's form.
	 */
	private static function handle_save_settings(): void {
		Form_Guard::verify( 'bookflow_save_settings' );

		update_option(
			self::OPTION_GENERAL,
			array(
				'business_name' => isset( $_POST['business_name'] ) ? sanitize_text_field( wp_unslash( $_POST['business_name'] ) ) : '',
			)
		);

		update_option( Constants::OPTION_REMOVE_DATA_ON_UNINSTALL, ! empty( $_POST['remove_data_on_uninstall'] ) ? '1' : '' );

		try {
			Weekly_Hours_Field::save_from_request( 'business', null );
			Notices::add( __( 'Settings saved.', 'bookflow-booking-scheduling' ) );
		} catch ( Validation_Exception $e ) {
			Notices::add( implode( ' ', $e->errors() ), 'error' );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-settings' ) );
		exit;
	}

	/**
	 * Handle the Custom Fields tab's add/edit form.
	 */
	private static function handle_save_custom_field(): void {
		Form_Guard::verify( 'bookflow_save_custom_field' );

		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

		$input = array(
			'context'     => isset( $_POST['context'] ) ? sanitize_key( $_POST['context'] ) : 'appointment',
			'label'       => isset( $_POST['label'] ) ? wp_unslash( $_POST['label'] ) : '',
			'field_key'   => isset( $_POST['field_key'] ) ? wp_unslash( $_POST['field_key'] ) : '',
			'field_type'  => isset( $_POST['field_type'] ) ? sanitize_key( $_POST['field_type'] ) : 'text',
			'options'     => isset( $_POST['options'] ) ? wp_unslash( $_POST['options'] ) : '',
			'is_required' => ! empty( $_POST['is_required'] ),
			'sort_order'  => isset( $_POST['sort_order'] ) ? (int) $_POST['sort_order'] : 0,
			'scope_id'    => isset( $_POST['scope_id'] ) && '' !== $_POST['scope_id'] ? absint( $_POST['scope_id'] ) : null,
		);

		try {
			if ( $id > 0 ) {
				Custom_Field_Repository::update( $id, $input );
			} else {
				Custom_Field_Repository::create( $input );
			}

			Notices::add( __( 'Question saved.', 'bookflow-booking-scheduling' ) );
			wp_safe_redirect( admin_url( 'admin.php?page=bookflow-settings&tab=custom_fields' ) );
			exit;
		} catch ( Validation_Exception $e ) {
			self::$error     = $e;
			self::$submitted = wp_unslash( $_POST );
		}
	}

	/**
	 * Handle a custom field delete link.
	 */
	private static function handle_delete_custom_field( int $id ): void {
		Form_Guard::verify( 'bookflow_delete_custom_field_' . $id );

		Custom_Field_Repository::delete( $id );

		Notices::add( __( 'Question deleted.', 'bookflow-booking-scheduling' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=bookflow-settings&tab=custom_fields' ) );
		exit;
	}

	/**
	 * Render the screen.
	 */
	public static function render(): void {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		/**
		 * Filters the Settings screen's tabs — the extension point for Premium's own settings
		 * (e.g. an "Integrations" tab for calendar sync / payment gateway configuration) to
		 * appear inside BookFlow's existing Settings screen rather than a separate admin page.
		 * Keyed by tab slug (used in `?tab=<slug>` and to pick the active nav-tab); each value
		 * is `array{label: string, render: callable}` — `render` takes no arguments and echoes
		 * the tab's markup, same as the three built-in tabs below. See docs/ARCHITECTURE.md §24.
		 *
		 * @param array<string, array{label: string, render: callable}> $tabs
		 */
		$tabs = apply_filters(
			'bookflow_settings_tabs',
			array(
				'general'       => array(
					'label'  => __( 'General', 'bookflow-booking-scheduling' ),
					'render' => array( self::class, 'render_general_tab' ),
				),
				'custom_fields' => array(
					'label'  => __( 'Custom Fields', 'bookflow-booking-scheduling' ),
					'render' => array( self::class, 'render_custom_fields_tab' ),
				),
				'notifications' => array(
					'label'  => __( 'Notifications', 'bookflow-booking-scheduling' ),
					'render' => array( self::class, 'render_notifications_tab' ),
				),
			)
		);

		// A stale/foreign ?tab= value (Premium deactivated after linking to its own tab, or a
		// hand-edited URL) falls back to General rather than rendering nothing.
		if ( ! isset( $tabs[ $tab ] ) || ! is_callable( $tabs[ $tab ]['render'] ?? null ) ) {
			$tab = 'general';
		}

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php esc_html_e( 'Settings', 'bookflow-booking-scheduling' ); ?></h1>

			<h2 class="nav-tab-wrapper">
				<?php foreach ( $tabs as $tab_key => $tab_data ) : ?>
					<a href="<?php echo esc_url( 'general' === $tab_key ? admin_url( 'admin.php?page=bookflow-settings' ) : admin_url( 'admin.php?page=bookflow-settings&tab=' . $tab_key ) ); ?>" class="nav-tab <?php echo $tab_key === $tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html( $tab_data['label'] ); ?></a>
				<?php endforeach; ?>
			</h2>

			<?php call_user_func( $tabs[ $tab ]['render'] ); ?>
		</div>
		<?php
	}

	/**
	 * Render the General/Business hours/Privacy tab.
	 */
	private static function render_general_tab(): void {
		$general       = get_option( self::OPTION_GENERAL, array() );
		$business_name = is_array( $general ) ? ( $general['business_name'] ?? '' ) : '';
		$remove_data   = '1' === get_option( Constants::OPTION_REMOVE_DATA_ON_UNINSTALL, '' );

		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-settings' ) ); ?>" class="bookflow-form">
			<?php wp_nonce_field( 'bookflow_save_settings' ); ?>
			<input type="hidden" name="bookflow_action" value="save_settings" />

			<h2><?php esc_html_e( 'General', 'bookflow-booking-scheduling' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><label for="bf-business-name"><?php esc_html_e( 'Business name', 'bookflow-booking-scheduling' ); ?></label></th>
					<td><input type="text" id="bf-business-name" name="business_name" class="regular-text" value="<?php echo esc_attr( $business_name ); ?>" /></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Site timezone', 'bookflow-booking-scheduling' ); ?></th>
					<td>
						<p>
							<?php
							printf(
								/* translators: 1: WordPress site timezone name, 2: URL to WordPress General Settings. */
								wp_kses(
									__( 'BookFlow uses your WordPress site timezone (currently <strong>%1$s</strong>) as the default. Change it under <a href="%2$s">Settings → General</a>.', 'bookflow-booking-scheduling' ),
									array(
										'strong' => array(),
										'a'      => array( 'href' => array() ),
									)
								),
								esc_html( wp_timezone_string() ),
								esc_url( admin_url( 'options-general.php' ) )
							);
							?>
						</p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Business hours', 'bookflow-booking-scheduling' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Default hours used whenever a staff member or location does not have its own schedule.', 'bookflow-booking-scheduling' ); ?></p>
			<?php Weekly_Hours_Field::render( 'business', null ); ?>

			<h2><?php esc_html_e( 'Privacy', 'bookflow-booking-scheduling' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><?php esc_html_e( 'Uninstall', 'bookflow-booking-scheduling' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="remove_data_on_uninstall" value="1" <?php checked( $remove_data ); ?> />
							<?php esc_html_e( 'Remove all BookFlow data (bookings, customers, services, staff, locations, settings) when the plugin is deleted.', 'bookflow-booking-scheduling' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Off by default — deactivating or deleting BookFlow never touches your data unless you enable this first.', 'bookflow-booking-scheduling' ); ?></p>
					</td>
				</tr>
			</table>

			<?php submit_button( __( 'Save Settings', 'bookflow-booking-scheduling' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Render the Notifications tab: per-type enable/disable toggles + admin notification email.
	 */
	private static function render_notifications_tab(): void {
		$settings = Notification_Settings::all();

		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-settings&tab=notifications' ) ); ?>" class="bookflow-form">
			<?php wp_nonce_field( 'bookflow_save_notifications' ); ?>
			<input type="hidden" name="bookflow_action" value="save_notifications" />

			<h2><?php esc_html_e( 'Email notifications', 'bookflow-booking-scheduling' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Sent using your WordPress site’s own email delivery (wp_mail) — no third-party email service required.', 'bookflow-booking-scheduling' ); ?></p>
			<table class="form-table" role="presentation">
				<?php foreach ( Notification_Settings::types() as $type => $label ) : ?>
					<tr>
						<th><?php echo esc_html( $label ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="notify[<?php echo esc_attr( $type ); ?>]" value="1" <?php checked( Notification_Settings::is_enabled( $type ) ); ?> />
								<?php esc_html_e( 'Enabled', 'bookflow-booking-scheduling' ); ?>
							</label>
						</td>
					</tr>
				<?php endforeach; ?>
				<tr>
					<th><label for="bf-notify-admin-email"><?php esc_html_e( 'Admin notification email', 'bookflow-booking-scheduling' ); ?></label></th>
					<td>
						<input type="email" id="bf-notify-admin-email" name="admin_email" class="regular-text" placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" value="<?php echo esc_attr( (string) ( $settings['admin_email'] ?? '' ) ); ?>" />
						<p class="description"><?php esc_html_e( 'Leave blank to use your WordPress admin email.', 'bookflow-booking-scheduling' ); ?></p>
					</td>
				</tr>
			</table>

			<?php submit_button( __( 'Save Notification Settings', 'bookflow-booking-scheduling' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Render the Custom Fields tab: list + add/edit form.
	 */
	private static function render_custom_fields_tab(): void {
		$editing_id = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$editing    = ( $editing_id > 0 && empty( self::$submitted ) ) ? Custom_Field_Repository::find( $editing_id ) : null;

		if ( $editing_id > 0 && null === $editing && empty( self::$submitted ) ) {
			$editing_id = 0;
		}

		?>
		<p class="description"><?php esc_html_e( 'Extra questions shown on the booking form. "Appointment" questions apply to plain service bookings; "Scheduling page" questions apply to bookings made through a scheduling page. Leave "Applies to" blank for a question to apply everywhere in its context, or enter a specific service/page ID to scope it to just that one.', 'bookflow-booking-scheduling' ); ?></p>

		<?php self::render_custom_fields_list(); ?>

		<h2><?php echo $editing ? esc_html__( 'Edit Question', 'bookflow-booking-scheduling' ) : esc_html__( 'Add Question', 'bookflow-booking-scheduling' ); ?></h2>

		<?php if ( self::$error ) : ?>
			<div class="notice notice-error"><p><?php echo esc_html( implode( ' ', self::$error->errors() ) ); ?></p></div>
		<?php endif; ?>

		<?php self::render_custom_field_form( $editing ); ?>
		<?php
	}

	/**
	 * The Custom Fields list.
	 */
	private static function render_custom_fields_list(): void {
		$fields = Custom_Field_Repository::all();

		if ( empty( $fields ) ) {
			return;
		}

		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Label', 'bookflow-booking-scheduling' ); ?></th>
					<th><?php esc_html_e( 'Context', 'bookflow-booking-scheduling' ); ?></th>
					<th><?php esc_html_e( 'Type', 'bookflow-booking-scheduling' ); ?></th>
					<th><?php esc_html_e( 'Applies to', 'bookflow-booking-scheduling' ); ?></th>
					<th><?php esc_html_e( 'Required', 'bookflow-booking-scheduling' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $fields as $field ) : ?>
					<?php
					$edit_url   = admin_url( 'admin.php?page=bookflow-settings&tab=custom_fields&edit=' . $field->id );
					$delete_url = wp_nonce_url( admin_url( 'admin.php?page=bookflow-settings&tab=custom_fields&bookflow_action=delete_custom_field&id=' . $field->id ), 'bookflow_delete_custom_field_' . $field->id );
					?>
					<tr>
						<td><a href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( $field->label ); ?></a></td>
						<td><?php echo esc_html( ucwords( str_replace( '_', ' ', $field->context ) ) ); ?></td>
						<td><?php echo esc_html( ucfirst( $field->field_type ) ); ?></td>
						<td><?php echo esc_html( self::scope_label( $field ) ); ?></td>
						<td><?php echo $field->is_required ? esc_html__( 'Yes', 'bookflow-booking-scheduling' ) : esc_html__( 'No', 'bookflow-booking-scheduling' ); ?></td>
						<td>
							<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'bookflow-booking-scheduling' ); ?></a> |
							<a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm(<?php echo esc_attr( wp_json_encode( __( 'Delete this question?', 'bookflow-booking-scheduling' ) ) ); ?>);"><?php esc_html_e( 'Delete', 'bookflow-booking-scheduling' ); ?></a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Human-readable "applies to" label for a custom field's scope_id.
	 */
	private static function scope_label( Custom_Field $field ): string {
		if ( null === $field->scope_id ) {
			return __( 'Everywhere', 'bookflow-booking-scheduling' );
		}

		if ( 'scheduling_page' === $field->context ) {
			$page = Scheduling_Page_Repository::find( $field->scope_id );
			return $page ? $page->title : sprintf( '#%d', $field->scope_id );
		}

		$service = Service_Repository::find( $field->scope_id );

		return $service ? $service->name : sprintf( '#%d', $field->scope_id );
	}

	/**
	 * The Custom Fields add/edit form.
	 */
	private static function render_custom_field_form( ?Custom_Field $editing ): void {
		$values = self::custom_field_form_values( $editing );

		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-settings&tab=custom_fields' ) ); ?>" class="bookflow-form">
			<?php wp_nonce_field( 'bookflow_save_custom_field' ); ?>
			<input type="hidden" name="bookflow_action" value="save_custom_field" />
			<input type="hidden" name="id" value="<?php echo esc_attr( (string) ( $editing ? $editing->id : 0 ) ); ?>" />

			<table class="form-table" role="presentation">
				<tr>
					<th><label for="bf-cf-label"><?php esc_html_e( 'Question label', 'bookflow-booking-scheduling' ); ?></label></th>
					<td><input type="text" id="bf-cf-label" name="label" class="regular-text" required value="<?php echo esc_attr( $values['label'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="bf-cf-context"><?php esc_html_e( 'Context', 'bookflow-booking-scheduling' ); ?></label></th>
					<td>
						<select id="bf-cf-context" name="context">
							<?php foreach ( Custom_Field::contexts() as $context ) : ?>
								<option value="<?php echo esc_attr( $context ); ?>" <?php selected( $values['context'], $context ); ?>><?php echo esc_html( ucwords( str_replace( '_', ' ', $context ) ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th><label for="bf-cf-type"><?php esc_html_e( 'Field type', 'bookflow-booking-scheduling' ); ?></label></th>
					<td>
						<select id="bf-cf-type" name="field_type">
							<?php foreach ( Custom_Field::field_types() as $type ) : ?>
								<option value="<?php echo esc_attr( $type ); ?>" <?php selected( $values['field_type'], $type ); ?>><?php echo esc_html( ucfirst( $type ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th><label for="bf-cf-options"><?php esc_html_e( 'Options (one per line — Select/Radio only)', 'bookflow-booking-scheduling' ); ?></label></th>
					<td><textarea id="bf-cf-options" name="options" rows="4" class="large-text"><?php echo esc_textarea( $values['options'] ); ?></textarea></td>
				</tr>
				<tr>
					<th><label for="bf-cf-scope"><?php esc_html_e( 'Applies to (service or page ID, blank = everywhere)', 'bookflow-booking-scheduling' ); ?></label></th>
					<td><input type="number" min="1" id="bf-cf-scope" name="scope_id" value="<?php echo esc_attr( (string) $values['scope_id'] ); ?>" style="width:100px" /></td>
				</tr>
				<tr>
					<th><label for="bf-cf-sort"><?php esc_html_e( 'Sort order', 'bookflow-booking-scheduling' ); ?></label></th>
					<td><input type="number" id="bf-cf-sort" name="sort_order" value="<?php echo esc_attr( (string) $values['sort_order'] ); ?>" style="width:80px" /></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Required', 'bookflow-booking-scheduling' ); ?></th>
					<td><label><input type="checkbox" name="is_required" value="1" <?php checked( $values['is_required'] ); ?> /> <?php esc_html_e( 'Customers must answer this question', 'bookflow-booking-scheduling' ); ?></label></td>
				</tr>
			</table>

			<?php submit_button( $editing ? __( 'Update Question', 'bookflow-booking-scheduling' ) : __( 'Add Question', 'bookflow-booking-scheduling' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Resolve display values for the custom field form.
	 *
	 * @return array<string, mixed>
	 */
	private static function custom_field_form_values( ?Custom_Field $editing ): array {
		if ( ! empty( self::$submitted ) ) {
			$post = self::$submitted;

			return array(
				'label'       => $post['label'] ?? '',
				'context'     => $post['context'] ?? 'appointment',
				'field_type'  => $post['field_type'] ?? 'text',
				'options'     => $post['options'] ?? '',
				'scope_id'    => $post['scope_id'] ?? '',
				'sort_order'  => (int) ( $post['sort_order'] ?? 0 ),
				'is_required' => ! empty( $post['is_required'] ),
			);
		}

		if ( $editing ) {
			return array(
				'label'       => $editing->label,
				'context'     => $editing->context,
				'field_type'  => $editing->field_type,
				'options'     => implode( "\n", $editing->options ),
				'scope_id'    => $editing->scope_id ?? '',
				'sort_order'  => $editing->sort_order,
				'is_required' => $editing->is_required,
			);
		}

		return array(
			'label'       => '',
			'context'     => 'appointment',
			'field_type'  => 'text',
			'options'     => '',
			'scope_id'    => '',
			'sort_order'  => 0,
			'is_required' => false,
		);
	}

	/**
	 * Whether the current admin request targets this screen.
	 */
	private static function is_current_screen(): bool {
		return isset( $_GET['page'] ) && 'bookflow-settings' === $_GET['page']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}
}

<?php
/**
 * Overview dashboard. Phase 4 scope: the counts and quick actions a returning admin actually
 * needs (Section 19), not yet the onboarding-aware "setup completion" version — that lands with
 * the onboarding wizard (Phase 10), which will extend this page rather than replace it.
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Booking\Appointment;
use BookFlow\Booking\Appointment_Repository;
use BookFlow\Locations\Location_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Overview_Page
 */
final class Overview_Page {

	/**
	 * Render the screen.
	 */
	public static function render(): void {
		$site_timezone = wp_timezone();
		$now_local     = new \DateTimeImmutable( 'now', $site_timezone );

		$today_start_utc = $now_local->setTime( 0, 0 )->setTimezone( new \DateTimeZone( 'UTC' ) );
		$today_end_utc   = $now_local->setTime( 23, 59, 59 )->setTimezone( new \DateTimeZone( 'UTC' ) );
		$week_end_utc    = $now_local->modify( '+7 days' )->setTimezone( new \DateTimeZone( 'UTC' ) );

		$today_count    = Appointment_Repository::count(
			array(
				'date_from' => $today_start_utc->format( 'Y-m-d H:i:s' ),
				'date_to'   => $today_end_utc->format( 'Y-m-d H:i:s' ),
			)
		);
		$upcoming_count = Appointment_Repository::count(
			array(
				'date_from' => $today_start_utc->format( 'Y-m-d H:i:s' ),
				'date_to'   => $week_end_utc->format( 'Y-m-d H:i:s' ),
			)
		);
		$pending_count  = Appointment_Repository::count( array( 'status' => 'pending' ) );

		$has_services  = ! empty( Service_Repository::all( array( 'limit' => 1 ) ) );
		$has_staff     = ! empty( Staff_Repository::all() );
		$has_locations = ! empty( Location_Repository::all() );

		?>
		<div class="wrap bookflow-wrap">
			<h1><?php esc_html_e( 'Overview', 'bookflow-booking-scheduling' ); ?></h1>

			<?php if ( '1' !== get_option( 'bookflow_onboarding_completed', '' ) ) : ?>
				<div class="notice notice-info">
					<p>
						<?php esc_html_e( 'Finish setting up BookFlow — it only takes a few minutes and gets you a working booking page.', 'bookflow-booking-scheduling' ); ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-onboarding' ) ); ?>"><?php esc_html_e( 'Resume setup', 'bookflow-booking-scheduling' ); ?></a>
					</p>
				</div>
			<?php elseif ( ! $has_services || ! $has_staff ) : ?>
				<div class="notice notice-info">
					<p>
						<?php esc_html_e( 'Add at least one service and staff member to start accepting bookings.', 'bookflow-booking-scheduling' ); ?>
					</p>
				</div>
			<?php endif; ?>

			<div class="bookflow-cards">
				<div class="bookflow-card">
					<span class="bookflow-card__value"><?php echo esc_html( (string) $today_count ); ?></span>
					<span class="bookflow-card__label"><?php esc_html_e( "Today's bookings", 'bookflow-booking-scheduling' ); ?></span>
				</div>
				<div class="bookflow-card">
					<span class="bookflow-card__value"><?php echo esc_html( (string) $upcoming_count ); ?></span>
					<span class="bookflow-card__label"><?php esc_html_e( 'Next 7 days', 'bookflow-booking-scheduling' ); ?></span>
				</div>
				<div class="bookflow-card">
					<span class="bookflow-card__value"><?php echo esc_html( (string) $pending_count ); ?></span>
					<span class="bookflow-card__label"><?php esc_html_e( 'Pending approval', 'bookflow-booking-scheduling' ); ?></span>
				</div>
			</div>

			<h2><?php esc_html_e( 'Quick actions', 'bookflow-booking-scheduling' ); ?></h2>
			<p class="bookflow-quick-actions">
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-bookings&action=add' ) ); ?>"><?php esc_html_e( 'Add Booking', 'bookflow-booking-scheduling' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-services&action=add' ) ); ?>"><?php esc_html_e( 'Add Service', 'bookflow-booking-scheduling' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-staff&action=add' ) ); ?>"><?php esc_html_e( 'Add Staff', 'bookflow-booking-scheduling' ); ?></a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-locations&action=add' ) ); ?>"><?php esc_html_e( 'Add Location', 'bookflow-booking-scheduling' ); ?></a>
			</p>

			<?php self::render_todays_bookings( $today_start_utc, $today_end_utc, $site_timezone ); ?>
		</div>
		<?php
	}

	/**
	 * A short list of today's active bookings.
	 */
	private static function render_todays_bookings( \DateTimeImmutable $today_start_utc, \DateTimeImmutable $today_end_utc, \DateTimeZone $site_timezone ): void {
		$appointments = Appointment_Repository::all(
			array(
				'date_from' => $today_start_utc->format( 'Y-m-d H:i:s' ),
				'date_to'   => $today_end_utc->format( 'Y-m-d H:i:s' ),
				'orderby'   => 'start_datetime_utc',
				'order'     => 'asc',
				'limit'     => 20,
			)
		);

		$appointments = array_values( array_filter( $appointments, static fn( Appointment $a ) => $a->is_active() ) );

		?>
		<h2><?php esc_html_e( "Today's bookings", 'bookflow-booking-scheduling' ); ?></h2>
		<?php if ( empty( $appointments ) ) : ?>
			<p><?php esc_html_e( 'Nothing booked for today.', 'bookflow-booking-scheduling' ); ?></p>
		<?php else : ?>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Time', 'bookflow-booking-scheduling' ); ?></th>
						<th><?php esc_html_e( 'Reference', 'bookflow-booking-scheduling' ); ?></th>
						<th><?php esc_html_e( 'Status', 'bookflow-booking-scheduling' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $appointments as $appointment ) : ?>
						<tr>
							<td><?php echo esc_html( $appointment->start->setTimezone( $site_timezone )->format( 'H:i' ) ); ?></td>
							<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=bookflow-bookings&action=view&id=' . $appointment->id ) ); ?>"><?php echo esc_html( $appointment->booking_reference ); ?></a></td>
							<td><span class="bookflow-status bookflow-status--<?php echo esc_attr( $appointment->status ); ?>"><?php echo esc_html( ucfirst( str_replace( '_', '-', $appointment->status ) ) ); ?></span></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<?php
	}
}

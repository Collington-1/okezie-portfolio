<?php
/**
 * Scheduling pages list table. Not paginated server-side — see Services_List_Table's docblock
 * for why (reference data, not high-volume transactional records).
 *
 * @package BookFlow\Admin
 */

declare( strict_types = 1 );

namespace BookFlow\Admin;

use BookFlow\Scheduling\Scheduling_Page;
use BookFlow\Scheduling\Scheduling_Page_Repository;
use BookFlow\Scheduling\Bootstrap as Scheduling_Bootstrap;
use BookFlow\Staff\Staff_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Class Scheduling_Pages_List_Table
 */
final class Scheduling_Pages_List_Table extends \WP_List_Table {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'scheduling_page',
				'plural'   => 'scheduling_pages',
				'ajax'     => false,
			)
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_columns(): array {
		return array(
			'title'  => __( 'Title', 'bookflow-booking-scheduling' ),
			'staff'  => __( 'Staff', 'bookflow-booking-scheduling' ),
			'url'    => __( 'Public URL', 'bookflow-booking-scheduling' ),
			'layout' => __( 'Layout', 'bookflow-booking-scheduling' ),
			'status' => __( 'Status', 'bookflow-booking-scheduling' ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function prepare_items(): void {
		$this->_column_headers = array( $this->get_columns(), array(), array() );

		$args = array();

		if ( ! empty( $_GET['s'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filtering.
			$args['search'] = sanitize_text_field( wp_unslash( $_GET['s'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		if ( ! empty( $_GET['status'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$args['status'] = sanitize_key( $_GET['status'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		}

		$this->items = Scheduling_Page_Repository::all( $args );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Scheduling_Page $item Row data.
	 */
	public function column_title( $item ): string {
		$edit_url   = add_query_arg( array( 'page' => 'bookflow-scheduling', 'action' => 'edit', 'id' => $item->id ), admin_url( 'admin.php' ) );
		$delete_url = wp_nonce_url( add_query_arg( array( 'page' => 'bookflow-scheduling', 'bookflow_action' => 'delete', 'id' => $item->id ), admin_url( 'admin.php' ) ), 'bookflow_delete_scheduling_page_' . $item->id );

		$actions = array(
			'edit'   => sprintf( '<a href="%s">%s</a>', esc_url( $edit_url ), esc_html__( 'Edit', 'bookflow-booking-scheduling' ) ),
			'view'   => sprintf( '<a href="%s" target="_blank" rel="noopener">%s</a>', esc_url( Scheduling_Bootstrap::public_url( $item ) ), esc_html__( 'View', 'bookflow-booking-scheduling' ) ),
			'delete' => sprintf(
				'<a href="%s" onclick="return confirm(%s);">%s</a>',
				esc_url( $delete_url ),
				esc_attr( wp_json_encode( __( 'Delete this scheduling page? This cannot be undone.', 'bookflow-booking-scheduling' ) ) ),
				esc_html__( 'Delete', 'bookflow-booking-scheduling' )
			),
		);

		return sprintf( '<strong><a href="%s">%s</a></strong>%s', esc_url( $edit_url ), esc_html( $item->title ), $this->row_actions( $actions ) );
	}

	/**
	 * {@inheritDoc}
	 *
	 * @param Scheduling_Page $item        Row data.
	 * @param string          $column_name Column key.
	 */
	public function column_default( $item, $column_name ): string {
		switch ( $column_name ) {
			case 'staff':
				if ( ! $item->staff_id ) {
					return '&#8212;';
				}
				$staff = Staff_Repository::find( $item->staff_id );
				return $staff ? esc_html( $staff->display_name ) : '&#8212;';

			case 'url':
				return sprintf( '<code>%s</code>', esc_html( Scheduling_Bootstrap::public_url( $item ) ) );

			case 'layout':
				return esc_html( ucwords( str_replace( '_', ' ', $item->layout ) ) );

			case 'status':
				return sprintf( '<span class="bookflow-status bookflow-status--%1$s">%2$s</span>', esc_attr( $item->status ), esc_html( ucfirst( $item->status ) ) );

			default:
				return '';
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public function no_items(): void {
		esc_html_e( 'No scheduling pages yet. Create one to share a bookable link.', 'bookflow-booking-scheduling' );
	}
}

<?php
/**
 * Generic many-to-many pivot table helper, shared by staff_services, staff_locations, and
 * service_locations — all three share the identical (id, <left>_id, <right>_id, created_at)
 * shape, so one small "replace the full set of associations" implementation covers all of them
 * instead of three near-duplicate ones. See docs/DATABASE-SCHEMA.md.
 *
 * @package BookFlow\Database
 */

declare( strict_types = 1 );

namespace BookFlow\Database;

use BookFlow\Support\Timestamps;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Pivot_Table
 */
final class Pivot_Table {

	/**
	 * Replace the full set of associations for one "left" row with exactly the given "right"
	 * IDs — deletes associations no longer present, inserts new ones, leaves unchanged ones
	 * alone. All column/table names are trusted constants supplied by call sites in this
	 * codebase, never user input.
	 *
	 * @param string            $table         Fully-prefixed pivot table name.
	 * @param string            $left_column   Column naming the "owning" side, e.g. 'staff_id'.
	 * @param string            $right_column  Column naming the associated side, e.g. 'service_id'.
	 * @param int               $left_id       ID of the owning row.
	 * @param array<int, int>   $right_ids     Full desired set of associated IDs.
	 */
	public static function sync( string $table, string $left_column, string $right_column, int $left_id, array $right_ids ): void {
		global $wpdb;

		$right_ids = array_values( array_unique( array_map( 'intval', $right_ids ) ) );

		$existing = self::right_ids_for( $table, $left_column, $right_column, $left_id );

		foreach ( array_diff( $existing, $right_ids ) as $stale_id ) {
			$wpdb->delete(
				$table,
				array(
					$left_column  => $left_id,
					$right_column => $stale_id,
				),
				array( '%d', '%d' )
			);
		}

		foreach ( array_diff( $right_ids, $existing ) as $new_id ) {
			$wpdb->insert(
				$table,
				array(
					$left_column  => $left_id,
					$right_column => $new_id,
					'created_at'  => Timestamps::now(),
				),
				array( '%d', '%d', '%s' )
			);
		}
	}

	/**
	 * All "right" IDs currently associated with one "left" ID.
	 *
	 * @param string $table        Fully-prefixed pivot table name.
	 * @param string $left_column  Column naming the "owning" side.
	 * @param string $right_column Column naming the associated side.
	 * @param int    $left_id      ID of the owning row.
	 * @return array<int, int>
	 */
	public static function right_ids_for( string $table, string $left_column, string $right_column, int $left_id ): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table/column names are trusted constants, not user input.
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT {$right_column} FROM {$table} WHERE {$left_column} = %d ORDER BY id ASC", $left_id ) );

		return array_map( 'intval', $ids );
	}

	/**
	 * All "left" IDs currently associated with one "right" ID — the reverse lookup, e.g. "which
	 * staff offer this service" from the service's point of view.
	 *
	 * @param string $table        Fully-prefixed pivot table name.
	 * @param string $left_column  Column naming the "owning" side.
	 * @param string $right_column Column naming the associated side.
	 * @param int    $right_id     ID of the associated row.
	 * @return array<int, int>
	 */
	public static function left_ids_for( string $table, string $left_column, string $right_column, int $right_id ): array {
		global $wpdb;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table/column names are trusted constants, not user input.
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT {$left_column} FROM {$table} WHERE {$right_column} = %d ORDER BY id ASC", $right_id ) );

		return array_map( 'intval', $ids );
	}

	/**
	 * Remove every association involving one ID on either side. Used when the owning entity
	 * itself is being deleted, to avoid leaving orphaned pivot rows.
	 *
	 * @param string $table  Fully-prefixed pivot table name.
	 * @param string $column Column to match ('staff_id', 'service_id', or 'location_id').
	 * @param int    $id     ID to remove.
	 */
	public static function delete_all_for( string $table, string $column, int $id ): void {
		global $wpdb;

		$wpdb->delete( $table, array( $column => $id ), array( '%d' ) );
	}
}

<?php
/**
 * Applies and version-tracks the database schema.
 *
 * @package BookFlow\Database
 */

declare( strict_types = 1 );

namespace BookFlow\Database;

use BookFlow\Support\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Migrator
 */
final class Migrator {

	/**
	 * Run every registered CREATE TABLE statement through dbDelta() and record the schema
	 * version. Safe to call multiple times (dbDelta itself is idempotent, and this method is
	 * called from both activation and the upgrade check).
	 */
	public static function install(): void {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		foreach ( Schema::statements() as $statement ) {
			// dbDelta() is sensitive to formatting (two spaces before PRIMARY KEY, one keyword
			// per line, etc.) — Schema::statements() follows that convention deliberately.
			dbDelta( $statement );
		}

		update_option( Constants::OPTION_DB_VERSION, Constants::DB_VERSION, false );
	}

	/**
	 * Compare the stored schema version against the current one and re-run installation (plus
	 * any registered data migrations) if the site is behind. Cheap no-op when already current.
	 */
	public static function maybe_upgrade(): void {
		$installed = get_option( Constants::OPTION_DB_VERSION, '' );

		if ( Constants::DB_VERSION === $installed ) {
			return;
		}

		self::install();

		/**
		 * Fires after the database schema has been (re)installed/upgraded to the current
		 * version. Data-transformation migrations (Migrations\Migration_x_y_z) should hook
		 * here rather than running inline, so they only ever run once per version bump and are
		 * easy to audit.
		 *
		 * @param string $previous_version Previously installed schema version, or '' if none.
		 * @param string $current_version  Newly installed schema version.
		 */
		do_action( 'bookflow_db_upgraded', $installed, Constants::DB_VERSION );
	}

	/**
	 * Drop every BookFlow table. Only ever called from uninstall.php, and only when the site
	 * owner has explicitly opted in to data removal.
	 */
	public static function drop_all_tables(): void {
		global $wpdb;

		// Reverse-ish order so pivot/child tables go first; harmless either way since there are
		// no DB-level foreign keys, but keeps intent readable.
		$tables = array(
			'audit_log',
			'notification_log',
			'custom_fields',
			'availability_exceptions',
			'availability_rules',
			'scheduling_page_services',
			'scheduling_pages',
			'event_attendees',
			'events',
			'appointment_participants',
			'appointments',
			'customers',
			'service_locations',
			'staff_locations',
			'locations',
			'staff_services',
			'staff',
			'services',
			'service_categories',
		);

		foreach ( $tables as $key ) {
			$table = Schema::table( $key );
			$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name only, not user input.
		}
	}
}

<?php
/**
 * Shared write helper for wp_bookflow_audit_log. Deliberately not a full repository (no
 * find/update — audit rows are append-only and never edited).
 *
 * @package BookFlow\Database
 */

declare( strict_types = 1 );

namespace BookFlow\Database;

use BookFlow\Support\Timestamps;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Audit_Logger
 */
final class Audit_Logger {

	/**
	 * Record an audit log entry.
	 *
	 * @param string     $object_type Object type, e.g. 'appointment'.
	 * @param int        $object_id   Object ID.
	 * @param string     $action      Action taken, e.g. 'status_changed'.
	 * @param int|null   $user_id     Acting user ID, or null for system/unauthenticated actions.
	 * @param mixed      $old_value   Previous value — scalars/strings stored as-is, arrays/objects JSON-encoded.
	 * @param mixed      $new_value   New value — same encoding rule as $old_value.
	 */
	public static function log( string $object_type, int $object_id, string $action, ?int $user_id, $old_value, $new_value ): void {
		global $wpdb;

		$wpdb->insert(
			Schema::table( 'audit_log' ),
			array(
				'object_type' => $object_type,
				'object_id'   => $object_id,
				'action'      => $action,
				'user_id'     => $user_id,
				'old_value'   => self::encode( $old_value ),
				'new_value'   => self::encode( $new_value ),
				'created_at'  => Timestamps::now(),
			),
			array( '%s', '%d', '%s', '%d', '%s', '%s', '%s' )
		);
	}

	/**
	 * Encode a value for storage: strings/null pass through, everything else is JSON-encoded.
	 *
	 * @param mixed $value Value to encode.
	 */
	private static function encode( $value ): ?string {
		if ( null === $value || is_string( $value ) ) {
			return $value;
		}

		return wp_json_encode( $value );
	}
}

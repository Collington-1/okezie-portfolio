<?php
/**
 * Free-scope database schema definitions, expressed as dbDelta()-compatible SQL.
 *
 * See docs/DATABASE-SCHEMA.md for the human-readable design, rationale, and index/lifecycle
 * notes. Every statement here must remain idempotent (safe to re-run via dbDelta on every
 * upgrade) — dbDelta() is intentionally picky about formatting; see the inline notes in
 * Migrator::install().
 *
 * @package BookFlow\Database
 */

declare( strict_types = 1 );

namespace BookFlow\Database;

use BookFlow\Support\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Schema
 */
final class Schema {

	/**
	 * Return the fully-prefixed table name for a given short table key (e.g. 'services').
	 *
	 * @param string $key Short table key, e.g. 'services', 'appointments'.
	 */
	public static function table( string $key ): string {
		global $wpdb;

		return $wpdb->prefix . Constants::TABLE_PREFIX . $key;
	}

	/**
	 * Build the full set of dbDelta() SQL statements for every Free-scope table.
	 *
	 * @return array<int, string> One CREATE TABLE statement per array entry.
	 */
	public static function statements(): array {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		return array(
			self::service_categories( $charset_collate ),
			self::services( $charset_collate ),
			self::staff( $charset_collate ),
			self::staff_services( $charset_collate ),
			self::locations( $charset_collate ),
			self::staff_locations( $charset_collate ),
			self::service_locations( $charset_collate ),
			self::customers( $charset_collate ),
			self::appointments( $charset_collate ),
			self::appointment_participants( $charset_collate ),
			self::events( $charset_collate ),
			self::event_attendees( $charset_collate ),
			self::scheduling_pages( $charset_collate ),
			self::scheduling_page_services( $charset_collate ),
			self::availability_rules( $charset_collate ),
			self::availability_exceptions( $charset_collate ),
			self::custom_fields( $charset_collate ),
			self::notification_log( $charset_collate ),
			self::audit_log( $charset_collate ),
		);
	}

	/**
	 * bookflow_service_categories
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function service_categories( string $charset_collate ): string {
		$table = self::table( 'service_categories' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(191) NOT NULL,
			slug VARCHAR(191) NOT NULL,
			description LONGTEXT NULL,
			sort_order INT NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug)
		) {$charset_collate};";
	}

	/**
	 * bookflow_services
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function services( string $charset_collate ): string {
		$table = self::table( 'services' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			category_id BIGINT UNSIGNED NULL,
			name VARCHAR(191) NOT NULL,
			slug VARCHAR(191) NOT NULL,
			description LONGTEXT NULL,
			duration_minutes INT UNSIGNED NOT NULL DEFAULT 30,
			price DECIMAL(12,2) NULL,
			currency VARCHAR(3) NULL,
			capacity SMALLINT UNSIGNED NOT NULL DEFAULT 1,
			color VARCHAR(7) NULL,
			icon VARCHAR(191) NULL,
			image_id BIGINT UNSIGNED NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			sort_order INT NOT NULL DEFAULT 0,
			settings LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY category_id (category_id),
			KEY status (status)
		) {$charset_collate};";
	}

	/**
	 * bookflow_staff
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function staff( string $charset_collate ): string {
		$table = self::table( 'staff' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NULL,
			display_name VARCHAR(191) NOT NULL,
			email VARCHAR(191) NULL,
			phone VARCHAR(50) NULL,
			avatar_id BIGINT UNSIGNED NULL,
			timezone VARCHAR(64) NULL,
			color VARCHAR(7) NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			settings LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY status (status)
		) {$charset_collate};";
	}

	/**
	 * bookflow_staff_services (pivot)
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function staff_services( string $charset_collate ): string {
		$table = self::table( 'staff_services' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			staff_id BIGINT UNSIGNED NOT NULL,
			service_id BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY staff_service (staff_id, service_id)
		) {$charset_collate};";
	}

	/**
	 * bookflow_locations
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function locations( string $charset_collate ): string {
		$table = self::table( 'locations' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(191) NOT NULL,
			slug VARCHAR(191) NOT NULL,
			type VARCHAR(20) NOT NULL DEFAULT 'physical',
			address LONGTEXT NULL,
			phone VARCHAR(50) NULL,
			timezone VARCHAR(64) NULL,
			meeting_url VARCHAR(255) NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			sort_order INT NOT NULL DEFAULT 0,
			settings LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY status (status)
		) {$charset_collate};";
	}

	/**
	 * bookflow_staff_locations (pivot)
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function staff_locations( string $charset_collate ): string {
		$table = self::table( 'staff_locations' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			staff_id BIGINT UNSIGNED NOT NULL,
			location_id BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY staff_location (staff_id, location_id)
		) {$charset_collate};";
	}

	/**
	 * bookflow_service_locations (pivot)
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function service_locations( string $charset_collate ): string {
		$table = self::table( 'service_locations' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			service_id BIGINT UNSIGNED NOT NULL,
			location_id BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY service_location (service_id, location_id)
		) {$charset_collate};";
	}

	/**
	 * bookflow_customers
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function customers( string $charset_collate ): string {
		$table = self::table( 'customers' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			wp_user_id BIGINT UNSIGNED NULL,
			first_name VARCHAR(191) NULL,
			last_name VARCHAR(191) NULL,
			email VARCHAR(191) NOT NULL,
			phone VARCHAR(50) NULL,
			timezone VARCHAR(64) NULL,
			notes LONGTEXT NULL,
			meta LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY email (email),
			KEY wp_user_id (wp_user_id)
		) {$charset_collate};";
	}

	/**
	 * bookflow_appointments
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function appointments( string $charset_collate ): string {
		$table = self::table( 'appointments' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			booking_reference VARCHAR(32) NOT NULL,
			service_id BIGINT UNSIGNED NOT NULL,
			staff_id BIGINT UNSIGNED NULL,
			location_id BIGINT UNSIGNED NULL,
			customer_id BIGINT UNSIGNED NOT NULL,
			scheduling_page_id BIGINT UNSIGNED NULL,
			start_datetime_utc DATETIME NOT NULL,
			end_datetime_utc DATETIME NOT NULL,
			timezone VARCHAR(64) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			price DECIMAL(12,2) NULL,
			currency VARCHAR(3) NULL,
			notes LONGTEXT NULL,
			custom_fields LONGTEXT NULL,
			series_id BIGINT UNSIGNED NULL,
			cancel_token VARCHAR(64) NULL,
			reschedule_token VARCHAR(64) NULL,
			source VARCHAR(20) NOT NULL DEFAULT 'frontend',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY booking_reference (booking_reference),
			KEY staff_start (staff_id, start_datetime_utc),
			KEY location_start (location_id, start_datetime_utc),
			KEY status (status),
			KEY customer_id (customer_id),
			KEY service_id (service_id),
			KEY scheduling_page_id (scheduling_page_id)
		) {$charset_collate};";
	}

	/**
	 * bookflow_appointment_participants
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function appointment_participants( string $charset_collate ): string {
		$table = self::table( 'appointment_participants' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			appointment_id BIGINT UNSIGNED NOT NULL,
			staff_id BIGINT UNSIGNED NOT NULL,
			role VARCHAR(20) NOT NULL DEFAULT 'primary',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY appointment_staff (appointment_id, staff_id)
		) {$charset_collate};";
	}

	/**
	 * bookflow_events
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function events( string $charset_collate ): string {
		$table = self::table( 'events' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			title VARCHAR(191) NOT NULL,
			slug VARCHAR(191) NOT NULL,
			description LONGTEXT NULL,
			start_datetime_utc DATETIME NOT NULL,
			end_datetime_utc DATETIME NOT NULL,
			timezone VARCHAR(64) NOT NULL,
			location_id BIGINT UNSIGNED NULL,
			capacity INT UNSIGNED NULL,
			image_id BIGINT UNSIGNED NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'draft',
			price DECIMAL(12,2) NULL,
			currency VARCHAR(3) NULL,
			settings LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY status (status),
			KEY start_datetime_utc (start_datetime_utc)
		) {$charset_collate};";
	}

	/**
	 * bookflow_event_attendees
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function event_attendees( string $charset_collate ): string {
		$table = self::table( 'event_attendees' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			event_id BIGINT UNSIGNED NOT NULL,
			customer_id BIGINT UNSIGNED NOT NULL,
			quantity INT UNSIGNED NOT NULL DEFAULT 1,
			status VARCHAR(20) NOT NULL DEFAULT 'confirmed',
			custom_fields LONGTEXT NULL,
			booking_reference VARCHAR(32) NOT NULL,
			cancel_token VARCHAR(64) NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY booking_reference (booking_reference),
			KEY event_id (event_id),
			KEY customer_id (customer_id),
			KEY status (status)
		) {$charset_collate};";
	}

	/**
	 * bookflow_scheduling_pages
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function scheduling_pages( string $charset_collate ): string {
		$table = self::table( 'scheduling_pages' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			staff_id BIGINT UNSIGNED NULL,
			title VARCHAR(191) NOT NULL,
			slug VARCHAR(191) NOT NULL,
			description LONGTEXT NULL,
			layout VARCHAR(20) NOT NULL DEFAULT 'classic',
			buffer_before_minutes INT UNSIGNED NOT NULL DEFAULT 0,
			buffer_after_minutes INT UNSIGNED NOT NULL DEFAULT 0,
			min_notice_minutes INT UNSIGNED NOT NULL DEFAULT 0,
			max_advance_days INT UNSIGNED NULL,
			approval_required TINYINT(1) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			settings LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY staff_id (staff_id),
			KEY status (status)
		) {$charset_collate};";
	}

	/**
	 * bookflow_scheduling_page_services (pivot)
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function scheduling_page_services( string $charset_collate ): string {
		$table = self::table( 'scheduling_page_services' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			scheduling_page_id BIGINT UNSIGNED NOT NULL,
			service_id BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY page_service (scheduling_page_id, service_id)
		) {$charset_collate};";
	}

	/**
	 * bookflow_availability_rules
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function availability_rules( string $charset_collate ): string {
		$table = self::table( 'availability_rules' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			entity_type VARCHAR(20) NOT NULL,
			entity_id BIGINT UNSIGNED NULL,
			day_of_week TINYINT UNSIGNED NOT NULL,
			start_time TIME NOT NULL,
			end_time TIME NOT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY entity_lookup (entity_type, entity_id, day_of_week)
		) {$charset_collate};";
	}

	/**
	 * bookflow_availability_exceptions
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function availability_exceptions( string $charset_collate ): string {
		$table = self::table( 'availability_exceptions' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			entity_type VARCHAR(20) NOT NULL,
			entity_id BIGINT UNSIGNED NULL,
			date DATE NOT NULL,
			start_time TIME NULL,
			end_time TIME NULL,
			is_available TINYINT(1) NOT NULL DEFAULT 0,
			reason VARCHAR(191) NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY entity_date (entity_type, entity_id, date)
		) {$charset_collate};";
	}

	/**
	 * bookflow_custom_fields
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function custom_fields( string $charset_collate ): string {
		$table = self::table( 'custom_fields' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			context VARCHAR(20) NOT NULL,
			label VARCHAR(191) NOT NULL,
			field_key VARCHAR(191) NOT NULL,
			field_type VARCHAR(20) NOT NULL,
			options LONGTEXT NULL,
			is_required TINYINT(1) NOT NULL DEFAULT 0,
			sort_order INT NOT NULL DEFAULT 0,
			scope_id BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY context_scope (context, scope_id)
		) {$charset_collate};";
	}

	/**
	 * bookflow_notification_log
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function notification_log( string $charset_collate ): string {
		$table = self::table( 'notification_log' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			appointment_id BIGINT UNSIGNED NULL,
			event_attendee_id BIGINT UNSIGNED NULL,
			type VARCHAR(50) NOT NULL,
			recipient VARCHAR(191) NOT NULL,
			status VARCHAR(20) NOT NULL,
			error TEXT NULL,
			sent_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY appointment_id (appointment_id),
			KEY event_attendee_id (event_attendee_id),
			KEY type (type)
		) {$charset_collate};";
	}

	/**
	 * bookflow_audit_log
	 *
	 * @param string $charset_collate Charset/collation clause.
	 */
	private static function audit_log( string $charset_collate ): string {
		$table = self::table( 'audit_log' );

		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			object_type VARCHAR(50) NOT NULL,
			object_id BIGINT UNSIGNED NOT NULL,
			action VARCHAR(50) NOT NULL,
			user_id BIGINT UNSIGNED NULL,
			old_value LONGTEXT NULL,
			new_value LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY object_lookup (object_type, object_id)
		) {$charset_collate};";
	}
}

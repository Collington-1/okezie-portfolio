<?php
/**
 * Shared low-level table access for domain repositories. Deliberately dumb: it knows how to
 * read/write rows as plain associative arrays through $wpdb's own prepared-statement methods,
 * and nothing about business rules, validation, or entity objects — that belongs in each
 * domain repository (Services\Service_Repository, Staff\Staff_Repository, ...).
 *
 * @package BookFlow\Database
 */

declare( strict_types = 1 );

namespace BookFlow\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Repository
 */
abstract class Repository {

	/**
	 * Short table key understood by Schema::table(), e.g. 'services'.
	 */
	abstract protected static function table_key(): string;

	/**
	 * $wpdb format specifier ('%d', '%s', '%f') for each writable column, keyed by column name.
	 * Used so insert()/update() always pass an explicit, correctly-ordered format array to
	 * $wpdb rather than guessing — every value still goes through $wpdb's own prepared-query
	 * escaping either way, but explicit formats catch accidental type mismatches early.
	 *
	 * @return array<string, string>
	 */
	abstract protected static function formats(): array;

	/**
	 * Fully-prefixed table name.
	 */
	protected static function table(): string {
		return Schema::table( static::table_key() );
	}

	/**
	 * Fetch a single row by primary key, as a raw associative array.
	 *
	 * Deliberately NOT named find() — domain repositories declare their own public find()
	 * returning a typed entity (e.g. Service_Repository::find(): ?Service), and PHP requires
	 * overriding methods to have a covariant return type. `?Service` is not a subtype of
	 * `?array`, so reusing the name find() here would be a fatal "declaration must be
	 * compatible" error the moment a domain repository tried to override it.
	 *
	 * @param int $id Row ID.
	 * @return array<string, mixed>|null
	 */
	public static function find_row( int $id ): ?array {
		global $wpdb;

		$table = static::table();

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is not user input, see Schema::table().
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );

		return is_array( $row ) ? $row : null;
	}

	/**
	 * Fetch several rows by primary key in one query, keyed by id — the batch-fetch counterpart
	 * to find_row(), used to avoid N+1 queries when a list screen needs to resolve many foreign
	 * keys to display names in one page (Section 10: "Avoid N+1 database queries").
	 *
	 * @param array<int, int> $ids Row IDs.
	 * @return array<int, array<string, mixed>> Keyed by id; IDs with no matching row are simply absent, not null.
	 */
	public static function find_many_rows( array $ids ): array {
		$ids = array_values( array_unique( array_map( 'absint', $ids ) ) );

		if ( empty( $ids ) ) {
			return array();
		}

		global $wpdb;

		$table        = static::table();
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name trusted; prepared immediately below.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE id IN ({$placeholders})", $ids ), ARRAY_A );

		$by_id = array();

		foreach ( ( $rows ? $rows : array() ) as $row ) {
			$by_id[ (int) $row['id'] ] = $row;
		}

		return $by_id;
	}

	/**
	 * Fetch a single row by an arbitrary column, for lookups like find-by-slug or
	 * find-by-booking-reference. Only ever called with a hard-coded, trusted $column from
	 * within this codebase — never with a caller-supplied column name.
	 *
	 * @param string $column Column name (trusted, not user input).
	 * @param mixed  $value  Value to match.
	 * @param string $format $wpdb format specifier for $value ('%s', '%d', '%f').
	 * @return array<string, mixed>|null
	 */
	protected static function find_by( string $column, $value, string $format = '%s' ): ?array {
		global $wpdb;

		$table = static::table();

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table/column names are trusted constants, not user input.
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE {$column} = {$format}", $value ), ARRAY_A );

		return is_array( $row ) ? $row : null;
	}

	/**
	 * Whether a row exists matching the given column/value, optionally excluding one ID —
	 * the shape needed by unique-slug checks on both create (no exclusion) and update
	 * (exclude the row being updated).
	 *
	 * @param string   $column      Column name (trusted, not user input).
	 * @param mixed    $value       Value to match.
	 * @param string   $format      $wpdb format specifier for $value.
	 * @param int|null $excluding_id Row ID to exclude from the check.
	 */
	protected static function exists_by( string $column, $value, string $format, ?int $excluding_id = null ): bool {
		global $wpdb;

		$table = static::table();

		if ( null !== $excluding_id ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table/column names are trusted constants, not user input.
			$sql = $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$column} = {$format} AND id != %d", $value, $excluding_id );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table/column names are trusted constants, not user input.
			$sql = $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$column} = {$format}", $value );
		}

		return ( (int) $wpdb->get_var( $sql ) ) > 0;
	}

	/**
	 * Insert a row.
	 *
	 * @param array<string, mixed> $data Column => value, already validated/sanitized by the
	 *                                    calling domain repository.
	 * @return int Newly inserted row ID.
	 *
	 * @throws \RuntimeException When the insert fails.
	 */
	public static function insert( array $data ): int {
		global $wpdb;

		$result = $wpdb->insert( static::table(), $data, self::formats_for( $data ) );

		if ( false === $result ) {
			throw new \RuntimeException( $wpdb->last_error ? $wpdb->last_error : 'BookFlow: database insert failed.' );
		}

		return (int) $wpdb->insert_id;
	}

	/**
	 * Update a row by primary key. Named update_row() for the same reason find() is named
	 * find_row() above — see that docblock.
	 *
	 * @param int                   $id   Row ID.
	 * @param array<string, mixed>  $data Column => value, already validated/sanitized.
	 *
	 * @throws \RuntimeException When the update fails outright (a matched-but-unchanged row is
	 *                            not an error — $wpdb->update() returns 0 in that case, which
	 *                            this method treats as success).
	 */
	public static function update_row( int $id, array $data ): bool {
		global $wpdb;

		$result = $wpdb->update(
			static::table(),
			$data,
			array( 'id' => $id ),
			self::formats_for( $data ),
			array( '%d' )
		);

		if ( false === $result ) {
			throw new \RuntimeException( $wpdb->last_error ? $wpdb->last_error : 'BookFlow: database update failed.' );
		}

		return true;
	}

	/**
	 * Delete a row by primary key.
	 *
	 * @param int $id Row ID.
	 */
	public static function delete( int $id ): bool {
		global $wpdb;

		return false !== $wpdb->delete( static::table(), array( 'id' => $id ), array( '%d' ) );
	}

	/**
	 * Reduce the full formats() map down to just the columns present in $data, in $data's own
	 * key order — the shape $wpdb->insert()/update() require.
	 *
	 * @param array<string, mixed> $data Column => value.
	 * @return array<int, string>
	 */
	private static function formats_for( array $data ): array {
		$all = static::formats();

		return array_map(
			static function ( string $column ) use ( $all ): string {
				return $all[ $column ] ?? '%s';
			},
			array_keys( $data )
		);
	}

	/**
	 * Acquire a MySQL named lock (GET_LOCK()) — the shared low-level primitive behind every
	 * "guard this capacity/collision check + insert as one atomic-enough critical section"
	 * pattern in the codebase (Appointment_Repository's double-booking guard, Events\
	 * Event_Attendee_Repository's overbooking guard). Named locks are connection-scoped but
	 * coordinate correctly across separate PHP-FPM/web requests because they live in MySQL
	 * itself, not PHP process memory — unlike a static/in-memory PHP lock, which would not help
	 * under a typical multi-worker WordPress deployment.
	 *
	 * Deliberately returns a bool rather than throwing: this base class knows nothing about
	 * domain-specific "conflict" exceptions (Booking_Conflict_Exception, etc.) and shouldn't —
	 * callers translate a false return into whatever exception fits their domain.
	 *
	 * @param string $key             Lock key. Callers should namespace this per-plugin and
	 *                                 per-scope (e.g. "bookflow_event_42") to avoid colliding
	 *                                 with locks held by unrelated code on the same MySQL server.
	 * @param int    $timeout_seconds How long to wait for the lock before giving up.
	 */
	protected static function acquire_named_lock( string $key, int $timeout_seconds = 10 ): bool {
		global $wpdb;

		$acquired = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $key, $timeout_seconds ) );

		return '1' === (string) $acquired;
	}

	/**
	 * Release a previously acquired named lock. Safe to call even if acquisition failed/was
	 * never attempted (RELEASE_LOCK() on a lock this connection doesn't hold is a harmless no-op
	 * from MySQL's point of view, just returns 0 instead of 1).
	 */
	protected static function release_named_lock( string $key ): void {
		global $wpdb;

		$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $key ) );
	}
}

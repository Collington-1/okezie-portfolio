<?php
/**
 * Scheduling module bootstrap: the public /schedule/{slug} route.
 *
 * @package BookFlow\Scheduling
 */

declare( strict_types = 1 );

namespace BookFlow\Scheduling;

use BookFlow\Frontend\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Bootstrap
 */
final class Bootstrap {

	/**
	 * Query var carrying the scheduling page slug.
	 *
	 * @var string
	 */
	private const QUERY_VAR = 'bookflow_schedule';

	/**
	 * Bump when the rewrite rule's pattern or url_prefix() default ever changes, to force a
	 * one-time re-flush on sites that already had BookFlow active before that change shipped.
	 * Support\Activation::run() already flushes on fresh activation; this covers the *upgrade*
	 * case — a site running a pre-Phase-6 version has no reason to have flushed for a rewrite
	 * rule that did not exist yet, and nothing else in the update pipeline would trigger one
	 * (this phase added no database schema change, so Migrator's own upgrade hook never fires).
	 *
	 * @var string
	 */
	private const REWRITE_VERSION = '1';

	/**
	 * Option tracking which REWRITE_VERSION has last been flushed for.
	 *
	 * @var string
	 */
	private const OPTION_REWRITE_VERSION = 'bookflow_schedule_rewrite_version';

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_action( 'init', array( self::class, 'register_rewrite_rule' ) );
		add_action( 'init', array( self::class, 'maybe_flush_rewrite_rules' ), 20 ); // after register_rewrite_rule() has run at the default priority.
		add_filter( 'query_vars', array( self::class, 'add_query_var' ) );
		add_filter( 'template_include', array( self::class, 'maybe_render' ) );
		add_shortcode( 'bookflow_schedule', array( self::class, 'render_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( self::class, 'maybe_enqueue_assets' ) );
	}

	/**
	 * Enqueue the shared widget style + script when a scheduling-page view will actually
	 * render: the dedicated /{prefix}/{slug} page, or wherever a theme page embeds
	 * [bookflow_schedule] (Section 10: load frontend assets only when a booking component is
	 * present). Unlike Events\Bootstrap's identical-looking method, this also needs the
	 * *script* (`bookflow-booking-form`), not just the stylesheet — a scheduling page renders
	 * the same interactive slot-picking widget as a plain service booking, where an event page
	 * is a static form. Both scripts/styles are already registered (not yet enqueued) by
	 * Frontend\Bootstrap::maybe_enqueue_assets(), which runs earlier in Plugin::boot_modules().
	 */
	public static function maybe_enqueue_assets(): void {
		if ( '' !== self::requested_slug() ) {
			wp_enqueue_style( 'bookflow-frontend' );
			wp_enqueue_script( 'bookflow-booking-form' );
			return;
		}

		if ( ! is_singular() ) {
			return;
		}

		$post = get_queried_object();

		// Not has_shortcode() alone — see Frontend\Bootstrap::page_needs_assets()'s docblock for
		// the real bug this exact gap caused for the Booking Form block, confirmed against a
		// real WordPress install: the Scheduling Page block has the identical gap otherwise.
		if (
			$post instanceof \WP_Post
			&& ( has_shortcode( (string) $post->post_content, 'bookflow_schedule' ) || has_block( 'bookflow/scheduling-page', $post ) )
		) {
			wp_enqueue_style( 'bookflow-frontend' );
			wp_enqueue_script( 'bookflow-booking-form' );
		}
	}

	/**
	 * Render the [bookflow_schedule] shortcode — Section 18's "shortcode equivalents for core
	 * booking components" applied to scheduling pages, and the Scheduling Page block's
	 * render_callback (Phase 9) shares this same method.
	 *
	 * @param array<string, string>|string $atts Shortcode/block attributes ('page' = slug or ID).
	 */
	public static function render_shortcode( $atts ): string {
		$atts = shortcode_atts( array( 'page' => '' ), is_array( $atts ) ? $atts : array(), 'bookflow_schedule' );

		return Scheduling_Page_View::render_by_slug_or_id( (string) $atts['page'] );
	}

	/**
	 * Flush rewrite rules once per REWRITE_VERSION — a cheap get_option() check on every
	 * request, but the expensive flush_rewrite_rules() call itself only ever runs once per
	 * version bump, not on every page load.
	 */
	public static function maybe_flush_rewrite_rules(): void {
		if ( get_option( self::OPTION_REWRITE_VERSION ) === self::REWRITE_VERSION ) {
			return;
		}

		flush_rewrite_rules();
		update_option( self::OPTION_REWRITE_VERSION, self::REWRITE_VERSION, false );
	}

	/**
	 * Register the /{prefix}/{slug} rewrite rule. A single generic pattern, not one rule per
	 * page — creating/renaming/deleting a scheduling page never needs a rewrite flush, only
	 * plugin activation/deactivation do (see Support\Activation / Support\Deactivation).
	 */
	public static function register_rewrite_rule(): void {
		$prefix = self::url_prefix();

		add_rewrite_rule(
			'^' . preg_quote( $prefix, '/' ) . '/([^/]+)/?$',
			'index.php?' . self::QUERY_VAR . '=$matches[1]',
			'top'
		);
	}

	/**
	 * The URL path segment scheduling pages live under (default 'schedule', giving
	 * yourdomain.com/schedule/example per Section 15). Filterable rather than a Free-tier
	 * settings field — Section 23: "Do not expose dozens of settings unnecessarily"; a site
	 * that needs a different prefix (e.g. avoiding a collision with existing content) can set
	 * this via a code snippet/mu-plugin without a database migration.
	 */
	public static function url_prefix(): string {
		/**
		 * Filters the URL path segment scheduling pages are published under.
		 *
		 * @param string $prefix Path segment, no leading/trailing slashes. Default 'schedule'.
		 */
		$prefix = (string) apply_filters( 'bookflow_schedule_url_prefix', 'schedule' );

		return trim( $prefix, '/' );
	}

	/**
	 * The public URL for one scheduling page — the single source of truth for this, instead of
	 * every admin screen concatenating `home_url( '/' . url_prefix() . '/' . $page->slug )`
	 * separately (three call sites had already done exactly that independently before this
	 * method existed, with a subtle trailing-slash inconsistency starting to creep in between
	 * them — see docs/ROADMAP.md's Phase 10 notes).
	 */
	public static function public_url( Scheduling_Page $page ): string {
		return home_url( '/' . self::url_prefix() . '/' . $page->slug . '/' );
	}

	/**
	 * Register the query var so the rewrite rule's target is readable via get_query_var().
	 *
	 * @param array<int, string> $vars Existing public query vars.
	 * @return array<int, string>
	 */
	public static function add_query_var( array $vars ): array {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	/**
	 * The slug requested by the current request, or '' if this isn't a scheduling-page request.
	 */
	public static function requested_slug(): string {
		return (string) get_query_var( self::QUERY_VAR, '' );
	}

	/**
	 * Swap in our own template (still rendered through the active theme's get_header()/
	 * get_footer()) when the scheduling-page query var is present.
	 *
	 * @param string $template Original template path WordPress would have used.
	 */
	public static function maybe_render( string $template ): string {
		if ( '' === self::requested_slug() ) {
			return $template;
		}

		$found = Templates::locate( 'scheduling-page' );

		return $found ?? $template;
	}
}

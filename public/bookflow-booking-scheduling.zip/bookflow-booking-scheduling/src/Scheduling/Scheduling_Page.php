<?php
/**
 * Scheduling page entity — one row of wp_bookflow_scheduling_pages. A shareable public booking
 * page: a first-class object per Section 15 of the master spec, with its own booking rules
 * (buffers, minimum notice, booking window, approval) that take precedence over the underlying
 * service's own settings when a booking is made through this page — see
 * docs/ARCHITECTURE.md's Phase 6 section for why, and effective_rules_for().
 *
 * @package BookFlow\Scheduling
 */

declare( strict_types = 1 );

namespace BookFlow\Scheduling;

use BookFlow\Services\Service;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Scheduling_Page
 */
final class Scheduling_Page {

	/**
	 * Constructor.
	 *
	 * @param int         $id                    Row ID.
	 * @param int|null    $staff_id              Owning staff member, if any.
	 * @param string      $title                 Page title.
	 * @param string      $slug                  Unique slug (public URL: /schedule/{slug}).
	 * @param string|null $description           Description shown on the public page.
	 * @param string      $layout                'classic' | 'calendar_first' | 'express' | 'scheduling'.
	 * @param int         $buffer_before_minutes Buffer required before a booking.
	 * @param int         $buffer_after_minutes  Buffer required after a booking.
	 * @param int         $min_notice_minutes    Minimum booking notice.
	 * @param int|null    $max_advance_days      Maximum advance booking window, or null for the service's own.
	 * @param bool        $approval_required     Whether bookings require manual approval.
	 * @param string      $status                'active' | 'inactive'.
	 * @param array<string, mixed> $settings     Decoded JSON settings (branding/display, confirmation copy, embed options).
	 * @param string      $created_at            UTC DATETIME string.
	 * @param string      $updated_at            UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public ?int $staff_id,
		public string $title,
		public string $slug,
		public ?string $description,
		public string $layout,
		public int $buffer_before_minutes,
		public int $buffer_after_minutes,
		public int $min_notice_minutes,
		public ?int $max_advance_days,
		public bool $approval_required,
		public string $status,
		public array $settings,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Recognised `status` values.
	 *
	 * @return array<int, string>
	 */
	public static function statuses(): array {
		return array( 'active', 'inactive' );
	}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		return new self(
			(int) $row['id'],
			isset( $row['staff_id'] ) && null !== $row['staff_id'] ? (int) $row['staff_id'] : null,
			(string) $row['title'],
			(string) $row['slug'],
			$row['description'] ?? null,
			(string) $row['layout'],
			(int) $row['buffer_before_minutes'],
			(int) $row['buffer_after_minutes'],
			(int) $row['min_notice_minutes'],
			isset( $row['max_advance_days'] ) && null !== $row['max_advance_days'] ? (int) $row['max_advance_days'] : null,
			! empty( $row['approval_required'] ),
			(string) $row['status'],
			self::decode_settings( $row['settings'] ?? null ),
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}

	/**
	 * Decode the settings JSON column, tolerating null/malformed values.
	 *
	 * @param string|null $json Raw JSON string.
	 * @return array<string, mixed>
	 */
	private static function decode_settings( ?string $json ): array {
		if ( null === $json || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * A settings value with a default fallback.
	 *
	 * @param string $key     Settings key.
	 * @param mixed  $default Default value if the key is absent.
	 */
	public function setting( string $key, $default = null ) {
		return $this->settings[ $key ] ?? $default;
	}

	/**
	 * This page's own buffer/notice/advance-window rules, taking precedence over the given
	 * service's own settings for those same concerns — the scheduling page IS the more specific
	 * configuration when a booking happens through it (Section 15: buffers, minimum notice, and
	 * booking window are all listed as attributes of the scheduling page itself). Duration,
	 * price, and capacity are deliberately NOT overridden here — those stay with the service,
	 * since "multiple duration options" (Section 15) is satisfied by a page offering multiple
	 * services rather than the page defining its own duration.
	 *
	 * max_advance_days falls back to the service's own value when the page has none set (the
	 * schema allows NULL there specifically to mean "no page-specific limit"); every other
	 * field the page's schema makes NOT NULL always wins outright.
	 *
	 * @return array{buffer_before_minutes:int, buffer_after_minutes:int, min_notice_minutes:int, max_advance_days:int|null}
	 */
	public function effective_rules_for( Service $service ): array {
		return array(
			'buffer_before_minutes' => $this->buffer_before_minutes,
			'buffer_after_minutes'  => $this->buffer_after_minutes,
			'min_notice_minutes'    => $this->min_notice_minutes,
			'max_advance_days'      => $this->max_advance_days ?? $service->setting( 'max_advance_days', null ),
		);
	}
}

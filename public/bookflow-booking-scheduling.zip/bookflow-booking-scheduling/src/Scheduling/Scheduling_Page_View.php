<?php
/**
 * Shared scheduling page details + booking widget view — extracted from
 * templates/scheduling-page.php (Phase 6) so the public /schedule/{slug} page, the new
 * [bookflow_schedule] shortcode, and the Scheduling Page block (Phase 9) all render identical
 * markup instead of three copies drifting apart. Mirrors Events\Event_View's role for events.
 *
 * @package BookFlow\Scheduling
 */

declare( strict_types = 1 );

namespace BookFlow\Scheduling;

use BookFlow\Frontend\Templates;
use BookFlow\Frontend\Widget_Config;
use BookFlow\Staff\Staff_Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Scheduling_Page_View
 */
final class Scheduling_Page_View {

	/**
	 * Render one scheduling page: header (title, host, description) + the booking widget
	 * restricted to the page's services/staff, or a "not found"/"no services" state.
	 *
	 * @param Scheduling_Page|null $page The page to render, or null (renders a "not found" notice).
	 */
	public static function render( ?Scheduling_Page $page ): string {
		if ( null === $page || 'active' !== $page->status ) {
			return self::not_found();
		}

		$staff       = $page->staff_id ? Staff_Repository::find( $page->staff_id ) : null;
		$service_ids = Scheduling_Page_Repository::service_ids( $page->id );

		ob_start();
		?>
		<div class="bookflow-schedule-wrap">
			<header class="bookflow-schedule-header">
				<h1><?php echo esc_html( $page->title ); ?></h1>
				<?php if ( $staff ) : ?>
					<p class="bookflow-schedule-host"><?php echo esc_html( $staff->display_name ); ?></p>
				<?php endif; ?>
				<?php if ( $page->description ) : ?>
					<div class="bookflow-schedule-description"><?php echo wp_kses_post( $page->description ); ?></div>
				<?php endif; ?>
			</header>

			<?php if ( empty( $service_ids ) ) : ?>
				<p class="bookflow-empty"><?php esc_html_e( 'No services are currently offered on this page.', 'bookflow-booking-scheduling' ); ?></p>
			<?php else : ?>
				<?php
				$config = Widget_Config::build(
					array(
						'layout'              => $page->layout,
						'allowed_service_ids' => $service_ids,
						'locked_staff_id'     => $page->staff_id,
						'scheduling_page_id'  => $page->id,
					)
				);

				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Templates::render() output is built entirely from esc_*()-wrapped markup in templates/booking-form.php.
				echo Templates::render( 'booking-form', array( 'layout' => $page->layout, 'config' => $config ) );
				?>
			<?php endif; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Resolve a shortcode/block 'page' attribute (numeric ID or slug) to a Scheduling_Page and
	 * render it.
	 */
	public static function render_by_slug_or_id( string $page_attr ): string {
		if ( '' === trim( $page_attr ) ) {
			return self::not_found();
		}

		$page = ctype_digit( $page_attr )
			? Scheduling_Page_Repository::find( (int) $page_attr )
			: Scheduling_Page_Repository::find_by_slug( sanitize_title( $page_attr ) );

		return self::render( $page );
	}

	/**
	 * "Not found" state, shared by all three entry points.
	 */
	private static function not_found(): string {
		return '<div class="bookflow-schedule-wrap"><h1>' .
			esc_html__( 'Page not found', 'bookflow-booking-scheduling' ) .
			'</h1><p class="bookflow-empty">' .
			esc_html__( 'This scheduling page does not exist or is no longer available.', 'bookflow-booking-scheduling' ) .
			'</p></div>';
	}
}

<?php
/**
 * Scheduling pages domain repository: validation, slug generation, and CRUD for
 * wp_bookflow_scheduling_pages, plus its service pivot associations.
 *
 * @package BookFlow\Scheduling
 */

declare( strict_types = 1 );

namespace BookFlow\Scheduling;

use BookFlow\Database\Pivot_Table;
use BookFlow\Database\Repository;
use BookFlow\Database\Schema;
use BookFlow\Support\Slugs;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Scheduling_Page_Repository
 */
final class Scheduling_Page_Repository extends Repository {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'scheduling_pages';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'staff_id'              => '%d',
			'title'                 => '%s',
			'slug'                  => '%s',
			'description'           => '%s',
			'layout'                => '%s',
			'buffer_before_minutes' => '%d',
			'buffer_after_minutes'  => '%d',
			'min_notice_minutes'    => '%d',
			'max_advance_days'      => '%d',
			'approval_required'     => '%d',
			'status'                => '%s',
			'settings'              => '%s',
			'created_at'            => '%s',
			'updated_at'            => '%s',
		);
	}

	/**
	 * Fetch a scheduling page by ID.
	 */
	public static function find( int $id ): ?Scheduling_Page {
		$row = parent::find_row( $id );

		return $row ? Scheduling_Page::from_row( $row ) : null;
	}

	/**
	 * Fetch a scheduling page by its unique slug — the public /schedule/{slug} route's lookup.
	 */
	public static function find_by_slug( string $slug ): ?Scheduling_Page {
		$row = self::find_by( 'slug', $slug, '%s' );

		return $row ? Scheduling_Page::from_row( $row ) : null;
	}

	/**
	 * List scheduling pages — reference data, not paginated server-side (Section 10; same
	 * reasoning as Services/Staff/Locations).
	 *
	 * @param array{status?: string, staff_id?: int, search?: string} $args Filter args.
	 * @return array<int, Scheduling_Page>
	 */
	public static function all( array $args = array() ): array {
		global $wpdb;

		$table  = static::table();
		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = (string) $args['status'];
		}

		if ( ! empty( $args['staff_id'] ) ) {
			$where[]  = 'staff_id = %d';
			$params[] = (int) $args['staff_id'];
		}

		if ( ! empty( $args['search'] ) ) {
			$where[]  = 'title LIKE %s';
			$params[] = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
		}

		$sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . ' ORDER BY title ASC'; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where fragments are hard-coded above; values are parameterized.

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared whenever placeholders are present.
		$rows     = $wpdb->get_results( $prepared, ARRAY_A );

		return array_map( array( Scheduling_Page::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Create a scheduling page.
	 *
	 * @param array<string, mixed> $input Raw input.
	 *
	 * @throws Validation_Exception When input fails validation.
	 */
	public static function create( array $input ): Scheduling_Page {
		$data                = self::validate( $input, null, null );
		$data['created_at']  = Timestamps::now();
		$data['updated_at']  = $data['created_at'];

		$id = parent::insert( $data );

		return self::find( $id );
	}

	/**
	 * Update a scheduling page. Fields absent from $input keep their current value.
	 *
	 * @param int                   $id    Scheduling page ID.
	 * @param array<string, mixed>  $input Raw partial input.
	 *
	 * @throws \InvalidArgumentException When the page does not exist.
	 * @throws Validation_Exception       When input fails validation.
	 */
	public static function update( int $id, array $input ): Scheduling_Page {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: scheduling page %d not found.', $id ) );
		}

		$data               = self::validate( $input, $id, $existing );
		$data['updated_at'] = Timestamps::now();

		parent::update_row( $id, $data );

		return self::find( $id );
	}

	/**
	 * Delete a scheduling page and its service associations.
	 */
	public static function delete( int $id ): bool {
		Pivot_Table::delete_all_for( Schema::table( 'scheduling_page_services' ), 'scheduling_page_id', $id );

		return parent::delete( $id );
	}

	/**
	 * IDs of services offered on this scheduling page.
	 *
	 * @return array<int, int>
	 */
	public static function service_ids( int $scheduling_page_id ): array {
		return Pivot_Table::right_ids_for( Schema::table( 'scheduling_page_services' ), 'scheduling_page_id', 'service_id', $scheduling_page_id );
	}

	/**
	 * Replace the full set of services offered on this scheduling page.
	 *
	 * @param array<int, int> $service_ids Service IDs.
	 */
	public static function set_services( int $scheduling_page_id, array $service_ids ): void {
		Pivot_Table::sync( Schema::table( 'scheduling_page_services' ), 'scheduling_page_id', 'service_id', $scheduling_page_id, $service_ids );
	}

	/**
	 * Validate and sanitize raw input.
	 *
	 * @param array<string, mixed>      $input        Raw input.
	 * @param int|null                  $excluding_id Page ID to exclude from the slug uniqueness check (update only).
	 * @param array<string, mixed>|null $existing     Existing raw row, for partial updates.
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, ?int $excluding_id, ?array $existing ): array {
		$get = static function ( string $key, $default ) use ( $input, $existing ) {
			if ( array_key_exists( $key, $input ) ) {
				return $input[ $key ];
			}

			if ( null !== $existing && array_key_exists( $key, $existing ) ) {
				return $existing[ $key ];
			}

			return $default;
		};

		$errors = array();

		$title = trim( sanitize_text_field( (string) $get( 'title', '' ) ) );

		if ( '' === $title ) {
			$errors['title'] = __( 'Title is required.', 'bookflow-booking-scheduling' );
		}

		$layout = (string) $get( 'layout', 'classic' );

		if ( ! in_array( $layout, array( 'classic', 'calendar_first', 'express' ), true ) ) {
			$errors['layout'] = __( 'Invalid layout.', 'bookflow-booking-scheduling' );
		}

		$status = (string) $get( 'status', 'active' );

		if ( ! in_array( $status, Scheduling_Page::statuses(), true ) ) {
			$errors['status'] = __( 'Invalid status.', 'bookflow-booking-scheduling' );
		}

		if ( ! empty( $errors ) ) {
			throw new Validation_Exception( $errors, __( 'The scheduling page could not be saved.', 'bookflow-booking-scheduling' ) );
		}

		$staff_id_raw = $get( 'staff_id', null );
		$staff_id     = ( null !== $staff_id_raw && '' !== $staff_id_raw ) ? absint( $staff_id_raw ) : null;

		$slug_input = $get( 'slug', '' );
		$slug       = '' !== trim( (string) $slug_input ) ? sanitize_title( (string) $slug_input ) : null;

		if ( null === $slug || '' === $slug || self::exists_by( 'slug', $slug, '%s', $excluding_id ) ) {
			$slug = Slugs::unique(
				$slug ? $slug : $title,
				static function ( string $candidate ) use ( $excluding_id ): bool {
					return self::exists_by( 'slug', $candidate, '%s', $excluding_id );
				},
				'schedule'
			);
		}

		$max_advance_raw = $get( 'max_advance_days', null );
		$max_advance     = ( null !== $max_advance_raw && '' !== $max_advance_raw ) ? max( 0, (int) $max_advance_raw ) : null;

		$settings = $get( 'settings', array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		return array(
			'staff_id'              => $staff_id,
			'title'                 => $title,
			'slug'                  => $slug,
			'description'           => wp_kses_post( (string) $get( 'description', '' ) ),
			'layout'                => $layout,
			'buffer_before_minutes' => max( 0, (int) $get( 'buffer_before_minutes', 0 ) ),
			'buffer_after_minutes'  => max( 0, (int) $get( 'buffer_after_minutes', 0 ) ),
			'min_notice_minutes'    => max( 0, (int) $get( 'min_notice_minutes', 0 ) ),
			'max_advance_days'      => $max_advance,
			'approval_required'     => ! empty( $get( 'approval_required', false ) ) ? 1 : 0,
			'status'                => $status,
			'settings'              => wp_json_encode( $settings ),
		);
	}
}

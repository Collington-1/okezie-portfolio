<?php
/**
 * Staff domain repository: validation and CRUD for wp_bookflow_staff, plus its
 * service/location pivot associations.
 *
 * @package BookFlow\Staff
 */

declare( strict_types = 1 );

namespace BookFlow\Staff;

use BookFlow\Database\Pivot_Table;
use BookFlow\Database\Repository;
use BookFlow\Database\Schema;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Staff_Repository
 */
final class Staff_Repository extends Repository {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'staff';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'user_id'      => '%d',
			'display_name' => '%s',
			'email'        => '%s',
			'phone'        => '%s',
			'avatar_id'    => '%d',
			'timezone'     => '%s',
			'color'        => '%s',
			'status'       => '%s',
			'settings'     => '%s',
			'created_at'   => '%s',
			'updated_at'   => '%s',
		);
	}

	/**
	 * Fetch a staff member by ID.
	 */
	public static function find( int $id ): ?Staff_Member {
		$row = parent::find_row( $id );

		return $row ? Staff_Member::from_row( $row ) : null;
	}

	/**
	 * Fetch several staff members by ID in one query, keyed by id. See Repository::find_many_rows().
	 *
	 * @param array<int, int> $ids Staff IDs.
	 * @return array<int, Staff_Member>
	 */
	public static function find_many( array $ids ): array {
		return array_map( array( Staff_Member::class, 'from_row' ), parent::find_many_rows( $ids ) );
	}

	/**
	 * List staff members.
	 *
	 * @param array{status?: string, search?: string} $args Filter args.
	 * @return array<int, Staff_Member>
	 */
	public static function all( array $args = array() ): array {
		global $wpdb;

		$table  = static::table();
		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = (string) $args['status'];
		}

		if ( ! empty( $args['search'] ) ) {
			$where[]  = 'display_name LIKE %s';
			$params[] = '%' . $wpdb->esc_like( (string) $args['search'] ) . '%';
		}

		$sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . ' ORDER BY display_name ASC'; // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where fragments are hard-coded above; values are parameterized.

		$prepared = $params ? $wpdb->prepare( $sql, $params ) : $sql; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- prepared whenever placeholders are present.
		$rows     = $wpdb->get_results( $prepared, ARRAY_A );

		return array_map( array( Staff_Member::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Create a staff member.
	 *
	 * @param array<string, mixed> $input Raw input.
	 *
	 * @throws Validation_Exception When input fails validation.
	 */
	public static function create( array $input ): Staff_Member {
		$data                = self::validate( $input, null, null );
		$data['created_at']  = Timestamps::now();
		$data['updated_at']  = $data['created_at'];

		$id = parent::insert( $data );

		return self::find( $id );
	}

	/**
	 * Update a staff member. Fields absent from $input keep their current value.
	 *
	 * @param int                   $id    Staff ID.
	 * @param array<string, mixed>  $input Raw partial input.
	 *
	 * @throws \InvalidArgumentException When the staff member does not exist.
	 * @throws Validation_Exception       When input fails validation.
	 */
	public static function update( int $id, array $input ): Staff_Member {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: staff member %d not found.', $id ) );
		}

		$data               = self::validate( $input, $id, $existing );
		$data['updated_at'] = Timestamps::now();

		parent::update_row( $id, $data );

		return self::find( $id );
	}

	/**
	 * Delete a staff member and their service/location associations.
	 */
	public static function delete( int $id ): bool {
		Pivot_Table::delete_all_for( Schema::table( 'staff_services' ), 'staff_id', $id );
		Pivot_Table::delete_all_for( Schema::table( 'staff_locations' ), 'staff_id', $id );

		return parent::delete( $id );
	}

	/**
	 * IDs of services this staff member is assigned to.
	 *
	 * @return array<int, int>
	 */
	public static function service_ids( int $staff_id ): array {
		return Pivot_Table::right_ids_for( Schema::table( 'staff_services' ), 'staff_id', 'service_id', $staff_id );
	}

	/**
	 * Replace the full set of services assigned to a staff member.
	 *
	 * @param array<int, int> $service_ids Service IDs.
	 */
	public static function set_services( int $staff_id, array $service_ids ): void {
		Pivot_Table::sync( Schema::table( 'staff_services' ), 'staff_id', 'service_id', $staff_id, $service_ids );
	}

	/**
	 * IDs of locations this staff member works at.
	 *
	 * @return array<int, int>
	 */
	public static function location_ids( int $staff_id ): array {
		return Pivot_Table::right_ids_for( Schema::table( 'staff_locations' ), 'staff_id', 'location_id', $staff_id );
	}

	/**
	 * Replace the full set of locations a staff member works at.
	 *
	 * @param array<int, int> $location_ids Location IDs.
	 */
	public static function set_locations( int $staff_id, array $location_ids ): void {
		Pivot_Table::sync( Schema::table( 'staff_locations' ), 'staff_id', 'location_id', $staff_id, $location_ids );
	}

	/**
	 * Validate and sanitize raw input.
	 *
	 * @param array<string, mixed>      $input        Raw input.
	 * @param int|null                  $excluding_id Staff ID to exclude from checks (update only).
	 * @param array<string, mixed>|null $existing     Existing raw row, for partial updates.
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, ?int $excluding_id, ?array $existing ): array { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- $excluding_id reserved for future uniqueness checks (e.g. one staff row per user_id).
		$get = static function ( string $key, $default ) use ( $input, $existing ) {
			if ( array_key_exists( $key, $input ) ) {
				return $input[ $key ];
			}

			if ( null !== $existing && array_key_exists( $key, $existing ) ) {
				return $existing[ $key ];
			}

			return $default;
		};

		$errors = array();

		$display_name = trim( sanitize_text_field( (string) $get( 'display_name', '' ) ) );

		if ( '' === $display_name ) {
			$errors['display_name'] = __( 'Staff display name is required.', 'bookflow-booking-scheduling' );
		}

		$email_raw = $get( 'email', '' );
		$email     = null;

		if ( null !== $email_raw && '' !== trim( (string) $email_raw ) ) {
			$email = sanitize_email( (string) $email_raw );

			if ( ! is_email( $email ) ) {
				$errors['email'] = __( 'Please enter a valid email address.', 'bookflow-booking-scheduling' );
			}
		}

		$status = (string) $get( 'status', 'active' );

		if ( ! in_array( $status, Staff_Member::statuses(), true ) ) {
			$errors['status'] = __( 'Invalid staff status.', 'bookflow-booking-scheduling' );
		}

		$color = $get( 'color', null );

		if ( null !== $color && '' !== $color && ! preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $color ) ) {
			$errors['color'] = __( 'Color must be a hex value like #4C6EF5.', 'bookflow-booking-scheduling' );
		}

		$timezone_raw = $get( 'timezone', null );
		$timezone     = null;

		if ( null !== $timezone_raw && '' !== trim( (string) $timezone_raw ) ) {
			$timezone = sanitize_text_field( (string) $timezone_raw );

			if ( ! in_array( $timezone, \DateTimeZone::listIdentifiers(), true ) ) {
				$errors['timezone'] = __( 'Please choose a valid timezone.', 'bookflow-booking-scheduling' );
			}
		}

		if ( ! empty( $errors ) ) {
			throw new Validation_Exception( $errors, __( 'The staff member could not be saved.', 'bookflow-booking-scheduling' ) );
		}

		$user_id_raw = $get( 'user_id', null );
		$user_id     = ( null !== $user_id_raw && '' !== $user_id_raw ) ? absint( $user_id_raw ) : null;

		$avatar_id_raw = $get( 'avatar_id', null );
		$avatar_id     = ( null !== $avatar_id_raw && '' !== $avatar_id_raw ) ? absint( $avatar_id_raw ) : null;

		$phone = sanitize_text_field( (string) $get( 'phone', '' ) );

		$settings = $get( 'settings', array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		return array(
			'user_id'      => $user_id,
			'display_name' => $display_name,
			'email'        => $email,
			'phone'        => '' !== $phone ? $phone : null,
			'avatar_id'    => $avatar_id,
			'timezone'     => $timezone,
			'color'        => $color ? sanitize_hex_color( (string) $color ) : null,
			'status'       => $status,
			'settings'     => wp_json_encode( $settings ),
		);
	}
}

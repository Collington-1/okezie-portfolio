<?php
/**
 * Staff entity — one row of wp_bookflow_staff.
 *
 * @package BookFlow\Staff
 */

declare( strict_types = 1 );

namespace BookFlow\Staff;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Staff_Member
 *
 * Named Staff_Member rather than Staff to avoid an awkward BookFlow\Staff\Staff class name
 * while keeping the module namespace itself named after the feature area (Staff), consistent
 * with Services\Service, Locations\Location, Customers\Customer.
 */
final class Staff_Member {

	/**
	 * Constructor.
	 *
	 * @param int         $id           Row ID.
	 * @param int|null    $user_id      Linked WordPress user ID, if any.
	 * @param string      $display_name Display name.
	 * @param string|null $email        Contact email.
	 * @param string|null $phone        Contact phone.
	 * @param int|null    $avatar_id    Attachment ID.
	 * @param string|null $timezone     IANA timezone name; null falls back to the site timezone.
	 * @param string|null $color        Hex color for the admin calendar.
	 * @param string      $status       'active' | 'inactive'.
	 * @param array<string, mixed> $settings Decoded JSON settings.
	 * @param string      $created_at   UTC DATETIME string.
	 * @param string      $updated_at   UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public ?int $user_id,
		public string $display_name,
		public ?string $email,
		public ?string $phone,
		public ?int $avatar_id,
		public ?string $timezone,
		public ?string $color,
		public string $status,
		public array $settings,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Recognised `status` values.
	 *
	 * @return array<int, string>
	 */
	public static function statuses(): array {
		return array( 'active', 'inactive' );
	}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		return new self(
			(int) $row['id'],
			isset( $row['user_id'] ) && null !== $row['user_id'] ? (int) $row['user_id'] : null,
			(string) $row['display_name'],
			$row['email'] ?? null,
			$row['phone'] ?? null,
			isset( $row['avatar_id'] ) && null !== $row['avatar_id'] ? (int) $row['avatar_id'] : null,
			$row['timezone'] ?? null,
			$row['color'] ?? null,
			(string) $row['status'],
			self::decode_settings( $row['settings'] ?? null ),
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}

	/**
	 * Decode the settings JSON column, tolerating null/malformed values.
	 *
	 * @param string|null $json Raw JSON string.
	 * @return array<string, mixed>
	 */
	private static function decode_settings( ?string $json ): array {
		if ( null === $json || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * The staff member's effective timezone, falling back to the site timezone.
	 */
	public function effective_timezone(): \DateTimeZone {
		if ( $this->timezone ) {
			try {
				return new \DateTimeZone( $this->timezone );
			} catch ( \Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- fall through to site timezone below.
				// Fall through to the site timezone below if the stored value is invalid.
				unset( $e );
			}
		}

		return wp_timezone();
	}
}

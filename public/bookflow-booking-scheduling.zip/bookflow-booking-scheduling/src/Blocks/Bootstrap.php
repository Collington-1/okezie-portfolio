<?php
/**
 * Gutenberg block registration (Section 18: "Do not make users manually paste complex code for
 * ordinary use"). Three dynamic (server-rendered) blocks — Booking Form, Scheduling Page, Event
 * Booking — each a thin editor-side wrapper around the render logic its equivalent shortcode
 * already uses (Booking_Shortcode::render(), Scheduling\Bootstrap::render_shortcode(),
 * Events\Bootstrap::render_shortcode()), so the block and the shortcode can never drift apart.
 *
 * Deliberately no JS build step: `assets/js/blocks.js` is plain ES6 using the `wp.*` globals
 * WordPress's own block editor already loads (wp.blocks/wp.element/wp.blockEditor/
 * wp.components/wp.i18n/wp.serverSideRender) — no JSX, no webpack, no @wordpress/scripts
 * dependency at runtime. See docs/ARCHITECTURE.md §20 for why (this machine's disk space
 * couldn't even complete `npm install` for @wordpress/scripts, which made the decision easy,
 * but the same build-free philosophy already governs assets/js/booking-form.js from Phase 5).
 * Each block's editor preview uses WordPress core's built-in `<ServerSideRender>` component,
 * which calls the core `/wp/v2/block-renderer/` REST route WordPress registers automatically
 * for any block with a render_callback — no custom REST API needed (Section 3 lists a REST API
 * as a Premium "developer feature"; this sidesteps needing one in Free at all).
 *
 * @package BookFlow\Blocks
 */

declare( strict_types = 1 );

namespace BookFlow\Blocks;

use BookFlow\Events\Bootstrap as Events_Bootstrap;
use BookFlow\Events\Event_Repository;
use BookFlow\Frontend\Booking_Shortcode;
use BookFlow\Locations\Location_Repository;
use BookFlow\Scheduling\Bootstrap as Scheduling_Bootstrap;
use BookFlow\Scheduling\Scheduling_Page_Repository;
use BookFlow\Services\Service_Repository;
use BookFlow\Staff\Staff_Repository;
use BookFlow\Support\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Bootstrap
 */
final class Bootstrap {

	/**
	 * Shared editor script/style handle, registered once and reused by all three blocks.
	 *
	 * @var string
	 */
	private const EDITOR_HANDLE = 'bookflow-blocks-editor';

	/**
	 * Register hooks.
	 */
	public static function init(): void {
		add_action( 'init', array( self::class, 'register_blocks' ) );
		add_action( 'enqueue_block_editor_assets', array( self::class, 'localize_editor_data' ) );
	}

	/**
	 * Register the editor script/style and the three block types.
	 */
	public static function register_blocks(): void {
		wp_register_script(
			self::EDITOR_HANDLE,
			BOOKFLOW_PLUGIN_URL . 'assets/js/blocks.js',
			array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-server-side-render' ),
			Constants::VERSION,
			true
		);

		wp_register_style(
			self::EDITOR_HANDLE,
			BOOKFLOW_PLUGIN_URL . 'assets/css/blocks-editor.css',
			array( 'wp-edit-blocks' ),
			Constants::VERSION
		);

		if ( function_exists( 'wp_set_script_translations' ) ) {
			wp_set_script_translations( self::EDITOR_HANDLE, Constants::TEXT_DOMAIN, BOOKFLOW_PLUGIN_DIR . 'languages' );
		}

		register_block_type(
			'bookflow/booking-form',
			array(
				'attributes'      => array(
					'service'  => array(
						'type'    => 'string',
						'default' => '',
					),
					'staff'    => array(
						'type'    => 'string',
						'default' => '',
					),
					'location' => array(
						'type'    => 'string',
						'default' => '',
					),
					'layout'   => array(
						'type'    => 'string',
						'default' => 'classic',
					),
				),
				'render_callback' => array( Booking_Shortcode::class, 'render' ),
				'editor_script'   => self::EDITOR_HANDLE,
				'editor_style'    => self::EDITOR_HANDLE,
			)
		);

		register_block_type(
			'bookflow/scheduling-page',
			array(
				'attributes'      => array(
					'page' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
				'render_callback' => array( Scheduling_Bootstrap::class, 'render_shortcode' ),
				'editor_script'   => self::EDITOR_HANDLE,
				'editor_style'    => self::EDITOR_HANDLE,
			)
		);

		register_block_type(
			'bookflow/event-booking',
			array(
				'attributes'      => array(
					'event' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
				'render_callback' => array( Events_Bootstrap::class, 'render_shortcode' ),
				'editor_script'   => self::EDITOR_HANDLE,
				'editor_style'    => self::EDITOR_HANDLE,
			)
		);
	}

	/**
	 * Hand the editor script the option lists its Inspector Controls need (services, staff,
	 * locations, scheduling pages, upcoming events) — embedded inline rather than fetched via a
	 * custom REST endpoint, consistent with the rest of this module's no-custom-REST-API
	 * approach. Small, bounded lists (a site's own configured services/staff/etc.), refreshed
	 * on every editor load.
	 */
	public static function localize_editor_data(): void {
		$data = array(
			'services'        => array_map(
				static fn( $s ) => array( 'value' => (string) $s->id, 'label' => $s->name ),
				Service_Repository::all( array( 'status' => 'active' ) )
			),
			'staff'           => array_map(
				static fn( $s ) => array( 'value' => (string) $s->id, 'label' => $s->display_name ),
				Staff_Repository::all( array( 'status' => 'active' ) )
			),
			'locations'       => array_map(
				static fn( $l ) => array( 'value' => (string) $l->id, 'label' => $l->name ),
				Location_Repository::all( array( 'status' => 'active' ) )
			),
			'schedulingPages' => array_map(
				static fn( $p ) => array( 'value' => (string) $p->id, 'label' => $p->title ),
				Scheduling_Page_Repository::all( array( 'status' => 'active' ) )
			),
			'events'          => array_map(
				static fn( $e ) => array( 'value' => (string) $e->id, 'label' => $e->title ),
				Event_Repository::all(
					array(
						'status'        => 'published',
						'upcoming_only' => true,
						'limit'         => 100,
					)
				)
			),
		);

		wp_add_inline_script(
			self::EDITOR_HANDLE,
			'window.bookflowBlocksData = ' . wp_json_encode( $data ) . ';',
			'before'
		);
	}
}

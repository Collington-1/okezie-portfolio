<?php
/**
 * Repository for wp_bookflow_custom_fields.
 *
 * @package BookFlow\CustomFields
 */

declare( strict_types = 1 );

namespace BookFlow\CustomFields;

use BookFlow\Database\Repository;
use BookFlow\Support\Timestamps;
use BookFlow\Support\Validation_Exception;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Custom_Field_Repository
 */
final class Custom_Field_Repository extends Repository {

	/**
	 * {@inheritDoc}
	 */
	protected static function table_key(): string {
		return 'custom_fields';
	}

	/**
	 * {@inheritDoc}
	 */
	protected static function formats(): array {
		return array(
			'context'     => '%s',
			'label'       => '%s',
			'field_key'   => '%s',
			'field_type'  => '%s',
			'options'     => '%s',
			'is_required' => '%d',
			'sort_order'  => '%d',
			'scope_id'    => '%d',
			'created_at'  => '%s',
			'updated_at'  => '%s',
		);
	}

	/**
	 * Fetch a field by ID.
	 */
	public static function find( int $id ): ?Custom_Field {
		$row = parent::find_row( $id );

		return $row ? Custom_Field::from_row( $row ) : null;
	}

	/**
	 * All fields for one context, filtered to those that apply to a given item: fields with no
	 * scope (apply to every item in the context) plus fields scoped specifically to $scope_id.
	 *
	 * @param string   $context 'appointment' | 'event' | 'scheduling_page'.
	 * @param int|null $scope_id Item ID (service ID for 'appointment', scheduling page ID for
	 *                            'scheduling_page'), or null to fetch only the unscoped
	 *                            (global-within-context) fields.
	 * @return array<int, Custom_Field>
	 */
	public static function for_context( string $context, ?int $scope_id = null ): array {
		global $wpdb;

		$table = static::table();

		if ( null === $scope_id ) {
			$sql = $wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
				"SELECT * FROM {$table} WHERE context = %s AND scope_id IS NULL ORDER BY sort_order ASC, id ASC",
				$context
			);
		} else {
			$sql = $wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
				"SELECT * FROM {$table} WHERE context = %s AND (scope_id IS NULL OR scope_id = %d) ORDER BY sort_order ASC, id ASC",
				$context,
				$scope_id
			);
		}

		$rows = $wpdb->get_results( $sql, ARRAY_A );

		return array_map( array( Custom_Field::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * All fields, optionally filtered by context — the admin management screen's data source.
	 *
	 * @param array{context?: string} $args Filter args.
	 * @return array<int, Custom_Field>
	 */
	public static function all( array $args = array() ): array {
		global $wpdb;

		$table = static::table();

		if ( ! empty( $args['context'] ) ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant.
			$sql  = $wpdb->prepare( "SELECT * FROM {$table} WHERE context = %s ORDER BY context ASC, sort_order ASC, id ASC", $args['context'] );
		} else {
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a trusted constant, no placeholders needed.
			$sql = "SELECT * FROM {$table} ORDER BY context ASC, sort_order ASC, id ASC";
		}

		$rows = $wpdb->get_results( $sql, ARRAY_A );

		return array_map( array( Custom_Field::class, 'from_row' ), $rows ? $rows : array() );
	}

	/**
	 * Create a field.
	 *
	 * @param array<string, mixed> $input Raw input.
	 *
	 * @throws Validation_Exception When input fails validation.
	 */
	public static function create( array $input ): Custom_Field {
		$data                = self::validate( $input, null );
		$data['created_at']  = Timestamps::now();
		$data['updated_at']  = $data['created_at'];

		$id = parent::insert( $data );

		return self::find( $id );
	}

	/**
	 * Update a field. Fields absent from $input keep their current value.
	 *
	 * @param int                  $id    Field ID.
	 * @param array<string, mixed> $input Raw partial input.
	 *
	 * @throws \InvalidArgumentException When the field does not exist.
	 * @throws Validation_Exception       When input fails validation.
	 */
	public static function update( int $id, array $input ): Custom_Field {
		$existing = parent::find_row( $id );

		if ( null === $existing ) {
			throw new \InvalidArgumentException( sprintf( 'BookFlow: custom field %d not found.', $id ) );
		}

		$data               = self::validate( $input, $existing );
		$data['updated_at'] = Timestamps::now();

		parent::update_row( $id, $data );

		return self::find( $id );
	}

	/**
	 * Validate and sanitize raw input.
	 *
	 * @param array<string, mixed>      $input    Raw input.
	 * @param array<string, mixed>|null $existing Existing raw row, for partial updates.
	 *
	 * @throws Validation_Exception When input fails validation.
	 *
	 * @return array<string, mixed>
	 */
	private static function validate( array $input, ?array $existing ): array {
		$get = static function ( string $key, $default ) use ( $input, $existing ) {
			if ( array_key_exists( $key, $input ) ) {
				return $input[ $key ];
			}

			if ( null !== $existing && array_key_exists( $key, $existing ) ) {
				return $existing[ $key ];
			}

			return $default;
		};

		$errors = array();

		$context = (string) $get( 'context', '' );

		if ( ! in_array( $context, Custom_Field::contexts(), true ) ) {
			$errors['context'] = __( 'Invalid field context.', 'bookflow-booking-scheduling' );
		}

		$label = trim( sanitize_text_field( (string) $get( 'label', '' ) ) );

		if ( '' === $label ) {
			$errors['label'] = __( 'Question label is required.', 'bookflow-booking-scheduling' );
		}

		$field_type = (string) $get( 'field_type', 'text' );

		if ( ! in_array( $field_type, Custom_Field::field_types(), true ) ) {
			$errors['field_type'] = __( 'Invalid field type.', 'bookflow-booking-scheduling' );
		}

		$options_raw = $get( 'options', array() );
		$options     = array();

		if ( is_string( $options_raw ) ) {
			// Admin form convenience: one choice per line.
			$options = array_values( array_filter( array_map( 'trim', explode( "\n", $options_raw ) ) ) );
		} elseif ( is_array( $options_raw ) ) {
			$options = array_values( array_filter( array_map( 'trim', array_map( 'strval', $options_raw ) ) ) );
		}

		if ( in_array( $field_type, Custom_Field::choice_types(), true ) && empty( $options ) ) {
			$errors['options'] = __( 'Please provide at least one option.', 'bookflow-booking-scheduling' );
		}

		if ( ! empty( $errors ) ) {
			throw new Validation_Exception( $errors, __( 'The question could not be saved.', 'bookflow-booking-scheduling' ) );
		}

		$field_key_raw = trim( (string) $get( 'field_key', '' ) );
		$field_key     = '' !== $field_key_raw ? sanitize_key( $field_key_raw ) : sanitize_key( $label );

		if ( '' === $field_key ) {
			$field_key = 'field_' . substr( md5( $label . microtime() ), 0, 8 );
		}

		$scope_id_raw = $get( 'scope_id', null );
		$scope_id     = ( null !== $scope_id_raw && '' !== $scope_id_raw ) ? absint( $scope_id_raw ) : null;

		return array(
			'context'     => $context,
			'label'       => $label,
			'field_key'   => $field_key,
			'field_type'  => $field_type,
			'options'     => wp_json_encode( $options ),
			'is_required' => ! empty( $get( 'is_required', false ) ) ? 1 : 0,
			'sort_order'  => (int) $get( 'sort_order', 0 ),
			'scope_id'    => $scope_id,
		);
	}
}

<?php
/**
 * Custom booking question entity — one row of wp_bookflow_custom_fields. A field *definition*;
 * answers are stored as a JSON snapshot directly on the appointment/attendee row that used them
 * (see docs/DATABASE-SCHEMA.md's rationale for not using a separate EAV values table).
 *
 * @package BookFlow\CustomFields
 */

declare( strict_types = 1 );

namespace BookFlow\CustomFields;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Custom_Field
 */
final class Custom_Field {

	/**
	 * Constructor.
	 *
	 * @param int         $id          Row ID.
	 * @param string      $context     'appointment' | 'event' | 'scheduling_page'.
	 * @param string      $label       Question label shown to the customer.
	 * @param string      $field_key   Stable machine key (used as the answer's storage key).
	 * @param string      $field_type  'text' | 'textarea' | 'select' | 'checkbox' | 'radio' | 'phone' | 'email' | 'number'.
	 * @param array<int, string> $options Choices, for select/radio.
	 * @param bool        $is_required Whether an answer is required.
	 * @param int         $sort_order  Display order.
	 * @param int|null    $scope_id    Ties the field to one service/scheduling page/event; null = applies to every item in this context.
	 * @param string      $created_at  UTC DATETIME string.
	 * @param string      $updated_at  UTC DATETIME string.
	 */
	public function __construct(
		public int $id,
		public string $context,
		public string $label,
		public string $field_key,
		public string $field_type,
		public array $options,
		public bool $is_required,
		public int $sort_order,
		public ?int $scope_id,
		public string $created_at,
		public string $updated_at
	) {}

	/**
	 * Recognised `context` values.
	 *
	 * @return array<int, string>
	 */
	public static function contexts(): array {
		return array( 'appointment', 'event', 'scheduling_page' );
	}

	/**
	 * Recognised `field_type` values.
	 *
	 * @return array<int, string>
	 */
	public static function field_types(): array {
		return array( 'text', 'textarea', 'select', 'checkbox', 'radio', 'phone', 'email', 'number' );
	}

	/**
	 * Field types that present a fixed set of choices (options are meaningful).
	 *
	 * @return array<int, string>
	 */
	public static function choice_types(): array {
		return array( 'select', 'radio' );
	}

	/**
	 * Build from a raw database row.
	 *
	 * @param array<string, mixed> $row Raw row.
	 */
	public static function from_row( array $row ): self {
		return new self(
			(int) $row['id'],
			(string) $row['context'],
			(string) $row['label'],
			(string) $row['field_key'],
			(string) $row['field_type'],
			self::decode_options( $row['options'] ?? null ),
			! empty( $row['is_required'] ),
			(int) $row['sort_order'],
			isset( $row['scope_id'] ) && null !== $row['scope_id'] ? (int) $row['scope_id'] : null,
			(string) $row['created_at'],
			(string) $row['updated_at']
		);
	}

	/**
	 * Decode the options JSON column, tolerating null/malformed values.
	 *
	 * @param string|null $json Raw JSON string.
	 * @return array<int, string>
	 */
	private static function decode_options( ?string $json ): array {
		if ( null === $json || '' === $json ) {
			return array();
		}

		$decoded = json_decode( $json, true );

		return is_array( $decoded ) ? array_values( array_map( 'strval', $decoded ) ) : array();
	}

	/**
	 * Validate one submitted answer against this field's rules, returning a translated error
	 * message, or null if the answer is acceptable. Shared by every booking entry point
	 * (frontend AJAX today; REST/admin-created bookings can reuse it later) so "is this answer
	 * valid" is defined in exactly one place.
	 *
	 * @param mixed $value Submitted answer.
	 */
	public function validate_answer( $value ): ?string {
		$is_blank = null === $value || '' === trim( (string) $value );

		if ( $this->is_required && $is_blank ) {
			return __( 'This field is required.', 'bookflow-booking-scheduling' );
		}

		if ( $is_blank ) {
			return null;
		}

		if ( 'email' === $this->field_type && ! is_email( (string) $value ) ) {
			return __( 'Please enter a valid email address.', 'bookflow-booking-scheduling' );
		}

		if ( 'number' === $this->field_type && ! is_numeric( $value ) ) {
			return __( 'Please enter a number.', 'bookflow-booking-scheduling' );
		}

		if ( in_array( $this->field_type, self::choice_types(), true ) && ! in_array( (string) $value, $this->options, true ) ) {
			return __( 'Please choose one of the available options.', 'bookflow-booking-scheduling' );
		}

		return null;
	}

	/**
	 * Sanitize one submitted answer for storage, appropriate to this field's type.
	 *
	 * @param mixed $value Raw submitted value.
	 */
	public function sanitize_answer( $value ): string {
		if ( 'textarea' === $this->field_type ) {
			return sanitize_textarea_field( (string) $value );
		}

		return sanitize_text_field( (string) $value );
	}
}

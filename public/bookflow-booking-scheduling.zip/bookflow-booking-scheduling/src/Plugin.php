<?php
/**
 * Plugin bootstrap.
 *
 * @package BookFlow
 */

declare( strict_types = 1 );

namespace BookFlow;

use BookFlow\Database\Migrator;
use BookFlow\Support\Capabilities;
use BookFlow\Support\Constants;
use BookFlow\Support\Requirements;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Plugin
 *
 * Deliberately thin: each functional area (Admin, Frontend, Api, Blocks, Booking, Scheduling,
 * Events, Notifications, Settings, ...) owns a bootstrap method that this class calls. A module
 * that isn't implemented yet (later phases) simply isn't called yet — nothing here should ever
 * need to change shape as modules are added, only gain one more line in boot_modules().
 */
final class Plugin {

	/**
	 * Whether boot() has already run, to guard against the plugins_loaded hook firing twice
	 * (e.g. a host that includes the plugin file more than once).
	 *
	 * @var bool
	 */
	private static bool $booted = false;

	/**
	 * Boot the plugin. Hooked to `plugins_loaded`.
	 */
	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		if ( ! Requirements::satisfied() ) {
			add_action( 'admin_notices', array( self::class, 'render_unsupported_environment_notice' ) );
			return;
		}

		self::load_textdomain();

		Capabilities::init();
		Migrator::maybe_upgrade();

		self::boot_modules();

		/**
		 * Fires once BookFlow has finished booting. Premium and third-party integrations should
		 * hook their own bootstrap here rather than on plugins_loaded directly, to guarantee
		 * BookFlow's core (capabilities, schema, module registry) is ready first.
		 */
		do_action( 'bookflow_loaded' );
	}

	/**
	 * Load the plugin's translations.
	 */
	private static function load_textdomain(): void {
		load_plugin_textdomain(
			Constants::TEXT_DOMAIN,
			false,
			dirname( plugin_basename( BOOKFLOW_PLUGIN_FILE ) ) . '/languages'
		);
	}

	/**
	 * Boot each functional module. Modules not yet implemented are commented with the phase
	 * that will introduce them — see docs/ROADMAP.md.
	 */
	private static function boot_modules(): void {
		// Services/Staff/Locations/Customers (Phase 2) and Booking (Phase 3) are domain
		// libraries called directly by their consumers (Admin, and later Frontend/Api) — they
		// register no WordPress hooks of their own, so there is nothing to boot here for them.
		// A Bootstrap::init() with nothing to hook would be exactly the kind of placeholder
		// Section 29 says to avoid.
		if ( is_admin() ) {
			Admin\Bootstrap::init();
		}

		// Not gated behind is_admin(): its wp_ajax_*/wp_ajax_nopriv_* handlers run through
		// admin-ajax.php, which reports is_admin() === true, so gating this the same way as
		// Admin\Bootstrap would silently break the booking widget's AJAX calls.
		Frontend\Bootstrap::init();

		// Registers the public /schedule/{slug} rewrite route — needed on every request
		// (frontend to serve the page, admin-ajax.php requests reuse Frontend\Ajax_Handlers
		// directly and don't need this, but there's no harm registering it universally like
		// Frontend\Bootstrap above).
		Scheduling\Bootstrap::init();

		// Registers the public /events/{slug} route and the (non-AJAX, plain-form) registration
		// + cancel handlers — see Events\Bootstrap's own docblock for why this module has no JS.
		Events\Bootstrap::init();

		// Listens on the lifecycle hooks Booking/Events fire (bookflow_appointment_created,
		// etc.) — needed on every request type those can fire from (frontend widget,
		// admin-ajax.php, and the admin "Add Booking"/status-transition screens alike).
		Notifications\Bootstrap::init();

		// Not gated behind is_admin(): register_block_type() must run on every request, not
		// just in wp-admin — rendering a post's content that contains one of these blocks needs
		// the block type registered server-side too, so its render_callback can run. The
		// enqueue_block_editor_assets hook Bootstrap also registers only ever fires inside the
		// block editor itself; WordPress handles that gating, not us.
		Blocks\Bootstrap::init();

		// Not gated behind is_admin(): Elementor's own widget registration hooks
		// (elementor/widgets/register, elementor/elements/categories_registered) fire on every
		// request that boots Elementor, including the public-facing render of a page that uses
		// one of these widgets, not just its own admin-side editor. Bootstrap::init() itself is a
		// complete no-op whenever Elementor isn't active — see its own docblock.
		Elementor\Bootstrap::init();

		// A public REST API is explicitly a Premium "developer feature" (master spec §3), not
		// Free scope — see src/Blocks/Bootstrap.php's docblock for how the block editor's own
		// live preview avoids needing one anyway (core's built-in block-renderer route).
	}

	/**
	 * Admin notice shown when the environment does not meet BookFlow's minimum requirements.
	 * Kept static/stateless and only registered when actually needed, per Section 29 ("Do not
	 * create unnecessary admin notices").
	 */
	public static function render_unsupported_environment_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		printf(
			'<div class="notice notice-error"><p>%s</p></div>',
			esc_html( Requirements::explanation() )
		);
	}
}

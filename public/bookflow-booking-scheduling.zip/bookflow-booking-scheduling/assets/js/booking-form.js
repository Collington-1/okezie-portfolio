/**
 * BookFlow booking widget — vanilla JavaScript, no build step (see docs/ARCHITECTURE.md §18 for
 * why: it keeps the frontend framework-free and independently verifiable file-by-file). Finds
 * every `[data-bookflow-widget="booking"]` container on the page and drives it through a small
 * step state machine, talking to the server only via the AJAX actions registered in
 * BookFlow\Frontend\Ajax_Handlers.
 *
 * No dependency on jQuery or any bundler-provided global; only standard browser APIs
 * (fetch, DOM, Intl) that have been baseline-available for years.
 */
( function () {
	'use strict';

	/**
	 * Build a DOM element. A tiny helper so dynamic text always goes through textContent/props
	 * (never innerHTML) — safe by construction against XSS regardless of what the config data
	 * contains.
	 *
	 * @param {string} tag
	 * @param {Object} [props]
	 * @param {Array<Node|string>} [children]
	 * @return {HTMLElement}
	 */
	function el( tag, props, children ) {
		var node = document.createElement( tag );

		if ( props ) {
			Object.keys( props ).forEach( function ( key ) {
				var value = props[ key ];

				if ( 'class' === key ) {
					node.className = value;
				} else if ( 'text' === key ) {
					node.textContent = value;
				} else if ( key.indexOf( 'on' ) === 0 && 'function' === typeof value ) {
					node.addEventListener( key.slice( 2 ).toLowerCase(), value );
				} else if ( 'html' === key ) {
					// Only ever used for the tiny, fixed, translator-controlled i18n strings
					// that legitimately need inline markup (currently unused, kept for clarity
					// that plain string interpolation into innerHTML is deliberately avoided).
					node.innerHTML = value; // eslint-disable-line no-unsanitized/property
				} else {
					node.setAttribute( key, value );
				}
			} );
		}

		( children || [] ).forEach( function ( child ) {
			if ( null === child || undefined === child ) {
				return;
			}
			node.appendChild( 'string' === typeof child ? document.createTextNode( child ) : child );
		} );

		return node;
	}

	/**
	 * Remove all children of a node.
	 *
	 * @param {HTMLElement} node
	 */
	function empty( node ) {
		while ( node.firstChild ) {
			node.removeChild( node.firstChild );
		}
	}

	/**
	 * The customer's own timezone, best-effort. Falls back to the site timezone (already in
	 * config) if the browser cannot report one.
	 *
	 * @param {Object} config
	 * @return {string}
	 */
	function detectTimezone( config ) {
		try {
			var tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
			return tz || config.siteTimezone;
		} catch ( e ) {
			return config.siteTimezone;
		}
	}

	/**
	 * 'YYYY-MM-DD' for a given Date, in a given IANA timezone.
	 *
	 * @param {Date} date
	 * @param {string} timezone
	 * @return {string}
	 */
	function isoDateInTimezone( date, timezone ) {
		var formatter = new Intl.DateTimeFormat( 'en-CA', {
			timeZone: timezone,
			year: 'numeric',
			month: '2-digit',
			day: '2-digit',
		} );
		// en-CA formats as YYYY-MM-DD directly.
		return formatter.format( date );
	}

	/**
	 * Today's date, as 'YYYY-MM-DD', in the given timezone.
	 *
	 * @param {string} timezone
	 * @return {string}
	 */
	function todayInTimezone( timezone ) {
		return isoDateInTimezone( new Date(), timezone );
	}

	/**
	 * Add N days to a 'YYYY-MM-DD' date string, returning a new 'YYYY-MM-DD' string. Uses noon
	 * UTC as the anchor instant so DST/timezone edge cases near midnight never shift the
	 * calendar date under simple day arithmetic.
	 *
	 * @param {string} dateStr
	 * @param {number} days
	 * @return {string}
	 */
	function addDays( dateStr, days ) {
		var parts = dateStr.split( '-' ).map( Number );
		var d = new Date( Date.UTC( parts[ 0 ], parts[ 1 ] - 1, parts[ 2 ], 12, 0, 0 ) );
		d.setUTCDate( d.getUTCDate() + days );
		return d.toISOString().slice( 0, 10 );
	}

	/**
	 * Human-readable heading for a 'YYYY-MM-DD' date, e.g. "Tuesday, March 10, 2026".
	 *
	 * @param {string} dateStr
	 * @return {string}
	 */
	function formatDateHeading( dateStr ) {
		var parts = dateStr.split( '-' ).map( Number );
		var d = new Date( Date.UTC( parts[ 0 ], parts[ 1 ] - 1, parts[ 2 ], 12, 0, 0 ) );
		return new Intl.DateTimeFormat( undefined, {
			timeZone: 'UTC',
			weekday: 'long',
			year: 'numeric',
			month: 'long',
			day: 'numeric',
		} ).format( d );
	}

	/**
	 * Format an ISO instant as a local time-of-day string in the given timezone, e.g. "2:30 PM".
	 *
	 * @param {string} isoString
	 * @param {string} timezone
	 * @return {string}
	 */
	function formatSlotTime( isoString, timezone ) {
		var d = new Date( isoString );
		return new Intl.DateTimeFormat( undefined, {
			timeZone: timezone,
			hour: 'numeric',
			minute: '2-digit',
		} ).format( d );
	}

	/**
	 * POST to admin-ajax.php and return the parsed JSON body, regardless of HTTP status code
	 * (wp_send_json_error() sets a non-2xx status; the body is still the shape to read).
	 *
	 * @param {Object} config
	 * @param {string} action
	 * @param {Object} params
	 * @return {Promise<{success: boolean, data: Object}>}
	 */
	function apiPost( config, action, params ) {
		var body = new URLSearchParams();
		body.set( 'action', action );
		body.set( 'nonce', config.nonce );

		Object.keys( params || {} ).forEach( function ( key ) {
			var value = params[ key ];
			if ( null !== value && undefined !== value ) {
				body.set( key, value );
			}
		} );

		return fetch( config.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: body.toString(),
		} )
			.then( function ( response ) {
				return response.json();
			} )
			.catch( function () {
				return { success: false, data: { message: null } };
			} );
	}

	/**
	 * One widget instance: owns its DOM container, config, and step state.
	 *
	 * @param {HTMLElement} container
	 */
	function Widget( container ) {
		this.container = container;
		this.config = JSON.parse( container.getAttribute( 'data-config' ) || '{}' );
		this.i18n = this.config.i18n || {};
		this.timezone = detectTimezone( this.config );
		this.isReschedule = !! this.config.reschedule;

		this.selection = {
			serviceId: this.config.lockedServiceId || null,
			staffId: this.config.lockedStaffId || null,
			locationId: this.config.lockedLocationId || null,
			date: null,
			slot: null,
			firstName: '',
			lastName: '',
			email: '',
			phone: '',
			notes: '',
			customFieldAnswers: {},
		};

		this.slotsCache = {};
		this.submitting = false;

		// Set once the first render has happened — see render()'s focus-management comment.
		this._mounted = false;

		this.start();
	}

	Widget.prototype.t = function ( key, fallback ) {
		return this.i18n[ key ] || fallback || key;
	};

	Widget.prototype.selectedService = function () {
		var self = this;
		return ( this.config.services || [] ).filter( function ( s ) {
			return s.id === self.selection.serviceId;
		} )[ 0 ] || null;
	};

	/**
	 * The custom questions that apply right now: the scheduling page's own set when booking
	 * through one (config.customFields — the same regardless of which of the page's services is
	 * picked), otherwise the selected service's own set.
	 *
	 * @return {Array}
	 */
	Widget.prototype.activeCustomFields = function () {
		if ( this.config.schedulingPageId && ( this.config.customFields || [] ).length ) {
			return this.config.customFields;
		}
		var service = this.selectedService();
		return ( service && service.customFields ) || [];
	};

	Widget.prototype.staffOptionsForSelectedService = function () {
		var service = this.selectedService();
		if ( ! service ) {
			return [];
		}
		return ( this.config.staff || [] ).filter( function ( person ) {
			return service.staffIds.indexOf( person.id ) !== -1;
		} );
	};

	Widget.prototype.locationOptionsForSelectedService = function () {
		var service = this.selectedService();
		if ( ! service ) {
			return [];
		}
		return ( this.config.locations || [] ).filter( function ( loc ) {
			return service.locationIds.indexOf( loc.id ) !== -1;
		} );
	};

	/**
	 * Entry point: figure out the first step and render it.
	 */
	Widget.prototype.start = function () {
		if ( this.isReschedule ) {
			this.goToDateStep();
			return;
		}
		this.goToStep( 'service' );
	};

	/**
	 * Advance to whichever of staff/location/date is next after the service (or staff, or
	 * location) has just been chosen — auto-skipping a step when there is only one option.
	 */
	Widget.prototype.goToStaffOrNext = function () {
		var options = this.staffOptionsForSelectedService();
		if ( options.length <= 1 ) {
			this.selection.staffId = options.length === 1 ? options[ 0 ].id : null;
			this.goToLocationOrNext();
			return;
		}
		this.goToStep( 'staff' );
	};

	Widget.prototype.goToLocationOrNext = function () {
		var options = this.locationOptionsForSelectedService();
		if ( options.length <= 1 ) {
			this.selection.locationId = options.length === 1 ? options[ 0 ].id : null;
			this.goToDateStep();
			return;
		}
		this.goToStep( 'location' );
	};

	Widget.prototype.goToDateStep = function () {
		if ( 'express' === this.config.layout && ! this.isReschedule ) {
			this.goToStep( 'searching' );
			this.findSoonestDay();
			return;
		}
		this.goToStep( 'date' );
	};

	/**
	 * Render whichever step is now current.
	 *
	 * @param {string} step
	 */
	Widget.prototype.goToStep = function ( step ) {
		this.step = step;
		this.render();
	};

	/**
	 * Fetch slots for the currently selected date, caching by the full selection key.
	 *
	 * @return {Promise<Array>}
	 */
	Widget.prototype.fetchSlots = function ( dateStr ) {
		var self = this;
		var service = this.selectedService();
		var cacheKey = [ service.id, this.selection.staffId, this.selection.locationId, dateStr, this.timezone ].join( '|' );

		if ( this.slotsCache[ cacheKey ] ) {
			return Promise.resolve( this.slotsCache[ cacheKey ] );
		}

		var params = {
			service_id: service.id,
			staff_id: this.selection.staffId,
			location_id: this.selection.locationId,
			date: dateStr,
			timezone: this.timezone,
		};

		if ( this.isReschedule ) {
			params.appointment_token = this.config.reschedule.token;
		}

		if ( this.config.schedulingPageId ) {
			params.scheduling_page_id = this.config.schedulingPageId;
		}

		return apiPost( this.config, 'bookflow_get_slots', params ).then( function ( response ) {
			var slots = response.success && response.data && response.data.slots ? response.data.slots : [];
			self.slotsCache[ cacheKey ] = slots;
			return slots;
		} );
	};

	/**
	 * Express layout: walk forward day by day (bounded) until a day with at least one slot is
	 * found, then land on the time step for that day.
	 */
	Widget.prototype.findSoonestDay = function () {
		var self = this;
		var earliest = todayInTimezone( this.timezone );
		var maxDaysToScan = 60;

		function tryDay( offset ) {
			if ( offset > maxDaysToScan ) {
				self.selection.date = earliest;
				self.lastSlots = [];
				self.goToStep( 'time' );
				return;
			}

			var dateStr = addDays( earliest, offset );

			self.fetchSlots( dateStr ).then( function ( slots ) {
				if ( slots.length > 0 ) {
					self.selection.date = dateStr;
					self.lastSlots = slots;
					self.goToStep( 'time' );
				} else {
					tryDay( offset + 1 );
				}
			} );
		}

		tryDay( 0 );
	};

	/**
	 * Date step: fetch and render slots for the currently selected date.
	 */
	Widget.prototype.loadTimeStep = function () {
		var self = this;
		this.goToStep( 'time-loading' );
		this.fetchSlots( this.selection.date ).then( function ( slots ) {
			self.lastSlots = slots;
			self.goToStep( 'time' );
		} );
	};

	/**
	 * Submit the booking (create, or reschedule if in reschedule mode).
	 */
	Widget.prototype.submit = function () {
		var self = this;

		if ( this.submitting ) {
			return;
		}
		this.submitting = true;
		this.goToStep( 'submitting' );

		var service = this.selectedService();
		var params = {
			service_id: service.id,
			staff_id: this.selection.staffId,
			location_id: this.selection.locationId,
			start: this.selection.slot.start,
			timezone: this.timezone,
		};

		var action = 'bookflow_create_booking';

		if ( this.isReschedule ) {
			action = 'bookflow_reschedule_booking';
			params.token = this.config.reschedule.token;
		} else {
			params.first_name = this.selection.firstName;
			params.last_name = this.selection.lastName;
			params.email = this.selection.email;
			params.phone = this.selection.phone;
			params.notes = this.selection.notes;
			params.custom_fields = JSON.stringify( this.selection.customFieldAnswers );

			if ( this.config.schedulingPageId ) {
				params.scheduling_page_id = this.config.schedulingPageId;
			}
		}

		apiPost( this.config, action, params ).then( function ( response ) {
			self.submitting = false;

			if ( response.success ) {
				self.result = response.data;
				self.goToStep( 'success' );
			} else {
				self.submitError = ( response.data && response.data.message ) || self.t( 'genericError' );
				self.fieldErrors = ( response.data && response.data.errors ) || {};
				self.goToStep( self.isReschedule ? 'time' : 'confirm' );
			}
		} );
	};

	/* ---------------------------------------------------------------------
	 * Rendering
	 * ------------------------------------------------------------------- */

	Widget.prototype.render = function () {
		empty( this.container );

		var body = el( 'div', { class: 'bookflow-body' } );

		if ( this.submitError && 'confirm' !== this.step && 'time' !== this.step ) {
			this.submitError = null;
		}

		switch ( this.step ) {
			case 'service':
				body.appendChild( this.renderServiceStep() );
				break;
			case 'staff':
				body.appendChild( this.renderStaffStep() );
				break;
			case 'location':
				body.appendChild( this.renderLocationStep() );
				break;
			case 'date':
				body.appendChild( this.renderDateStep() );
				break;
			case 'searching':
				body.appendChild( this.renderMessage( this.t( 'searchingSoonest' ) ) );
				break;
			case 'time-loading':
				body.appendChild( this.renderMessage( this.t( 'loading' ) ) );
				break;
			case 'time':
				body.appendChild( this.renderTimeStep() );
				break;
			case 'details':
				body.appendChild( this.renderDetailsStep() );
				break;
			case 'confirm':
				body.appendChild( this.renderConfirmStep() );
				break;
			case 'submitting':
				body.appendChild( this.renderMessage( this.t( 'submitting' ) ) );
				break;
			case 'success':
				body.appendChild( this.renderSuccessStep() );
				break;
			default:
				body.appendChild( this.renderMessage( this.t( 'loading' ) ) );
		}

		this.container.appendChild( body );

		// The container is fully replaced on every render, so a step transition (service ->
		// staff -> date -> time -> details -> confirm -> success) is otherwise silent to
		// screen-reader and keyboard users: nothing is announced and focus stays wherever it
		// was, often on a button that no longer exists in the DOM. Moving focus to the new
		// step's heading both announces it (assistive tech reads focused content) and gives
		// keyboard users a sane tab order starting point. Skipped on the very first render —
		// stealing focus on page load, before the user interacted with the widget at all,
		// would be disruptive rather than helpful. The transient loading/searching/submitting
		// messages use aria-live in renderMessage() instead of a focus move, since they render
		// and clear too quickly for a focus jump to be useful.
		if ( this._mounted ) {
			var heading = body.querySelector( '.bookflow-step-title' );
			if ( heading ) {
				heading.setAttribute( 'tabindex', '-1' );
				heading.focus();
			}
		}
		this._mounted = true;
	};

	Widget.prototype.renderMessage = function ( text ) {
		return el( 'div', { class: 'bookflow-message', 'aria-live': 'polite' }, [ text ] );
	};

	Widget.prototype.renderBackLink = function ( label, handler ) {
		return el( 'button', { type: 'button', class: 'bookflow-back-link', onClick: handler.bind( this ) }, [ '← ' + label ] );
	};

	Widget.prototype.renderServiceStep = function () {
		var self = this;
		var wrap = el( 'div', { class: 'bookflow-step bookflow-step--service' } );
		wrap.appendChild( el( 'h3', { class: 'bookflow-step-title' }, [ this.t( 'selectService' ) ] ) );

		var list = el( 'div', { class: 'bookflow-service-list' } );

		( this.config.services || [] ).forEach( function ( service ) {
			var meta = [ service.durationMinutes + ' ' + self.t( 'minutes' ) ];
			if ( service.price ) {
				meta.push( service.price + ( service.currency ? ' ' + service.currency : '' ) );
			}

			var card = el(
				'button',
				{
					type: 'button',
					class: 'bookflow-service-card',
					onClick: function () {
						self.selection.serviceId = service.id;
						self.selection.staffId = null;
						self.selection.locationId = null;
						self.goToStaffOrNext();
					},
				},
				[
					el( 'span', { class: 'bookflow-service-card__name' }, [ service.name ] ),
					service.description ? el( 'span', { class: 'bookflow-service-card__description' }, [ service.description ] ) : null,
					el( 'span', { class: 'bookflow-service-card__meta' }, [ meta.join( ' · ' ) ] ),
				]
			);

			list.appendChild( card );
		} );

		wrap.appendChild( list );
		return wrap;
	};

	Widget.prototype.renderOptionListStep = function ( title, options, currentValue, onPick, includeNoPreference ) {
		var self = this;
		var wrap = el( 'div', { class: 'bookflow-step' } );
		wrap.appendChild( el( 'h3', { class: 'bookflow-step-title' }, [ title ] ) );

		var list = el( 'div', { class: 'bookflow-option-list' } );

		if ( includeNoPreference ) {
			list.appendChild(
				el(
					'button',
					{ type: 'button', class: 'bookflow-option-button', onClick: function () { onPick( null ); } },
					[ this.t( 'noPreference' ) ]
				)
			);
		}

		options.forEach( function ( option ) {
			list.appendChild(
				el(
					'button',
					{ type: 'button', class: 'bookflow-option-button', onClick: function () { onPick( option.id ); } },
					[ option.name ]
				)
			);
		} );

		wrap.appendChild( list );
		return wrap;
	};

	Widget.prototype.renderStaffStep = function () {
		var self = this;
		return this.renderOptionListStep(
			this.t( 'selectStaff' ),
			this.staffOptionsForSelectedService(),
			this.selection.staffId,
			function ( id ) {
				self.selection.staffId = id;
				self.goToLocationOrNext();
			},
			true
		);
	};

	Widget.prototype.renderLocationStep = function () {
		var self = this;
		return this.renderOptionListStep(
			this.t( 'selectLocation' ),
			this.locationOptionsForSelectedService(),
			this.selection.locationId,
			function ( id ) {
				self.selection.locationId = id;
				self.goToDateStep();
			},
			false
		);
	};

	Widget.prototype.renderDateStep = function () {
		var self = this;
		var wrap = el( 'div', { class: 'bookflow-step bookflow-step--date' } );
		wrap.appendChild( el( 'h3', { class: 'bookflow-step-title' }, [ this.t( 'selectDate' ) ] ) );

		var min = todayInTimezone( this.timezone );
		var input = el( 'input', {
			type: 'date',
			class: 'bookflow-date-input',
			min: min,
			value: this.selection.date || min,
		} );

		input.addEventListener( 'change', function () {
			self.selection.date = input.value;
			self.loadTimeStep();
		} );

		wrap.appendChild( input );

		var goButton = el(
			'button',
			{
				type: 'button',
				class: 'bookflow-button bookflow-button--primary',
				onClick: function () {
					self.selection.date = input.value;
					self.loadTimeStep();
				},
			},
			[ this.t( 'next' ) ]
		);
		wrap.appendChild( goButton );

		return wrap;
	};

	Widget.prototype.renderTimeStep = function () {
		var self = this;
		var wrap = el( 'div', { class: 'bookflow-step bookflow-step--time' } );

		wrap.appendChild( el( 'h3', { class: 'bookflow-step-title' }, [ formatDateHeading( this.selection.date ) ] ) );

		if ( this.submitError ) {
			wrap.appendChild( el( 'p', { class: 'bookflow-error-banner', role: 'alert' }, [ this.submitError ] ) );
		}

		var slots = this.lastSlots || [];

		if ( 0 === slots.length ) {
			wrap.appendChild( el( 'p', { class: 'bookflow-empty' }, [ this.t( 'noSlots' ) ] ) );
		} else {
			var list = el( 'div', { class: 'bookflow-slot-list' } );
			slots.forEach( function ( slot ) {
				list.appendChild(
					el(
						'button',
						{
							type: 'button',
							class: 'bookflow-slot-button',
							onClick: function () {
								self.selection.slot = slot;
								self.goToStep( self.isReschedule ? 'confirm' : 'details' );
							},
						},
						[ formatSlotTime( slot.start, self.timezone ) ]
					)
				);
			} );
			wrap.appendChild( list );
		}

		// Reschedule mode never auto-searched for a soonest day (see goToDateStep()), so it
		// always wants the inline date input to change days — never the express-only "choose a
		// different day" link, which only makes sense after an auto-search.
		if ( 'express' === this.config.layout && ! this.isReschedule ) {
			wrap.appendChild(
				this.renderBackLink( this.t( 'differentDay' ), function () {
					this.goToStep( 'date' );
				} )
			);
		} else {
			wrap.appendChild(
				el(
					'input',
					{
						type: 'date',
						class: 'bookflow-date-input bookflow-date-input--inline',
						min: todayInTimezone( this.timezone ),
						value: this.selection.date,
						onChange: function ( e ) {
							self.selection.date = e.target.value;
							self.loadTimeStep();
						},
					},
					[]
				)
			);
		}

		return wrap;
	};

	Widget.prototype.renderDetailsStep = function () {
		var self = this;
		var wrap = el( 'div', { class: 'bookflow-step bookflow-step--details' } );
		wrap.appendChild( el( 'h3', { class: 'bookflow-step-title' }, [ this.t( 'yourDetails' ) ] ) );

		var form = el( 'div', { class: 'bookflow-form-fields' } );

		function field( key, label, type, required ) {
			var inputId = 'bookflow-field-' + key + '-' + Math.random().toString( 36 ).slice( 2, 8 );
			var fieldWrap = el( 'div', { class: 'bookflow-field' } );
			fieldWrap.appendChild( el( 'label', { for: inputId }, [ label ] ) );
			var input = el( 'input', {
				type: type,
				id: inputId,
				value: self.selection[ key ] || '',
			} );
			if ( required ) {
				input.setAttribute( 'required', 'required' );
			}
			input.addEventListener( 'input', function () {
				self.selection[ key ] = input.value;
			} );
			fieldWrap.appendChild( input );
			return fieldWrap;
		}

		form.appendChild( field( 'firstName', this.t( 'firstName' ), 'text', false ) );
		form.appendChild( field( 'lastName', this.t( 'lastName' ), 'text', false ) );
		form.appendChild( field( 'email', this.t( 'email' ), 'email', true ) );
		form.appendChild( field( 'phone', this.t( 'phone' ), 'tel', false ) );

		var notesId = 'bookflow-notes-' + Math.random().toString( 36 ).slice( 2, 8 );
		var notesWrap = el( 'div', { class: 'bookflow-field' } );
		notesWrap.appendChild( el( 'label', { for: notesId }, [ this.t( 'notes' ) ] ) );
		var notesInput = el( 'textarea', { id: notesId, rows: '3' } );
		notesInput.value = this.selection.notes || '';
		notesInput.addEventListener( 'input', function () {
			self.selection.notes = notesInput.value;
		} );
		notesWrap.appendChild( notesInput );
		form.appendChild( notesWrap );

		var customFields = this.activeCustomFields();
		customFields.forEach( function ( fieldDef ) {
			form.appendChild( self.renderCustomField( fieldDef ) );
		} );

		wrap.appendChild( form );

		var next = el(
			'button',
			{
				type: 'button',
				class: 'bookflow-button bookflow-button--primary',
				onClick: function () {
					if ( ! self.selection.email || -1 === self.selection.email.indexOf( '@' ) ) {
						window.alert( self.t( 'invalidEmail' ) ); // eslint-disable-line no-alert
						return;
					}
					var missing = customFields.filter( function ( fieldDef ) {
						return fieldDef.required && ! self.selection.customFieldAnswers[ fieldDef.key ];
					} );
					if ( missing.length > 0 ) {
						window.alert( self.t( 'requiredField' ) ); // eslint-disable-line no-alert
						return;
					}
					self.goToStep( 'confirm' );
				},
			},
			[ this.t( 'next' ) ]
		);
		wrap.appendChild( next );

		return wrap;
	};

	/**
	 * Render one dynamic custom question (Phase 6), from a field definition of the shape
	 * Widget_Config::custom_fields_payload() produces: { key, label, type, required, options }.
	 * Answers are written into this.selection.customFieldAnswers[ key ].
	 *
	 * @param {Object} fieldDef
	 * @return {HTMLElement}
	 */
	Widget.prototype.renderCustomField = function ( fieldDef ) {
		var self = this;
		var inputId = 'bookflow-cf-' + fieldDef.key + '-' + Math.random().toString( 36 ).slice( 2, 8 );
		var wrap = el( 'div', { class: 'bookflow-field' } );
		var labelText = fieldDef.required ? fieldDef.label : fieldDef.label + ' (' + this.t( 'optional' ) + ')';

		wrap.appendChild( el( 'label', { for: inputId }, [ labelText ] ) );

		function record( value ) {
			if ( value ) {
				self.selection.customFieldAnswers[ fieldDef.key ] = value;
			} else {
				delete self.selection.customFieldAnswers[ fieldDef.key ];
			}
		}

		if ( 'textarea' === fieldDef.type ) {
			var textarea = el( 'textarea', { id: inputId, rows: '3' } );
			textarea.addEventListener( 'input', function () {
				record( textarea.value );
			} );
			wrap.appendChild( textarea );
		} else if ( 'select' === fieldDef.type ) {
			var select = el( 'select', { id: inputId } );
			select.appendChild( el( 'option', { value: '' }, [ '—' ] ) );
			( fieldDef.options || [] ).forEach( function ( optionValue ) {
				select.appendChild( el( 'option', { value: optionValue }, [ optionValue ] ) );
			} );
			select.addEventListener( 'change', function () {
				record( select.value );
			} );
			wrap.appendChild( select );
		} else if ( 'radio' === fieldDef.type ) {
			var group = el( 'div', { class: 'bookflow-radio-group' } );
			( fieldDef.options || [] ).forEach( function ( optionValue, index ) {
				var radioId = inputId + '-' + index;
				var radio = el( 'input', {
					type: 'radio',
					id: radioId,
					name: inputId,
					value: optionValue,
				} );
				radio.addEventListener( 'change', function () {
					record( optionValue );
				} );
				var optionLabel = el( 'label', { for: radioId, class: 'bookflow-radio-option' }, [ radio, ' ' + optionValue ] );
				group.appendChild( optionLabel );
			} );
			wrap.appendChild( group );
		} else if ( 'checkbox' === fieldDef.type ) {
			var checkbox = el( 'input', { type: 'checkbox', id: inputId } );
			checkbox.addEventListener( 'change', function () {
				record( checkbox.checked ? '1' : '' );
			} );
			wrap.appendChild( checkbox );
		} else {
			var inputType = 'email' === fieldDef.type || 'number' === fieldDef.type ? fieldDef.type : ( 'phone' === fieldDef.type ? 'tel' : 'text' );
			var textInput = el( 'input', { type: inputType, id: inputId } );
			textInput.addEventListener( 'input', function () {
				record( textInput.value );
			} );
			wrap.appendChild( textInput );
		}

		if ( fieldDef.required ) {
			wrap.appendChild( el( 'span', { class: 'bookflow-field-required', 'aria-hidden': 'true' }, [ ' *' ] ) );
		}

		return wrap;
	};

	Widget.prototype.renderConfirmStep = function () {
		var self = this;
		var wrap = el( 'div', { class: 'bookflow-step bookflow-step--confirm' } );
		wrap.appendChild( el( 'h3', { class: 'bookflow-step-title' }, [ this.t( 'reviewAndConfirm' ) ] ) );

		if ( this.submitError ) {
			wrap.appendChild( el( 'p', { class: 'bookflow-error-banner', role: 'alert' }, [ this.submitError ] ) );
		}

		var service = this.selectedService();
		var staff = ( this.config.staff || [] ).filter( function ( s ) { return s.id === self.selection.staffId; } )[ 0 ];
		var location = ( this.config.locations || [] ).filter( function ( l ) { return l.id === self.selection.locationId; } )[ 0 ];

		var summary = el( 'dl', { class: 'bookflow-summary' } );

		function row( label, value ) {
			if ( ! value ) {
				return;
			}
			summary.appendChild( el( 'dt', {}, [ label ] ) );
			summary.appendChild( el( 'dd', {}, [ value ] ) );
		}

		row( this.t( 'selectService' ), service ? service.name : '' );
		if ( staff ) {
			row( this.t( 'selectStaff' ), staff.name );
		}
		if ( location ) {
			row( this.t( 'selectLocation' ), location.name );
		}
		row( this.t( 'selectDate' ), formatDateHeading( this.selection.date ) );
		row( this.t( 'selectTime' ), formatSlotTime( this.selection.slot.start, this.timezone ) );

		if ( ! this.isReschedule ) {
			var name = ( this.selection.firstName + ' ' + this.selection.lastName ).trim();
			row( this.t( 'yourDetails' ), name || this.selection.email );
		}

		wrap.appendChild( summary );

		var confirmButton = el(
			'button',
			{
				type: 'button',
				class: 'bookflow-button bookflow-button--primary',
				onClick: function () {
					self.submit();
				},
			},
			[ this.isReschedule ? this.t( 'confirmNewTime' ) : this.t( 'confirmBooking' ) ]
		);
		wrap.appendChild( confirmButton );

		return wrap;
	};

	Widget.prototype.renderSuccessStep = function () {
		var data = this.result || {};
		var wrap = el( 'div', { class: 'bookflow-step bookflow-step--success', role: 'status' } );

		if ( this.isReschedule ) {
			wrap.appendChild( el( 'h3', { class: 'bookflow-step-title' }, [ this.t( 'rescheduledTitle' ) ] ) );
		} else if ( 'pending' === data.status ) {
			wrap.appendChild( el( 'h3', { class: 'bookflow-step-title' }, [ this.t( 'bookingPendingTitle' ) ] ) );
			wrap.appendChild( el( 'p', {}, [ this.t( 'bookingPendingBody' ) ] ) );
		} else {
			wrap.appendChild( el( 'h3', { class: 'bookflow-step-title' }, [ this.t( 'bookingConfirmedTitle' ) ] ) );
		}

		if ( data.reference ) {
			wrap.appendChild(
				el( 'p', { class: 'bookflow-reference' }, [ this.t( 'reference' ) + ': ', el( 'strong', {}, [ data.reference ] ) ] )
			);
		}

		if ( data.manageUrl && ! this.isReschedule ) {
			wrap.appendChild( el( 'p', {}, [ el( 'a', { href: data.manageUrl }, [ data.manageUrl ] ) ] ) );
		}

		return wrap;
	};

	/* ---------------------------------------------------------------------
	 * Init
	 * ------------------------------------------------------------------- */

	function initAll() {
		var containers = document.querySelectorAll( '[data-bookflow-widget="booking"]' );
		containers.forEach( function ( container ) {
			try {
				new Widget( container ); // eslint-disable-line no-new
			} catch ( e ) {
				container.textContent = 'BookFlow: unable to load the booking form.';
			}
		} );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', initAll );
	} else {
		initAll();
	}
} )();

/**
 * BookFlow Gutenberg blocks — Booking Form, Scheduling Page, Event Booking. Plain ES6 using the
 * `wp.*` globals WordPress's own block editor already loads (no JSX, no build step — see
 * src/Blocks/Bootstrap.php's docblock for why). Every block is "dynamic": save() returns null,
 * and the actual markup always comes from the matching render_callback in Bootstrap.php — the
 * editor preview below is a live <ServerSideRender> of that same PHP output, not a second
 * hand-maintained copy of it.
 */
( function ( blocks, element, blockEditor, components, i18n, ServerSideRender ) {
	'use strict';

	var el = element.createElement;
	var Fragment = element.Fragment;
	var __ = i18n.__;
	var registerBlockType = blocks.registerBlockType;
	var InspectorControls = blockEditor.InspectorControls;
	var PanelBody = components.PanelBody;
	var SelectControl = components.SelectControl;

	/**
	 * Data localized by Blocks\Bootstrap::localize_editor_data() — services/staff/locations/
	 * scheduling pages/upcoming events, each as [{ value, label }, ...]. Always present with
	 * empty arrays as a fallback so a block never hard-errors if localization didn't run.
	 */
	var data = window.bookflowBlocksData || {
		services: [],
		staff: [],
		locations: [],
		schedulingPages: [],
		events: [],
	};

	/**
	 * Build a SelectControl `options` array with a leading placeholder entry.
	 *
	 * @param {Array} list
	 * @param {string} placeholderLabel
	 * @return {Array}
	 */
	function withPlaceholder( list, placeholderLabel ) {
		var options = [ { value: '', label: placeholderLabel } ];
		( list || [] ).forEach( function ( item ) {
			options.push( { value: item.value, label: item.label } );
		} );
		return options;
	}

	/**
	 * Shared editor preview wrapper: Inspector Controls panel (children) + a live
	 * ServerSideRender of the block's actual PHP output.
	 *
	 * @param {string} blockName
	 * @param {string} panelTitle
	 * @param {Object} attributes
	 * @param {Array}  controls Array of SelectControl elements to render inside the panel.
	 * @return {Object}
	 */
	function editWrapper( blockName, panelTitle, attributes, controls ) {
		return el(
			Fragment,
			{},
			el(
				InspectorControls,
				{},
				el.apply( null, [ PanelBody, { title: panelTitle, initialOpen: true } ].concat( controls ) )
			),
			el(
				'div',
				{ className: 'bookflow-block-preview' },
				el( ServerSideRender, { block: blockName, attributes: attributes } )
			)
		);
	}

	registerBlockType( 'bookflow/booking-form', {
		title: __( 'Booking Form', 'bookflow-booking-scheduling' ),
		description: __( 'Let visitors book an appointment for one of your services.', 'bookflow-booking-scheduling' ),
		icon: 'calendar-alt',
		category: 'widgets',
		attributes: {
			service: { type: 'string', default: '' },
			staff: { type: 'string', default: '' },
			location: { type: 'string', default: '' },
			layout: { type: 'string', default: 'classic' },
		},
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;

			return editWrapper( 'bookflow/booking-form', __( 'Booking Form Settings', 'bookflow-booking-scheduling' ), attributes, [
				el( SelectControl, {
					key: 'service',
					label: __( 'Service', 'bookflow-booking-scheduling' ),
					value: attributes.service,
					options: withPlaceholder( data.services, __( 'All services (visitor chooses)', 'bookflow-booking-scheduling' ) ),
					onChange: function ( value ) {
						setAttributes( { service: value } );
					},
				} ),
				el( SelectControl, {
					key: 'staff',
					label: __( 'Staff member', 'bookflow-booking-scheduling' ),
					value: attributes.staff,
					options: withPlaceholder( data.staff, __( 'No preference', 'bookflow-booking-scheduling' ) ),
					onChange: function ( value ) {
						setAttributes( { staff: value } );
					},
				} ),
				el( SelectControl, {
					key: 'location',
					label: __( 'Location', 'bookflow-booking-scheduling' ),
					value: attributes.location,
					options: withPlaceholder( data.locations, __( 'Any location', 'bookflow-booking-scheduling' ) ),
					onChange: function ( value ) {
						setAttributes( { location: value } );
					},
				} ),
				el( SelectControl, {
					key: 'layout',
					label: __( 'Layout', 'bookflow-booking-scheduling' ),
					value: attributes.layout,
					options: [
						{ value: 'classic', label: __( 'Classic', 'bookflow-booking-scheduling' ) },
						{ value: 'calendar_first', label: __( 'Calendar first', 'bookflow-booking-scheduling' ) },
						{ value: 'express', label: __( 'Express', 'bookflow-booking-scheduling' ) },
					],
					onChange: function ( value ) {
						setAttributes( { layout: value } );
					},
				} ),
			] );
		},
		save: function () {
			return null;
		},
	} );

	registerBlockType( 'bookflow/scheduling-page', {
		title: __( 'Scheduling Page', 'bookflow-booking-scheduling' ),
		description: __( 'Embed one of your public scheduling pages.', 'bookflow-booking-scheduling' ),
		icon: 'clock',
		category: 'widgets',
		attributes: {
			page: { type: 'string', default: '' },
		},
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;

			if ( ! data.schedulingPages || 0 === data.schedulingPages.length ) {
				return el(
					'div',
					{ className: 'bookflow-block-empty' },
					__( 'You don’t have any scheduling pages yet. Create one under BookFlow → Scheduling, then add it here.', 'bookflow-booking-scheduling' )
				);
			}

			return editWrapper( 'bookflow/scheduling-page', __( 'Scheduling Page Settings', 'bookflow-booking-scheduling' ), attributes, [
				el( SelectControl, {
					key: 'page',
					label: __( 'Scheduling page', 'bookflow-booking-scheduling' ),
					value: attributes.page,
					options: withPlaceholder( data.schedulingPages, __( '— Select —', 'bookflow-booking-scheduling' ) ),
					onChange: function ( value ) {
						setAttributes( { page: value } );
					},
				} ),
			] );
		},
		save: function () {
			return null;
		},
	} );

	registerBlockType( 'bookflow/event-booking', {
		title: __( 'Event Booking', 'bookflow-booking-scheduling' ),
		description: __( 'Let visitors register for one of your events.', 'bookflow-booking-scheduling' ),
		icon: 'tickets-alt',
		category: 'widgets',
		attributes: {
			event: { type: 'string', default: '' },
		},
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;

			if ( ! data.events || 0 === data.events.length ) {
				return el(
					'div',
					{ className: 'bookflow-block-empty' },
					__( 'You don’t have any upcoming published events yet. Create one under BookFlow → Events, then add it here.', 'bookflow-booking-scheduling' )
				);
			}

			return editWrapper( 'bookflow/event-booking', __( 'Event Booking Settings', 'bookflow-booking-scheduling' ), attributes, [
				el( SelectControl, {
					key: 'event',
					label: __( 'Event', 'bookflow-booking-scheduling' ),
					value: attributes.event,
					options: withPlaceholder( data.events, __( '— Select —', 'bookflow-booking-scheduling' ) ),
					onChange: function ( value ) {
						setAttributes( { event: value } );
					},
				} ),
			] );
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.i18n, window.wp.serverSideRender );

<?php
/**
 * Uninstall routine.
 *
 * WordPress only executes this file when the plugin is deleted from the Plugins screen (or via
 * WP-CLI `wp plugin uninstall`), never on a simple deactivation — so it is safe to treat
 * anything that reaches this file as a deliberate "remove the plugin" action by the site owner.
 *
 * Data is still only removed if the site owner explicitly opted in via
 * Settings → Privacy → "Remove all BookFlow data on uninstall" (default: off). This mirrors the
 * spec's Section 24 privacy requirement and WordPress.org's guidance that uninstall should not
 * silently destroy user data.
 *
 * @package BookFlow
 */

declare( strict_types = 1 );

use BookFlow\Database\Migrator;
use BookFlow\Support\Constants;

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

define( 'BOOKFLOW_PLUGIN_DIR', __DIR__ . '/' );

require_once __DIR__ . '/src/Support/Autoloader.php';
\BookFlow\Support\Autoloader::register();

$should_remove_data = get_option( Constants::OPTION_REMOVE_DATA_ON_UNINSTALL, '' );

if ( '1' !== $should_remove_data ) {
	// Site owner chose to keep their booking data. Leave tables and options in place.
	return;
}

Migrator::drop_all_tables();

$options = array(
	Constants::OPTION_DB_VERSION,
	Constants::OPTION_REMOVE_DATA_ON_UNINSTALL,
	'bookflow_onboarding_completed',
	'bookflow_booking_model',
	'bookflow_business_type',
	'bookflow_settings_general',
	'bookflow_settings_business',
	'bookflow_settings_booking_defaults',
	'bookflow_settings_availability',
	'bookflow_settings_notifications',
	'bookflow_settings_frontend',
	'bookflow_settings_privacy',
	'bookflow_settings_integrations',
	'bookflow_settings_advanced',
);

foreach ( $options as $option ) {
	delete_option( $option );

	// Multisite: also clear network-activated sub-sites' copies of the same option.
	if ( is_multisite() ) {
		delete_site_option( $option );
	}
}

$capability_role = get_role( 'administrator' );

if ( $capability_role instanceof WP_Role && $capability_role->has_cap( Constants::CAPABILITY ) ) {
	$capability_role->remove_cap( Constants::CAPABILITY );
}

wp_clear_scheduled_hook( Constants::CRON_DAILY_MAINTENANCE );

<?php
/**
 * Plugin Name:       BookFlow – Booking & Scheduling
 * Plugin URI:        https://example.com/bookflow
 * Description:       A modern WordPress-native booking and scheduling workspace for appointments, events, teams and shareable scheduling pages.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            BookFlow
 * Author URI:        https://example.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:        bookflow-booking-scheduling
 * Domain Path:        /languages
 *
 * @package BookFlow
 */

declare( strict_types = 1 );

// Refuse to run outside of WordPress.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Guard against double-inclusion (e.g. symlinked into two plugin slugs during development).
if ( defined( 'BOOKFLOW_PLUGIN_FILE' ) ) {
	return;
}

define( 'BOOKFLOW_PLUGIN_FILE', __FILE__ );
define( 'BOOKFLOW_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BOOKFLOW_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// The autoloader is required directly (it is the one class not loaded by itself).
require_once BOOKFLOW_PLUGIN_DIR . 'src/Support/Autoloader.php';
\BookFlow\Support\Autoloader::register();

/**
 * Activation callback. Kept as a thin static wrapper so WordPress can serialize/store the
 * callback reference reliably across requests.
 */
function bookflow_activate(): void {
	\BookFlow\Support\Activation::run();
}
register_activation_hook( __FILE__, 'bookflow_activate' );

/**
 * Deactivation callback. Never deletes data — see docs/ARCHITECTURE.md §6.
 */
function bookflow_deactivate(): void {
	\BookFlow\Support\Deactivation::run();
}
register_deactivation_hook( __FILE__, 'bookflow_deactivate' );

/**
 * Boot the plugin once all plugins are loaded, so we can safely detect Premium, other
 * integrations, and translation-ready strings.
 */
add_action( 'plugins_loaded', array( \BookFlow\Plugin::class, 'boot' ) );

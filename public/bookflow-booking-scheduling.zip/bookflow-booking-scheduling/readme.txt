=== BookFlow – Booking & Scheduling ===
Contributors: bookflow
Tags: booking, appointment, scheduling, events, calendar
Requires at least: 6.4
Tested up to: 6.7
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Modern WordPress booking, appointment scheduling, events and shareable public scheduling pages for businesses, teams and professionals.

== Description ==

BookFlow turns your WordPress website into a booking and scheduling workspace — appointments,
events, team scheduling, and shareable public scheduling pages — without requiring a
subscription to another SaaS booking tool. Your bookings, customers, and availability live in
your own WordPress database.

**Core features (Free)**

* Services with duration, price, capacity, category, staff and location assignment.
* Working hours, availability exceptions, buffers, minimum notice and maximum booking window.
* Admin calendar and a searchable, filterable bookings list with status management.
* Shareable, embeddable public scheduling pages with custom booking questions.
* One-time events with capacity and attendee registration.
* Staff, locations (including online), and service/staff/location assignment.
* Booking confirmation, cancellation, rescheduling, and admin notification emails via
  WordPress's own mail system — no third-party email API required.
* Gutenberg blocks, shortcodes, and Elementor widgets for the booking form, scheduling page, and
  event booking — use whichever page-building tool your site already runs on.
* A five-minute guided onboarding wizard.

BookFlow does not require a mandatory external database, SaaS backend, or paid API for its core
functionality. Optional integrations (calendar sync, video conferencing, payments) are available
as part of BookFlow Premium and always fail gracefully if not configured — they never break core
booking.

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/bookflow-booking-scheduling`, or install the
   plugin through the WordPress Plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Follow the onboarding wizard under BookFlow → Overview to create your first service, staff
   member, and scheduling page.

== Frequently Asked Questions ==

= Do I need an external account or subscription to use BookFlow? =

No. Free version bookings, customers, and availability are stored entirely in your WordPress
database and delivered via your site's own email sending. Optional integrations in the Premium
extension (calendar sync, video conferencing, payment gateways) are opt-in.

= What happens to my data if I deactivate or uninstall BookFlow? =

Deactivating BookFlow never deletes any data. Uninstalling (deleting the plugin) only removes
BookFlow's data if you explicitly enable "Remove all BookFlow data on uninstall" under
Settings → Privacy; by default your data is kept.

== Changelog ==

= 1.0.0 =
* Initial release.
* Services, staff, locations, and customers, with working hours, availability exceptions,
  buffers, minimum notice, and maximum booking window.
* Frontend booking widget in three layouts (classic, calendar-first, express), plus booking
  confirmation, cancellation, and self-service rescheduling.
* Shareable, embeddable public scheduling pages with per-page booking rules and custom
  questions.
* One-time events with capacity and attendee registration.
* Admin calendar, and searchable/filterable/paginated admin screens for bookings, events, and
  customers, each with full CRUD.
* Email notifications (confirmation, cancellation, reschedule, reminders, and admin alerts) via
  WordPress's own mail system — no third-party email API required.
* Gutenberg blocks, shortcodes, and Elementor widgets for the booking form, scheduling page, and
  event booking.
* A guided onboarding wizard for first-time setup.
* Documented action/filter extension points for a future Premium extension; the Free plugin
  never depends on Premium being present.
* Security: capability- and nonce-checked admin actions, token-based (not ID-based) public
  booking/event management links, rate limiting on public booking/registration endpoints.
* Privacy: booking data stored only in your own WordPress database; no external service calls;
  opt-in data removal on uninstall (kept by default).

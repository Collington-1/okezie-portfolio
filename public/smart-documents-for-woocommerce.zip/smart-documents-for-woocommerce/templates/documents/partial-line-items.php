<?php
/**
 * Shared line-items table, included by every document template.
 *
 * Expects `$data` (see Woosdd\Documents\Document_Data::from_order()) and
 * `$show_prices` (bool — false hides money columns, used by Packing Slip
 * and Delivery Note which are picking/shipping documents, not bills).
 *
 * @package Woosdd
 */

defined( 'ABSPATH' ) || exit;

/** @var array $data */ // phpcs:ignore Generic.Commenting.DocComment.MissingShort -- inline IDE type hint, not a documented symbol.
/** @var bool $show_prices */ // phpcs:ignore Generic.Commenting.DocComment.MissingShort -- inline IDE type hint, not a documented symbol.
?>
<table class="woosdd-items" cellspacing="0" cellpadding="0">
	<thead>
		<tr>
			<th class="col-name"><?php esc_html_e( 'Item', 'smart-documents-for-woocommerce' ); ?></th>
			<th class="col-sku"><?php esc_html_e( 'SKU', 'smart-documents-for-woocommerce' ); ?></th>
			<th class="col-qty"><?php esc_html_e( 'Qty', 'smart-documents-for-woocommerce' ); ?></th>
			<?php if ( $show_prices ) : ?>
				<th class="col-price"><?php esc_html_e( 'Unit Price', 'smart-documents-for-woocommerce' ); ?></th>
				<?php if ( ! empty( $data['coupons'] ) ) : ?>
					<th class="col-discount"><?php esc_html_e( 'Discount', 'smart-documents-for-woocommerce' ); ?></th>
				<?php endif; ?>
				<th class="col-total"><?php esc_html_e( 'Total', 'smart-documents-for-woocommerce' ); ?></th>
			<?php endif; ?>
		</tr>
	</thead>
	<tbody>
		<?php foreach ( $data['line_items'] as $woosdd_line ) : ?>
			<tr>
				<td class="col-name"><?php echo esc_html( $woosdd_line['name'] ); ?></td>
				<td class="col-sku"><?php echo esc_html( $woosdd_line['sku'] ); ?></td>
				<td class="col-qty"><?php echo esc_html( $woosdd_line['quantity'] ); ?></td>
				<?php if ( $show_prices ) : ?>
					<td class="col-price"><?php echo wp_kses_post( wc_price( $woosdd_line['unit_price'], array( 'currency' => $data['currency'] ) ) ); ?></td>
					<?php if ( ! empty( $data['coupons'] ) ) : ?>
						<td class="col-discount"><?php echo wp_kses_post( wc_price( $woosdd_line['discount'], array( 'currency' => $data['currency'] ) ) ); ?></td>
					<?php endif; ?>
					<td class="col-total"><?php echo wp_kses_post( wc_price( $woosdd_line['total'], array( 'currency' => $data['currency'] ) ) ); ?></td>
				<?php endif; ?>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<?php
/**
 * Free Template 2 — "Classic". A bordered, boxed layout with a solid
 * header band and gridded totals table.
 *
 * Expects `$data`, an associative array from
 * Woosdd\Documents\Document_Data::from_order(), and `$document_number`
 * (string, the allocated/reused number for this specific document).
 *
 * @package Woosdd
 */

defined( 'ABSPATH' ) || exit;

/** @var array $data */ // phpcs:ignore Generic.Commenting.DocComment.MissingShort -- inline IDE type hint, not a documented symbol.
/** @var string $document_number */ // phpcs:ignore Generic.Commenting.DocComment.MissingShort -- inline IDE type hint, not a documented symbol.

// Not renamed with a woosdd_ prefix: partial-line-items.php reads this
// exact variable name from the including scope (see that file's own
// docblock) — this file is always `include`d from inside
// Generator::render_template()'s method scope, never truly global at
// runtime, so this is a false positive on the prefix sniff.
$show_prices = ! in_array( $data['type'], array( 'packing_slip', 'delivery_note' ), true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
$woosdd_logo_html   = '';
if ( ! empty( $data['business']['logo_id'] ) ) {
	$woosdd_logo_html = wp_get_attachment_image( $data['business']['logo_id'], array( 200, 80 ), false, array( 'style' => 'max-height:80px;max-width:200px;' ) );
}
?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr( get_bloginfo( 'language' ) ); ?>" <?php echo is_rtl() ? 'dir="rtl"' : ''; ?>>
<head>
	<meta charset="utf-8" />
	<title><?php echo esc_html( $data['type_label'] . ' ' . $document_number ); ?></title>
	<style>
		body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color: #111827; margin: 0; }
		.woosdd-band { background: <?php echo esc_html( $data['accent_color'] ); ?>; color: #ffffff; padding: 16px 20px; overflow: hidden; margin-bottom: 20px; }
		.woosdd-band .logo { float: <?php echo is_rtl() ? 'right' : 'left'; ?>; }
		.woosdd-band .doc-meta { float: <?php echo is_rtl() ? 'left' : 'right'; ?>; text-align: <?php echo is_rtl() ? 'left' : 'right'; ?>; }
		.woosdd-band .doc-meta h1 { font-size: 18px; margin: 0 0 6px; color: #ffffff; }
		.woosdd-band .biz-name { font-size: 15px; font-weight: bold; }
		.woosdd-outer { border: 1px solid #d1d5db; padding: 16px 20px; }
		.woosdd-addresses { overflow: hidden; margin-bottom: 16px; }
		.woosdd-addresses .box { width: 48%; border: 1px solid #e5e7eb; padding: 8px 10px; box-sizing: border-box; }
		.woosdd-addresses .box.from { float: <?php echo is_rtl() ? 'right' : 'left'; ?>; }
		.woosdd-addresses .box.to { float: <?php echo is_rtl() ? 'left' : 'right'; ?>; }
		.woosdd-addresses h3 { font-size: 10px; text-transform: uppercase; letter-spacing: .04em; color: #6b7280; margin: 0 0 4px; }
		table.woosdd-items { width: 100%; border-collapse: collapse; margin-bottom: 16px; border: 1px solid #d1d5db; }
		table.woosdd-items th { text-align: left; font-size: 11px; text-transform: uppercase; color: #ffffff; background: <?php echo esc_html( $data['accent_color'] ); ?>; padding: 6px 6px; }
		table.woosdd-items td { padding: 6px 6px; border-bottom: 1px solid #e5e7eb; }
		table.woosdd-items .col-qty, table.woosdd-items .col-price, table.woosdd-items .col-total, table.woosdd-items .col-discount { text-align: right; }
		table.woosdd-totals { width: 260px; float: <?php echo is_rtl() ? 'left' : 'right'; ?>; border-collapse: collapse; border: 1px solid #d1d5db; }
		table.woosdd-totals td { padding: 5px 8px; border-bottom: 1px solid #e5e7eb; }
		table.woosdd-totals .label { color: #6b7280; }
		table.woosdd-totals .value { text-align: right; }
		table.woosdd-totals .grand-total td { background: #f3f4f6; font-weight: bold; font-size: 14px; border-bottom: none; }
		.woosdd-notes { clear: both; margin-top: 24px; padding-top: 12px; border-top: 1px solid #e5e7eb; font-size: 11px; color: #6b7280; }
		.woosdd-footer { margin-top: 30px; text-align: center; font-size: 10px; color: #9ca3af; }
	</style>
</head>
<body>

	<div class="woosdd-band">
		<div class="logo">
			<?php
			if ( $woosdd_logo_html ) {
				echo wp_kses_post( $woosdd_logo_html );
			} else {
				echo '<span class="biz-name">' . esc_html( $data['business']['name'] ) . '</span>';
			}
			?>
		</div>
		<div class="doc-meta">
			<h1><?php echo esc_html( $data['type_label'] ); ?></h1>
			<div><?php echo esc_html__( 'Number:', 'smart-documents-for-woocommerce' ) . ' ' . esc_html( $document_number ); ?></div>
			<div><?php echo esc_html__( 'Order:', 'smart-documents-for-woocommerce' ) . ' #' . esc_html( $data['order_number'] ); ?></div>
			<div><?php echo esc_html__( 'Date:', 'smart-documents-for-woocommerce' ) . ' ' . esc_html( $data['order_date'] ); ?></div>
		</div>
		<div style="clear:both;"></div>
	</div>

	<div class="woosdd-outer">

		<div class="woosdd-addresses">
			<div class="box from">
				<h3><?php esc_html_e( 'From', 'smart-documents-for-woocommerce' ); ?></h3>
				<div><?php echo esc_html( $data['business']['name'] ); ?></div>
				<?php if ( $data['business']['address'] ) : ?>
					<div><?php echo wp_kses_post( nl2br( esc_html( $data['business']['address'] ) ) ); ?></div>
				<?php endif; ?>
				<?php if ( $data['business']['email'] ) : ?>
					<div><?php echo esc_html( $data['business']['email'] ); ?></div>
				<?php endif; ?>
				<?php if ( $data['business']['phone'] ) : ?>
					<div><?php echo esc_html( $data['business']['phone'] ); ?></div>
				<?php endif; ?>
				<?php if ( $data['business']['tax_id'] ) : ?>
					<div><?php echo esc_html__( 'Tax ID:', 'smart-documents-for-woocommerce' ) . ' ' . esc_html( $data['business']['tax_id'] ); ?></div>
				<?php endif; ?>
			</div>
			<div class="box to">
				<h3><?php echo esc_html( $data['shows_shipping'] ? __( 'Bill To', 'smart-documents-for-woocommerce' ) : __( 'To', 'smart-documents-for-woocommerce' ) ); ?></h3>
				<div><?php echo wp_kses_post( $data['billing']['address'] ); ?></div>
				<?php if ( $data['billing']['email'] ) : ?>
					<div><?php echo esc_html( $data['billing']['email'] ); ?></div>
				<?php endif; ?>
				<?php if ( $data['billing']['phone'] ) : ?>
					<div><?php echo esc_html( $data['billing']['phone'] ); ?></div>
				<?php endif; ?>
			</div>
			<div style="clear:both;"></div>
		</div>

		<?php if ( $data['shows_shipping'] ) : ?>
			<div class="woosdd-addresses">
				<div class="box from">
					<h3><?php esc_html_e( 'Ship To', 'smart-documents-for-woocommerce' ); ?></h3>
					<div><?php echo wp_kses_post( $data['shipping']['address'] ); ?></div>
				</div>
				<div class="box to">
					<h3><?php esc_html_e( 'Payment Method', 'smart-documents-for-woocommerce' ); ?></h3>
					<div><?php echo esc_html( $data['payment_method'] ); ?></div>
				</div>
				<div style="clear:both;"></div>
			</div>
		<?php endif; ?>

		<?php require __DIR__ . '/partial-line-items.php'; ?>

		<?php if ( $show_prices ) : ?>
			<table class="woosdd-totals">
				<tr>
					<td class="label"><?php esc_html_e( 'Subtotal', 'smart-documents-for-woocommerce' ); ?></td>
					<td class="value"><?php echo wp_kses_post( wc_price( $data['totals']['subtotal'], array( 'currency' => $data['currency'] ) ) ); ?></td>
				</tr>
				<?php if ( (float) $data['totals']['discount_total'] > 0 ) : ?>
					<tr>
						<td class="label"><?php esc_html_e( 'Discount', 'smart-documents-for-woocommerce' ); ?></td>
						<td class="value">-<?php echo wp_kses_post( wc_price( $data['totals']['discount_total'], array( 'currency' => $data['currency'] ) ) ); ?></td>
					</tr>
				<?php endif; ?>
				<?php if ( (float) $data['totals']['shipping_total'] > 0 ) : ?>
					<tr>
						<td class="label"><?php esc_html_e( 'Shipping', 'smart-documents-for-woocommerce' ); ?></td>
						<td class="value"><?php echo wp_kses_post( wc_price( $data['totals']['shipping_total'], array( 'currency' => $data['currency'] ) ) ); ?></td>
					</tr>
				<?php endif; ?>
				<?php foreach ( $data['tax_lines'] as $woosdd_tax_line ) : ?>
					<tr>
						<td class="label"><?php echo esc_html( $woosdd_tax_line['label'] ); ?></td>
						<td class="value"><?php echo wp_kses_post( wc_price( $woosdd_tax_line['amount'], array( 'currency' => $data['currency'] ) ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				<tr class="grand-total">
					<td class="label"><?php esc_html_e( 'Total', 'smart-documents-for-woocommerce' ); ?></td>
					<td class="value"><?php echo wp_kses_post( wc_price( $data['totals']['total'], array( 'currency' => $data['currency'] ) ) ); ?></td>
				</tr>
			</table>
			<div style="clear:both;"></div>
		<?php endif; ?>

		<?php if ( $data['customer_note'] ) : ?>
			<div class="woosdd-notes">
				<div><strong><?php esc_html_e( 'Note:', 'smart-documents-for-woocommerce' ); ?></strong> <?php echo esc_html( $data['customer_note'] ); ?></div>
			</div>
		<?php endif; ?>

		<?php if ( $data['business']['footer_text'] ) : ?>
			<div class="woosdd-footer"><?php echo wp_kses_post( nl2br( esc_html( $data['business']['footer_text'] ) ) ); ?></div>
		<?php endif; ?>

	</div>
</body>
</html>

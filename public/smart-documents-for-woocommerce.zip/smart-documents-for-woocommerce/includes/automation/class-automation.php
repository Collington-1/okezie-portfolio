<?php
/**
 * Basic (free-tier) automation rules.
 *
 * @package Woosdd
 */

namespace Woosdd\Automation;

use Woosdd\Cpt;
use Woosdd\Documents\Generator;

defined( 'ABSPATH' ) || exit;

/**
 * Wires the handful of fixed automation rules that ship in the free
 * plugin:
 *
 * - Order paid            → generate Invoice (once)
 * - Order completed        → generate Receipt (once)
 * - Matching WooCommerce email → PDF attached automatically
 *
 * Premium replaces the hardcoded rule list here with a full
 * conditions/actions rule builder (see `woosdd_automation_rules` and
 * `woosdd_email_attachment_map`, both filterable so Premium can extend
 * without touching this class) — this class intentionally stays simple.
 *
 * Idempotent by design: every rule only auto-generates a document that
 * doesn't already exist yet (Generator itself also reuses an existing
 * document+number for the same order+type), so repeated status-changed
 * events — WooCommerce can fire more than one for the same transition in
 * a single request — never regenerate the PDF or attach it twice.
 */
class Automation {

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'woocommerce_payment_complete', array( $this, 'on_order_paid' ) );
		add_action( 'woocommerce_order_status_completed', array( $this, 'on_order_completed' ) );
		add_filter( 'woocommerce_email_attachments', array( $this, 'attach_documents_to_email' ), 10, 3 );
	}

	/**
	 * Order paid → generate Invoice, if one doesn't already exist.
	 *
	 * @param int $order_id Order ID.
	 */
	public function on_order_paid( $order_id ) {
		$this->maybe_generate( $order_id, 'invoice' );
	}

	/**
	 * Order completed → generate Receipt, if one doesn't already exist.
	 *
	 * @param int $order_id Order ID.
	 */
	public function on_order_completed( $order_id ) {
		$this->maybe_generate( $order_id, 'receipt' );
	}

	/**
	 * Generate a document only if this order+type doesn't already have
	 * one — automation never overwrites a document a merchant may have
	 * already manually generated or regenerated.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $type     Document type slug.
	 */
	private function maybe_generate( $order_id, $type ) {
		/**
		 * Filter to disable a specific automation rule entirely.
		 *
		 * @param bool   $enabled  Whether this rule should run.
		 * @param int    $order_id Order ID.
		 * @param string $type     Document type slug.
		 */
		if ( ! apply_filters( 'woosdd_automation_rule_enabled', true, $order_id, $type ) ) {
			return;
		}

		$existing = get_posts(
			array(
				'post_type'   => Cpt::DOCUMENT,
				'post_status' => 'any',
				'numberposts' => 1,
				'fields'      => 'ids',
				'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => '_order_id',
						'value' => $order_id,
					),
					array(
						'key'   => '_type',
						'value' => $type,
					),
				),
			)
		);

		if ( ! empty( $existing ) ) {
			return; // Already generated (by automation or manually) — leave it alone.
		}

		$generator = new Generator();
		$generator->generate( $order_id, $type );
	}

	/**
	 * Attach the matching document PDF to WooCommerce transactional
	 * emails, per the free-tier default mapping. Only attaches a document
	 * that already exists — never triggers generation from inside an
	 * email-sending context.
	 *
	 * @param string[]        $attachments Existing attachment file paths.
	 * @param string          $email_id    WC_Email id, e.g. 'customer_processing_order'.
	 * @param \WC_Order|mixed $email_subject_object Email's subject object (order for order emails).
	 * @return string[]
	 */
	public function attach_documents_to_email( $attachments, $email_id, $email_subject_object ) {
		if ( 'no' === woosdd_get_setting( 'email_attachments_enabled', 'yes' ) ) {
			return $attachments;
		}

		if ( ! $email_subject_object instanceof \WC_Order ) {
			return $attachments;
		}

		$type = $this->document_type_for_email( $email_id );
		if ( ! $type ) {
			return $attachments;
		}

		$existing = get_posts(
			array(
				'post_type'   => Cpt::DOCUMENT,
				'post_status' => 'any',
				'numberposts' => 1,
				'fields'      => 'ids',
				'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => '_order_id',
						'value' => $email_subject_object->get_id(),
					),
					array(
						'key'   => '_type',
						'value' => $type,
					),
				),
			)
		);

		if ( empty( $existing ) ) {
			return $attachments;
		}

		$file_path = get_post_meta( $existing[0], '_file_path', true );
		if ( $file_path && file_exists( $file_path ) ) {
			$attachments[] = $file_path;
		}

		return $attachments;
	}

	/**
	 * Default free-tier email → document type mapping.
	 *
	 * @param string $email_id WC_Email id.
	 * @return string|null Document type slug, or null if this email gets no attachment.
	 */
	private function document_type_for_email( $email_id ) {
		/**
		 * Filter the WooCommerce email ID → document type attachment map.
		 * A future Premium add-on extends this with configurable
		 * conditions/multiple attachments; free stays this fixed map.
		 *
		 * @param array $map Email ID => document type slug.
		 */
		$map = apply_filters(
			'woosdd_email_attachment_map',
			array(
				'customer_processing_order' => 'invoice',
				'customer_invoice'          => 'invoice',
				'customer_completed_order'  => 'receipt',
			)
		);

		return isset( $map[ $email_id ] ) ? $map[ $email_id ] : null;
	}
}

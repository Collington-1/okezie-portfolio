<?php
/**
 * Basic COD (Cash on Delivery) tracking tab.
 *
 * @package Woosdd
 */

namespace Woosdd\Delivery;

defined( 'ABSPATH' ) || exit;

/**
 * Free tier: expected / collected / remitted / outstanding amounts per
 * order, entered manually from the order's Delivery & Dispatch meta box,
 * plus a simple running total. Premium adds reconciliation history, rider
 * balances, batch reconciliation and reports.
 */
class Cod {

	/**
	 * Render the COD tab: every order with any COD amount recorded.
	 */
	public function render() {
		// See Dispatch::find_orders_by_order_meta() docblock: wc_get_orders()'s
		// meta_query is not reliably honored on every WooCommerce storage
		// backend, so we scan-and-filter via WC_Order::get_meta() instead.
		$orders = Dispatch::find_orders_by_order_meta(
			'_woosdd_cod_expected',
			function ( \WC_Order $order ) {
				return '' !== $order->get_meta( '_woosdd_cod_expected' );
			},
			50
		);

		if ( empty( $orders ) ) {
			echo '<p>' . esc_html__( 'No COD amounts recorded yet. Set an expected COD amount from an order\'s Delivery & Dispatch box.', 'smart-documents-for-woocommerce' ) . '</p>';
			return;
		}

		$total_expected  = 0.0;
		$total_collected = 0.0;
		$total_remitted  = 0.0;
		?>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Order', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Rider', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Expected', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Collected', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Remitted', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Outstanding', 'smart-documents-for-woocommerce' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $orders as $order ) : ?>
					<?php
					$expected    = (float) $order->get_meta( '_woosdd_cod_expected' );
					$collected   = (float) $order->get_meta( '_woosdd_cod_collected' );
					$remitted    = (float) $order->get_meta( '_woosdd_cod_remitted' );
					$outstanding = $collected - $remitted;

					$total_expected  += $expected;
					$total_collected += $collected;
					$total_remitted  += $remitted;

					$rider_id = (int) $order->get_meta( '_woosdd_rider_id' );
					$rider    = $rider_id ? get_post( $rider_id ) : null;
					?>
					<tr>
						<td><a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>">#<?php echo esc_html( $order->get_order_number() ); ?></a></td>
						<td><?php echo esc_html( $rider ? $rider->post_title : '—' ); ?></td>
						<td><?php echo wp_kses_post( wc_price( $expected, array( 'currency' => $order->get_currency() ) ) ); ?></td>
						<td><?php echo wp_kses_post( wc_price( $collected, array( 'currency' => $order->get_currency() ) ) ); ?></td>
						<td><?php echo wp_kses_post( wc_price( $remitted, array( 'currency' => $order->get_currency() ) ) ); ?></td>
						<td><?php echo wp_kses_post( wc_price( $outstanding, array( 'currency' => $order->get_currency() ) ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="2"><?php esc_html_e( 'Totals', 'smart-documents-for-woocommerce' ); ?></th>
					<th><?php echo wp_kses_post( wc_price( $total_expected ) ); ?></th>
					<th><?php echo wp_kses_post( wc_price( $total_collected ) ); ?></th>
					<th><?php echo wp_kses_post( wc_price( $total_remitted ) ); ?></th>
					<th><?php echo wp_kses_post( wc_price( $total_collected - $total_remitted ) ); ?></th>
				</tr>
			</tfoot>
		</table>
		<p class="description"><?php esc_html_e( 'Reconciliation history, rider balances and batch reconciliation reports are a Premium add-on feature.', 'smart-documents-for-woocommerce' ); ?></p>
		<?php
	}
}

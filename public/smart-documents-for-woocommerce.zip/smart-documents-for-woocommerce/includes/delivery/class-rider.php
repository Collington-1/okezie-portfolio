<?php
/**
 * Rider profile CRUD (Riders tab, under Delivery & Dispatch).
 *
 * @package Woosdd
 */

namespace Woosdd\Delivery;

use Woosdd\Cpt;

defined( 'ABSPATH' ) || exit;

/**
 * Free-tier rider profiles: name (post title), phone, email, photo,
 * vehicle type, vehicle registration, rider ID, assigned zone,
 * active/inactive. Stored on the woosdd_rider CPT. Management is
 * wp-admin only in the free plugin — a restricted, mobile-friendly
 * frontend rider dashboard is a Premium feature (riders never get general
 * wp-admin access even there).
 */
class Rider {

	const ACTION_SAVE   = 'woosdd_save_rider';
	const ACTION_DELETE = 'woosdd_delete_rider';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'admin_post_' . self::ACTION_SAVE, array( $this, 'handle_save' ) );
		add_action( 'admin_post_' . self::ACTION_DELETE, array( $this, 'handle_delete' ) );
	}

	/**
	 * All riders, active first, alphabetical.
	 *
	 * @param bool $active_only Only return active riders.
	 * @return \WP_Post[]
	 */
	public static function get_riders( $active_only = false ) {
		$args = array(
			'post_type'      => Cpt::RIDER,
			'post_status'    => 'publish',
			'orderby'        => 'title',
			'order'          => 'ASC',
			'posts_per_page' => -1,
		);

		if ( $active_only ) {
			$args['meta_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				array(
					'key'   => '_active',
					'value' => 'yes',
				),
			);
		}

		return get_posts( $args );
	}

	/**
	 * Handle the add/edit rider form submission.
	 */
	public function handle_save() {
		if ( ! current_user_can( woosdd_admin_capability() ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'smart-documents-for-woocommerce' ), 403 );
		}
		check_admin_referer( self::ACTION_SAVE );

		$rider_id = isset( $_POST['rider_id'] ) ? absint( $_POST['rider_id'] ) : 0;
		$name     = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';

		if ( '' === $name ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'         => 'woosdd-delivery',
						'tab'          => 'riders',
						'woosdd_error' => rawurlencode( __( 'Rider name is required.', 'smart-documents-for-woocommerce' ) ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		$post_args = array(
			'post_type'   => Cpt::RIDER,
			'post_title'  => $name,
			'post_status' => 'publish',
		);

		if ( $rider_id ) {
			$post_args['ID'] = $rider_id;
			wp_update_post( $post_args );
		} else {
			$rider_id = wp_insert_post( $post_args );
		}

		if ( is_wp_error( $rider_id ) || ! $rider_id ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page' => 'woosdd-delivery',
						'tab'  => 'riders',
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}

		$fields = array(
			'_phone'                => 'sanitize_text_field',
			'_email'                => 'sanitize_email',
			'_vehicle_type'         => 'sanitize_text_field',
			'_vehicle_registration' => 'sanitize_text_field',
			'_rider_code'           => 'sanitize_text_field',
			'_zone'                 => 'sanitize_text_field',
		);

		foreach ( $fields as $meta_key => $sanitizer ) {
			$field_name = ltrim( $meta_key, '_' );
			// The sanitizer is applied dynamically via call_user_func()
			// (each field's own callback from the $fields map above), so
			// WPCS can't statically see that $_POST[ $field_name ] is
			// sanitized before use — it genuinely is, on every path.
			$value = isset( $_POST[ $field_name ] ) ? call_user_func( $sanitizer, wp_unslash( $_POST[ $field_name ] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			update_post_meta( $rider_id, $meta_key, $value );
		}

		update_post_meta( $rider_id, '_active', isset( $_POST['active'] ) ? 'yes' : 'no' );

		if ( isset( $_POST['photo_id'] ) ) {
			update_post_meta( $rider_id, '_photo_id', absint( $_POST['photo_id'] ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'         => 'woosdd-delivery',
					'tab'          => 'riders',
					'woosdd_saved' => 1,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Handle rider deletion. Never touches WooCommerce order data — a
	 * deleted rider simply leaves past deliveries' `_woosdd_rider_id`
	 * pointing at a rider post that no longer exists, which the queue
	 * screen already handles gracefully.
	 */
	public function handle_delete() {
		if ( ! current_user_can( woosdd_admin_capability() ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'smart-documents-for-woocommerce' ), 403 );
		}

		$rider_id = isset( $_GET['rider_id'] ) ? absint( $_GET['rider_id'] ) : 0;
		check_admin_referer( self::ACTION_DELETE . '_' . $rider_id );

		if ( $rider_id ) {
			wp_delete_post( $rider_id, true );
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'           => 'woosdd-delivery',
					'tab'            => 'riders',
					'woosdd_deleted' => 1,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Render the Riders tab: list + add/edit form.
	 */
	public function render() {
		$editing = isset( $_GET['edit_rider'] ) ? absint( $_GET['edit_rider'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only, edit form is separately nonced on submit.
		$this->render_form( $editing );
		echo '<hr />';
		$this->render_list();
	}

	/**
	 * Add/edit rider form.
	 *
	 * @param int $rider_id 0 for a new rider, otherwise the rider being edited.
	 */
	private function render_form( $rider_id ) {
		$rider = $rider_id ? get_post( $rider_id ) : null;
		$meta  = array(
			'phone'                => $rider_id ? get_post_meta( $rider_id, '_phone', true ) : '',
			'email'                => $rider_id ? get_post_meta( $rider_id, '_email', true ) : '',
			'vehicle_type'         => $rider_id ? get_post_meta( $rider_id, '_vehicle_type', true ) : '',
			'vehicle_registration' => $rider_id ? get_post_meta( $rider_id, '_vehicle_registration', true ) : '',
			'rider_code'           => $rider_id ? get_post_meta( $rider_id, '_rider_code', true ) : '',
			'zone'                 => $rider_id ? get_post_meta( $rider_id, '_zone', true ) : '',
			'active'               => $rider_id ? get_post_meta( $rider_id, '_active', true ) : 'yes',
		);
		?>
		<h2><?php echo $rider ? esc_html__( 'Edit Rider', 'smart-documents-for-woocommerce' ) : esc_html__( 'Add Rider', 'smart-documents-for-woocommerce' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( self::ACTION_SAVE ); ?>
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION_SAVE ); ?>" />
			<input type="hidden" name="rider_id" value="<?php echo esc_attr( $rider_id ); ?>" />
			<table class="form-table" role="presentation">
				<tr>
					<th><label for="name"><?php esc_html_e( 'Name', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="text" id="name" name="name" class="regular-text" value="<?php echo esc_attr( $rider ? $rider->post_title : '' ); ?>" required /></td>
				</tr>
				<tr>
					<th><label for="phone"><?php esc_html_e( 'Phone', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="text" id="phone" name="phone" class="regular-text" value="<?php echo esc_attr( $meta['phone'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="email"><?php esc_html_e( 'Email', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="email" id="email" name="email" class="regular-text" value="<?php echo esc_attr( $meta['email'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="vehicle_type"><?php esc_html_e( 'Vehicle Type', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="text" id="vehicle_type" name="vehicle_type" class="regular-text" value="<?php echo esc_attr( $meta['vehicle_type'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. Motorcycle, Bicycle, Van', 'smart-documents-for-woocommerce' ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="vehicle_registration"><?php esc_html_e( 'Vehicle Registration', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="text" id="vehicle_registration" name="vehicle_registration" class="regular-text" value="<?php echo esc_attr( $meta['vehicle_registration'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="rider_code"><?php esc_html_e( 'Rider ID', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="text" id="rider_code" name="rider_code" class="regular-text" value="<?php echo esc_attr( $meta['rider_code'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="zone"><?php esc_html_e( 'Zone', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="text" id="zone" name="zone" class="regular-text" value="<?php echo esc_attr( $meta['zone'] ); ?>" placeholder="<?php esc_attr_e( 'Free text — structured delivery zones are a Premium feature', 'smart-documents-for-woocommerce' ); ?>" /></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Status', 'smart-documents-for-woocommerce' ); ?></th>
					<td><label><input type="checkbox" name="active" <?php checked( 'yes', $meta['active'] ); ?> /> <?php esc_html_e( 'Active', 'smart-documents-for-woocommerce' ); ?></label></td>
				</tr>
			</table>
			<?php submit_button( $rider ? __( 'Update Rider', 'smart-documents-for-woocommerce' ) : __( 'Add Rider', 'smart-documents-for-woocommerce' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Rider list table.
	 */
	private function render_list() {
		$riders = self::get_riders();

		if ( empty( $riders ) ) {
			echo '<p>' . esc_html__( 'No riders yet.', 'smart-documents-for-woocommerce' ) . '</p>';
			return;
		}
		?>
		<h2><?php esc_html_e( 'Riders', 'smart-documents-for-woocommerce' ); ?></h2>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Name', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Phone', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Vehicle', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Zone', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $riders as $rider ) : ?>
					<tr>
						<td><?php echo esc_html( $rider->post_title ); ?></td>
						<td><?php echo esc_html( get_post_meta( $rider->ID, '_phone', true ) ); ?></td>
						<td><?php echo esc_html( get_post_meta( $rider->ID, '_vehicle_type', true ) ); ?></td>
						<td><?php echo esc_html( get_post_meta( $rider->ID, '_zone', true ) ); ?></td>
						<td><?php echo 'yes' === get_post_meta( $rider->ID, '_active', true ) ? esc_html__( 'Active', 'smart-documents-for-woocommerce' ) : esc_html__( 'Inactive', 'smart-documents-for-woocommerce' ); ?></td>
						<td>
							<a href="
							<?php
							echo esc_url(
								add_query_arg(
									array(
										'page'       => 'woosdd-delivery',
										'tab'        => 'riders',
										'edit_rider' => $rider->ID,
									),
									admin_url( 'admin.php' )
								)
							);
							?>
										"><?php esc_html_e( 'Edit', 'smart-documents-for-woocommerce' ); ?></a>
							|
							<a href="
							<?php
							echo esc_url(
								wp_nonce_url(
									add_query_arg(
										array(
											'action'   => self::ACTION_DELETE,
											'rider_id' => $rider->ID,
										),
										admin_url( 'admin-post.php' )
									),
									self::ACTION_DELETE . '_' . $rider->ID
								)
							);
							?>
										" onclick="return confirm('<?php echo esc_js( __( 'Delete this rider?', 'smart-documents-for-woocommerce' ) ); ?>');"><?php esc_html_e( 'Delete', 'smart-documents-for-woocommerce' ); ?></a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}
}

<?php
/**
 * Delivery & Dispatch: statuses, order meta box, and the Dispatch Queue
 * admin screen (with its Riders / COD tabs).
 *
 * @package Woosdd
 */

namespace Woosdd\Delivery;

defined( 'ABSPATH' ) || exit;

/**
 * Everything delivery/dispatch-related lives on the WooCommerce order
 * itself, as order meta accessed exclusively through WC_Order's own
 * CRUD methods (`get_meta()`/`update_meta_data()`/`save()`) — this is
 * what makes the module HPOS-safe and avoids a custom database table.
 *
 * Free-tier statuses only (Premium adds custom statuses via the
 * `woosdd_delivery_statuses` filter below).
 */
class Dispatch {

	const META_STATUS          = '_woosdd_delivery_status';
	const META_RIDER           = '_woosdd_rider_id';
	const META_FEE             = '_woosdd_delivery_fee';
	const META_NOTE            = '_woosdd_delivery_note';
	const META_DISPATCH_DATE   = '_woosdd_dispatch_date';
	const META_TRACKING_TOKEN  = '_woosdd_tracking_token';
	const META_COD_EXPECTED    = '_woosdd_cod_expected';
	const META_COD_COLLECTED   = '_woosdd_cod_collected';
	const META_COD_REMITTED    = '_woosdd_cod_remitted';
	const META_FAILED_REASON   = '_woosdd_failed_delivery_reason';
	const META_FAILED_ATTEMPTS = '_woosdd_failed_delivery_attempts';

	const SAVE_ACTION = 'woosdd_save_delivery_meta_box';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		if ( 'yes' !== woosdd_get_setting( 'delivery_module_enabled', 'yes' ) ) {
			return;
		}

		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'woocommerce_process_shop_order_meta', array( $this, 'save_meta_box' ), 10, 1 );
		add_action( 'save_post_shop_order', array( $this, 'save_meta_box' ), 10, 1 ); // Legacy storage fallback.
	}

	/**
	 * The nine free-tier delivery statuses.
	 *
	 * @return array slug => label
	 */
	public static function statuses() {
		$statuses = array(
			'pending_dispatch'   => __( 'Pending Dispatch', 'smart-documents-for-woocommerce' ),
			'ready_for_dispatch' => __( 'Ready for Dispatch', 'smart-documents-for-woocommerce' ),
			'assigned'           => __( 'Assigned', 'smart-documents-for-woocommerce' ),
			'picked_up'          => __( 'Picked Up', 'smart-documents-for-woocommerce' ),
			'out_for_delivery'   => __( 'Out for Delivery', 'smart-documents-for-woocommerce' ),
			'delivered'          => __( 'Delivered', 'smart-documents-for-woocommerce' ),
			'failed_delivery'    => __( 'Failed Delivery', 'smart-documents-for-woocommerce' ),
			'cancelled'          => __( 'Cancelled', 'smart-documents-for-woocommerce' ),
			'returned'           => __( 'Returned', 'smart-documents-for-woocommerce' ),
		);

		/**
		 * Extend the delivery status list. Premium adds fully custom,
		 * merchant-defined statuses on top of these nine.
		 *
		 * @param array $statuses slug => label.
		 */
		return apply_filters( 'woosdd_delivery_statuses', $statuses );
	}

	/**
	 * Register the order-edit-screen meta box (HPOS-aware screen ID).
	 */
	public function add_meta_box() {
		$screen = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';

		add_meta_box(
			'woosdd-delivery',
			__( 'Delivery & Dispatch', 'smart-documents-for-woocommerce' ),
			array( $this, 'render_meta_box' ),
			$screen,
			'side',
			'default'
		);
	}

	/**
	 * Render the order meta box.
	 *
	 * @param \WP_Post|\WC_Order $post_or_order WP_Post on legacy storage, WC_Order under HPOS.
	 */
	public function render_meta_box( $post_or_order ) {
		$order = $post_or_order instanceof \WC_Order ? $post_or_order : wc_get_order( $post_or_order->ID );
		if ( ! $order ) {
			return;
		}

		$status          = $order->get_meta( self::META_STATUS );
		$rider_id        = (int) $order->get_meta( self::META_RIDER );
		$fee             = $order->get_meta( self::META_FEE );
		$note            = $order->get_meta( self::META_NOTE );
		$cod_expected    = $order->get_meta( self::META_COD_EXPECTED );
		$cod_collected   = $order->get_meta( self::META_COD_COLLECTED );
		$cod_remitted    = $order->get_meta( self::META_COD_REMITTED );
		$failed_reason   = $order->get_meta( self::META_FAILED_REASON );
		$failed_attempts = $order->get_meta( self::META_FAILED_ATTEMPTS );

		wp_nonce_field( self::SAVE_ACTION, 'woosdd_delivery_nonce' );
		?>
		<p>
			<label for="woosdd_delivery_status"><strong><?php esc_html_e( 'Status', 'smart-documents-for-woocommerce' ); ?></strong></label><br />
			<select name="woosdd_delivery_status" id="woosdd_delivery_status" style="width:100%;">
				<option value=""><?php esc_html_e( '— Not dispatched —', 'smart-documents-for-woocommerce' ); ?></option>
				<?php foreach ( self::statuses() as $slug => $label ) : ?>
					<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $status, $slug ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<p>
			<label for="woosdd_rider_id"><strong><?php esc_html_e( 'Rider', 'smart-documents-for-woocommerce' ); ?></strong></label><br />
			<select name="woosdd_rider_id" id="woosdd_rider_id" style="width:100%;">
				<option value="0"><?php esc_html_e( '— Unassigned —', 'smart-documents-for-woocommerce' ); ?></option>
				<?php foreach ( Rider::get_riders() as $rider ) : ?>
					<option value="<?php echo esc_attr( $rider->ID ); ?>" <?php selected( $rider_id, $rider->ID ); ?>><?php echo esc_html( $rider->post_title ); ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<p>
			<label for="woosdd_delivery_fee"><strong><?php esc_html_e( 'Delivery Fee', 'smart-documents-for-woocommerce' ); ?></strong></label><br />
			<input type="text" inputmode="decimal" name="woosdd_delivery_fee" id="woosdd_delivery_fee" style="width:100%;" value="<?php echo esc_attr( $fee ); ?>" />
			<span class="description"><?php esc_html_e( 'Internal dispatch fee — separate from WooCommerce shipping.', 'smart-documents-for-woocommerce' ); ?></span>
		</p>
		<p>
			<label for="woosdd_delivery_note"><strong><?php esc_html_e( 'Delivery Note', 'smart-documents-for-woocommerce' ); ?></strong></label><br />
			<textarea name="woosdd_delivery_note" id="woosdd_delivery_note" rows="2" style="width:100%;"><?php echo esc_textarea( $note ); ?></textarea>
		</p>
		<p>
			<strong><?php esc_html_e( 'Cash on Delivery', 'smart-documents-for-woocommerce' ); ?></strong><br />
			<label style="display:inline-block;width:32%;"><?php esc_html_e( 'Expected', 'smart-documents-for-woocommerce' ); ?><br />
				<input type="text" inputmode="decimal" name="woosdd_cod_expected" style="width:100%;" value="<?php echo esc_attr( $cod_expected ); ?>" /></label>
			<label style="display:inline-block;width:32%;"><?php esc_html_e( 'Collected', 'smart-documents-for-woocommerce' ); ?><br />
				<input type="text" inputmode="decimal" name="woosdd_cod_collected" style="width:100%;" value="<?php echo esc_attr( $cod_collected ); ?>" /></label>
			<label style="display:inline-block;width:32%;"><?php esc_html_e( 'Remitted', 'smart-documents-for-woocommerce' ); ?><br />
				<input type="text" inputmode="decimal" name="woosdd_cod_remitted" style="width:100%;" value="<?php echo esc_attr( $cod_remitted ); ?>" /></label>
		</p>
		<?php if ( 'failed_delivery' === $status ) : ?>
			<p>
				<label for="woosdd_failed_reason"><strong><?php esc_html_e( 'Failure Reason', 'smart-documents-for-woocommerce' ); ?></strong></label><br />
				<input type="text" name="woosdd_failed_reason" id="woosdd_failed_reason" style="width:100%;" value="<?php echo esc_attr( $failed_reason ); ?>" />
			</p>
			<p>
				<label for="woosdd_failed_attempts"><strong><?php esc_html_e( 'Attempt Count', 'smart-documents-for-woocommerce' ); ?></strong></label><br />
				<input type="number" min="1" name="woosdd_failed_attempts" id="woosdd_failed_attempts" style="width:100%;" value="<?php echo esc_attr( $failed_attempts ? $failed_attempts : 1 ); ?>" />
			</p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Save the meta box fields. Fired from `woocommerce_process_shop_order_meta`
	 * (HPOS + legacy) and, redundantly but harmlessly, from
	 * `save_post_shop_order` on legacy storage — the nonce/capability
	 * checks make a duplicate call a no-op rather than a problem.
	 *
	 * @param int $order_id Order ID.
	 */
	public function save_meta_box( $order_id ) {
		if ( ! isset( $_POST['woosdd_delivery_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['woosdd_delivery_nonce'] ) ), self::SAVE_ACTION ) ) {
			return;
		}

		if ( ! current_user_can( woosdd_admin_capability() ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$new_status = isset( $_POST['woosdd_delivery_status'] ) ? sanitize_key( wp_unslash( $_POST['woosdd_delivery_status'] ) ) : '';
		$old_status = $order->get_meta( self::META_STATUS );

		$order->update_meta_data( self::META_STATUS, $new_status );
		$order->update_meta_data( self::META_RIDER, isset( $_POST['woosdd_rider_id'] ) ? absint( $_POST['woosdd_rider_id'] ) : 0 );
		$order->update_meta_data( self::META_FEE, isset( $_POST['woosdd_delivery_fee'] ) ? wc_format_decimal( sanitize_text_field( wp_unslash( $_POST['woosdd_delivery_fee'] ) ) ) : '' );
		$order->update_meta_data( self::META_NOTE, isset( $_POST['woosdd_delivery_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['woosdd_delivery_note'] ) ) : '' );
		$order->update_meta_data( self::META_COD_EXPECTED, isset( $_POST['woosdd_cod_expected'] ) ? wc_format_decimal( sanitize_text_field( wp_unslash( $_POST['woosdd_cod_expected'] ) ) ) : '' );
		$order->update_meta_data( self::META_COD_COLLECTED, isset( $_POST['woosdd_cod_collected'] ) ? wc_format_decimal( sanitize_text_field( wp_unslash( $_POST['woosdd_cod_collected'] ) ) ) : '' );
		$order->update_meta_data( self::META_COD_REMITTED, isset( $_POST['woosdd_cod_remitted'] ) ? wc_format_decimal( sanitize_text_field( wp_unslash( $_POST['woosdd_cod_remitted'] ) ) ) : '' );

		if ( 'failed_delivery' === $new_status ) {
			$order->update_meta_data( self::META_FAILED_REASON, isset( $_POST['woosdd_failed_reason'] ) ? sanitize_text_field( wp_unslash( $_POST['woosdd_failed_reason'] ) ) : '' );
			$order->update_meta_data( self::META_FAILED_ATTEMPTS, isset( $_POST['woosdd_failed_attempts'] ) ? absint( $_POST['woosdd_failed_attempts'] ) : 1 );
		}

		if ( $new_status && ! $order->get_meta( self::META_DISPATCH_DATE ) ) {
			$order->update_meta_data( self::META_DISPATCH_DATE, current_time( 'mysql' ) );
		}

		if ( ! $order->get_meta( self::META_TRACKING_TOKEN ) ) {
			$order->update_meta_data( self::META_TRACKING_TOKEN, wp_generate_password( 40, false, false ) );
		}

		$order->save();

		if ( $new_status !== $old_status && $new_status ) {
			/**
			 * Fires when an order's delivery status changes.
			 *
			 * @param \WC_Order $order      The order.
			 * @param string    $new_status New delivery status slug.
			 * @param string    $old_status Previous delivery status slug.
			 */
			do_action( 'woosdd_delivery_status_changed', $order, $new_status, $old_status );
		}
	}

	/**
	 * Render the Delivery & Dispatch screen: tab navigation plus the
	 * active tab's content (Dispatch Queue, Riders, COD are free; Zones,
	 * Batches, Reports are Premium upsell placeholders).
	 */
	public function render_screen() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'queue'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab selector.

		$tabs         = array(
			'queue'  => __( 'Dispatch Queue', 'smart-documents-for-woocommerce' ),
			'riders' => __( 'Riders', 'smart-documents-for-woocommerce' ),
			'cod'    => __( 'COD', 'smart-documents-for-woocommerce' ),
		);
		$premium_tabs = array(
			'zones'   => __( 'Zones', 'smart-documents-for-woocommerce' ),
			'batches' => __( 'Batches', 'smart-documents-for-woocommerce' ),
			'reports' => __( 'Delivery Reports', 'smart-documents-for-woocommerce' ),
		);

		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $tabs as $slug => $label ) {
			$url = add_query_arg(
				array(
					'page' => 'woosdd-delivery',
					'tab'  => $slug,
				),
				admin_url( 'admin.php' )
			);
			printf(
				'<a href="%1$s" class="nav-tab%2$s">%3$s</a>',
				esc_url( $url ),
				$tab === $slug ? ' nav-tab-active' : '',
				esc_html( $label )
			);
		}
		foreach ( $premium_tabs as $label ) {
			echo '<span class="nav-tab" style="opacity:0.5;cursor:default;">' . esc_html( $label ) . ' 🔒</span>';
		}
		echo '</h2>';

		echo '<div class="woosdd-tab-content" style="margin-top:16px;">';
		switch ( $tab ) {
			case 'riders':
				( new Rider() )->render();
				break;
			case 'cod':
				( new Cod() )->render();
				break;
			default:
				$this->render_queue();
		}
		echo '</div>';
	}

	/**
	 * Dispatch Queue tab: every order that has a delivery status set,
	 * newest first, with basic status/rider/zone/COD filters.
	 */
	private function render_queue() {
		$filter_status = isset( $_GET['woosdd_status'] ) ? sanitize_key( wp_unslash( $_GET['woosdd_status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter.
		$filter_rider  = isset( $_GET['woosdd_rider'] ) ? absint( $_GET['woosdd_rider'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$orders = self::find_orders_by_order_meta(
			self::META_STATUS,
			function ( \WC_Order $order ) use ( $filter_status, $filter_rider ) {
				$status = $order->get_meta( self::META_STATUS );
				if ( '' === $status ) {
					return false;
				}
				if ( $filter_status && $filter_status !== $status ) {
					return false;
				}
				if ( $filter_rider && $filter_rider !== (int) $order->get_meta( self::META_RIDER ) ) {
					return false;
				}
				return true;
			},
			50
		);

		$this->render_filters( $filter_status, $filter_rider );

		if ( empty( $orders ) ) {
			echo '<p>' . esc_html__( 'No orders in the dispatch queue yet. Set a delivery status from an order\'s Delivery & Dispatch box.', 'smart-documents-for-woocommerce' ) . '</p>';
			return;
		}

		$statuses = self::statuses();
		?>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Order', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Customer', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Rider', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Fee', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Payment', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Dispatch Date', 'smart-documents-for-woocommerce' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $orders as $order ) : ?>
					<?php
					$status        = $order->get_meta( self::META_STATUS );
					$rider_id      = (int) $order->get_meta( self::META_RIDER );
					$rider         = $rider_id ? get_post( $rider_id ) : null;
					$fee           = $order->get_meta( self::META_FEE );
					$dispatch_date = $order->get_meta( self::META_DISPATCH_DATE );
					?>
					<tr>
						<td><a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>">#<?php echo esc_html( $order->get_order_number() ); ?></a></td>
						<td><?php echo esc_html( trim( $order->get_formatted_billing_full_name() ) ); ?></td>
						<td><?php echo esc_html( isset( $statuses[ $status ] ) ? $statuses[ $status ] : $status ); ?></td>
						<td><?php echo esc_html( $rider ? $rider->post_title : '—' ); ?></td>
						<td><?php echo $fee ? wp_kses_post( wc_price( $fee, array( 'currency' => $order->get_currency() ) ) ) : '—'; ?></td>
						<td><?php echo esc_html( $order->get_payment_method_title() ); ?></td>
						<td><?php echo esc_html( $dispatch_date ? mysql2date( get_option( 'date_format' ), $dispatch_date ) : '—' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Status/rider filter dropdowns for the queue tab.
	 *
	 * @param string $filter_status Currently selected status filter.
	 * @param int    $filter_rider  Currently selected rider filter.
	 */
	private function render_filters( $filter_status, $filter_rider ) {
		?>
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" style="margin-bottom:12px;">
			<input type="hidden" name="page" value="woosdd-delivery" />
			<input type="hidden" name="tab" value="queue" />
			<select name="woosdd_status">
				<option value=""><?php esc_html_e( 'All statuses', 'smart-documents-for-woocommerce' ); ?></option>
				<?php foreach ( self::statuses() as $slug => $label ) : ?>
					<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $filter_status, $slug ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<select name="woosdd_rider">
				<option value="0"><?php esc_html_e( 'All riders', 'smart-documents-for-woocommerce' ); ?></option>
				<?php foreach ( Rider::get_riders() as $rider ) : ?>
					<option value="<?php echo esc_attr( $rider->ID ); ?>" <?php selected( $filter_rider, $rider->ID ); ?>><?php echo esc_html( $rider->post_title ); ?></option>
				<?php endforeach; ?>
			</select>
			<?php submit_button( __( 'Filter', 'smart-documents-for-woocommerce' ), 'secondary', '', false ); ?>
		</form>
		<?php
	}

	/**
	 * Scan recent orders (newest first) and return up to $limit whose
	 * $callback returns true, checking order meta via $order->get_meta().
	 *
	 * `wc_get_orders( [ 'meta_query' => ... ] )` was confirmed during live
	 * testing to NOT reliably filter on this store's WooCommerce version
	 * under legacy (post-based) order storage — the same meta_query that
	 * correctly filters via a raw WP_Query silently returned every order
	 * unfiltered when passed to wc_get_orders(). This scan-and-filter
	 * approach is slower for very large order volumes but behaves
	 * identically and correctly under HPOS and legacy storage alike; see
	 * docs/known-limitations.md for the scaling tradeoff.
	 *
	 * @param string   $meta_key Unused directly, kept for call-site clarity/documentation.
	 * @param callable $callback function( WC_Order $order ): bool.
	 * @param int      $limit    Maximum matching orders to return.
	 * @return \WC_Order[]
	 */
	public static function find_orders_by_order_meta( $meta_key, callable $callback, $limit ) {
		$matches     = array();
		$match_count = 0;
		$batch_size  = 100;
		$max_scan    = 1000; // Only the most recent 1000 orders are scanned.
		$scanned     = 0;
		$offset      = 0;

		while ( $match_count < $limit && $scanned < $max_scan ) {
			$batch = wc_get_orders(
				array(
					'limit'   => $batch_size,
					'offset'  => $offset,
					'orderby' => 'date',
					'order'   => 'DESC',
				)
			);

			$batch_count = count( $batch );

			if ( 0 === $batch_count ) {
				break;
			}

			foreach ( $batch as $order ) {
				if ( $callback( $order ) ) {
					$matches[] = $order;
					++$match_count;
					if ( $match_count >= $limit ) {
						break;
					}
				}
			}

			$scanned += $batch_count;
			$offset  += $batch_size;

			if ( $batch_count < $batch_size ) {
				break; // Reached the end of all orders.
			}
		}

		return $matches;
	}
}

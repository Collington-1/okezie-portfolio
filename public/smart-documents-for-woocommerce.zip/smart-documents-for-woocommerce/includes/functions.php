<?php
/**
 * Small standalone helper functions used across the plugin.
 *
 * Kept procedural (rather than static methods) because they're called from
 * templates and other contexts where pulling in a full class is overkill.
 *
 * @package Woosdd
 */

defined( 'ABSPATH' ) || exit;

/**
 * The capability required to manage Smart Documents screens.
 *
 * Per the plugin's own security requirements: use `manage_woocommerce` for
 * WooCommerce-adjacent management (this covers every admin screen except
 * the ones below), and reserve `manage_options` only for settings that are
 * truly site-wide.
 *
 * @return string
 */
function woosdd_admin_capability() {
	return apply_filters( 'woosdd_admin_capability', 'manage_woocommerce' );
}

/**
 * Get a plugin setting, with dot-notation support for nested keys
 * (e.g. `woosdd_get_setting( 'numbering.prefix.invoice' )`).
 *
 * @param string $key           Dot-notation key. Empty string returns everything.
 * @param mixed  $default_value Fallback if the key isn't set.
 * @return mixed
 */
function woosdd_get_setting( $key = '', $default_value = null ) {
	$settings = get_option( 'woosdd_settings', array() );

	if ( ! is_array( $settings ) ) {
		$settings = array();
	}

	// Merge over defaults so newly-added settings always have a value even
	// on a site that activated an older version of the plugin.
	$settings = array_replace_recursive( \Woosdd\Install::default_settings(), $settings );

	if ( '' === $key ) {
		return $settings;
	}

	$value = $settings;
	foreach ( explode( '.', $key ) as $segment ) {
		if ( is_array( $value ) && array_key_exists( $segment, $value ) ) {
			$value = $value[ $segment ];
		} else {
			return $default_value;
		}
	}

	return $value;
}

/**
 * Whether a Premium add-on is active and licensed.
 *
 * The free plugin never implements Premium features itself — this filter
 * is the single integration point a separate Premium add-on plugin hooks
 * into (returning true once it verifies its own license), so free-plugin
 * code can show upsell placeholders instead of building gated features.
 *
 * @return bool
 */
function woosdd_is_premium_active() {
	return (bool) apply_filters( 'woosdd_is_premium_active', false );
}

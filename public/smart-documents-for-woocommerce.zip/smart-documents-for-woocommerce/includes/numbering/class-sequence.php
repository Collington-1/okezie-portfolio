<?php
/**
 * Concurrency-safe document numbering.
 *
 * @package Woosdd
 */

namespace Woosdd\Numbering;

defined( 'ABSPATH' ) || exit;

/**
 * Allocates document numbers.
 *
 * Two numbering sources are supported (merchant's choice, see Settings):
 * - 'order_number': reuse the WooCommerce order number, no separate
 *   sequence is ever touched.
 * - 'separate': an independent, gap-free sequence per document type (and
 *   optionally per year / per year+month if a date token is enabled).
 *
 * Concurrency safety for 'separate' sequences uses MySQL's
 * LAST_INSERT_ID(expr) idiom: a single UPDATE atomically increments the
 * counter and stores the new value in the *connection-local*
 * LAST_INSERT_ID(), which a following SELECT LAST_INSERT_ID() reads back
 * safely even under concurrent requests, because LAST_INSERT_ID() is
 * scoped per-connection — unlike a plain UPDATE followed by a separate
 * SELECT, it can never return a value produced by a different request's
 * increment. This never silently reuses an issued number.
 */
class Sequence {

	/**
	 * Get the next formatted document number for a type (e.g. "invoice"),
	 * or null when the merchant has chosen to reuse the WooCommerce order
	 * number instead of a separate sequence.
	 *
	 * @param string $type Document type slug (invoice, receipt, packing_slip, delivery_note).
	 * @return string|null
	 */
	public static function next( $type ) {
		$numbering = woosdd_get_setting( 'numbering' );

		if ( 'order_number' === $numbering['source'] ) {
			return null;
		}

		$prefix     = isset( $numbering['prefix'][ $type ] ) ? $numbering['prefix'][ $type ] : strtoupper( $type ) . '-';
		$padding    = max( 1, (int) $numbering['padding'] );
		$date_token = $numbering['date_token'];
		$start      = max( 1, (int) $numbering['start'] );

		$option_key = self::option_key( $type, $date_token );
		$next_value = self::atomic_increment( $option_key, $start );

		$date_part   = self::date_part( $date_token );
		$number_part = str_pad( (string) $next_value, $padding, '0', STR_PAD_LEFT );

		return $prefix . ( $date_part ? $date_part . '-' : '' ) . $number_part;
	}

	/**
	 * Build the option name that stores a given (type, date-scope) counter.
	 *
	 * @param string $type       Document type slug.
	 * @param string $date_token 'none' | 'year' | 'year_month'.
	 * @return string
	 */
	private static function option_key( $type, $date_token ) {
		$suffix = '';
		if ( 'year' === $date_token ) {
			$suffix = '_' . gmdate( 'Y' );
		} elseif ( 'year_month' === $date_token ) {
			$suffix = '_' . gmdate( 'Y_m' );
		}
		return 'woosdd_seq_' . sanitize_key( $type ) . $suffix;
	}

	/**
	 * The date fragment inserted into the formatted number, e.g. "2026" or
	 * "2026-08". Empty when no date token is configured.
	 *
	 * @param string $date_token 'none' | 'year' | 'year_month'.
	 * @return string
	 */
	private static function date_part( $date_token ) {
		if ( 'year' === $date_token ) {
			return gmdate( 'Y' );
		}
		if ( 'year_month' === $date_token ) {
			return gmdate( 'Y-m' );
		}
		return '';
	}

	/**
	 * Atomically increment (creating if necessary) the named counter and
	 * return its new value.
	 *
	 * @param string $option_key wp_options row name for this counter.
	 * @param int    $start      First value to hand out if the counter is new.
	 * @return int
	 */
	private static function atomic_increment( $option_key, $start ) {
		global $wpdb;

		// Seed the row if it doesn't exist yet. `add_option()` is not
		// itself race-proof, but wp_options.option_name has a UNIQUE
		// index — if two requests race here, the loser's insert simply
		// fails and both fall through to the same atomic UPDATE below,
		// which is what actually guarantees correctness.
		// A direct, uncached query is required here: this is the atomic
		// increment itself (see the LAST_INSERT_ID() note in the class
		// docblock) — caching it would defeat the entire purpose, and
		// there's no wp_options accessor that exposes this SQL idiom.
		$exists = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare( "SELECT option_id FROM {$wpdb->options} WHERE option_name = %s", $option_key ) // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);
		if ( ! $exists ) {
			// autoload: false (not the legacy 'no' string) — these
			// counters are only ever read during document generation,
			// never on ordinary page loads, so there's no reason to
			// autoload them.
			add_option( $option_key, (string) ( $start - 1 ), '', false );
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $wpdb->options is a trusted table name, not user input.
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = LAST_INSERT_ID(CAST(option_value AS UNSIGNED) + 1) WHERE option_name = %s",
				$option_key
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$value = (int) $wpdb->get_var( 'SELECT LAST_INSERT_ID()' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching

		wp_cache_delete( $option_key, 'options' );

		return $value;
	}
}

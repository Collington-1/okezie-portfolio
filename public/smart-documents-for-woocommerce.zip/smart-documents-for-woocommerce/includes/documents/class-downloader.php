<?php
/**
 * Protected document downloads.
 *
 * @package Woosdd
 */

namespace Woosdd\Documents;

use Woosdd\Cpt;

defined( 'ABSPATH' ) || exit;

/**
 * Serves generated PDFs. Files never live at a public, guessable URL —
 * every download goes through one of two authorization paths:
 *
 * - Admin: `admin-post.php?action=woosdd_download_document` — requires
 *   the plugin's admin capability plus a valid nonce.
 * - Public (My Account / guest email link): `?woosdd_download=1&
 *   document=<id>&token=<random 40-char token>` — the token is compared
 *   with hash_equals() against the document's own `_access_token` meta,
 *   which is only ever handed out via the customer's My Account screen or
 *   their order email, never guessable from the document/order ID alone.
 */
class Downloader {

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'admin_post_woosdd_download_document', array( $this, 'handle_admin_download' ) );
		add_filter( 'query_vars', array( $this, 'add_query_vars' ) );
		add_action( 'template_redirect', array( $this, 'maybe_handle_public_download' ) );
	}

	/**
	 * Register the query vars used by the public/tokenized download URL.
	 *
	 * @param string[] $vars Existing public query vars.
	 * @return string[]
	 */
	public function add_query_vars( $vars ) {
		$vars[] = 'woosdd_download';
		$vars[] = 'woosdd_document';
		$vars[] = 'woosdd_token';
		return $vars;
	}

	/**
	 * Build the admin (capability-checked) download URL for a document.
	 *
	 * @param int $document_id Document post ID.
	 * @return string
	 */
	public static function admin_download_url( $document_id ) {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action'      => 'woosdd_download_document',
					'document_id' => $document_id,
				),
				admin_url( 'admin-post.php' )
			),
			'woosdd_download_document_' . $document_id
		);
	}

	/**
	 * Build the public tokenized download URL for a document (used in My
	 * Account and — via secure guest access — order emails).
	 *
	 * @param int $document_id Document post ID.
	 * @return string
	 */
	public static function public_download_url( $document_id ) {
		$token = get_post_meta( $document_id, '_access_token', true );
		return add_query_arg(
			array(
				'woosdd_download' => 1,
				'woosdd_document' => $document_id,
				'woosdd_token'    => $token,
			),
			home_url( '/' )
		);
	}

	/**
	 * Admin-post.php handler: capability + nonce checked download.
	 */
	public function handle_admin_download() {
		$document_id = isset( $_GET['document_id'] ) ? absint( $_GET['document_id'] ) : 0;

		if ( ! $document_id || ! current_user_can( woosdd_admin_capability() ) ) {
			wp_die( esc_html__( 'You are not allowed to download this document.', 'smart-documents-for-woocommerce' ), 403 );
		}

		check_admin_referer( 'woosdd_download_document_' . $document_id );

		$this->stream_document( $document_id );
	}

	/**
	 * `template_redirect` handler for the public tokenized download URL.
	 */
	public function maybe_handle_public_download() {
		if ( ! get_query_var( 'woosdd_download' ) ) {
			return;
		}

		$document_id = absint( get_query_var( 'woosdd_document' ) );
		$token       = sanitize_text_field( wp_unslash( (string) get_query_var( 'woosdd_token' ) ) );

		if ( ! $document_id || '' === $token ) {
			wp_die( esc_html__( 'Invalid document link.', 'smart-documents-for-woocommerce' ), 400 );
		}

		$stored_token = get_post_meta( $document_id, '_access_token', true );

		if ( ! $stored_token || ! hash_equals( (string) $stored_token, $token ) ) {
			wp_die( esc_html__( 'This document link is invalid or has expired.', 'smart-documents-for-woocommerce' ), 403 );
		}

		$this->stream_document( $document_id );
	}

	/**
	 * Validate a document exists/has a file, then send it with headers
	 * that prevent caching/inline execution, and exit.
	 *
	 * @param int $document_id Document post ID.
	 */
	private function stream_document( $document_id ) {
		$post = get_post( $document_id );

		if ( ! $post || Cpt::DOCUMENT !== $post->post_type ) {
			wp_die( esc_html__( 'Document not found.', 'smart-documents-for-woocommerce' ), 404 );
		}

		$path = get_post_meta( $document_id, '_file_path', true );

		// Defence in depth: the stored path must resolve inside our own
		// protected uploads directory — never trust it blindly even
		// though it's never user-supplied.
		$upload_dir  = wp_get_upload_dir();
		$allowed_dir = trailingslashit( $upload_dir['basedir'] ) . 'woosdd-documents';
		$real_path   = $path ? realpath( $path ) : false;

		if ( ! $real_path || 0 !== strpos( $real_path, realpath( $allowed_dir ) ) || ! file_exists( $real_path ) ) {
			wp_die( esc_html__( 'The PDF file for this document could not be found.', 'smart-documents-for-woocommerce' ), 404 );
		}

		$number = get_post_meta( $document_id, '_number', true );
		$type   = get_post_meta( $document_id, '_type', true );

		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: inline; filename="' . sanitize_file_name( $type . '-' . $number . '.pdf' ) . '"' );
		header( 'Content-Length: ' . filesize( $real_path ) );
		header( 'X-Content-Type-Options: nosniff' );

		// readfile() (not WP_Filesystem) is deliberate: this streams a
		// potentially large PDF straight to output without loading it
		// into memory first, which is exactly what WP_Filesystem's
		// get_contents()-based API can't do.
		readfile( $real_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		exit;
	}
}

<?php
/**
 * Normalizes WooCommerce order data for document templates.
 *
 * @package Woosdd
 */

namespace Woosdd\Documents;

defined( 'ABSPATH' ) || exit;

/**
 * Pulls everything a document template needs out of a WC_Order using only
 * WooCommerce's own CRUD accessors (never get_post_meta()/wp_posts) and
 * shapes it into one flat, template-friendly array. Every value is raw
 * (not yet escaped) — templates are responsible for escaping by context
 * when they echo it.
 */
class Document_Data {

	/**
	 * Build the template data array for one order + document type.
	 *
	 * @param \WC_Order $order Order object.
	 * @param string    $type  Document type slug.
	 * @return array
	 */
	public static function from_order( \WC_Order $order, $type ) {
		$settings = woosdd_get_setting( '' );

		return array(
			'type'            => $type,
			'type_label'      => self::type_label( $type ),
			'order'           => $order,
			'order_number'    => $order->get_order_number(),
			'order_date'      => $order->get_date_created() ? $order->get_date_created()->date_i18n( get_option( 'date_format' ) ) : '',
			'currency'        => $order->get_currency(),
			'business'        => self::business_profile( $settings ),
			'billing'         => self::billing_address( $order ),
			'shipping'        => self::shipping_address( $order ),
			'shows_shipping'  => 'packing_slip' !== $type && 'delivery_note' !== $type && $order->has_shipping_address(),
			'payment_method'  => $order->get_payment_method_title(),
			'shipping_method' => $order->get_shipping_method(),
			'line_items'      => self::line_items( $order ),
			'coupons'         => self::coupons( $order ),
			'totals'          => self::totals( $order ),
			'tax_lines'       => self::tax_lines( $order ),
			'customer_note'   => $order->get_customer_note(),
			'accent_color'    => isset( $settings['accent_color'] ) ? $settings['accent_color'] : '#2271b1',
		);
	}

	/**
	 * Human-readable label for a document type.
	 *
	 * @param string $type Document type slug.
	 * @return string
	 */
	public static function type_label( $type ) {
		$labels = array(
			'invoice'       => __( 'Invoice', 'smart-documents-for-woocommerce' ),
			'receipt'       => __( 'Receipt', 'smart-documents-for-woocommerce' ),
			'packing_slip'  => __( 'Packing Slip', 'smart-documents-for-woocommerce' ),
			'delivery_note' => __( 'Delivery Note', 'smart-documents-for-woocommerce' ),
		);
		return isset( $labels[ $type ] ) ? $labels[ $type ] : ucwords( str_replace( '_', ' ', $type ) );
	}

	/**
	 * Merchant business/payment profile, from plugin settings.
	 *
	 * @param array $settings Full plugin settings array.
	 * @return array
	 */
	private static function business_profile( $settings ) {
		$business = isset( $settings['business'] ) ? $settings['business'] : array();

		return wp_parse_args(
			$business,
			array(
				'name'         => get_bloginfo( 'name' ),
				'logo_id'      => 0,
				'address'      => '',
				'email'        => get_bloginfo( 'admin_email' ),
				'phone'        => '',
				'tax_id'       => '',
				'bank_details' => '',
				'footer_text'  => '',
			)
		);
	}

	/**
	 * Billing address block, using WooCommerce's own formatter.
	 *
	 * `get_formatted_billing_address()` already includes the customer's
	 * name as its first line (WooCommerce bakes {name} into the country
	 * address format) — templates must render `address` as-is and must
	 * NOT also print a separate name line, or the name is duplicated.
	 *
	 * @param \WC_Order $order Order object.
	 * @return array
	 */
	private static function billing_address( \WC_Order $order ) {
		return array(
			'address' => $order->get_formatted_billing_address( '' ),
			'email'   => $order->get_billing_email(),
			'phone'   => $order->get_billing_phone(),
		);
	}

	/**
	 * Shipping address block. Falls back to the full billing address
	 * (name included) when no separate shipping address was given —
	 * matching `has_shipping_address` used elsewhere to decide whether to
	 * show a "Ship To" box at all.
	 *
	 * @param \WC_Order $order Order object.
	 * @return array
	 */
	private static function shipping_address( \WC_Order $order ) {
		$formatted = $order->get_formatted_shipping_address( '' );

		return array(
			'address' => $formatted ? $formatted : $order->get_formatted_billing_address( '' ),
		);
	}

	/**
	 * Line items (products, fees are handled separately).
	 *
	 * @param \WC_Order $order Order object.
	 * @return array[]
	 */
	private static function line_items( \WC_Order $order ) {
		$items = array();

		foreach ( $order->get_items( 'line_item' ) as $item ) {
			/** @var \WC_Order_Item_Product $item */ // phpcs:ignore Generic.Commenting.DocComment.MissingShort -- inline IDE type hint, not a documented symbol.
			$product = $item->get_product();

			$items[] = array(
				'name'       => $item->get_name(),
				'sku'        => $product ? $product->get_sku() : '',
				'quantity'   => $item->get_quantity(),
				'unit_price' => $order->get_item_subtotal( $item, false, true ),
				'subtotal'   => wc_format_decimal( $item->get_subtotal(), '' ),
				'total'      => wc_format_decimal( $item->get_total(), '' ),
				'discount'   => wc_format_decimal( $item->get_subtotal() - $item->get_total(), '' ),
				'tax'        => wc_format_decimal( $item->get_total_tax(), '' ),
				'image_id'   => $product ? $product->get_image_id() : 0,
			);
		}

		foreach ( $order->get_items( 'fee' ) as $item ) {
			/** @var \WC_Order_Item_Fee $item */ // phpcs:ignore Generic.Commenting.DocComment.MissingShort -- inline IDE type hint, not a documented symbol.
			$items[] = array(
				'name'       => $item->get_name(),
				'sku'        => '',
				'quantity'   => 1,
				'unit_price' => wc_format_decimal( $item->get_total(), '' ),
				'subtotal'   => wc_format_decimal( $item->get_total(), '' ),
				'total'      => wc_format_decimal( $item->get_total(), '' ),
				'discount'   => '0',
				'tax'        => wc_format_decimal( $item->get_total_tax(), '' ),
				'image_id'   => 0,
			);
		}

		return $items;
	}

	/**
	 * Applied coupon codes.
	 *
	 * @param \WC_Order $order Order object.
	 * @return string[]
	 */
	private static function coupons( \WC_Order $order ) {
		$codes = array();
		foreach ( $order->get_items( 'coupon' ) as $item ) {
			/** @var \WC_Order_Item_Coupon $item */ // phpcs:ignore Generic.Commenting.DocComment.MissingShort -- inline IDE type hint, not a documented symbol.
			$codes[] = $item->get_code();
		}
		return $codes;
	}

	/**
	 * Order-level totals (subtotal, shipping, discount, tax, grand total).
	 *
	 * @param \WC_Order $order Order object.
	 * @return array
	 */
	private static function totals( \WC_Order $order ) {
		return array(
			'subtotal'       => $order->get_subtotal(),
			'discount_total' => $order->get_discount_total(),
			'shipping_total' => $order->get_shipping_total(),
			'fee_total'      => $order->get_total_fees(),
			'tax_total'      => $order->get_total_tax(),
			'total'          => $order->get_total(),
		);
	}

	/**
	 * Per-rate tax lines, so templates can show a tax breakdown.
	 *
	 * @param \WC_Order $order Order object.
	 * @return array[]
	 */
	private static function tax_lines( \WC_Order $order ) {
		$lines = array();
		foreach ( $order->get_items( 'tax' ) as $item ) {
			/** @var \WC_Order_Item_Tax $item */ // phpcs:ignore Generic.Commenting.DocComment.MissingShort -- inline IDE type hint, not a documented symbol.
			$lines[] = array(
				'label'  => $item->get_label(),
				'amount' => wc_format_decimal( $item->get_tax_total(), '' ),
			);
		}
		return $lines;
	}
}

<?php
/**
 * Document + PDF generation.
 *
 * @package Woosdd
 */

namespace Woosdd\Documents;

use Dompdf\Dompdf;
use Dompdf\Options;
use Woosdd\Cpt;
use Woosdd\Numbering\Sequence;

defined( 'ABSPATH' ) || exit;

/**
 * Generates Invoice / Receipt / Packing Slip / Delivery Note documents
 * for a WooCommerce order: allocates (or reuses) a document number,
 * renders the merchant's chosen template to HTML, converts it to a PDF
 * with Dompdf entirely locally, and stores the file in the plugin's
 * protected uploads directory.
 *
 * Regenerating an already-issued document (same order + type) always
 * reuses its existing woosdd_document post and number — it never
 * allocates a second number for the same document.
 */
class Generator {

	const VALID_TYPES = array( 'invoice', 'receipt', 'packing_slip', 'delivery_note' );

	/**
	 * Generate (or regenerate) a document and return its post ID.
	 *
	 * @param \WC_Order|int $order Order object or ID.
	 * @param string        $type  One of Generator::VALID_TYPES.
	 * @return int|\WP_Error Document post ID on success.
	 */
	public function generate( $order, $type ) {
		if ( ! in_array( $type, self::VALID_TYPES, true ) ) {
			return new \WP_Error( 'woosdd_invalid_type', __( 'Unknown document type.', 'smart-documents-for-woocommerce' ) );
		}

		$order = $order instanceof \WC_Order ? $order : wc_get_order( $order );
		if ( ! $order ) {
			return new \WP_Error( 'woosdd_invalid_order', __( 'Order not found.', 'smart-documents-for-woocommerce' ) );
		}

		$document_id = $this->get_or_create_document( $order, $type );
		if ( is_wp_error( $document_id ) ) {
			return $document_id;
		}

		$number   = get_post_meta( $document_id, '_number', true );
		$template = woosdd_get_setting( 'template', 'template-1' );

		$data = Document_Data::from_order( $order, $type );

		$html = $this->render_template( $template, $data, $number );
		if ( is_wp_error( $html ) ) {
			return $html;
		}

		$pdf_path = $this->render_pdf( $html );
		if ( is_wp_error( $pdf_path ) ) {
			return $pdf_path;
		}

		update_post_meta( $document_id, '_status', 'generated' );
		update_post_meta( $document_id, '_template', $template );
		update_post_meta( $document_id, '_file_path', $pdf_path );
		update_post_meta( $document_id, '_generated_at', current_time( 'mysql' ) );

		/**
		 * Fires after a document has been generated.
		 *
		 * @param int       $document_id Document post ID.
		 * @param string    $type        Document type slug.
		 * @param \WC_Order $order       The order it was generated for.
		 */
		do_action( 'woosdd_document_generated', $document_id, $type, $order );

		return $document_id;
	}

	/**
	 * Find the existing document for this order+type, or create a new
	 * woosdd_document post with a freshly allocated number.
	 *
	 * @param \WC_Order $order Order object.
	 * @param string    $type  Document type slug.
	 * @return int|\WP_Error
	 */
	private function get_or_create_document( \WC_Order $order, $type ) {
		$existing = get_posts(
			array(
				'post_type'   => Cpt::DOCUMENT,
				'post_status' => 'any',
				'numberposts' => 1,
				'fields'      => 'ids',
				'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => '_order_id',
						'value' => $order->get_id(),
					),
					array(
						'key'   => '_type',
						'value' => $type,
					),
				),
			)
		);

		if ( ! empty( $existing ) ) {
			return $existing[0];
		}

		$number = Sequence::next( $type );
		if ( null === $number ) {
			// Merchant chose to reuse the WooCommerce order number instead
			// of a separate sequence.
			$numbering = woosdd_get_setting( 'numbering' );
			$prefix    = isset( $numbering['prefix'][ $type ] ) ? $numbering['prefix'][ $type ] : strtoupper( $type ) . '-';
			$number    = $prefix . $order->get_order_number();
		}

		$document_id = wp_insert_post(
			array(
				'post_type'   => Cpt::DOCUMENT,
				'post_title'  => $number,
				'post_status' => 'publish',
			),
			true
		);

		if ( is_wp_error( $document_id ) ) {
			return $document_id;
		}

		update_post_meta( $document_id, '_order_id', $order->get_id() );
		update_post_meta( $document_id, '_type', $type );
		update_post_meta( $document_id, '_number', $number );
		update_post_meta( $document_id, '_status', 'pending' );
		update_post_meta( $document_id, '_access_token', wp_generate_password( 40, false, false ) );

		return $document_id;
	}

	/**
	 * Render the chosen template to an HTML string.
	 *
	 * @param string $template        Template slug ('template-1' or 'template-2').
	 * @param array  $data            Document_Data::from_order() output.
	 * @param string $document_number Allocated/reused document number. Not
	 *                                referenced directly in this method —
	 *                                `include` below shares this method's
	 *                                local scope with the template file,
	 *                                which reads $document_number by name.
	 * @return string|\WP_Error
	 */
	private function render_template( $template, array $data, $document_number ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		$template = in_array( $template, array( 'template-1', 'template-2' ), true ) ? $template : 'template-1';
		$file     = WOOSDD_PATH . 'templates/documents/' . $template . '.php';

		/**
		 * Filter the template file path before rendering. Lets a future
		 * Premium add-on register additional (unlimited) templates without
		 * touching this class.
		 *
		 * @param string $file     Absolute path to the template file.
		 * @param string $template Template slug.
		 * @param array  $data     Document data.
		 */
		$file = apply_filters( 'woosdd_document_template_file', $file, $template, $data );

		if ( ! file_exists( $file ) ) {
			return new \WP_Error( 'woosdd_missing_template', __( 'Document template file is missing.', 'smart-documents-for-woocommerce' ) );
		}

		ob_start();
		include $file;
		return ob_get_clean();
	}

	/**
	 * Convert HTML to a PDF file inside the protected uploads directory
	 * and return its absolute path.
	 *
	 * @param string $html Rendered document HTML.
	 * @return string|\WP_Error
	 */
	private function render_pdf( $html ) {
		$options = new Options();
		// No remote fonts/CSS/images/CDNs — everything must be local, per
		// the plugin's own security requirements.
		$options->set( 'isRemoteEnabled', false );
		$options->set( 'isHtml5ParserEnabled', true );
		$options->set( 'defaultFont', 'DejaVu Sans' );
		$options->set( 'chroot', array( WOOSDD_PATH, wp_get_upload_dir()['basedir'] ) );

		$dompdf = new Dompdf( $options );
		$dompdf->loadHtml( $html );

		$page_size   = woosdd_get_setting( 'page_size', 'a4' );
		$orientation = woosdd_get_setting( 'orientation', 'portrait' );
		$dompdf->setPaper( $page_size, $orientation );

		$dompdf->render();

		$upload_dir = wp_get_upload_dir();
		$target_dir = trailingslashit( $upload_dir['basedir'] ) . 'woosdd-documents';
		if ( ! file_exists( $target_dir ) ) {
			wp_mkdir_p( $target_dir );
		}

		$filename = 'woosdd-' . wp_generate_password( 20, false, false ) . '.pdf';
		$path     = trailingslashit( $target_dir ) . $filename;

		$bytes = file_put_contents( $path, $dompdf->output() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		if ( false === $bytes ) {
			return new \WP_Error( 'woosdd_pdf_write_failed', __( 'Could not save the generated PDF.', 'smart-documents-for-woocommerce' ) );
		}

		return $path;
	}
}

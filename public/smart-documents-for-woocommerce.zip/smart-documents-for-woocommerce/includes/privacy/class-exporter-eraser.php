<?php
/**
 * WordPress privacy exporter/eraser integration.
 *
 * @package Woosdd
 */

namespace Woosdd\Privacy;

use Woosdd\Cpt;

defined( 'ABSPATH' ) || exit;

/**
 * Registers this plugin's data with WordPress's built-in "Export Personal
 * Data" / "Erase Personal Data" tools (Settings -> Privacy -> the request
 * screens).
 *
 * What this plugin stores about a customer, and why the eraser is
 * intentionally conservative:
 *
 * - Generated documents (invoice/receipt/packing slip/delivery note)
 *   contain the customer's billing name/address, baked into an already
 *   issued PDF. WooCommerce itself does not erase completed orders by
 *   default for the same reason: they are financial/accounting records a
 *   merchant may be legally required to retain. This plugin follows that
 *   same precedent and does not delete already-generated PDFs or their
 *   document number/history on an erasure request.
 * - What genuinely is safe, useful, and expected to be erased on request
 *   is the customer's *direct access* to those documents/tracking: their
 *   secure guest download tokens and tracking token are revoked, so old
 *   links stop working. The document itself remains in the merchant's own
 *   records, exactly like the underlying order does.
 * - Delivery/COD/rider-assignment data lives on the order as
 *   `_woosdd_*` order meta — again a transactional/accounting record tied
 *   to the order, not separate customer data, so it follows the order's
 *   own retention, not a separate erasure path.
 */
class Exporter_Eraser {

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_filter( 'wp_privacy_personal_data_exporters', array( $this, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( $this, 'register_eraser' ) );
	}

	/**
	 * Register our exporter callback with WordPress's Privacy tools.
	 *
	 * @param array $exporters Existing registered exporters.
	 * @return array
	 */
	public function register_exporter( $exporters ) {
		$exporters['woosdd-documents'] = array(
			'exporter_friendly_name' => __( 'Smart Documents for WooCommerce', 'smart-documents-for-woocommerce' ),
			'callback'               => array( $this, 'export' ),
		);
		return $exporters;
	}

	/**
	 * Register our eraser callback with WordPress's Privacy tools.
	 *
	 * @param array $erasers Existing registered erasers.
	 * @return array
	 */
	public function register_eraser( $erasers ) {
		$erasers['woosdd-documents'] = array(
			'eraser_friendly_name' => __( 'Smart Documents for WooCommerce', 'smart-documents-for-woocommerce' ),
			'callback'             => array( $this, 'erase' ),
		);
		return $erasers;
	}

	/**
	 * Export every document generated for orders placed with this email
	 * address, plus the delivery/COD data recorded against those orders.
	 *
	 * @param string $email_address Requested email address.
	 * @param int    $page          Page number (1-indexed). Unused — the
	 *                              full result set is small enough for a
	 *                              single pass, but the parameter is
	 *                              required by WordPress's exporter
	 *                              callback signature.
	 * @return array
	 */
	public function export( $email_address, $page = 1 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		$order_ids = $this->order_ids_for_email( $email_address );
		$items     = array();

		foreach ( $order_ids as $order_id ) {
			$order = wc_get_order( $order_id );
			if ( ! $order ) {
				continue;
			}

			$documents = get_posts(
				array(
					'post_type'   => Cpt::DOCUMENT,
					'post_status' => 'any',
					'numberposts' => -1,
					'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						array(
							'key'   => '_order_id',
							'value' => $order_id,
						),
					),
				)
			);

			foreach ( $documents as $document ) {
				$items[] = array(
					'group_id'    => 'woosdd-documents',
					'group_label' => __( 'Documents', 'smart-documents-for-woocommerce' ),
					'item_id'     => 'woosdd-document-' . $document->ID,
					'data'        => array(
						array(
							'name'  => __( 'Document Number', 'smart-documents-for-woocommerce' ),
							'value' => $document->post_title,
						),
						array(
							'name'  => __( 'Document Type', 'smart-documents-for-woocommerce' ),
							'value' => get_post_meta( $document->ID, '_type', true ),
						),
						array(
							'name'  => __( 'Order', 'smart-documents-for-woocommerce' ),
							'value' => '#' . $order->get_order_number(),
						),
						array(
							'name'  => __( 'Generated', 'smart-documents-for-woocommerce' ),
							'value' => get_post_meta( $document->ID, '_generated_at', true ),
						),
					),
				);
			}

			$delivery_status = $order->get_meta( '_woosdd_delivery_status' );
			if ( $delivery_status ) {
				$items[] = array(
					'group_id'    => 'woosdd-delivery',
					'group_label' => __( 'Delivery', 'smart-documents-for-woocommerce' ),
					'item_id'     => 'woosdd-delivery-' . $order_id,
					'data'        => array(
						array(
							'name'  => __( 'Order', 'smart-documents-for-woocommerce' ),
							'value' => '#' . $order->get_order_number(),
						),
						array(
							'name'  => __( 'Delivery Status', 'smart-documents-for-woocommerce' ),
							'value' => $delivery_status,
						),
						array(
							'name'  => __( 'Delivery Fee', 'smart-documents-for-woocommerce' ),
							'value' => $order->get_meta( '_woosdd_delivery_fee' ),
						),
						array(
							'name'  => __( 'COD Expected', 'smart-documents-for-woocommerce' ),
							'value' => $order->get_meta( '_woosdd_cod_expected' ),
						),
						array(
							'name'  => __( 'COD Collected', 'smart-documents-for-woocommerce' ),
							'value' => $order->get_meta( '_woosdd_cod_collected' ),
						),
					),
				);
			}
		}

		return array(
			'data' => $items,
			'done' => true, // Single pass — order counts here are small enough not to need real pagination.
		);
	}

	/**
	 * Revoke direct customer access to documents/tracking for this email's
	 * orders (guest download + tracking tokens). Never deletes the
	 * documents, the order, or delivery/COD records themselves — see the
	 * class docblock for why.
	 *
	 * @param string $email_address Requested email address.
	 * @param int    $page          Page number (1-indexed). Unused — same
	 *                              reasoning as export() above.
	 * @return array
	 */
	public function erase( $email_address, $page = 1 ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
		$order_ids     = $this->order_ids_for_email( $email_address );
		$items_removed = false;

		foreach ( $order_ids as $order_id ) {
			$order = wc_get_order( $order_id );
			if ( $order && $order->get_meta( '_woosdd_tracking_token' ) ) {
				$order->delete_meta_data( '_woosdd_tracking_token' );
				$order->save();
				$items_removed = true;
			}

			$documents = get_posts(
				array(
					'post_type'   => Cpt::DOCUMENT,
					'post_status' => 'any',
					'numberposts' => -1,
					'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
						array(
							'key'   => '_order_id',
							'value' => $order_id,
						),
					),
				)
			);

			foreach ( $documents as $document ) {
				if ( get_post_meta( $document->ID, '_access_token', true ) ) {
					delete_post_meta( $document->ID, '_access_token' );
					$items_removed = true;
				}
			}
		}

		return array(
			'items_removed'  => $items_removed,
			'items_retained' => ! empty( $order_ids ), // Documents/orders themselves are retained as financial records.
			'messages'       => empty( $order_ids ) ? array() : array(
				__( 'Generated documents and delivery/order records are retained as financial records, matching how WooCommerce retains the underlying order. Direct guest access links (document downloads and delivery tracking) have been revoked.', 'smart-documents-for-woocommerce' ),
			),
			'done'           => true,
		);
	}

	/**
	 * All order IDs (any status) placed with a given billing email.
	 *
	 * @param string $email_address Email address.
	 * @return int[]
	 */
	private function order_ids_for_email( $email_address ) {
		return wc_get_orders(
			array(
				'billing_email' => $email_address,
				'limit'         => -1,
				'return'        => 'ids',
			)
		);
	}
}

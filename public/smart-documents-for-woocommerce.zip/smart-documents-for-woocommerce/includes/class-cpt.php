<?php
/**
 * Custom post type registration.
 *
 * @package Woosdd
 */

namespace Woosdd;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the plugin's two custom post types. Both are internal,
 * admin-only records — never queried by WooCommerce order code — which is
 * how the plugin satisfies the "no custom database tables in v1" rule
 * while still getting a real list-table UI for free.
 *
 * - woosdd_document: one row per generated document (invoice/receipt/
 *   packing slip/delivery note). Post title is the document number; post
 *   meta holds type, linked order ID, template, status and file path.
 * - woosdd_rider: one row per delivery rider profile.
 */
class Cpt {

	const DOCUMENT = 'woosdd_document';
	const RIDER    = 'woosdd_rider';

	/**
	 * Register post types on `init`.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_document_cpt' ) );
		add_action( 'init', array( $this, 'register_rider_cpt' ) );
	}

	/**
	 * Register the document history post type.
	 */
	public function register_document_cpt() {
		register_post_type(
			self::DOCUMENT,
			array(
				'label'               => __( 'Documents', 'smart-documents-for-woocommerce' ),
				'labels'              => array(
					'name'          => __( 'Documents', 'smart-documents-for-woocommerce' ),
					'singular_name' => __( 'Document', 'smart-documents-for-woocommerce' ),
				),
				'public'              => false,
				'show_ui'             => false, // We render our own list screen under the Documents submenu.
				'show_in_menu'        => false,
				'show_in_rest'        => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'capabilities'        => array(
					'create_posts' => 'do_not_allow', // Documents are only ever created programmatically.
				),
				'map_meta_cap'        => true,
				'hierarchical'        => false,
				'supports'            => array( 'title' ),
				'rewrite'             => false,
				'query_var'           => false,
			)
		);
	}

	/**
	 * Register the rider profile post type.
	 */
	public function register_rider_cpt() {
		register_post_type(
			self::RIDER,
			array(
				'label'               => __( 'Riders', 'smart-documents-for-woocommerce' ),
				'labels'              => array(
					'name'          => __( 'Riders', 'smart-documents-for-woocommerce' ),
					'singular_name' => __( 'Rider', 'smart-documents-for-woocommerce' ),
				),
				'public'              => false,
				'show_ui'             => false, // We render our own screen under Delivery & Dispatch > Riders.
				'show_in_menu'        => false,
				'show_in_rest'        => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'hierarchical'        => false,
				'supports'            => array( 'title' ),
				'rewrite'             => false,
				'query_var'           => false,
			)
		);
	}
}

<?php
/**
 * Activation-time setup.
 *
 * @package Woosdd
 */

namespace Woosdd;

defined( 'ABSPATH' ) || exit;

/**
 * Runs once, on plugin activation. Never touches WooCommerce order data —
 * it only prepares this plugin's own protected upload directory and
 * rewrite rules.
 */
class Install {

	/**
	 * Activation entry point (called from register_activation_hook()).
	 */
	public static function activate() {
		self::create_protected_upload_dir();
		self::add_default_options();

		// Only offer the setup wizard redirect for a genuinely fresh
		// install — never on every reactivation once onboarding is done.
		if ( 'yes' !== get_option( 'woosdd_onboarding_complete', 'no' ) ) {
			set_transient( 'woosdd_activation_redirect', 1, 30 );
		}

		// Rewrite rules (My Account "documents" endpoint, tracking page)
		// are registered by Frontend\My_Account / Frontend\Tracking on
		// `init`, which already ran earlier in this request — flush now
		// so they take effect immediately instead of waiting for the
		// merchant to visit Settings > Permalinks.
		flush_rewrite_rules();
	}

	/**
	 * Create wp-content/uploads/woosdd-documents/ with an index.php guard
	 * so directory listing never exposes generated PDFs. Individual files
	 * inside are additionally only ever served through the nonce +
	 * ownership-checked download handler — never linked to directly.
	 */
	private static function create_protected_upload_dir() {
		$upload_dir = wp_get_upload_dir();
		$target_dir = trailingslashit( $upload_dir['basedir'] ) . 'woosdd-documents';

		if ( ! file_exists( $target_dir ) ) {
			wp_mkdir_p( $target_dir );
		}

		$index_file = trailingslashit( $target_dir ) . 'index.php';
		if ( ! file_exists( $index_file ) ) {
			file_put_contents( $index_file, "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$htaccess_file = trailingslashit( $target_dir ) . '.htaccess';
		if ( ! file_exists( $htaccess_file ) ) {
			// Belt-and-braces for Apache hosts; nginx hosts rely solely on
			// the download handler never exposing a guessable path plus
			// the fact that nothing links to this directory publicly.
			file_put_contents( $htaccess_file, "Require all denied\ndeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
	}

	/**
	 * Seed default options (only if they don't already exist, so
	 * re-activation never clobbers a merchant's settings).
	 */
	private static function add_default_options() {
		add_option( 'woosdd_settings', self::default_settings() );
		add_option( 'woosdd_remove_data_on_uninstall', 'no' );
		add_option( 'woosdd_onboarding_complete', 'no' );
	}

	/**
	 * Default plugin settings.
	 *
	 * @return array
	 */
	public static function default_settings() {
		return array(
			'template'                  => 'template-1',
			'accent_color'              => '#2271b1',
			'page_size'                 => 'a4',
			'orientation'               => 'portrait',
			'numbering'                 => array(
				// 'source' is either "order_number" or "separate" — see
				// Numbering\Sequence for where it's consumed.
				'source'     => 'separate',
				'prefix'     => array(
					'invoice'       => 'INV-',
					'receipt'       => 'REC-',
					'packing_slip'  => 'PAK-',
					'delivery_note' => 'DEL-',
				),
				'start'      => 1,
				'padding'    => 6,
				// 'date_token' is one of "none", "year" or "year_month".
				'date_token' => 'none',
			),
			'delivery_module_enabled'   => 'yes',
			'email_attachments_enabled' => 'yes',
		);
	}
}

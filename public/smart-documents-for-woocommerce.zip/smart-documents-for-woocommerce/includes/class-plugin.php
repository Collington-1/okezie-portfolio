<?php
/**
 * Main plugin container.
 *
 * @package Woosdd
 */

namespace Woosdd;

defined( 'ABSPATH' ) || exit;

/**
 * Boots and holds every subsystem of the plugin. Constructed once from
 * woosdd_bootstrap() on `plugins_loaded`, after we've already confirmed
 * WooCommerce is active.
 */
final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get (and lazily create) the singleton instance.
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Wire up every subsystem. Kept intentionally flat and readable —
	 * each class registers its own hooks in its constructor.
	 */
	private function __construct() {
		$this->includes();
		$this->init_hooks();
	}

	/**
	 * Nothing to manually require: Composer's classmap autoloader (see
	 * composer.json — classmap, not PSR-4, so our WordPress-style
	 * `class-*.php` filenames don't need to match their class names)
	 * resolves every Woosdd\* class on first use. This method exists as
	 * an explicit hook point for anything that isn't autoload-friendly
	 * (e.g. procedural template-tag files).
	 */
	private function includes() {
		// Reserved for future procedural includes (e.g. template-tags.php).
	}

	/**
	 * Instantiate every subsystem. Each class is self-contained and wires
	 * its own WordPress hooks in its constructor — Plugin itself never
	 * calls add_action()/add_filter() directly.
	 *
	 * This list grows milestone by milestone (see the plan); classes are
	 * only referenced here once they exist, so a partially-built plugin
	 * never fatals on activation.
	 */
	private function init_hooks() {
		new Cpt();
		new Documents\Downloader();
		new Automation\Automation();
		new Delivery\Dispatch();
		new Delivery\Rider();
		new Frontend\My_Account();
		new Frontend\Tracking();
		new Privacy\Exporter_Eraser();

		if ( is_admin() ) {
			new Admin\Menu();
			new Admin\Order_Actions();
			new Admin\Settings_Screen();
			new Admin\Templates_Screen();
			new Admin\Onboarding();
		}
	}
}

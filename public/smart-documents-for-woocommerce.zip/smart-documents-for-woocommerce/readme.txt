=== Smart Documents for WooCommerce – Invoices, Receipts & Delivery ===
Contributors: okezie
Tags: woocommerce invoices, pdf invoices, receipts, packing slips, delivery notes
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.1.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Generate professional WooCommerce invoices, receipts, packing slips and delivery notes, plus dispatch and delivery tracking.

== Description ==

Smart Documents for WooCommerce lets you generate professional PDF invoices,
receipts, packing slips and delivery notes directly from your WooCommerce
orders — no third-party service, no paid API, no account registration.
Everything runs locally on your own WordPress install.

A companion Delivery & Dispatch module (toggleable, and lightweight by
default) helps small stores and service businesses track rider assignment,
delivery status and cash-on-delivery, which is especially useful for
merchants in Nigeria, across Africa, and other emerging markets where
last-mile delivery tracking matters as much as the invoice itself.

**This plugin is under active development.** This readme, the changelog and
the full feature list will be completed as each milestone lands — see the
project's `docs/` folder for current build status.

= Free features =

* Invoice, Receipt, Packing Slip and Delivery Note documents
* Two polished, ready-to-use templates
* Logo, accent color and business profile
* Flexible document numbering (prefix, padding, date tokens, or reuse the WooCommerce order number)
* PDF, print and browser preview, generated 100% locally
* Basic automation (e.g. order paid → generate invoice → attach to email)
* My Account document access for logged-in customers, plus secure tokenized guest access
* Delivery & Dispatch: standard statuses, rider assignment and profiles, manual delivery fee, delivery notes, basic COD tracking

= Premium (separate add-on) =

Proforma invoices, credit notes, quotes, purchase orders, unlimited custom
templates, a drag-and-drop document builder, delivery zones, dispatch
batches, proof of delivery, advanced COD reconciliation, delivery reports
and more. Premium is sold as a separate add-on plugin — the free plugin is
never trialware and remains genuinely useful on its own.

== Installation ==

1. Upload the plugin to `/wp-content/plugins/` (or install via the Plugins screen).
2. Activate Smart Documents for WooCommerce.
3. WooCommerce must already be installed and active.
4. Follow the onboarding wizard, or visit Smart Documents → Settings to configure manually.

== Frequently Asked Questions ==

= Does this require a paid API or external service? =

No. PDF generation, storage and delivery tracking all run locally on your
own WordPress install. No mandatory account, no license server for core
functionality.

= Will this work with High-Performance Order Storage (HPOS)? =

Yes — the plugin declares and is tested against HPOS, and reads/writes
order data exclusively through WooCommerce's own CRUD APIs.

== Privacy ==

See `docs/privacy.md` in the plugin source for a full description of the
personal data this plugin processes (customer contact/billing details on
generated documents, rider profile data, optional proof-of-delivery data)
and how the built-in WordPress privacy exporter/eraser tools apply.

== Changelog ==

= 0.1.5 =
* WordPress.org's official Plugin Check tool now reports zero errors and zero warnings, verified against a real (non-symlinked) copy of the actual built ZIP.
* Fixed the last remaining finding (missing_composer_json_file): composer.json is now included in the release build since it's an inert manifest with no functional risk to ship (composer.lock and composer.phar remain excluded).

= 0.1.4 =
* Renamed the plugin to "Smart Documents for WooCommerce" (slug: smart-documents-for-woocommerce) to comply with WordPress.org's trademark policy on "WooCommerce" in plugin names/slugs.
* Fixed real findings from the official Plugin Check tool: removed a discouraged load_plugin_textdomain() call and a discouraged suppress_filters usage, switched an option's autoload param from the legacy 'no' string to false, prefixed unprefixed global variables in uninstall.php, bumped readme.txt's "Tested up to" and shortened its short description.
* Fixed a real production-build issue: a stale build/ output folder was living inside the plugin's own source directory, which caused dev-only tooling to be scanned as if it were part of the live plugin. Build output now always goes to a sibling directory.

= 0.1.3 =
* WordPress.org pre-submission checklist: all 20 items now verified against a real running site (was 18/20).
* PHP 7.4 compatibility verified on a real downloaded PHP 7.4.33 interpreter (php -l across all 28 plugin files + 415 vendored files, plus Dompdf instantiated directly under it).
* Customer authorization verified (My Account "My Documents" tab: empty state, populated state with a real working download link, tracking action) without creating any account or browser session.

= 0.1.2 =
* Built the real Dashboard (document/delivery counts, recent activity, quick links) — was previously a placeholder.
* Verified HPOS (on and off), uninstall (opt-in and opt-out), and the Delivery module toggle live.
* Ran WPCS/PHPCS to 0 errors/0 warnings (was 46/138); fixed two real WordPress-global variable-name collisions found in the process.
* Generated the .pot translation file and verified RTL rendering live against a real Arabic-locale invoice.
* Fixed two real production-ZIP packaging bugs: backslash path separators (broken on Linux hosts) and a missing top-level plugin folder.
* Added a self-cleaning WP-CLI smoke test suite (25 assertions).
* Accessibility pass: scope="col" on data-table headers, alt text on preview images.

= 0.1.1 =
* First live test pass against a real WordPress + WooCommerce install (WP-CLI + anonymous HTTP; see docs/test-report.md).
* Fixed a Dompdf rendering bug: floated header/address elements weren't clearing, causing overlapping text in generated PDFs.
* Fixed duplicated customer name in the Bill To/Ship To blocks.
* Fixed the Dispatch Queue and COD tabs silently showing unfiltered results (`wc_get_orders()`'s `meta_query` isn't reliable on this WooCommerce version/storage combination).
* Fixed delivery tracking links always failing: the `order` query var collided with WordPress core's own reserved query var of the same name.

= 0.1.0 =
* Initial development scaffold: plugin bootstrap, HPOS compatibility declaration, admin menu shell.

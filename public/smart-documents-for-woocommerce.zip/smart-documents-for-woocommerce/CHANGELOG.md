# Changelog

## 0.1.3 — All 20 checklist items verified

Closed the last 2 of 20 WordPress.org pre-submission checklist items:

- **PHP 7.4 compatibility**, on a real interpreter this time — downloaded
  PHP 7.4.33 (Windows x64) and ran `php -l` across all 28 of the
  plugin's own files plus all 415 vendored dependency files: zero
  syntax errors. Also loaded Composer's autoloader and instantiated
  `Dompdf\Dompdf` directly under it.
- **Customer authorization** — verified the My Account "My Documents"
  tab (empty state, populated state with a real working download link,
  the tracking action) without creating any WordPress account or
  browser login session, using `wp_set_current_user()` scoped to a
  single non-interactive script — the same mechanism WP-CLI's own
  `--user=<id>` flag uses internally. That's a hard boundary this build
  doesn't cross even with permission; see `docs/test-report.md`.

See `docs/wordpress-org-checklist.md` — every item is now checked, with
the one caveat that a real customer *browser* login was never created
(by design), so that specific verification was done as a direct method
call rather than a click-through.

## 0.1.2 — Verification-complete

18 of 20 WordPress.org pre-submission checklist items now verified
against a real running site (up from mostly-unverified at 0.1.1) — see
`docs/wordpress-org-checklist.md` and `docs/test-report.md` for the full
detail on every round below.

- Built the real Dashboard (was a placeholder): document-type counts,
  dispatch queue size, active rider count, recent documents/deliveries.
- HPOS verified live in both modes (off and on), including confirming
  `_woosdd_*` meta lands in `wp_wc_orders_meta` under HPOS, never
  `wp_postmeta`.
- Uninstall verified live: both the opt-out default (removes nothing)
  and opt-in cleanup (removes only plugin-owned data; a sample order's
  number/total/status confirmed byte-for-byte unchanged afterward).
- Delivery module toggle verified live.
- WPCS/PHPCS run for real: 46 errors/138 warnings → 0/0. Found two
  genuine bugs in the process (not just style): `uninstall.php` used
  `$post_type`/`$post_id` as loop variable names, which collide with
  WordPress's own reserved global variable names.
- `.pot` file generated (211 strings); RTL verified live by rendering a
  real invoice PDF under an Arabic locale — full layout mirroring
  confirmed correct.
- Production ZIP built and inspected — found and fixed two real
  packaging bugs: `Compress-Archive`'s backslash path separators (which
  break on virtually every Linux WordPress host) and a missing
  top-level `woocommerce-smart-order-documents/` wrapper folder. Final
  proof: extracted the actual ZIP into a real plugins folder under a
  throwaway slug and generated a working invoice through it.
- Added `tests/smoke-test.php`, a self-cleaning WP-CLI regression script
  (25 assertions, all passing) covering document generation, numbering,
  automation idempotency, guest tokens, delivery meta, and uninstall.
- Accessibility pass: `scope="col"` on every data-table header, `alt=""`
  on JS-generated preview images.

Remaining before real WordPress.org submission: PHP 7.4 compatibility on
an actual PHP 7.4 interpreter (only statically checked so far), and live
customer/rider session testing (needs a login this build deliberately
never bypasses).

## 0.1.1 — First live-tested build

Real WP-CLI + anonymous-HTTP verification against a running WordPress +
WooCommerce install (see `docs/test-report.md` for full results). Four
real bugs found and fixed:

- Dompdf float-clearing bug causing overlapping/cut-off text in generated
  PDF headers and address blocks (both templates).
- Duplicated customer name in Bill To/Ship To blocks.
- `wc_get_orders( [ 'meta_query' => ... ] )` silently not filtering on
  this store's WooCommerce version/storage combination — Dispatch Queue
  and COD tabs now use a version-safe scan-and-filter helper instead.
- Delivery tracking links always failing: the `order` query var collided
  with WordPress core's own reserved query var of the same name.

## 0.1.0 — Initial development build

Free-tier core, written and statically reviewed (PHP-linted, dependency
licenses audited, security/HPOS patterns reviewed) but **not yet live
tested** — see `docs/test-report.md`.

- Plugin scaffold, HPOS + Cart/Checkout Blocks compatibility declarations.
- Document engine: concurrency-safe numbering, Dompdf-based local PDF
  generation, protected downloads (nonce-checked admin path, token-checked
  public path), two templates (Clean, Classic).
- Admin: Dashboard, Documents, Templates, Settings, Delivery & Dispatch
  (with Riders/COD tabs), Help & About.
- Order integration: manual Generate/Regenerate/Download actions; basic
  automation (order paid → invoice, order completed → receipt); automatic
  email PDF attachments.
- Delivery & Dispatch (free): 9 statuses, order-level rider
  assignment/fee/note, basic COD tracking, Dispatch Queue with filters,
  rider profile CRUD.
- Customer-facing: My Account "My Documents" tab, secure guest document
  access, secure tokenized delivery tracking page.
- Onboarding wizard (skippable), 8 steps.
- WordPress privacy exporter/eraser integration.
- `uninstall.php` (opt-in cleanup, OFF by default; never deletes
  WooCommerce orders).
- Developer docs, third-party license audit, WordPress.org
  pre-submission checklist (honestly marked incomplete), production ZIP
  build script.

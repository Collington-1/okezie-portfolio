<?php
/**
 * Secure tokenized delivery tracking page.
 *
 * @package Woosdd
 */

namespace Woosdd\Frontend;

use Woosdd\Delivery\Dispatch;

defined( 'ABSPATH' ) || exit;

/**
 * A standalone, unauthenticated tracking page reachable only via a random
 * 40-character token — never by order ID alone (`/order/123`-style URLs
 * are explicitly disallowed by the spec). Shows only what a customer is
 * meant to see: order reference, delivery status and (if assigned) the
 * rider's name. It deliberately never shows the merchant's internal
 * delivery note, COD reconciliation, or rider contact details.
 */
class Tracking {

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_filter( 'query_vars', array( $this, 'add_query_vars' ) );
		add_action( 'template_redirect', array( $this, 'maybe_render' ) );
	}

	/**
	 * Register the tracking page's public query vars.
	 *
	 * @param string[] $vars Existing public query vars.
	 * @return string[]
	 */
	public function add_query_vars( $vars ) {
		$vars[] = 'woosdd_track';
		$vars[] = 'woosdd_order';
		$vars[] = 'woosdd_token';
		return $vars;
	}

	/**
	 * Build the tracking URL for an order.
	 *
	 * Note: the query var is `woosdd_order`, not `order` — `order` is a
	 * reserved WordPress core public query var (sort direction, ASC/DESC)
	 * and WP's own request parsing silently overwrites any custom value
	 * assigned to it, which caused a real bug during testing (every
	 * tracking link was rejected as invalid because the order ID never
	 * actually reached this code). Never reuse WP's built-in query var
	 * names for plugin-specific values.
	 *
	 * @param int $order_id Order ID.
	 * @return string
	 */
	public static function tracking_url( $order_id ) {
		$order = wc_get_order( $order_id );
		$token = $order ? $order->get_meta( '_woosdd_tracking_token' ) : '';

		return add_query_arg(
			array(
				'woosdd_track' => 1,
				'woosdd_order' => $order_id,
				'woosdd_token' => $token,
			),
			home_url( '/' )
		);
	}

	/**
	 * `template_redirect` handler: validate the token and render the page.
	 */
	public function maybe_render() {
		if ( ! get_query_var( 'woosdd_track' ) ) {
			return;
		}

		$order_id = absint( get_query_var( 'woosdd_order' ) );
		$token    = sanitize_text_field( wp_unslash( (string) get_query_var( 'woosdd_token' ) ) );

		$order = $order_id ? wc_get_order( $order_id ) : false;

		if ( ! $order || '' === $token ) {
			$this->render_error( __( 'Invalid tracking link.', 'smart-documents-for-woocommerce' ) );
		}

		$stored_token = $order->get_meta( '_woosdd_tracking_token' );

		if ( ! $stored_token || ! hash_equals( (string) $stored_token, $token ) ) {
			$this->render_error( __( 'This tracking link is invalid or has expired.', 'smart-documents-for-woocommerce' ) );
		}

		$this->render_tracking_page( $order );
	}

	/**
	 * Render a minimal standalone error page and exit.
	 *
	 * @param string $message Error message.
	 */
	private function render_error( $message ) {
		status_header( 403 );
		nocache_headers();
		echo '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' . esc_html__( 'Tracking', 'smart-documents-for-woocommerce' ) . '</title></head><body style="font-family:sans-serif;padding:40px;text-align:center;">';
		echo '<p>' . esc_html( $message ) . '</p>';
		echo '</body></html>';
		exit;
	}

	/**
	 * Render the tracking page and exit.
	 *
	 * @param \WC_Order $order Order object.
	 */
	private function render_tracking_page( \WC_Order $order ) {
		nocache_headers();

		$statuses       = Dispatch::statuses();
		$current_status = $order->get_meta( '_woosdd_delivery_status' );
		$dispatch_date  = $order->get_meta( '_woosdd_dispatch_date' );
		$rider_id       = (int) $order->get_meta( '_woosdd_rider_id' );
		$rider          = $rider_id ? get_post( $rider_id ) : null;
		$accent_color   = woosdd_get_setting( 'accent_color', '#2271b1' );

		/**
		 * Filter what the public tracking page is allowed to show. Only
		 * customer-appropriate fields; internal notes, COD data and rider
		 * contact details are intentionally never included by default.
		 *
		 * @param array     $fields Visible field values.
		 * @param \WC_Order $order  Order object.
		 */
		$fields = apply_filters(
			'woosdd_tracking_visible_fields',
			array(
				'order_number'  => $order->get_order_number(),
				'status_label'  => isset( $statuses[ $current_status ] ) ? $statuses[ $current_status ] : __( 'Awaiting dispatch', 'smart-documents-for-woocommerce' ),
				'dispatch_date' => $dispatch_date ? mysql2date( get_option( 'date_format' ), $dispatch_date ) : '',
				'rider_name'    => $rider ? $rider->post_title : '',
			),
			$order
		);

		?>
		<!DOCTYPE html>
		<html lang="<?php echo esc_attr( get_bloginfo( 'language' ) ); ?>">
		<head>
			<meta charset="utf-8" />
			<meta name="viewport" content="width=device-width, initial-scale=1" />
			<title><?php esc_html_e( 'Delivery Tracking', 'smart-documents-for-woocommerce' ); ?></title>
			<style>
				body { font-family: -apple-system, Segoe UI, Roboto, sans-serif; background: #f6f7f7; margin: 0; padding: 40px 16px; color: #1d2327; }
				.woosdd-card { max-width: 480px; margin: 0 auto; background: #fff; border-radius: 8px; padding: 28px; box-shadow: 0 1px 3px rgba(0,0,0,.1); }
				.woosdd-card h1 { font-size: 18px; margin: 0 0 4px; }
				.woosdd-status { display: inline-block; margin-top: 12px; padding: 6px 14px; border-radius: 999px; background: <?php echo esc_attr( $accent_color ); ?>; color: #fff; font-weight: 600; font-size: 13px; }
				.woosdd-row { margin-top: 16px; font-size: 14px; color: #50575e; }
				.woosdd-row strong { color: #1d2327; }
			</style>
		</head>
		<body>
			<div class="woosdd-card">
				<h1><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1>
				<div class="woosdd-row"><?php esc_html_e( 'Order', 'smart-documents-for-woocommerce' ); ?> #<?php echo esc_html( $fields['order_number'] ); ?></div>
				<div class="woosdd-status"><?php echo esc_html( $fields['status_label'] ); ?></div>
				<?php if ( $fields['dispatch_date'] ) : ?>
					<div class="woosdd-row"><strong><?php esc_html_e( 'Dispatched:', 'smart-documents-for-woocommerce' ); ?></strong> <?php echo esc_html( $fields['dispatch_date'] ); ?></div>
				<?php endif; ?>
				<?php if ( $fields['rider_name'] ) : ?>
					<div class="woosdd-row"><strong><?php esc_html_e( 'Rider:', 'smart-documents-for-woocommerce' ); ?></strong> <?php echo esc_html( $fields['rider_name'] ); ?></div>
				<?php endif; ?>
			</div>
		</body>
		</html>
		<?php
		exit;
	}
}

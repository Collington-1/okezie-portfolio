<?php
/**
 * "My Documents" My Account endpoint.
 *
 * @package Woosdd
 */

namespace Woosdd\Frontend;

use Woosdd\Cpt;
use Woosdd\Documents\Document_Data;
use Woosdd\Documents\Downloader;

defined( 'ABSPATH' ) || exit;

/**
 * Adds a "My Documents" tab to WooCommerce's My Account, listing every
 * generated document for orders that belong to the logged-in customer.
 * Downloads use the same token-based public download path as guest
 * access — ownership is enforced here at query time (we only ever look up
 * documents attached to *this* customer's own orders), and again,
 * defensively, by the token check in Downloader itself.
 */
class My_Account {

	const ENDPOINT = 'woosdd-documents';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'add_endpoint' ) );
		add_filter( 'query_vars', array( $this, 'add_query_var' ) );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'add_menu_item' ) );
		add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( $this, 'render_endpoint_content' ) );
		add_filter( 'woocommerce_my_account_my_orders_actions', array( $this, 'add_tracking_action' ), 10, 2 );
	}

	/**
	 * Register the `/my-account/woosdd-documents/` endpoint.
	 */
	public function add_endpoint() {
		add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
	}

	/**
	 * Register our My Account endpoint as a public query var.
	 *
	 * @param string[] $vars Existing public query vars.
	 * @return string[]
	 */
	public function add_query_var( $vars ) {
		$vars[] = self::ENDPOINT;
		return $vars;
	}

	/**
	 * Insert "My Documents" into the My Account nav, right after Orders.
	 *
	 * @param string[] $items Existing menu items (endpoint => label).
	 * @return string[]
	 */
	public function add_menu_item( $items ) {
		$new_items = array();
		foreach ( $items as $key => $label ) {
			$new_items[ $key ] = $label;
			if ( 'orders' === $key ) {
				$new_items[ self::ENDPOINT ] = __( 'My Documents', 'smart-documents-for-woocommerce' );
			}
		}
		if ( ! isset( $new_items[ self::ENDPOINT ] ) ) {
			$new_items[ self::ENDPOINT ] = __( 'My Documents', 'smart-documents-for-woocommerce' );
		}
		return $new_items;
	}

	/**
	 * Render the "My Documents" tab content.
	 */
	public function render_endpoint_content() {
		$customer_id = get_current_user_id();
		if ( ! $customer_id ) {
			return;
		}

		$order_ids = wc_get_orders(
			array(
				'customer_id' => $customer_id,
				'limit'       => -1,
				'return'      => 'ids',
			)
		);

		if ( empty( $order_ids ) ) {
			echo '<p>' . esc_html__( 'No documents yet.', 'smart-documents-for-woocommerce' ) . '</p>';
			return;
		}

		$documents = get_posts(
			array(
				'post_type'   => Cpt::DOCUMENT,
				'post_status' => 'any',
				'numberposts' => -1,
				'orderby'     => 'date',
				'order'       => 'DESC',
				'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'     => '_order_id',
						'value'   => $order_ids,
						'compare' => 'IN',
					),
					array(
						'key'   => '_status',
						'value' => 'generated',
					),
				),
			)
		);

		if ( empty( $documents ) ) {
			echo '<p>' . esc_html__( 'No documents yet.', 'smart-documents-for-woocommerce' ) . '</p>';
			return;
		}
		?>
		<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Document', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Order', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Type', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $documents as $document ) : ?>
					<?php
					$order_id = (int) get_post_meta( $document->ID, '_order_id', true );
					$type     = get_post_meta( $document->ID, '_type', true );
					$order    = wc_get_order( $order_id );
					?>
					<tr>
						<td><?php echo esc_html( $document->post_title ); ?></td>
						<td><?php echo $order ? '#' . esc_html( $order->get_order_number() ) : '—'; ?></td>
						<td><?php echo esc_html( Document_Data::type_label( $type ) ); ?></td>
						<td><a class="button" href="<?php echo esc_url( Downloader::public_download_url( $document->ID ) ); ?>"><?php esc_html_e( 'Download', 'smart-documents-for-woocommerce' ); ?></a></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Add a "Track Delivery" button to the My Account orders list for any
	 * order that has a delivery status and tracking token set.
	 *
	 * @param array     $actions Existing action buttons.
	 * @param \WC_Order $order   Order object.
	 * @return array
	 */
	public function add_tracking_action( $actions, $order ) {
		$token = $order->get_meta( '_woosdd_tracking_token' );
		if ( $token ) {
			$actions['woosdd_track'] = array(
				'url'  => Tracking::tracking_url( $order->get_id() ),
				'name' => __( 'Track Delivery', 'smart-documents-for-woocommerce' ),
			);
		}
		return $actions;
	}
}

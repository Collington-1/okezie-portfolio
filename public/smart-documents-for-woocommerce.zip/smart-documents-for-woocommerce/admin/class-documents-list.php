<?php
/**
 * Documents screen: generated document history.
 *
 * @package Woosdd
 */

namespace Woosdd\Admin;

use Woosdd\Cpt;
use Woosdd\Documents\Document_Data;
use Woosdd\Documents\Downloader;

defined( 'ABSPATH' ) || exit;

/**
 * Read-only history of every generated document, satisfying the spec's
 * "Document history is core" requirement. Backed entirely by the
 * woosdd_document CPT — never duplicates the underlying WooCommerce order.
 */
class Documents_List {

	const PER_PAGE = 20;

	/**
	 * Render the screen.
	 */
	public function render() {
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list, pagination only.

		$query = new \WP_Query(
			array(
				'post_type'      => Cpt::DOCUMENT,
				'post_status'    => 'any',
				'posts_per_page' => self::PER_PAGE,
				'paged'          => $paged,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		if ( ! $query->have_posts() ) {
			echo '<p>' . esc_html__( 'No documents have been generated yet. Generate one from any WooCommerce order.', 'smart-documents-for-woocommerce' ) . '</p>';
			return;
		}
		?>
		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Number', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Type', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Order', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Generated', 'smart-documents-for-woocommerce' ); ?></th>
					<th scope="col"></th>
				</tr>
			</thead>
			<tbody>
				<?php
				while ( $query->have_posts() ) :
					$query->the_post();
					?>
					<?php
					$document_id  = get_the_ID();
					$order_id     = (int) get_post_meta( $document_id, '_order_id', true );
					$type         = get_post_meta( $document_id, '_type', true );
					$status       = get_post_meta( $document_id, '_status', true );
					$generated_at = get_post_meta( $document_id, '_generated_at', true );
					$order        = $order_id ? wc_get_order( $order_id ) : false;
					?>
					<tr>
						<td><?php the_title(); ?></td>
						<td><?php echo esc_html( Document_Data::type_label( $type ) ); ?></td>
						<td>
							<?php if ( $order ) : ?>
								<a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>">#<?php echo esc_html( $order->get_order_number() ); ?></a>
							<?php else : ?>
								&mdash;
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( ucfirst( $status ) ); ?></td>
						<td><?php echo esc_html( $generated_at ? mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $generated_at ) : '—' ); ?></td>
						<td>
							<?php if ( 'generated' === $status ) : ?>
								<a href="<?php echo esc_url( Downloader::admin_download_url( $document_id ) ); ?>" class="button button-small" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Download', 'smart-documents-for-woocommerce' ); ?></a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endwhile; ?>
			</tbody>
		</table>
		<?php
		wp_reset_postdata();

		if ( $query->max_num_pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo wp_kses_post(
				paginate_links(
					array(
						'total'   => $query->max_num_pages,
						'current' => $paged,
					)
				)
			);
			echo '</div></div>';
		}
	}
}

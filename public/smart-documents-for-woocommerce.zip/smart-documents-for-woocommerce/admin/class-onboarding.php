<?php
/**
 * Onboarding wizard: Welcome -> Business Info -> Logo -> Invoice Settings
 * -> Template -> Email Attachments -> Delivery Module -> Finish.
 *
 * @package Woosdd
 */

namespace Woosdd\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * A skippable, step-by-step setup flow show once after activation (or any
 * time from Smart Documents -> Dashboard). Registered as a *hidden*
 * submenu page (no parent slug) so it never appears in the nav but is
 * still capability-checked and reachable by URL, matching how WooCommerce
 * itself hides its own setup wizard page.
 */
class Onboarding {

	const PAGE_SLUG    = 'woosdd-onboarding';
	const NONCE_ACTION = 'woosdd_onboarding_step';

	/**
	 * Ordered step slugs.
	 *
	 * @var string[]
	 */
	private $steps = array( 'welcome', 'business', 'logo', 'invoice', 'template', 'email', 'delivery', 'finish' );

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_page' ) );
		add_action( 'admin_init', array( $this, 'maybe_redirect_after_activation' ) );
	}

	/**
	 * Register the hidden wizard page.
	 */
	public function register_page() {
		add_submenu_page(
			null, // phpcs:ignore WordPress.Security.NonceVerification -- null parent hides it from any menu; still capability-gated by add_submenu_page itself.
			__( 'Smart Documents Setup', 'smart-documents-for-woocommerce' ),
			__( 'Setup', 'smart-documents-for-woocommerce' ),
			woosdd_admin_capability(),
			self::PAGE_SLUG,
			array( $this, 'render' )
		);
	}

	/**
	 * Redirect to the wizard once, right after activation.
	 */
	public function maybe_redirect_after_activation() {
		if ( ! get_transient( 'woosdd_activation_redirect' ) ) {
			return;
		}
		delete_transient( 'woosdd_activation_redirect' );

		if ( wp_doing_ajax() || ! current_user_can( woosdd_admin_capability() ) ) {
			return;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) );
		exit;
	}

	/**
	 * Render + process the current step.
	 */
	public function render() {
		$step = isset( $_GET['step'] ) ? sanitize_key( wp_unslash( $_GET['step'] ) ) : 'welcome'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only step selector; writes are separately nonced below.
		if ( ! in_array( $step, $this->steps, true ) ) {
			$step = 'welcome';
		}

		if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'POST' === $_SERVER['REQUEST_METHOD'] ) {
			$step = $this->handle_step_submit( $step );
		}

		echo '<div class="wrap woosdd-wrap woosdd-onboarding">';
		echo '<h1>' . esc_html__( 'Smart Documents Setup', 'smart-documents-for-woocommerce' ) . '</h1>';
		echo '<p><a href="' . esc_url( admin_url( 'admin.php?page=woosdd' ) ) . '">' . esc_html__( 'Skip setup', 'smart-documents-for-woocommerce' ) . '</a></p>';

		$method = 'render_step_' . $step;
		if ( method_exists( $this, $method ) ) {
			$this->{$method}();
		}

		echo '</div>';
	}

	/**
	 * Process the POSTed step and return the next step slug.
	 *
	 * @param string $step Current step slug.
	 * @return string Next step slug.
	 */
	private function handle_step_submit( $step ) {
		if ( ! isset( $_POST['woosdd_onboarding_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['woosdd_onboarding_nonce'] ) ), self::NONCE_ACTION . '_' . $step ) ) {
			return $step;
		}
		if ( ! current_user_can( woosdd_admin_capability() ) ) {
			return $step;
		}

		$settings = woosdd_get_setting( '' );

		switch ( $step ) {
			case 'business':
				$settings['business']['name']    = sanitize_text_field( wp_unslash( $_POST['business_name'] ?? '' ) );
				$settings['business']['address'] = sanitize_textarea_field( wp_unslash( $_POST['business_address'] ?? '' ) );
				$settings['business']['email']   = sanitize_email( wp_unslash( $_POST['business_email'] ?? '' ) );
				$settings['business']['phone']   = sanitize_text_field( wp_unslash( $_POST['business_phone'] ?? '' ) );
				break;

			case 'logo':
				$settings['business']['logo_id'] = absint( $_POST['logo_id'] ?? 0 );
				break;

			case 'invoice':
				$numbering_source                 = isset( $_POST['numbering_source'] ) ? sanitize_key( wp_unslash( $_POST['numbering_source'] ) ) : '';
				$settings['numbering']['source']  = 'order_number' === $numbering_source ? 'order_number' : 'separate';
				$settings['numbering']['padding'] = min( 10, max( 1, absint( $_POST['numbering_padding'] ?? 6 ) ) );
				$page_size                        = isset( $_POST['page_size'] ) ? sanitize_key( wp_unslash( $_POST['page_size'] ) ) : '';
				$settings['page_size']            = in_array( $page_size, array( 'a4', 'letter', 'a5' ), true ) ? $page_size : $settings['page_size'];
				break;

			case 'template':
				$template             = isset( $_POST['template'] ) ? sanitize_key( wp_unslash( $_POST['template'] ) ) : '';
				$settings['template'] = in_array( $template, array( 'template-1', 'template-2' ), true ) ? $template : $settings['template'];
				$color                = sanitize_hex_color( wp_unslash( $_POST['accent_color'] ?? '' ) );
				if ( $color ) {
					$settings['accent_color'] = $color;
				}
				break;

			case 'email':
				$settings['email_attachments_enabled'] = isset( $_POST['email_attachments_enabled'] ) ? 'yes' : 'no';
				break;

			case 'delivery':
				$settings['delivery_module_enabled'] = isset( $_POST['delivery_module_enabled'] ) ? 'yes' : 'no';
				break;
		}

		update_option( 'woosdd_settings', $settings );

		$index = array_search( $step, $this->steps, true );
		$next  = isset( $this->steps[ $index + 1 ] ) ? $this->steps[ $index + 1 ] : 'finish';

		if ( 'finish' === $next || 'finish' === $step ) {
			update_option( 'woosdd_onboarding_complete', 'yes' );
		}

		return $next;
	}

	/**
	 * Shared step wrapper: heading, form, nonce, Continue button.
	 *
	 * @param string   $step  Step slug.
	 * @param string   $title Step heading.
	 * @param callable $body  Echoes the step's fields.
	 */
	private function step_form( $step, $title, callable $body ) {
		$index = array_search( $step, $this->steps, true );
		$next  = isset( $this->steps[ $index + 1 ] ) ? $this->steps[ $index + 1 ] : 'finish';

		echo '<h2>' . esc_html( $title ) . '</h2>';
		echo '<form method="post">';
		wp_nonce_field( self::NONCE_ACTION . '_' . $step, 'woosdd_onboarding_nonce' );
		call_user_func( $body );
		submit_button( 'finish' === $next ? __( 'Finish', 'smart-documents-for-woocommerce' ) : __( 'Continue', 'smart-documents-for-woocommerce' ) );
		echo '</form>';
	}

	/** Step: Welcome. */
	private function render_step_welcome() {
		echo '<p>' . esc_html__( 'Let\'s get Smart Documents for WooCommerce set up. This takes about two minutes — you can skip it any time and configure everything later from Settings.', 'smart-documents-for-woocommerce' ) . '</p>';
		echo '<p><a class="button button-primary" href="' . esc_url( add_query_arg( 'step', 'business' ) ) . '">' . esc_html__( 'Get Started', 'smart-documents-for-woocommerce' ) . '</a></p>';
	}

	/** Step: Business Information. */
	private function render_step_business() {
		$business = woosdd_get_setting( 'business' );
		$this->step_form(
			'business',
			__( 'Business Information', 'smart-documents-for-woocommerce' ),
			function () use ( $business ) {
				echo '<table class="form-table"><tr><th>' . esc_html__( 'Business Name', 'smart-documents-for-woocommerce' ) . '</th><td><input type="text" class="regular-text" name="business_name" value="' . esc_attr( $business['name'] ) . '" /></td></tr>';
				echo '<tr><th>' . esc_html__( 'Address', 'smart-documents-for-woocommerce' ) . '</th><td><textarea class="large-text" name="business_address" rows="3">' . esc_textarea( $business['address'] ) . '</textarea></td></tr>';
				echo '<tr><th>' . esc_html__( 'Email', 'smart-documents-for-woocommerce' ) . '</th><td><input type="email" class="regular-text" name="business_email" value="' . esc_attr( $business['email'] ) . '" /></td></tr>';
				echo '<tr><th>' . esc_html__( 'Phone', 'smart-documents-for-woocommerce' ) . '</th><td><input type="text" class="regular-text" name="business_phone" value="' . esc_attr( $business['phone'] ) . '" /></td></tr></table>';
			}
		);
	}

	/** Step: Logo. */
	private function render_step_logo() {
		wp_enqueue_media();
		$logo_id = woosdd_get_setting( 'business.logo_id' );
		$this->step_form(
			'logo',
			__( 'Logo', 'smart-documents-for-woocommerce' ),
			function () use ( $logo_id ) {
				echo '<div id="woosdd-onboarding-logo-preview">';
				if ( $logo_id ) {
					echo wp_get_attachment_image( $logo_id, array( 150, 60 ) );
				}
				echo '</div>';
				echo '<input type="hidden" id="logo_id" name="logo_id" value="' . esc_attr( $logo_id ) . '" />';
				echo '<button type="button" class="button" id="woosdd-onboarding-select-logo">' . esc_html__( 'Select from Media Library', 'smart-documents-for-woocommerce' ) . '</button>';
				?>
				<script>
				jQuery(function($){
					var frame;
					$('#woosdd-onboarding-select-logo').on('click', function(e){
						e.preventDefault();
						if (frame) { frame.open(); return; }
						frame = wp.media({ multiple: false, library: { type: 'image' } });
						frame.on('select', function(){
							var att = frame.state().get('selection').first().toJSON();
							$('#logo_id').val(att.id);
							$('#woosdd-onboarding-logo-preview').html('<img src="' + att.url + '" alt="" style="max-height:60px;" />');
						});
						frame.open();
					});
				});
				</script>
				<?php
			}
		);
	}

	/** Step: Invoice Settings. */
	private function render_step_invoice() {
		$numbering = woosdd_get_setting( 'numbering' );
		$page_size = woosdd_get_setting( 'page_size' );
		$this->step_form(
			'invoice',
			__( 'Invoice Settings', 'smart-documents-for-woocommerce' ),
			function () use ( $numbering, $page_size ) {
				echo '<table class="form-table">';
				echo '<tr><th>' . esc_html__( 'Number Source', 'smart-documents-for-woocommerce' ) . '</th><td>';
				echo '<label><input type="radio" name="numbering_source" value="separate" ' . checked( $numbering['source'], 'separate', false ) . ' /> ' . esc_html__( 'Separate document sequence', 'smart-documents-for-woocommerce' ) . '</label><br />';
				echo '<label><input type="radio" name="numbering_source" value="order_number" ' . checked( $numbering['source'], 'order_number', false ) . ' /> ' . esc_html__( 'Reuse WooCommerce order number', 'smart-documents-for-woocommerce' ) . '</label>';
				echo '</td></tr>';
				echo '<tr><th>' . esc_html__( 'Digit Padding', 'smart-documents-for-woocommerce' ) . '</th><td><input type="number" min="1" max="10" name="numbering_padding" value="' . esc_attr( $numbering['padding'] ) . '" /></td></tr>';
				echo '<tr><th>' . esc_html__( 'Page Size', 'smart-documents-for-woocommerce' ) . '</th><td><select name="page_size">';
				foreach ( array(
					'a4'     => 'A4',
					'letter' => __( 'Letter', 'smart-documents-for-woocommerce' ),
					'a5'     => 'A5',
				) as $value => $label ) {
					echo '<option value="' . esc_attr( $value ) . '" ' . selected( $page_size, $value, false ) . '>' . esc_html( $label ) . '</option>';
				}
				echo '</select></td></tr></table>';
			}
		);
	}

	/** Step: Template. */
	private function render_step_template() {
		$template     = woosdd_get_setting( 'template' );
		$accent_color = woosdd_get_setting( 'accent_color' );
		$this->step_form(
			'template',
			__( 'Template', 'smart-documents-for-woocommerce' ),
			function () use ( $template, $accent_color ) {
				echo '<table class="form-table">';
				echo '<tr><th>' . esc_html__( 'Template', 'smart-documents-for-woocommerce' ) . '</th><td><select name="template">';
				echo '<option value="template-1" ' . selected( $template, 'template-1', false ) . '>' . esc_html__( 'Clean', 'smart-documents-for-woocommerce' ) . '</option>';
				echo '<option value="template-2" ' . selected( $template, 'template-2', false ) . '>' . esc_html__( 'Classic', 'smart-documents-for-woocommerce' ) . '</option>';
				echo '</select></td></tr>';
				echo '<tr><th>' . esc_html__( 'Accent Color', 'smart-documents-for-woocommerce' ) . '</th><td><input type="text" name="accent_color" value="' . esc_attr( $accent_color ) . '" /></td></tr>';
				echo '</table>';
			}
		);
	}

	/** Step: Email Attachments. */
	private function render_step_email() {
		$enabled = woosdd_get_setting( 'email_attachments_enabled' );
		$this->step_form(
			'email',
			__( 'Email Attachments', 'smart-documents-for-woocommerce' ),
			function () use ( $enabled ) {
				echo '<p><label><input type="checkbox" name="email_attachments_enabled" ' . checked( $enabled, 'yes', false ) . ' /> ' . esc_html__( 'Automatically attach invoice/receipt PDFs to order emails.', 'smart-documents-for-woocommerce' ) . '</label></p>';
			}
		);
	}

	/** Step: Delivery Module. */
	private function render_step_delivery() {
		$enabled = woosdd_get_setting( 'delivery_module_enabled' );
		$this->step_form(
			'delivery',
			__( 'Delivery Module', 'smart-documents-for-woocommerce' ),
			function () use ( $enabled ) {
				echo '<p><label><input type="checkbox" name="delivery_module_enabled" ' . checked( $enabled, 'yes', false ) . ' /> ' . esc_html__( 'Enable Delivery & Dispatch (riders, statuses, basic COD tracking).', 'smart-documents-for-woocommerce' ) . '</label></p>';
			}
		);
	}

	/** Step: Finish. */
	private function render_step_finish() {
		update_option( 'woosdd_onboarding_complete', 'yes' );
		echo '<p>' . esc_html__( 'You\'re all set! Generate your first document from any WooCommerce order.', 'smart-documents-for-woocommerce' ) . '</p>';
		echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=woosdd' ) ) . '">' . esc_html__( 'Go to Dashboard', 'smart-documents-for-woocommerce' ) . '</a></p>';
	}
}

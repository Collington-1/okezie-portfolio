<?php
/**
 * Templates screen: choose between the two free templates.
 *
 * @package Woosdd
 */

namespace Woosdd\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Free tier ships two polished templates (Clean, Classic). Premium adds
 * unlimited custom templates via a drag-and-drop builder — this screen
 * already renders a locked upsell card for that so the admin information
 * architecture is visible even though Premium itself isn't built here.
 */
class Templates_Screen {

	const ACTION = 'woosdd_select_template';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle_select' ) );
	}

	/**
	 * Handle the "Use this template" button.
	 */
	public function handle_select() {
		if ( ! current_user_can( woosdd_admin_capability() ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'smart-documents-for-woocommerce' ), 403 );
		}

		check_admin_referer( self::ACTION );

		$template = isset( $_POST['template'] ) ? sanitize_key( wp_unslash( $_POST['template'] ) ) : '';
		if ( in_array( $template, array( 'template-1', 'template-2' ), true ) ) {
			$settings             = woosdd_get_setting( '' );
			$settings['template'] = $template;
			update_option( 'woosdd_settings', $settings );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=woosdd-templates&woosdd_selected=1' ) );
		exit;
	}

	/**
	 * Render the screen.
	 */
	public function render() {
		$current = woosdd_get_setting( 'template', 'template-1' );

		$templates = array(
			'template-1' => array(
				'label'       => __( 'Clean', 'smart-documents-for-woocommerce' ),
				'description' => __( 'A minimal, left-aligned layout with a single accent-colored rule under the header.', 'smart-documents-for-woocommerce' ),
			),
			'template-2' => array(
				'label'       => __( 'Classic', 'smart-documents-for-woocommerce' ),
				'description' => __( 'A boxed, bordered layout with a solid accent-colored header band and gridded tables.', 'smart-documents-for-woocommerce' ),
			),
		);

		echo '<div class="woosdd-templates" style="display:flex;gap:20px;flex-wrap:wrap;">';

		foreach ( $templates as $slug => $template ) {
			$is_active = ( $slug === $current );
			echo '<div class="card" style="width:320px;">';
			echo '<h2>' . esc_html( $template['label'] ) . ( $is_active ? ' <span style="color:#2271b1;font-size:12px;">(' . esc_html__( 'Active', 'smart-documents-for-woocommerce' ) . ')</span>' : '' ) . '</h2>';
			echo '<p>' . esc_html( $template['description'] ) . '</p>';

			if ( ! $is_active ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
				wp_nonce_field( self::ACTION );
				echo '<input type="hidden" name="action" value="' . esc_attr( self::ACTION ) . '" />';
				echo '<input type="hidden" name="template" value="' . esc_attr( $slug ) . '" />';
				submit_button( __( 'Use this template', 'smart-documents-for-woocommerce' ), 'secondary', 'submit', false );
				echo '</form>';
			}
			echo '</div>';
		}

		echo '<div class="card" style="width:320px;opacity:0.6;">';
		echo '<h2>' . esc_html__( 'Unlimited Custom Templates', 'smart-documents-for-woocommerce' ) . ' 🔒</h2>';
		echo '<p>' . esc_html__( 'Premium adds a drag-and-drop document builder with unlimited custom templates. Available as a separate add-on.', 'smart-documents-for-woocommerce' ) . '</p>';
		echo '</div>';

		echo '</div>';
	}
}

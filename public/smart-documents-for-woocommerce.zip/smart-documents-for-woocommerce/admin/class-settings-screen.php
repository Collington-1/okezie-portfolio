<?php
/**
 * Settings screen: business profile, numbering, appearance, uninstall.
 *
 * @package Woosdd
 */

namespace Woosdd\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Renders and saves the Smart Documents → Settings screen. Manual
 * form handling (rather than the Settings API) so every field can be
 * grouped under the single `woosdd_settings` option as documented in
 * Woosdd\Install::default_settings(), with dot-notation access via
 * woosdd_get_setting().
 */
class Settings_Screen {

	const NONCE_ACTION = 'woosdd_save_settings';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'maybe_save' ) );
	}

	/**
	 * Process a settings form submission, if one was posted to us.
	 */
	public function maybe_save() {
		if ( ! isset( $_POST['woosdd_settings_nonce'] ) ) {
			return;
		}

		if ( ! current_user_can( woosdd_admin_capability() ) ) {
			return;
		}

		check_admin_referer( self::NONCE_ACTION, 'woosdd_settings_nonce' );

		$existing = woosdd_get_setting( '' );

		$settings = array(
			'template'                  => in_array( $this->post( 'template' ), array( 'template-1', 'template-2' ), true ) ? $this->post( 'template' ) : $existing['template'],
			'accent_color'              => sanitize_hex_color( $this->post( 'accent_color' ) ) ? sanitize_hex_color( $this->post( 'accent_color' ) ) : $existing['accent_color'],
			'page_size'                 => in_array( $this->post( 'page_size' ), array( 'a4', 'letter', 'a5' ), true ) ? $this->post( 'page_size' ) : $existing['page_size'],
			'orientation'               => in_array( $this->post( 'orientation' ), array( 'portrait', 'landscape' ), true ) ? $this->post( 'orientation' ) : $existing['orientation'],
			'numbering'                 => array(
				'source'     => 'order_number' === $this->post( 'numbering_source' ) ? 'order_number' : 'separate',
				'prefix'     => array(
					'invoice'       => sanitize_text_field( $this->post( 'prefix_invoice', $existing['numbering']['prefix']['invoice'] ) ),
					'receipt'       => sanitize_text_field( $this->post( 'prefix_receipt', $existing['numbering']['prefix']['receipt'] ) ),
					'packing_slip'  => sanitize_text_field( $this->post( 'prefix_packing_slip', $existing['numbering']['prefix']['packing_slip'] ) ),
					'delivery_note' => sanitize_text_field( $this->post( 'prefix_delivery_note', $existing['numbering']['prefix']['delivery_note'] ) ),
				),
				'start'      => max( 1, absint( $this->post( 'numbering_start', $existing['numbering']['start'] ) ) ),
				'padding'    => min( 10, max( 1, absint( $this->post( 'numbering_padding', $existing['numbering']['padding'] ) ) ) ),
				'date_token' => in_array( $this->post( 'date_token' ), array( 'none', 'year', 'year_month' ), true ) ? $this->post( 'date_token' ) : $existing['numbering']['date_token'],
			),
			'business'                  => array(
				'name'         => sanitize_text_field( $this->post( 'business_name' ) ),
				'logo_id'      => absint( $this->post( 'logo_id' ) ),
				'address'      => sanitize_textarea_field( $this->post( 'business_address' ) ),
				'email'        => sanitize_email( $this->post( 'business_email' ) ),
				'phone'        => sanitize_text_field( $this->post( 'business_phone' ) ),
				'tax_id'       => sanitize_text_field( $this->post( 'business_tax_id' ) ),
				'bank_details' => sanitize_textarea_field( $this->post( 'business_bank_details' ) ),
				'footer_text'  => sanitize_textarea_field( $this->post( 'business_footer_text' ) ),
			),
			'delivery_module_enabled'   => isset( $_POST['delivery_module_enabled'] ) ? 'yes' : 'no',
			'email_attachments_enabled' => isset( $_POST['email_attachments_enabled'] ) ? 'yes' : 'no',
		);

		update_option( 'woosdd_settings', $settings );
		update_option( 'woosdd_remove_data_on_uninstall', isset( $_POST['remove_data_on_uninstall'] ) ? 'yes' : 'no' );

		add_settings_error( 'woosdd_settings', 'saved', __( 'Settings saved.', 'smart-documents-for-woocommerce' ), 'success' );
		set_transient( 'woosdd_settings_notice', get_settings_errors( 'woosdd_settings' ), 30 );

		wp_safe_redirect( admin_url( 'admin.php?page=woosdd-settings&woosdd_saved=1' ) );
		exit;
	}

	/**
	 * Sanitized, unslashed helper for reading a $_POST field.
	 *
	 * @param string $key           Field name.
	 * @param string $default_value Fallback.
	 * @return string
	 */
	private function post( $key, $default_value = '' ) {
		// Nonce is verified once, up front, in maybe_save() before this
		// helper is ever called — WPCS can't see across method
		// boundaries, so it flags every call site individually.
		return isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : $default_value; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.NonceVerification.Missing -- caller sanitizes per field; nonce already verified in maybe_save().
	}

	/**
	 * Render the settings screen.
	 */
	public function render() {
		$settings = woosdd_get_setting( '' );

		$notices = get_transient( 'woosdd_settings_notice' );
		if ( $notices ) {
			delete_transient( 'woosdd_settings_notice' );
			foreach ( (array) $notices as $notice ) {
				echo '<div class="notice notice-' . esc_attr( $notice['type'] ) . ' is-dismissible"><p>' . esc_html( $notice['message'] ) . '</p></div>';
			}
		}
		?>
		<form method="post" action="">
			<?php wp_nonce_field( self::NONCE_ACTION, 'woosdd_settings_nonce' ); ?>

			<h2><?php esc_html_e( 'Business Profile', 'smart-documents-for-woocommerce' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><label for="business_name"><?php esc_html_e( 'Business Name', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="text" class="regular-text" id="business_name" name="business_name" value="<?php echo esc_attr( $settings['business']['name'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="logo_id"><?php esc_html_e( 'Logo', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td>
						<div id="woosdd-logo-preview">
							<?php if ( ! empty( $settings['business']['logo_id'] ) ) : ?>
								<?php echo wp_get_attachment_image( $settings['business']['logo_id'], array( 150, 60 ) ); ?>
							<?php endif; ?>
						</div>
						<input type="hidden" id="logo_id" name="logo_id" value="<?php echo esc_attr( $settings['business']['logo_id'] ); ?>" />
						<button type="button" class="button" id="woosdd-select-logo"><?php esc_html_e( 'Select from Media Library', 'smart-documents-for-woocommerce' ); ?></button>
					</td>
				</tr>
				<tr>
					<th><label for="business_address"><?php esc_html_e( 'Address', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><textarea class="large-text" rows="3" id="business_address" name="business_address"><?php echo esc_textarea( $settings['business']['address'] ); ?></textarea></td>
				</tr>
				<tr>
					<th><label for="business_email"><?php esc_html_e( 'Email', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="email" class="regular-text" id="business_email" name="business_email" value="<?php echo esc_attr( $settings['business']['email'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="business_phone"><?php esc_html_e( 'Phone', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="text" class="regular-text" id="business_phone" name="business_phone" value="<?php echo esc_attr( $settings['business']['phone'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="business_tax_id"><?php esc_html_e( 'Tax ID', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="text" class="regular-text" id="business_tax_id" name="business_tax_id" value="<?php echo esc_attr( $settings['business']['tax_id'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="business_bank_details"><?php esc_html_e( 'Bank / Payment Details', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><textarea class="large-text" rows="3" id="business_bank_details" name="business_bank_details"><?php echo esc_textarea( $settings['business']['bank_details'] ); ?></textarea></td>
				</tr>
				<tr>
					<th><label for="business_footer_text"><?php esc_html_e( 'Document Footer Text', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><textarea class="large-text" rows="2" id="business_footer_text" name="business_footer_text"><?php echo esc_textarea( $settings['business']['footer_text'] ); ?></textarea></td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Appearance', 'smart-documents-for-woocommerce' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><label for="template"><?php esc_html_e( 'Template', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td>
						<select id="template" name="template">
							<option value="template-1" <?php selected( $settings['template'], 'template-1' ); ?>><?php esc_html_e( 'Clean', 'smart-documents-for-woocommerce' ); ?></option>
							<option value="template-2" <?php selected( $settings['template'], 'template-2' ); ?>><?php esc_html_e( 'Classic', 'smart-documents-for-woocommerce' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th><label for="accent_color"><?php esc_html_e( 'Accent Color', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="text" id="accent_color" name="accent_color" value="<?php echo esc_attr( $settings['accent_color'] ); ?>" class="woosdd-color-field" /></td>
				</tr>
				<tr>
					<th><label for="page_size"><?php esc_html_e( 'Page Size', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td>
						<select id="page_size" name="page_size">
							<option value="a4" <?php selected( $settings['page_size'], 'a4' ); ?>>A4</option>
							<option value="letter" <?php selected( $settings['page_size'], 'letter' ); ?>><?php esc_html_e( 'Letter', 'smart-documents-for-woocommerce' ); ?></option>
							<option value="a5" <?php selected( $settings['page_size'], 'a5' ); ?>>A5</option>
						</select>
						<select id="orientation" name="orientation">
							<option value="portrait" <?php selected( $settings['orientation'], 'portrait' ); ?>><?php esc_html_e( 'Portrait', 'smart-documents-for-woocommerce' ); ?></option>
							<option value="landscape" <?php selected( $settings['orientation'], 'landscape' ); ?>><?php esc_html_e( 'Landscape', 'smart-documents-for-woocommerce' ); ?></option>
						</select>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Document Numbering', 'smart-documents-for-woocommerce' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><?php esc_html_e( 'Number Source', 'smart-documents-for-woocommerce' ); ?></th>
					<td>
						<label><input type="radio" name="numbering_source" value="separate" <?php checked( $settings['numbering']['source'], 'separate' ); ?> /> <?php esc_html_e( 'Separate document sequence', 'smart-documents-for-woocommerce' ); ?></label><br />
						<label><input type="radio" name="numbering_source" value="order_number" <?php checked( $settings['numbering']['source'], 'order_number' ); ?> /> <?php esc_html_e( 'Reuse the WooCommerce order number', 'smart-documents-for-woocommerce' ); ?></label>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Prefixes', 'smart-documents-for-woocommerce' ); ?></th>
					<td>
						<p><label><?php esc_html_e( 'Invoice', 'smart-documents-for-woocommerce' ); ?> <input type="text" name="prefix_invoice" value="<?php echo esc_attr( $settings['numbering']['prefix']['invoice'] ); ?>" size="10" /></label></p>
						<p><label><?php esc_html_e( 'Receipt', 'smart-documents-for-woocommerce' ); ?> <input type="text" name="prefix_receipt" value="<?php echo esc_attr( $settings['numbering']['prefix']['receipt'] ); ?>" size="10" /></label></p>
						<p><label><?php esc_html_e( 'Packing Slip', 'smart-documents-for-woocommerce' ); ?> <input type="text" name="prefix_packing_slip" value="<?php echo esc_attr( $settings['numbering']['prefix']['packing_slip'] ); ?>" size="10" /></label></p>
						<p><label><?php esc_html_e( 'Delivery Note', 'smart-documents-for-woocommerce' ); ?> <input type="text" name="prefix_delivery_note" value="<?php echo esc_attr( $settings['numbering']['prefix']['delivery_note'] ); ?>" size="10" /></label></p>
					</td>
				</tr>
				<tr>
					<th><label for="numbering_start"><?php esc_html_e( 'Start Number', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="number" min="1" id="numbering_start" name="numbering_start" value="<?php echo esc_attr( $settings['numbering']['start'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="numbering_padding"><?php esc_html_e( 'Digit Padding', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td><input type="number" min="1" max="10" id="numbering_padding" name="numbering_padding" value="<?php echo esc_attr( $settings['numbering']['padding'] ); ?>" /></td>
				</tr>
				<tr>
					<th><label for="date_token"><?php esc_html_e( 'Date Token', 'smart-documents-for-woocommerce' ); ?></label></th>
					<td>
						<select id="date_token" name="date_token">
							<option value="none" <?php selected( $settings['numbering']['date_token'], 'none' ); ?>><?php esc_html_e( 'None (INV-000123)', 'smart-documents-for-woocommerce' ); ?></option>
							<option value="year" <?php selected( $settings['numbering']['date_token'], 'year' ); ?>><?php esc_html_e( 'Year (INV-2026-000123)', 'smart-documents-for-woocommerce' ); ?></option>
							<option value="year_month" <?php selected( $settings['numbering']['date_token'], 'year_month' ); ?>><?php esc_html_e( 'Year-Month (INV-2026-08-000123)', 'smart-documents-for-woocommerce' ); ?></option>
						</select>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Automation & Email', 'smart-documents-for-woocommerce' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><?php esc_html_e( 'Email Attachments', 'smart-documents-for-woocommerce' ); ?></th>
					<td>
						<label><input type="checkbox" name="email_attachments_enabled" <?php checked( $settings['email_attachments_enabled'], 'yes' ); ?> /> <?php esc_html_e( 'Automatically attach the invoice PDF to processing-order emails and the receipt PDF to completed-order emails.', 'smart-documents-for-woocommerce' ); ?></label>
						<p class="description"><?php esc_html_e( 'Basic automation is free: order paid → generate invoice, order completed → generate receipt. Advanced conditions and multiple attachment rules are a Premium add-on feature.', 'smart-documents-for-woocommerce' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Delivery & Dispatch', 'smart-documents-for-woocommerce' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><?php esc_html_e( 'Module', 'smart-documents-for-woocommerce' ); ?></th>
					<td>
						<label><input type="checkbox" name="delivery_module_enabled" <?php checked( $settings['delivery_module_enabled'], 'yes' ); ?> /> <?php esc_html_e( 'Enable Delivery & Dispatch', 'smart-documents-for-woocommerce' ); ?></label>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Uninstall', 'smart-documents-for-woocommerce' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th><?php esc_html_e( 'On Uninstall', 'smart-documents-for-woocommerce' ); ?></th>
					<td>
						<label><input type="checkbox" name="remove_data_on_uninstall" <?php checked( get_option( 'woosdd_remove_data_on_uninstall', 'no' ), 'yes' ); ?> /> <?php esc_html_e( 'Remove plugin data on uninstall (documents, riders, settings, generated files). WooCommerce orders are never deleted.', 'smart-documents-for-woocommerce' ); ?></label>
					</td>
				</tr>
			</table>

			<?php submit_button( __( 'Save Settings', 'smart-documents-for-woocommerce' ) ); ?>
		</form>
		<?php
	}
}

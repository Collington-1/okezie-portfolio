<?php
/**
 * Top-level admin menu and submenu registration.
 *
 * @package Woosdd
 */

namespace Woosdd\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the "Smart Documents" top-level admin menu and its eight
 * submenus: Dashboard, Documents, Templates, Automation, Delivery &
 * Dispatch, Settings, Tools, Help & About — per the plugin spec's admin
 * architecture. Original layout; not a copy of any reference screenshot.
 *
 * Each submenu delegates rendering to its own screen class so this file
 * stays a pure router. Screen classes not yet built (later milestones)
 * render a lightweight "under construction" placeholder instead of being
 * left out of the menu, so the full information architecture is visible
 * from milestone 1 onward.
 */
class Menu {

	const MENU_SLUG = 'woosdd';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	/**
	 * Register the top-level menu and every submenu page.
	 */
	public function register_menu() {
		$capability = woosdd_admin_capability();

		add_menu_page(
			__( 'Smart Documents', 'smart-documents-for-woocommerce' ),
			__( 'Smart Documents', 'smart-documents-for-woocommerce' ),
			$capability,
			self::MENU_SLUG,
			array( $this, 'render_dashboard' ),
			'dashicons-media-document',
			56 // Just under WooCommerce's own menu position.
		);

		$submenus = array(
			self::MENU_SLUG                 => array( __( 'Dashboard', 'smart-documents-for-woocommerce' ), 'render_dashboard' ),
			self::MENU_SLUG . '-documents'  => array( __( 'Documents', 'smart-documents-for-woocommerce' ), 'render_documents' ),
			self::MENU_SLUG . '-templates'  => array( __( 'Templates', 'smart-documents-for-woocommerce' ), 'render_templates' ),
			self::MENU_SLUG . '-automation' => array( __( 'Automation', 'smart-documents-for-woocommerce' ), 'render_automation' ),
			self::MENU_SLUG . '-delivery'   => array( __( 'Delivery & Dispatch', 'smart-documents-for-woocommerce' ), 'render_delivery' ),
			self::MENU_SLUG . '-settings'   => array( __( 'Settings', 'smart-documents-for-woocommerce' ), 'render_settings' ),
			self::MENU_SLUG . '-tools'      => array( __( 'Tools', 'smart-documents-for-woocommerce' ), 'render_tools' ),
			self::MENU_SLUG . '-help'       => array( __( 'Help & About', 'smart-documents-for-woocommerce' ), 'render_help' ),
		);

		foreach ( $submenus as $slug => list( $label, $callback ) ) {
			add_submenu_page(
				self::MENU_SLUG,
				$label,
				$label,
				$capability,
				$slug,
				array( $this, $callback )
			);
		}
	}

	/**
	 * Enqueue admin CSS/JS only on our own screens.
	 *
	 * @param string $hook_suffix Current admin page hook suffix.
	 */
	public function enqueue_admin_assets( $hook_suffix ) {
		if ( false === strpos( (string) $hook_suffix, self::MENU_SLUG ) ) {
			return;
		}

		wp_enqueue_style(
			'woosdd-admin',
			WOOSDD_URL . 'assets/css/admin.css',
			array(),
			WOOSDD_VERSION
		);

		// Settings screen only: Media Library picker (logo) + color picker (accent color).
		if ( false !== strpos( (string) $hook_suffix, self::MENU_SLUG . '-settings' ) ) {
			wp_enqueue_media();
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script(
				'woosdd-admin-settings',
				WOOSDD_URL . 'assets/js/admin-settings.js',
				array( 'jquery', 'wp-color-picker' ),
				WOOSDD_VERSION,
				true
			);
			wp_localize_script(
				'woosdd-admin-settings',
				'woosddAdminSettings',
				array(
					'mediaTitle'  => __( 'Select Logo', 'smart-documents-for-woocommerce' ),
					'mediaButton' => __( 'Use this logo', 'smart-documents-for-woocommerce' ),
				)
			);
		}
	}

	/**
	 * Wrap a screen's inner content in the shared admin page chrome.
	 *
	 * @param string   $title      Screen title.
	 * @param callable $content_cb Callable that echoes the screen body.
	 */
	private function render_screen( $title, callable $content_cb ) {
		echo '<div class="wrap woosdd-wrap">';
		echo '<h1>' . esc_html( $title ) . '</h1>';
		call_user_func( $content_cb );
		echo '</div>';
	}

	/**
	 * A placeholder body for screens not yet built in this milestone.
	 *
	 * @param string $milestone_note Human-readable note on when it lands.
	 */
	private function render_placeholder( $milestone_note ) {
		echo '<p>' . esc_html( $milestone_note ) . '</p>';
	}

	/** Dashboard screen. */
	public function render_dashboard() {
		$this->render_screen(
			__( 'Dashboard', 'smart-documents-for-woocommerce' ),
			function () {
				if ( class_exists( '\\Woosdd\\Admin\\Views\\Dashboard' ) ) {
					( new \Woosdd\Admin\Views\Dashboard() )->render();
					return;
				}
				$this->render_placeholder( __( 'Dashboard widgets (documents/deliveries at a glance) are being built next.', 'smart-documents-for-woocommerce' ) );
			}
		);
	}

	/** Documents screen. */
	public function render_documents() {
		$this->render_screen(
			__( 'Documents', 'smart-documents-for-woocommerce' ),
			function () {
				if ( class_exists( '\\Woosdd\\Admin\\Documents_List' ) ) {
					( new \Woosdd\Admin\Documents_List() )->render();
					return;
				}
				$this->render_placeholder( __( 'Generated document history will appear here once the document engine lands.', 'smart-documents-for-woocommerce' ) );
			}
		);
	}

	/** Templates screen. */
	public function render_templates() {
		$this->render_screen(
			__( 'Templates', 'smart-documents-for-woocommerce' ),
			function () {
				if ( class_exists( '\\Woosdd\\Admin\\Templates_Screen' ) ) {
					( new \Woosdd\Admin\Templates_Screen() )->render();
					return;
				}
				$this->render_placeholder( __( 'Choose from two free templates, logo, and accent color — coming next.', 'smart-documents-for-woocommerce' ) );
			}
		);
	}

	/** Automation screen. */
	public function render_automation() {
		$this->render_screen(
			__( 'Automation', 'smart-documents-for-woocommerce' ),
			function () {
				$this->render_placeholder( __( 'Basic automation rules (e.g. order paid → generate invoice) are configured here.', 'smart-documents-for-woocommerce' ) );
			}
		);
	}

	/** Delivery & Dispatch screen. */
	public function render_delivery() {
		$this->render_screen(
			__( 'Delivery & Dispatch', 'smart-documents-for-woocommerce' ),
			function () {
				if ( class_exists( '\\Woosdd\\Delivery\\Dispatch' ) ) {
					( new \Woosdd\Delivery\Dispatch() )->render_screen();
					return;
				}
				$this->render_placeholder( __( 'Dispatch queue, riders and basic COD tracking are being built next.', 'smart-documents-for-woocommerce' ) );
			}
		);
	}

	/** Settings screen. */
	public function render_settings() {
		$this->render_screen(
			__( 'Settings', 'smart-documents-for-woocommerce' ),
			function () {
				if ( class_exists( '\\Woosdd\\Admin\\Settings_Screen' ) ) {
					( new \Woosdd\Admin\Settings_Screen() )->render();
					return;
				}
				$this->render_placeholder( __( 'Numbering, business profile and email attachment settings are coming next.', 'smart-documents-for-woocommerce' ) );
			}
		);
	}

	/** Tools screen. */
	public function render_tools() {
		$this->render_screen(
			__( 'Tools', 'smart-documents-for-woocommerce' ),
			function () {
				$this->render_placeholder( __( 'Utility tools (manual regenerate, cache clear) will live here.', 'smart-documents-for-woocommerce' ) );
			}
		);
	}

	/** Help & About screen. */
	public function render_help() {
		$this->render_screen(
			__( 'Help & About', 'smart-documents-for-woocommerce' ),
			function () {
				echo '<p>' . esc_html__( 'Smart Documents for WooCommerce – Invoices, Receipts & Delivery', 'smart-documents-for-woocommerce' ) . '</p>';
				printf(
					/* translators: 1: plugin version number */
					'<p>' . esc_html__( 'Version %1$s — by okezie.', 'smart-documents-for-woocommerce' ) . '</p>',
					esc_html( WOOSDD_VERSION )
				);
				printf(
					'<p><a href="%1$s" target="_blank" rel="noopener noreferrer">%1$s</a></p>',
					esc_url( 'https://okeziecollington.netlify.app/' )
				);
			}
		);
	}
}

<?php
/**
 * Dashboard: documents/deliveries at a glance.
 *
 * @package Woosdd
 */

namespace Woosdd\Admin\Views;

use Woosdd\Cpt;
use Woosdd\Delivery\Dispatch;
use Woosdd\Delivery\Rider;
use Woosdd\Documents\Document_Data;
use Woosdd\Documents\Downloader;

defined( 'ABSPATH' ) || exit;

/**
 * The Smart Documents landing screen: quick counts, the most recent
 * documents, the most recent dispatch queue entries, and shortcuts into
 * the rest of the plugin. Read-only — no forms/state-changing actions
 * live here, so it needs no nonce handling of its own.
 */
class Dashboard {

	/**
	 * Render the dashboard body.
	 */
	public function render() {
		$this->render_stats();
		echo '<div style="display:flex;gap:20px;flex-wrap:wrap;margin-top:20px;">';
		$this->render_recent_documents();
		$this->render_recent_deliveries();
		echo '</div>';
	}

	/**
	 * Top row: document-type counts, dispatch queue size, active riders.
	 */
	private function render_stats() {
		$counts = array();
		foreach ( array( 'invoice', 'receipt', 'packing_slip', 'delivery_note' ) as $type ) {
			$counts[ $type ] = $this->count_documents( $type );
		}

		$queue_count = count( Dispatch::find_orders_by_order_meta( '_woosdd_delivery_status', array( $this, 'has_delivery_status' ), 1000 ) );
		$rider_count = count( Rider::get_riders( true ) );

		echo '<div class="woosdd-stats" style="display:flex;gap:16px;flex-wrap:wrap;">';
		foreach ( $counts as $type => $count ) {
			$this->stat_card( Document_Data::type_label( $type ), $count );
		}
		$this->stat_card( __( 'In Dispatch Queue', 'smart-documents-for-woocommerce' ), $queue_count );
		$this->stat_card( __( 'Active Riders', 'smart-documents-for-woocommerce' ), $rider_count );
		echo '</div>';
	}

	/**
	 * Callback for Dispatch::find_orders_by_order_meta() — true for any
	 * order that has a delivery status set at all.
	 *
	 * @param \WC_Order $order Order object.
	 * @return bool
	 */
	public function has_delivery_status( \WC_Order $order ) {
		return '' !== $order->get_meta( '_woosdd_delivery_status' );
	}

	/**
	 * One stat card.
	 *
	 * @param string $label Card label.
	 * @param int    $value Card value.
	 */
	private function stat_card( $label, $value ) {
		echo '<div class="card" style="min-width:150px;text-align:center;">';
		echo '<div style="font-size:28px;font-weight:600;line-height:1.2;">' . esc_html( $value ) . '</div>';
		echo '<div style="color:#6b7280;font-size:12px;text-transform:uppercase;letter-spacing:.03em;">' . esc_html( $label ) . '</div>';
		echo '</div>';
	}

	/**
	 * Count generated documents of a given type.
	 *
	 * @param string $type Document type slug.
	 * @return int
	 */
	private function count_documents( $type ) {
		$query = new \WP_Query(
			array(
				'post_type'      => Cpt::DOCUMENT,
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => '_type',
						'value' => $type,
					),
				),
			)
		);
		return (int) $query->found_posts;
	}

	/**
	 * Left column: the 5 most recently generated documents.
	 */
	private function render_recent_documents() {
		$documents = get_posts(
			array(
				'post_type'   => Cpt::DOCUMENT,
				'post_status' => 'any',
				'numberposts' => 5,
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		);

		echo '<div class="card" style="flex:1;min-width:320px;">';
		echo '<h2>' . esc_html__( 'Recent Documents', 'smart-documents-for-woocommerce' ) . '</h2>';

		if ( empty( $documents ) ) {
			echo '<p>' . esc_html__( 'No documents generated yet.', 'smart-documents-for-woocommerce' ) . '</p>';
		} else {
			echo '<table class="widefat striped">';
			foreach ( $documents as $document ) {
				$type     = get_post_meta( $document->ID, '_type', true );
				$order_id = (int) get_post_meta( $document->ID, '_order_id', true );
				$order    = $order_id ? wc_get_order( $order_id ) : false;
				echo '<tr>';
				echo '<td>' . esc_html( $document->post_title ) . '</td>';
				echo '<td>' . esc_html( Document_Data::type_label( $type ) ) . '</td>';
				echo '<td>' . ( $order ? '<a href="' . esc_url( $order->get_edit_order_url() ) . '">#' . esc_html( $order->get_order_number() ) . '</a>' : '&mdash;' ) . '</td>';
				echo '<td><a class="button button-small" target="_blank" rel="noopener noreferrer" href="' . esc_url( Downloader::admin_download_url( $document->ID ) ) . '">' . esc_html__( 'Download', 'smart-documents-for-woocommerce' ) . '</a></td>';
				echo '</tr>';
			}
			echo '</table>';
		}

		printf(
			'<p style="margin-top:12px;"><a class="button" href="%s">%s</a></p>',
			esc_url( admin_url( 'admin.php?page=woosdd-documents' ) ),
			esc_html__( 'View All Documents', 'smart-documents-for-woocommerce' )
		);
		echo '</div>';
	}

	/**
	 * Right column: the 5 most recent dispatch queue entries.
	 */
	private function render_recent_deliveries() {
		$orders   = Dispatch::find_orders_by_order_meta( '_woosdd_delivery_status', array( $this, 'has_delivery_status' ), 5 );
		$statuses = Dispatch::statuses();

		echo '<div class="card" style="flex:1;min-width:320px;">';
		echo '<h2>' . esc_html__( 'Recent Deliveries', 'smart-documents-for-woocommerce' ) . '</h2>';

		if ( 'yes' !== woosdd_get_setting( 'delivery_module_enabled', 'yes' ) ) {
			echo '<p>' . esc_html__( 'Delivery & Dispatch is currently disabled in Settings.', 'smart-documents-for-woocommerce' ) . '</p>';
		} elseif ( empty( $orders ) ) {
			echo '<p>' . esc_html__( 'No orders in the dispatch queue yet.', 'smart-documents-for-woocommerce' ) . '</p>';
		} else {
			echo '<table class="widefat striped">';
			foreach ( $orders as $order ) {
				$status = $order->get_meta( '_woosdd_delivery_status' );
				echo '<tr>';
				echo '<td><a href="' . esc_url( $order->get_edit_order_url() ) . '">#' . esc_html( $order->get_order_number() ) . '</a></td>';
				echo '<td>' . esc_html( trim( $order->get_formatted_billing_full_name() ) ) . '</td>';
				echo '<td>' . esc_html( isset( $statuses[ $status ] ) ? $statuses[ $status ] : $status ) . '</td>';
				echo '</tr>';
			}
			echo '</table>';
		}

		printf(
			'<p style="margin-top:12px;"><a class="button" href="%s">%s</a></p>',
			esc_url( admin_url( 'admin.php?page=woosdd-delivery' ) ),
			esc_html__( 'View Dispatch Queue', 'smart-documents-for-woocommerce' )
		);
		echo '</div>';
	}
}

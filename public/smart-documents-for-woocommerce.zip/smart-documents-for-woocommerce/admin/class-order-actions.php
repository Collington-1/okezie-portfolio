<?php
/**
 * Order-edit-screen "generate document" meta box and handler.
 *
 * @package Woosdd
 */

namespace Woosdd\Admin;

use Woosdd\Cpt;
use Woosdd\Documents\Downloader;
use Woosdd\Documents\Generator;

defined( 'ABSPATH' ) || exit;

/**
 * Adds a "Smart Documents" meta box to the WooCommerce order edit screen
 * (HPOS and legacy storage both use the same screen-ID helper, so this
 * works identically either way) with one Generate/Regenerate + Download
 * button per free document type, and handles the resulting admin-post.php
 * request.
 */
class Order_Actions {

	const ACTION = 'woosdd_generate_document';

	/**
	 * Register hooks.
	 */
	public function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle_generate' ) );
	}

	/**
	 * Register the meta box on the order edit screen (HPOS-aware).
	 */
	public function add_meta_box() {
		$screen = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';

		add_meta_box(
			'woosdd-order-documents',
			__( 'Smart Documents', 'smart-documents-for-woocommerce' ),
			array( $this, 'render_meta_box' ),
			$screen,
			'side',
			'default'
		);
	}

	/**
	 * Render the meta box body.
	 *
	 * @param \WP_Post|\WC_Order $post_or_order WP_Post on legacy storage, WC_Order under HPOS.
	 */
	public function render_meta_box( $post_or_order ) {
		$order = $post_or_order instanceof \WC_Order ? $post_or_order : wc_get_order( $post_or_order->ID );

		if ( ! $order ) {
			return;
		}

		echo '<ul class="woosdd-doc-actions" style="margin:0;">';
		foreach ( Generator::VALID_TYPES as $type ) {
			$this->render_type_row( $order, $type );
		}
		echo '</ul>';
	}

	/**
	 * One list row per document type: a Generate/Regenerate button, and a
	 * Download link once a document has actually been generated.
	 *
	 * @param \WC_Order $order Order object.
	 * @param string    $type  Document type slug.
	 */
	private function render_type_row( \WC_Order $order, $type ) {
		$document = $this->find_document( $order->get_id(), $type );
		$label    = \Woosdd\Documents\Document_Data::type_label( $type );

		$generate_url = wp_nonce_url(
			add_query_arg(
				array(
					'action'   => self::ACTION,
					'order_id' => $order->get_id(),
					'type'     => $type,
				),
				admin_url( 'admin-post.php' )
			),
			self::ACTION . '_' . $order->get_id() . '_' . $type
		);

		echo '<li style="margin-bottom:8px;">';
		echo '<strong>' . esc_html( $label ) . '</strong><br />';
		echo '<a href="' . esc_url( $generate_url ) . '" class="button button-small">';
		echo $document ? esc_html__( 'Regenerate', 'smart-documents-for-woocommerce' ) : esc_html__( 'Generate', 'smart-documents-for-woocommerce' );
		echo '</a>';

		if ( $document && 'generated' === get_post_meta( $document->ID, '_status', true ) ) {
			echo ' <a href="' . esc_url( Downloader::admin_download_url( $document->ID ) ) . '" class="button button-small" target="_blank" rel="noopener noreferrer">';
			esc_html_e( 'Download', 'smart-documents-for-woocommerce' );
			echo '</a>';
			echo '<br /><span style="color:#6b7280;font-size:11px;">' . esc_html( get_post_meta( $document->ID, '_number', true ) ) . '</span>';
		}

		echo '</li>';
	}

	/**
	 * Find an existing document post for this order + type, if any.
	 *
	 * @param int    $order_id Order ID.
	 * @param string $type     Document type slug.
	 * @return \WP_Post|null
	 */
	private function find_document( $order_id, $type ) {
		$found = get_posts(
			array(
				'post_type'   => Cpt::DOCUMENT,
				'post_status' => 'any',
				'numberposts' => 1,
				'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => '_order_id',
						'value' => $order_id,
					),
					array(
						'key'   => '_type',
						'value' => $type,
					),
				),
			)
		);
		return ! empty( $found ) ? $found[0] : null;
	}

	/**
	 * Admin-post.php handler for the Generate/Regenerate buttons.
	 */
	public function handle_generate() {
		$order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;
		$type     = isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : '';

		if ( ! $order_id || ! $type || ! current_user_can( woosdd_admin_capability() ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'smart-documents-for-woocommerce' ), 403 );
		}

		check_admin_referer( self::ACTION . '_' . $order_id . '_' . $type );

		$generator   = new Generator();
		$document_id = $generator->generate( $order_id, $type );

		$redirect = wp_get_referer() ? wp_get_referer() : admin_url( 'edit.php?post_type=shop_order' );

		if ( is_wp_error( $document_id ) ) {
			$redirect = add_query_arg( 'woosdd_error', rawurlencode( $document_id->get_error_message() ), $redirect );
		} else {
			$redirect = add_query_arg( 'woosdd_generated', $type, $redirect );
		}

		wp_safe_redirect( $redirect );
		exit;
	}
}

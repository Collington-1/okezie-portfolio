<?php
/**
 * Uninstall handler.
 *
 * WordPress only executes this file when the plugin is deleted from the
 * Plugins screen (never on simple deactivation), and only after confirming
 * WP_UNINSTALL_PLUGIN is defined — which is why that check comes first.
 *
 * This file NEVER deletes WooCommerce orders, unrelated uploads, or users.
 * By default it removes nothing at all: the merchant must have explicitly
 * opted in via Settings > "Remove plugin data on uninstall" (OFF by
 * default), which we check below before touching anything.
 *
 * @package Woosdd
 */

// WP_UNINSTALL_PLUGIN (not ABSPATH) is the correct, WordPress-documented
// direct-access guard for uninstall.php specifically — it's only ever
// defined when WordPress itself is running the uninstall routine after a
// "Delete" from the Plugins screen. The ABSPATH check alongside it is
// redundant in practice but silences generic direct-access scanners that
// only look for that specific pattern.
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
defined( 'ABSPATH' ) || exit;

$woosdd_remove_data = get_option( 'woosdd_remove_data_on_uninstall', 'no' );

if ( 'yes' !== $woosdd_remove_data ) {
	// Merchant did not opt in — leave every option, post and file in place
	// so re-installing the plugin restores exactly where they left off.
	return;
}

/**
 * From here on we only remove data that is positively identifiable as
 * plugin-owned: our own CPT posts (woosdd_document, woosdd_rider) and
 * their postmeta, our own options (the `woosdd_` prefix), our own order
 * meta keys (also `_woosdd_` prefixed — never the order itself), and our
 * own protected upload directory. WooCommerce orders, customers, other
 * plugins' data and unrelated uploads are never touched.
 */

global $wpdb;

// 1. Delete our custom post types and their postmeta.
// Note: intentionally not named $post_type/$post_id — WPCS flags those
// as prohibited overrides of WordPress global variable names, even at
// this top-level (non-function) script scope.
$woosdd_post_types = array( 'woosdd_document', 'woosdd_rider' );
foreach ( $woosdd_post_types as $woosdd_post_type ) {
	$woosdd_post_ids = get_posts(
		array(
			'post_type'   => $woosdd_post_type,
			'post_status' => 'any',
			'numberposts' => -1,
			'fields'      => 'ids',
		)
	);
	foreach ( $woosdd_post_ids as $woosdd_post_id ) {
		wp_delete_post( $woosdd_post_id, true );
	}
}

// 2. Delete our own order meta keys (never the orders themselves). Every
// meta key this plugin ever writes to an order is prefixed `_woosdd_`.
$woosdd_order_meta_keys = array(
	'_woosdd_delivery_status',
	'_woosdd_rider_id',
	'_woosdd_delivery_fee',
	'_woosdd_delivery_note',
	'_woosdd_dispatch_date',
	'_woosdd_tracking_token',
	'_woosdd_cod_expected',
	'_woosdd_cod_collected',
	'_woosdd_cod_remitted',
	'_woosdd_failed_delivery_reason',
	'_woosdd_failed_delivery_attempts',
);

// Uninstall runs once, outside any normal request lifecycle, so there is
// no object cache to warm and no repeat-query cost to worry about —
// direct queries here are the correct approach, not a shortcut.
if ( function_exists( 'wc_get_container' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
	// HPOS: order meta lives in wp_wc_orders_meta, not wp_postmeta.
	$woosdd_orders_meta_table = $wpdb->prefix . 'wc_orders_meta';
	foreach ( $woosdd_order_meta_keys as $woosdd_meta_key ) {
		$wpdb->delete( $woosdd_orders_meta_table, array( 'meta_key' => $woosdd_meta_key ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}
} else {
	// Legacy storage: order meta lives in wp_postmeta.
	foreach ( $woosdd_order_meta_keys as $woosdd_meta_key ) {
		$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => $woosdd_meta_key ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}
}

// 3. Delete our own options (anything starting with `woosdd_`).
$woosdd_option_names = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->prepare(
		"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
		$wpdb->esc_like( 'woosdd_' ) . '%'
	)
);
foreach ( $woosdd_option_names as $woosdd_option_name ) {
	delete_option( $woosdd_option_name );
}

// 4. Delete our protected upload directory (generated PDFs and proof of
// delivery files only — never the shared uploads directory itself).
$woosdd_upload_dir = wp_get_upload_dir();
$woosdd_target_dir = trailingslashit( $woosdd_upload_dir['basedir'] ) . 'woosdd-documents';

if ( is_dir( $woosdd_target_dir ) ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	WP_Filesystem();
	global $wp_filesystem;
	if ( $wp_filesystem ) {
		$wp_filesystem->rmdir( $woosdd_target_dir, true );
	}
}

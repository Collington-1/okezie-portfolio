<?php
/**
 * Plugin Name:       Smart Documents for WooCommerce – Invoices, Receipts & Delivery
 * Plugin URI:        https://okeziecollington.netlify.app/
 * Description:       Create professional WooCommerce invoices, receipts, packing slips and delivery notes, while managing dispatch, riders and delivery status from WordPress.
 * Version:           0.1.5
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            okezie
 * Author URI:        https://okeziecollington.netlify.app/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       smart-documents-for-woocommerce
 * Domain Path:       /languages
 * Requires Plugins:  woocommerce
 *
 * WC requires at least: 8.0
 * WC tested up to:       9.4
 *
 * @package Woosdd
 */

defined( 'ABSPATH' ) || exit;

// Core plugin constants. Every constant is namespaced so we never collide
// with another plugin's globals.
define( 'WOOSDD_VERSION', '0.1.5' );
define( 'WOOSDD_FILE', __FILE__ );
define( 'WOOSDD_PATH', plugin_dir_path( __FILE__ ) );
define( 'WOOSDD_URL', plugin_dir_url( __FILE__ ) );
define( 'WOOSDD_BASENAME', plugin_basename( __FILE__ ) );
define( 'WOOSDD_TEXT_DOMAIN', 'smart-documents-for-woocommerce' );

// Composer autoloader (Dompdf + our own PSR-4 classes under includes/, admin/, frontend/).
if ( file_exists( WOOSDD_PATH . 'vendor/autoload.php' ) ) {
	require_once WOOSDD_PATH . 'vendor/autoload.php';
}

// Procedural helpers aren't autoloadable (no class), so require directly.
require_once WOOSDD_PATH . 'includes/functions.php';

/**
 * Declare HPOS (High-Performance Order Storage) compatibility.
 *
 * Must run on `before_woocommerce_init`, before WooCommerce itself finishes
 * loading, per the WooCommerce FeaturesUtil recipe book.
 *
 * @see https://developer.woocommerce.com/docs/features/orders/high-performance-order-storage/recipe-book/
 */
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				WOOSDD_FILE,
				true
			);
			// Cart & Checkout Blocks: this plugin does not touch checkout/cart
			// rendering, so it is compatible by default; declare explicitly.
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'cart_checkout_blocks',
				WOOSDD_FILE,
				true
			);
		}
	}
);

/**
 * Bootstraps the plugin once we know WooCommerce is active and loaded.
 *
 * Everything WooCommerce-dependent (CPT registration, admin menu, order
 * hooks, delivery module, etc.) is wired from Woosdd\Plugin::instance(),
 * which is only constructed here — never at file-load time — so a missing
 * WooCommerce install never produces a fatal error, only an admin notice.
 */
function woosdd_bootstrap() {
	if ( ! woosdd_is_woocommerce_active() ) {
		add_action( 'admin_notices', 'woosdd_missing_woocommerce_notice' );
		return;
	}

	// No load_plugin_textdomain() call: WordPress.org has auto-loaded
	// translations for hosted plugins since WP 4.6, based on the plugin
	// slug matching its text domain. Calling it manually is discouraged
	// (and the `languages/` directory + .pot file are still what
	// translate.wordpress.org actually uses to generate those language
	// packs — nothing else changes).

	if ( class_exists( \Woosdd\Plugin::class ) ) {
		\Woosdd\Plugin::instance();
	}
}
add_action( 'plugins_loaded', 'woosdd_bootstrap', 20 );

/**
 * True when WooCommerce is active on this site (network or single).
 *
 * @return bool
 */
function woosdd_is_woocommerce_active() {
	return class_exists( 'WooCommerce' );
}

/**
 * Admin notice shown when WooCommerce is missing/inactive.
 */
function woosdd_missing_woocommerce_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	printf(
		'<div class="notice notice-error"><p>%s</p></div>',
		esc_html__( 'Smart Documents for WooCommerce requires WooCommerce to be installed and active.', 'smart-documents-for-woocommerce' )
	);
}

/**
 * Activation hook: create protected upload directory, flush rewrite rules
 * (My Account documents endpoint, tracking page endpoint). Never touches
 * WooCommerce order data.
 */
function woosdd_activate() {
	if ( class_exists( \Woosdd\Install::class ) ) {
		\Woosdd\Install::activate();
	}
}
register_activation_hook( WOOSDD_FILE, 'woosdd_activate' );

/**
 * Deactivation hook: flush rewrite rules only. Never deletes plugin data —
 * that only happens from uninstall.php, and only if the merchant opted in.
 */
function woosdd_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( WOOSDD_FILE, 'woosdd_deactivate' );

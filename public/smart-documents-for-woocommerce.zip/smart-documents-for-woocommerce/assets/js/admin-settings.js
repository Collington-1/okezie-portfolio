/**
 * Settings screen behaviors: Media Library logo picker + accent color picker.
 *
 * @package Woosdd
 */
( function ( $ ) {
	'use strict';

	$( function () {
		$( '.woosdd-color-field' ).wpColorPicker();

		var frame;

		$( '#woosdd-select-logo' ).on( 'click', function ( e ) {
			e.preventDefault();

			if ( frame ) {
				frame.open();
				return;
			}

			frame = wp.media( {
				title: woosddAdminSettings.mediaTitle,
				button: { text: woosddAdminSettings.mediaButton },
				library: { type: 'image' },
				multiple: false,
			} );

			frame.on( 'select', function () {
				var attachment = frame.state().get( 'selection' ).first().toJSON();
				var previewUrl = ( attachment.sizes && attachment.sizes.thumbnail ) ? attachment.sizes.thumbnail.url : attachment.url;
				$( '#logo_id' ).val( attachment.id );
				$( '#woosdd-logo-preview' ).html( '<img src="' + previewUrl + '" alt="" style="max-height:60px;" />' );
			} );

			frame.open();
		} );
	} );
} )( jQuery );
